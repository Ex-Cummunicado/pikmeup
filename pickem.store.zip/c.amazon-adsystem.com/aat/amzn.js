/* Use of this pixel is subject to the Amazon ad specs and policies at http://www.amazon.com/b/?&node=7253015011. Version number: 6, Changeset: Adding in phone number support for setUserData */ ! function() {
    "use strict";
    const e = 1e3,
        t = 86400 * e;
    var n = {
        NAME_MAX_LENGTH: 256,
        EVENT_PARAMETER_MAX_VALUE_LENGTH: 1e3,
        EVENT_NAME_EXCEEDED_MAX_LENGTH_WARNING: "Length of event's name is longer than 256 characters.",
        EVENT_PARAMETER_NAME_EXCEEDED_MAX_LENGTH_WARNING: "Length of event's parameter name exceeds 256 characters.",
        EVENT_PARAMETER_VALUE_EXCEEDED_MAX_LENGTH_WARNING: "Length of event's parameter value exceeds 1000 characters.",
        EVENT_PARAMETER_KEY_EXCEEDED_MAX_LENGTH_WARNING: "Length of event's parameter key exceeds 256 characters.",
        AMZN_TOKEN_COOKIE_NAME: "aatToken",
        AMZN_TOKEN_URL_QUERY_PARAM_NAME: "amznToken",
        NO_CONSENT_COOKIE_NAME: "AMZN-NoCookieConsent",
        MEASUREMENT_TOKEN_SOURCE_QUERY_PARAM_NAME: "arefsSource",
        MT_LP_QUERY_PARAM: "aref",
        MTS_EVENT_ATTRIBUTE: "arefs",
        MEASUREMENT_TOKEN_COOKIE_NAME: "amznAref",
        MEASUREMENT_TOKEN_EVENT_FIRE_URL_QUERY_PARAM_NAME: "arefs",
        MEASUREMENT_TOKEN_FETCH_COUNTRY_HEADER: "https://c.amazon-adsystem.com/aat/amzn.js",
        MS_IN_SEC: e,
        MS_IN_HOUR: 3600 * e,
        MS_IN_DAY: t,
        MEASUREMENT_TOKEN_TTL_IN_MS: 30 * t,
        NUM_MAX_MEASUREMENT_TOKENS: 147,
        MEASUREMENT_TOKEN_TIMESTAMP_PAIR_DELIMITER: "|",
        MEASUREMENT_TIMESTAMP_SEPARATOR: ".",
        MT_TS_PAIR_TS_INDEX: 1,
        NEWEST_MEASUREMENT_TOKEN_INDEX: 0,
        MEASUREMENT_TOKEN_FULLY_ENABLED_REGIONS: ["NA", "FE"],
        ARBITRARY_PAST_UNIX_TIMESTAMP: 1,
        AMAZON_CONSENT_AIPES_ENABLED: !1,
        AIPES_AMAZON_CONSENT_STRING_FIELD_NAME: "amazonConsentString",
        AIPES_AMAZON_CONSENT_GEO_FIELD_NAME: "geo",
        AIPES_AMAZON_CONSENT_CONSENT_FIELD_NAME: "consent",
        AIPES_AMAZON_CONSENT_AMAZON_CONSENT_FIELD_NAME: "amazonConsentFormat",
        AIPES_AMAZON_CONSENT_AD_STORAGE_FIELD_NAME: "amzn_ad_storage",
        AIPES_AMAZON_CONSENT_USER_DATA_FIELD_NAME: "amzn_user_data",
        AIPES_AMAZON_CONSENT_GPP_FIELD_NAME: "gpp",
        AIPES_AMAZON_CONSENT_TCF_FIELD_NAME: "tcf",
        AIPES_AMAZON_CONSENT_COUNTRY_CODE_FIELD_NAME: "countryCode",
        AIPES_AMAZON_CONSENT_IP_ADDRESS_FIELD_NAME: "ipAddress",
        REPORTING_ATTRIBUTES: ["brand", "category", "productid", "attr1", "attr2", "attr3", "attr4", "attr5", "attr6", "attr7", "attr8", "attr9", "attr10"],
        REPORTING_ATTRIBUTE_MAX_LENGTH: 256,
        REPORTING_ATTRIBUTE_NOT_ALLOWED_CHARACTERS_REGEX: /[^a-zA-Z0-9_]/,
        REPORTING_ATTRIBUTE_SPACE_REPLACEMENT_REGEX: /[^a-zA-Z0-9]+/g,
        REPORTING_ATTRIBUTE_MAX_LENGTH_WARNING: "Length of attribute must be between 1 and 256 characters.",
        REPORTING_ATTRIBUTE_PROHIBITED_CHARACTERS_WARNING: "Attribute may only contain letters, numbers, and the underscore character.",
        REPORTING_ATTRIBUTE_VALUE_NOT_STRING_WARNING: "Attribute must be a string and cannot be an object or array.",
        CHROME_EXTENSION_ID: "lfljgabnenicfhcbbfflijkeoebncchk",
        GDPR_VALUES: ["gdpr", "gdpr_pd", "gdpr_consent"],
        CONSENT_COOKIE_NAME: "amzn_consent",
        CONSENT_COOKIE_TTL_IN_MS: 24192e5
    };
    const o = n,
        r = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/i;
    const s = ["AD", "AL", "AT", "BA", "BE", "BG", "BY", "CH", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GB", "GR", "HR", "HU", "IE", "IS", "IT", "LI", "LT", "LU", "LV", "MC", "MD", "ME", "MK", "MT", "NL", "NO", "PL", "PT", "RO", "RS", "RU", "SE", "SI", "SK", "SM", "UA", "UK", "VA"];

    function a(e) {
        return !(!e || "string" != typeof e) && s.includes(e.toUpperCase())
    }
    var i = {
        isEmpty: function(e) {
            return null == e || "" === e || 0 === Object.keys(e).length || 0 === e.length
        },
        isValidAdTag: function(e) {
            return e && r.test(e)
        },
        measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie: function(e) {
            return e.map((e => e.join(o.MEASUREMENT_TIMESTAMP_SEPARATOR))).join(o.MEASUREMENT_TOKEN_TIMESTAMP_PAIR_DELIMITER)
        },
        measurementTokenCookieToMeasurementTokenTimestampPairsNestedArr: function(e) {
            return e ? e.split(o.MEASUREMENT_TOKEN_TIMESTAMP_PAIR_DELIMITER).map((e => {
                const [t, n] = e.split(o.MEASUREMENT_TIMESTAMP_SEPARATOR);
                return [t, Number(n)]
            })) : []
        },
        getMeasurementTokenTimestamp: function() {
            return window.performance && window.performance.timeOrigin ? Math.ceil(window.performance.timeOrigin) : Date.now()
        },
        isEUCountry: a,
        getRegionFromCountryCode: function(e, t = "NA") {
            return a(e) ? "EU" : t
        }
    };
    const E = n;

    function c() {}
    c.prototype.isCookiePresent = function(e) {
        return document.cookie.split(";").some((t => t.trim().startsWith(`${e}=`))) && !c.prototype.isCookieMarkedForDeletion(e)
    }, c.prototype.isCookieMarkedForDeletion = function(e) {
        return "0" === c.prototype.getCookieValue(e)
    }, c.prototype.getCookieValue = function(e) {
        return document.cookie.split(";").find((t => t.trim().startsWith(`${e}=`))) ? .split("=")[1]
    }, c.prototype.writeCookie = function(e, t, n) {
        const o = new Date(n).toUTCString();
        document.cookie = `${e}=${t}; expires=${o}; SameSite=Strict; secure=true;`
    }, c.prototype.deleteCookie = function(e) {
        c.prototype.writeCookie(e, "0", E.ARBITRARY_PAST_UNIX_TIMESTAMP)
    };
    var _ = c;
    const A = n,
        d = _,
        T = i;

    function u(e, t, n) {
        e.searchParams.set(t, n);
        const o = Array.from(e.searchParams.entries());
        e.search = "", o.forEach((n => {
            n[0] !== t && e.searchParams.set(n[0], n[1])
        })), e.search += `&${t}=${n}`
    }

    function N(e, t, n) {
        const o = !t || "" === t.trim(),
            r = new URLSearchParams(window.location.search).get(A.MT_LP_QUERY_PARAM),
            s = new d;
        if (n || "EU" === t || o) return function(e, t) {
            if (!t) return;
            const n = T.getMeasurementTokenTimestamp(),
                o = T.measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie([
                    [t, n]
                ]);
            e.searchParams.set(A.MEASUREMENT_TOKEN_SOURCE_QUERY_PARAM_NAME, "url"), e.searchParams.set(A.MEASUREMENT_TOKEN_EVENT_FIRE_URL_QUERY_PARAM_NAME, o)
        }(e, r), null;
        A.MEASUREMENT_TOKEN_FULLY_ENABLED_REGIONS.includes(t) && function(e, t, n) {
            let o, r = n.getCookieValue(A.MEASUREMENT_TOKEN_COOKIE_NAME);
            if (t) {
                const e = [t, T.getMeasurementTokenTimestamp()];
                if (r) {
                    const n = T.measurementTokenCookieToMeasurementTokenTimestampPairsNestedArr(r),
                        s = n.some((([e]) => e === t)) ? [e, ...n.filter((([e]) => e !== t))] : [e, ...n];
                    r = T.measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie(s), o = "cookie"
                } else r = T.measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie([e]), o = "cookie"
            } else r && (o = "cookie");
            r = function(e) {
                if (!e) return;
                const t = T.getMeasurementTokenTimestamp() - A.MEASUREMENT_TOKEN_TTL_IN_MS,
                    n = T.measurementTokenCookieToMeasurementTokenTimestampPairsNestedArr(e).filter((([, e]) => e > t));
                return n.length > 0 ? T.measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie(n) : void 0
            }(r), r && o && (e.searchParams.set(A.MEASUREMENT_TOKEN_SOURCE_QUERY_PARAM_NAME, o), e.searchParams.set(A.MEASUREMENT_TOKEN_EVENT_FIRE_URL_QUERY_PARAM_NAME, r))
        }(e, r, s)
    }
    var l = {
        createQueryParams: function(e, {
            tagId: t,
            eventName: n,
            eventAttributes: o,
            consent: r,
            uuid: s,
            amazonConsent: a,
            region: i,
            countryCode: E
        }) {
            const c = "string" == typeof e ? new URL(e) : e;
            if (T.isEmpty(t)) throw new Error("Tag ID is a required parameter.");
            if (!T.isValidAdTag(t)) throw new Error("Invalid ad tag provided.");
            if (c.searchParams.set("pid", t), T.isEmpty(n)) throw new Error("Event name is a required parameter.");
            c.searchParams.set("event", n), Array.isArray(o) && u(c, "items", encodeURI(JSON.stringify(o))), o && Object.entries(o).forEach((([e, t]) => {
                A.GDPR_VALUES.includes(e) || (t || "" === t) && ("object" == typeof t ? c.searchParams.set(e, JSON.stringify(t)) : c.searchParams.set(e, String(t)))
            })), r && A.GDPR_VALUES.forEach((e => {
                r[e] && c.searchParams.set(e, r[e])
            }));
            let _ = "EU" === i || "UK" === i,
                l = null;
            a && (l = JSON.stringify(a), c.searchParams.set("consentString", l), "{}" !== l && '"null"' !== l && "undefined" !== l && (_ = !0));
            const m = new d;
            if (m.isCookiePresent(A.AMZN_TOKEN_COOKIE_NAME)) {
                const e = m.getCookieValue(A.AMZN_TOKEN_COOKIE_NAME);
                e && u(c, A.AMZN_TOKEN_URL_QUERY_PARAM_NAME, e)
            }
            return N(c, i, _ ? l : null), c.searchParams.set("eventSource", "amzn.js"), s && c.searchParams.set("uuid", s), E && c.searchParams.set("countryCode", E), c
        }
    };
    const {
        createQueryParams: m
    } = l, h = {
        "Google Chrome": 106,
        Chromium: 106
    }, p = "paa-reporting-advertising.amazon";

    function g(e) {
        const t = "/assets/conversion_module.js";
        switch (e.toLowerCase()) {
            case "beta":
            case "test":
                return `https://beta-ara.${p}${t}`;
            case "gamma":
                return `https://gamma-ara.${p}${t}`;
            default:
                return `https://ara.${p}${t}`
        }
    }

    function f() {
        const {
            userAgentData: e
        } = navigator;
        return null != e && function(e) {
            return e.some((({
                brand: e,
                version: t
            }) => h[e] <= t))
        }(e.brands)
    }
    async function M(e, t) {
        try {
            const n = g(t);
            if (e && n) {
                const t = await e.json();
                return t && 0 !== Object.keys(t).length && "healthy" !== t ? (await (sharedStorage ? .createWorklet(n, {
                    dataOrigin: "script-origin"
                }))).run("conversion-module", {
                    data: t,
                    privateAggregationConfig: {
                        contextId: t ? .debugKey
                    }
                }) : Promise.resolve(!1)
            }
        } catch {}
        return Promise.resolve(!1)
    }
    var R = {
        performTriggerRegistration: async function(e) {
            const {
                stage: t
            } = e;
            if (!f() || !(document ? .featurePolicy ? .allowsFeature ? .("attribution-reporting") && document ? .featurePolicy ? .allowsFeature ? .("private-aggregation") && document ? .featurePolicy ? .allowsFeature ? .("shared-storage"))) return Promise.resolve(!1);
            const n = function(e) {
                    let t;
                    switch (e.toLowerCase()) {
                        case "beta":
                        case "test":
                            t = `https://beta-ara.${p}/aat`;
                            break;
                        case "gamma":
                            t = `https://gamma-ara.${p}/aat`;
                            break;
                        default:
                            t = `https://ara.${p}/aat`
                    }
                    return new URL(t)
                }(t),
                o = m(n, e),
                r = await async function(e) {
                    const t = {
                        credentials: "same-origin",
                        keepalive: !0,
                        attributionReporting: {
                            eventSourceEligible: !1,
                            triggerEligible: !0
                        }
                    };
                    let n;
                    try {
                        n = await (window ? .fetch(e, t))
                    } catch {}
                    return n
                }(o.href);
            return M(r, t), r
        },
        generateUUID: function() {
            return typeof crypto < "u" && "function" == typeof crypto.randomUUID ? crypto.randomUUID() : ""
        },
        generateWorkletUrl: g,
        runSharedStorageWorklet: M
    };
    const C = n;

    function O(e, t, n) {
        e.length > C.NAME_MAX_LENGTH && t.push(`${n}, ${e}`)
    }
    var S = {
        validateLength: O,
        validateEventAttributesAsArray: function(e, t) {
            e.forEach((function(e) {
                O(Object.keys(e)[0], t, C.EVENT_PARAMETER_NAME_EXCEEDED_MAX_LENGTH_WARNING), O(e[Object.keys(e)[0]], t, C.EVENT_PARAMETER_VALUE_EXCEEDED_MAX_LENGTH_WARNING)
            }))
        },
        filterGdprValuesOut: function(e) {
            return !C.GDPR_VALUES.includes(e)
        },
        validateCustomAttributesForReporting: function(e, t) {
            let n;
            const o = t[e];
            let r = o;
            const s = e.toLowerCase();
            return C.REPORTING_ATTRIBUTES.includes(s) && (n = {}, n[s] = {
                messages: []
            }, (o.length > C.REPORTING_ATTRIBUTE_MAX_LENGTH || o.length < 1) && n[s].messages.push(C.REPORTING_ATTRIBUTE_MAX_LENGTH_WARNING), "string" == typeof o ? (r = r.trim(), r = o.replaceAll(C.REPORTING_ATTRIBUTE_SPACE_REPLACEMENT_REGEX, "_").trim(), C.REPORTING_ATTRIBUTE_NOT_ALLOWED_CHARACTERS_REGEX.test(r) && n[s].messages.push(C.REPORTING_ATTRIBUTE_PROHIBITED_CHARACTERS_WARNING)) : n[s].messages.push(C.REPORTING_ATTRIBUTE_VALUE_NOT_STRING_WARNING), 0 === n[s].messages.length ? n = void 0 : (n[s].value = r, r = void 0)), {
                eventReportingAttributeWarnings: n,
                newAttributeValue: r
            }
        },
        validateAttributeValueAsObject: function(e, t) {
            if ("object" == typeof e && Object.keys(e) && Object.keys(e)[0]) return Object.keys(e).forEach((function(n) {
                n.length > C.NAME_MAX_LENGTH && t.push(`${C.EVENT_PARAMETER_KEY_EXCEEDED_MAX_LENGTH_WARNING}, ${n}`), e[n].length > C.EVENT_PARAMETER_MAX_VALUE_LENGTH && t.push(`${C.EVENT_PARAMETER_VALUE_EXCEEDED_MAX_LENGTH_WARNING}, ${e[n]}`)
            })), encodeURI(JSON.stringify(e))
        },
        validateAttributeValueAsString: function(e, t) {
            "string" == typeof e && e.length > C.EVENT_PARAMETER_MAX_VALUE_LENGTH && t.push(`${C.EVENT_PARAMETER_VALUE_EXCEEDED_MAX_LENGTH_WARNING}, ${e}`)
        }
    };
    const y = n,
        {
            isEmpty: I,
            isValidAdTag: k
        } = i,
        {
            createQueryParams: P
        } = l,
        {
            generateUUID: v
        } = R,
        {
            validateLength: U,
            validateEventAttributesAsArray: w,
            filterGdprValuesOut: L,
            validateCustomAttributesForReporting: D,
            validateAttributeValueAsString: b,
            validateAttributeValueAsObject: G
        } = S;

    function H(e, t) {
        this.endpoints = e, this.region = "NA", this.stage = "PROD", this.countryCode = null, this.tagIdsByLabels = {}, this.TCFv2 = {}, this.consentHandler = t
    }

    function K(e, t, n) {
        const o = document.createElement("iframe");
        o.style.display = "none", o.setAttribute("src", e), o.setAttribute("id", `tag_fire_${t}_${n}_${Date.now()}`), document.body.appendChild(o)
    }
    H.prototype.addTag = function({
        tagId: e,
        tagLabel: t
    }) {
        if (I(e)) return void console.warn("Tag id is required for addTag command");
        if (!k(e)) return void console.warn(`Invalid tag id provided: ${e}`);
        const n = I(t) ? e : t;
        this.tagIdsByLabels[n] = e
    }, H.prototype.getTagIds = function(e) {
        const {
            tagIdsByLabels: t
        } = this;
        return e.map((function(e) {
            return t[e] || e
        }))
    }, H.prototype.trackEvent = async function(e, t, n) {
        return this.trackEventWithTags(e, t, n, Object.keys(this.tagIdsByLabels))
    }, H.prototype.trackRequest = async function(e, t, n, o) {
        const r = v();
        let s = { ...this.TCFv2[e]
        };
        const a = this.consentHandler.getTcfString();
        this.consentHandler.isConsentSet() && a && (void 0 === s.gdpr_consent || "" === s.gdpr_consent) && (s = {
            gdpr: 1,
            gdpr_pd: 1,
            gdpr_consent: a
        });
        try {
            await async function({
                eventIngestionEndpoint: e,
                consent: t,
                eventAttributes: n,
                eventName: o,
                tagId: r,
                uuid: s,
                consentHandler: a,
                region: i,
                countryCode: E
            }) {
                const c = [],
                    _ = {},
                    A = JSON.parse(JSON.stringify(n));
                if (U(o, c, y.EVENT_NAME_EXCEEDED_MAX_LENGTH_WARNING), Array.isArray(n) ? w(n, c) : n && Object.keys(n).filter(L).forEach((function(e) {
                        let t;
                        U(e, c, y.EVENT_PARAMETER_NAME_EXCEEDED_MAX_LENGTH_WARNING), t = n[e];
                        const {
                            newAttributeValue: o,
                            eventReportingAttributeWarnings: r
                        } = D(e, A);
                        if (r && (_[e] = r[e.toLowerCase()]), o ? A[e] = o : void 0 === o && delete A[e], t) {
                            b(t, c);
                            const e = G(t, c);
                            e && (t = e)
                        } else console.warn(`Key ${e} has no value`)
                    })), c.length > 0) {
                    const e = `Event has ${c.length} validation errors.`;
                    return console.warn(e), console.warn(c), Promise.reject(e)
                }
                const d = P(new URL(e), {
                    tagId: r,
                    eventName: o,
                    eventAttributes: A,
                    consent: t,
                    uuid: s,
                    region: i,
                    amazonConsent: a.getFormattedAmazonConsent(!1),
                    countryCode: E || void 0
                }).href;
                if (Object.keys(_).length > 0 && void 0 !== window.chrome && void 0 !== window.chrome.runtime) try {
                    window.chrome.runtime.sendMessage(y.CHROME_EXTENSION_ID, {
                        adTagEventWarnings: !0,
                        eventUrl: d,
                        attributeWarnings: _
                    })
                } catch {}
                if (!window.fetch || typeof window.fetch > "u") return K(d, r, o);
                try {
                    const e = await fetch(d, {
                        method: "get",
                        credentials: "include",
                        mode: "no-cors",
                        keepalive: !0
                    });
                    return Promise.resolve(e)
                } catch {
                    return console.warn("Event request via fetch failed, reverting to iframe"), K(d, r, o)
                }
            }({
                eventIngestionEndpoint: t,
                consent: s,
                eventAttributes: o,
                eventName: n,
                tagId: e,
                uuid: r,
                consentHandler: this.consentHandler,
                region: this.region,
                countryCode: this.countryCode
            })
        } catch (e) {
            return console.warn("Event request failed.", e), Promise.reject(e)
        }
        try {
            const {
                performTriggerRegistration: t
            } = R;
            await t({
                stage: this.stage,
                consent: s,
                tagId: e,
                eventName: n,
                eventAttributes: o,
                uuid: r,
                region: this.region
            })
        } catch (e) {
            console.warn("ARA trigger registration failed", e)
        }
        return Promise.resolve()
    }, H.prototype.trackEventWithTags = async function(e, t, n, o) {
        const r = this.getPixelEndpoint(this.region),
            s = t || {},
            a = "No eventName name specified.",
            i = "No valid endpoint.";
        if (!e) return console.warn(a), Promise.reject(a);
        if (!r) return console.warn(i), Promise.reject(i);
        n && (s.ts = n);
        const E = this.getTagIds(o).map((t => this.trackRequest(t, r, e, s)));
        return Promise.all(E)
    }, H.prototype.trackPixel = function(e, t, n) {
        let o;
        const r = {};
        let s = t || "";
        s = s.split("?"), o = s.length > 1 ? s[1] : s[0], o = o.split("&"), o.forEach((e => {
            const t = e.split("=");
            let n, o;
            t.length <= 1 || ("ex-fargs" === t[0] ? (n = this.parsePixelArgs(t[1], "&"), r.fargs_id = n.id, r.fargs_type = n.type) : "ex-hargs" === t[0] && (o = this.parsePixelArgs(t[1], ";"), r.hargs_c = o.c, r.hargs_p = o.p))
        })), this.validatePixelData(r), Object.keys(r).forEach((function(e) {
            r[e] || delete r[e]
        })), this.trackEvent(e, r, n)
    }, H.prototype.addTCFv2 = function(e) {
        this.addTCFv2WithTags(e, Object.keys(this.tagIdsByLabels))
    }, H.prototype.addTCFv2WithTags = function(e, t) {
        const {
            TCFv2: n
        } = this;
        this.getTagIds(t).forEach((function(t) {
            n[t] = e
        }))
    }, H.prototype.getPixelEndpoint = function(e) {
        const t = this.endpoints[e.toUpperCase()];
        return "" === t || null == t ? (console.warn("Endpoint does not exist, please check your region configuration!"), null) : t
    }, H.prototype.parsePixelArgs = function(e, t) {
        let n = decodeURIComponent(e);
        const o = {};
        return n = n.replace(/\?/g, ""), n.split(t).forEach((function(e) {
            const t = e.split("=");
            if (t.length > 1) {
                const [e, n] = t;
                o[e] = n
            }
        })), o
    }, H.prototype.validatePixelData = function(e) {
        const t = e.hargs_c && e.hargs_p,
            n = e.fargs_id && e.fargs_type;
        !t && !n && console.warn("Invalid arguments for a trackPixel event, please check your implementation!")
    }, H.prototype.setRegion = function(e) {
        this.region = e
    }, H.prototype.setStage = function(e) {
        this.stage = e
    }, H.prototype.setCountryCode = function(e) {
        e && "string" == typeof e ? (this.countryCode = e.toUpperCase(), console.log(`[AAT] Country code set to: ${this.countryCode}`)) : console.warn("Invalid country code provided")
    }, H.prototype.getCountryCode = function() {
        return this.countryCode
    };
    var z = H;
    const F = n,
        {
            measurementTokenTimestampPairsNestedArrToMeasurementTokenCookie: V,
            measurementTokenCookieToMeasurementTokenTimestampPairsNestedArr: X,
            getMeasurementTokenTimestamp: Z
        } = i,
        B = "AIPToken",
        j = "cookieExpiry",
        x = {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "omit",
            headers: {
                "Content-Type": "application/json"
            },
            redirect: "follow",
            referrerPolicy: "no-referrer-when-downgrade"
        };

    function W(e) {
        this.cookieHandler = e, this.alreadySavedMeasurementToken = !1, window.addEventListener("load", (() => {
            this.alreadySavedMeasurementToken = !1
        }))
    }
    W.prototype.saveMeasurementTokenInURLToCookieIfPresent = function(e, t) {
        try {
            if (t || -1 === F.MEASUREMENT_TOKEN_FULLY_ENABLED_REGIONS.indexOf(e) || this.alreadySavedMeasurementToken) return;
            const n = new URLSearchParams(window.location.search).get(F.MT_LP_QUERY_PARAM);
            if (!n) return;
            let o = this.cookieHandler.getCookieValue(F.MEASUREMENT_TOKEN_COOKIE_NAME);
            o && o ? .split(F.MEASUREMENT_TOKEN_TIMESTAMP_PAIR_DELIMITER).length >= F.NUM_MAX_MEASUREMENT_TOKENS && (o = V(X(o).slice(0, -1)));
            const r = performance && performance.timeOrigin ? Math.ceil(performance.timeOrigin) : Date.now(),
                s = X(o || ""),
                a = V([
                    [n, r]
                ].concat(s)),
                i = r + F.MEASUREMENT_TOKEN_TTL_IN_MS;
            this.cookieHandler.writeCookie(F.MEASUREMENT_TOKEN_COOKIE_NAME, a, i), this.alreadySavedMeasurementToken = !0
        } catch (e) {
            console.error("[AAT] Error saving measurement token from URL to cookie:", e)
        }
    }, W.prototype.removeAnyExpiredMeasurementTokens = function() {
        try {
            const e = this.cookieHandler.getCookieValue(F.MEASUREMENT_TOKEN_COOKIE_NAME);
            if (!e) return;
            const t = Z() - F.MEASUREMENT_TOKEN_TTL_IN_MS,
                n = X(e).filter((([, e]) => e > t));
            if (0 === n.length) return this.cookieHandler.deleteCookie(F.MEASUREMENT_TOKEN_COOKIE_NAME), void(this.alreadySavedMeasurementToken = !1);
            const o = V(n),
                r = n[F.NEWEST_MEASUREMENT_TOKEN_INDEX][F.MT_TS_PAIR_TS_INDEX] + F.MEASUREMENT_TOKEN_TTL_IN_MS;
            this.cookieHandler.writeCookie(F.MEASUREMENT_TOKEN_COOKIE_NAME, o, r)
        } catch {}
    }, W.prototype.formatRequestBody = function(e) {
        const t = {};
        if (null !== e.gdpr && (t.gdpr = e.gdpr.enabled ? 1 : 0, null !== e.gdpr.consent && (t.gdprConsent = e.gdpr.consent)), null === e.hashedRecords) throw Error("hashedRecords array is null");
        if (0 === e.hashedRecords.length) throw Error("hashedRecords array is empty");
        return t.hashedRecords = e.hashedRecords, null !== e.ttl && (t.ttl = e.ttl), void 0 !== e.consentString && (t[F.AIPES_AMAZON_CONSENT_STRING_FIELD_NAME] = e.consentString), t
    }, W.prototype.requestAmznToken = async function(e) {
        const t = { ...x,
                body: JSON.stringify(e)
            },
            n = await fetch("https://tk.amazon-adsystem.com/envelope", t);
        if (n.ok) return await n.json();
        const o = await n.text();
        throw Error(o)
    }, W.prototype.renewAmznToken = async function(e) {
        if (!this.cookieHandler.isCookiePresent(F.AMZN_TOKEN_COOKIE_NAME) && !this.cookieHandler.isCookiePresent(F.NO_CONSENT_COOKIE_NAME)) try {
            const t = this.formatRequestBody(e),
                n = await this.requestAmznToken(t);
            return "" === n[B] ? this.cookieHandler.writeCookie(F.NO_CONSENT_COOKIE_NAME, n[B], n[j]) : this.cookieHandler.writeCookie(F.AMZN_TOKEN_COOKIE_NAME, n[B], n[j]), n
        } catch (e) {
            console.error(e)
        }
        return "no-op"
    }, W.prototype.deleteAmznToken = async function() {
        this.cookieHandler.isCookiePresent(F.AMZN_TOKEN_COOKIE_NAME) && this.cookieHandler.deleteCookie(F.AMZN_TOKEN_COOKIE_NAME), this.cookieHandler.isCookiePresent(F.NO_CONSENT_COOKIE_NAME) && this.cookieHandler.deleteCookie(F.NO_CONSENT_COOKIE_NAME)
    }, W.prototype.updateAmznToken = async function(e) {
        return await this.deleteAmznToken(), this.renewAmznToken(e)
    };
    var $ = W;

    function Y(e, t) {
        this.tokensHandler = e, this.consentHandler = t
    }
    async function Q(e) {
        const t = (new TextEncoder).encode(e),
            n = await crypto.subtle.digest("SHA-256", t);
        return Array.from(new Uint8Array(n)).map((e => e.toString(16).padStart(2, "0"))).join("")
    }

    function q(e) {
        return null != e && "string" == typeof e && e.length > 0
    }
    Y.prototype.setUserData = async function(e) {
        const t = {
                gdpr: {
                    enabled: !1,
                    consent: ""
                },
                hashedRecords: [],
                ttl: 9600
            },
            n = e[1];
        n.gdpr && (t.gdpr = n.gdpr), n.ttl && (t.ttl = n.ttl);
        const o = /[A-Fa-f0-9]{64}/;
        if (q(n.email)) {
            const e = {
                type: "email",
                record: ""
            };
            n.email = n.email.trim().toLowerCase(), o.test(n.email) ? e.record = n.email : e.record = await Q(n.email), t.hashedRecords.push(e)
        }
        if (q(n.phonenumber)) {
            const e = {
                type: "phonenumber",
                record: ""
            };
            o.test(n.phonenumber) ? e.record = n.phonenumber : e.record = await Q(function(e) {
                let t = e.replace(/[^\d+]+/g, "");
                return t = t.replace(/^00/, "+"), t.match(/^1/) && (t = `+${t}`), t.match(/^\+/) || (t = `+1${t}`), t = t.replace(/^\+/, ""), t
            }(n.phonenumber)), t.hashedRecords.push(e)
        }
        if (this.consentHandler.isConsentSet() && this.consentHandler.isAipesEgressEnabled()) {
            t.consentString = this.consentHandler.getFormattedAmazonConsent(!1);
            const e = this.consentHandler.getTcfString();
            void 0 !== e && "" !== e && "" === t.gdpr.consent && (t.gdpr.enabled = !0, t.gdpr.consent = e)
        }
        return t.hashedRecords.length > 0 ? this.tokensHandler.updateAmznToken(t) : Promise.resolve()
    };
    var J = Y;
    const {
        isEUCountry: ee
    } = i, te = n;

    function ne(e, t, n, o, r) {
        this.eventTracker = e, this.setUserDataHandler = t, this.tokensHandler = n, this.aatEventsQueue = [], this.isSetUserDataInProcess = !1, this.consentHandler = r
    }
    ne.prototype.processCommandQueue = async function(e) {
        return Promise.all((e || []).map((e => this.processCommand(e[0], e[1]))))
    }, ne.prototype.processCommand = async function(e, t = Date.now()) {
        const n = Array.prototype.slice.call(e),
            o = e[0],
            r = `Unsupported tag command "${o}"`,
            s = {
                trackevent: (e, t) => this.trackEvent(e, t),
                trackpixel: (e, t) => this.trackPixel(e, t),
                pixel: (e, t) => this.withTag(e, t),
                withtag: (e, t) => this.withTag(e, t),
                addpixel: e => this.addTag(e),
                addtag: e => this.addTag(e),
                addtcfv2: e => this.addTCFv2(e),
                setregion: e => this.setRegion(e),
                setstage: e => this.setStage(e),
                setuserdata: e => this.setUserData(e)
            },
            a = o.toLowerCase();
        return s[a] ? s[a](n, t) : (console.warn(r), Promise.reject(r))
    }, ne.prototype.setUserData = async function(e) {
        this.isSetUserDataInProcess = !0;
        try {
            await this.setUserDataHandler.setUserData(e), this.isSetUserDataInProcess = !1, this.processAatEventsQueue()
        } catch (e) {
            return console.warn(e), Promise.reject(e)
        }
        return Promise.resolve()
    }, ne.prototype.processAatEventsQueue = function() {
        if (this.aatEventsQueue.length)
            for (; this.aatEventsQueue.length;) {
                const {
                    argumentArray: e,
                    timestamp: t,
                    tagLabel: n
                } = this.aatEventsQueue.pop();
                this.trackEvent(e, t, n).catch((e => {
                    console.warn(e)
                }))
            }
    }, ne.prototype.trackEvent = async function(e, t, n) {
        if (this.isSetUserDataInProcess) return this.aatEventsQueue.unshift({
            argumentArray: e,
            timestamp: t,
            tagLabel: n
        }), Promise.resolve();
        this.tokensHandler.removeAnyExpiredMeasurementTokens();
        const o = e[1],
            r = e[2];
        return void 0 !== n ? this.eventTracker.trackEventWithTags(o, r, t, [n]) : this.eventTracker.trackEvent(o, r, t)
    }, ne.prototype.trackPixel = function(e, t) {
        this.eventTracker.trackPixel("__pixel__", e[1], t)
    }, ne.prototype.withTag = async function(e, t) {
        const n = e[1],
            o = e[2] || "",
            r = `Unsupported command "${o}" used after "withTag" command`;
        switch (o.toUpperCase()) {
            case "TRACKEVENT":
                return this.trackEvent(e.slice(2), t, n);
            case "ADDTCFV2":
                this.addTCFv2(e.slice(2), n);
                break;
            default:
                return console.warn(r), Promise.reject(r)
        }
        return Promise.resolve()
    }, ne.prototype.addTag = function(e) {
        const t = e[2],
            n = e[1];
        this.eventTracker.addTag({
            tagId: n,
            tagLabel: t
        })
    }, ne.prototype.addTCFv2 = function(e, t) {
        const n = e[1];
        void 0 !== t ? this.eventTracker.addTCFv2WithTags(n, [t]) : this.eventTracker.addTCFv2(n)
    }, ne.prototype.setRegion = async function(e) {
        const t = e[1].toUpperCase();
        let n = null;
        try {
            n = (await fetch(te.MEASUREMENT_TOKEN_FETCH_COUNTRY_HEADER, {
                method: "get",
                mode: "cors",
                keepalive: !0
            })).headers.get("x-viewer-country"), console.log("[AAT] Country code from headers:", n)
        } catch (e) {
            console.warn("[AAT] Error fetching country code from headers:", e)
        }
        let o = null,
            r = !1;
        try {
            if (this.consentHandler && this.consentHandler.isConsentSet()) {
                r = !0;
                const e = this.consentHandler.getFormattedAmazonConsent(!1);
                e && e.geo && e.geo.countryCode && (o = e.geo.countryCode)
            }
        } catch (e) {
            console.warn("[AAT] Error checking Amazon consent or getting country code:", e)
        }
        let s = t;
        n && ee(n) && (s = "EU"), o && ee(o) && (s = "EU");
        try {
            this.eventTracker.setRegion(s)
        } catch (e) {
            console.warn("[AAT] Error setting region in event tracker:", e)
        }
        try {
            this.tokensHandler.saveMeasurementTokenInURLToCookieIfPresent(s, r)
        } catch (e) {
            console.warn("Error saving measurement token in URL to cookie:", e)
        }
    }, ne.prototype.setStage = function(e) {
        const t = e[1].toUpperCase();
        this.eventTracker.setStage(t)
    }, ne.prototype.listen = function() {
        this.eventListener.init()
    }, ne.prototype.setAmazonConsent = function(e) {
        this.consentHandler.setAmazonConsent(e[1])
    };
    var oe = ne;
    const re = n;

    function se(e) {
        this.amazonConsent = void 0, this.cookieHandler = e
    }
    se.prototype.init = function() {
        try {
            const e = this.cookieHandler.getCookieValue(re.CONSENT_COOKIE_NAME);
            if (e) {
                const t = JSON.parse(decodeURIComponent(e));
                this.setAmazonConsent({ ...t,
                    AMAZON_CONSENT_AIPES_ENABLED: !0
                })
            }
        } catch (e) {
            console.warn("Error reading consent cookie:", e)
        }
        window.addEventListener("amznConsentChange", (e => {
            this.setAmazonConsent({ ...e ? .detail ? .consent,
                AMAZON_CONSENT_AIPES_ENABLED : !0
            })
        }))
    }, se.prototype.setAmazonConsent = function(e) {
        this.amazonConsent = e
    }, se.prototype.isConsentSet = function() {
        return void 0 !== this.amazonConsent
    }, se.prototype.isAipesEgressEnabled = function() {
        return this.amazonConsent.AMAZON_CONSENT_AIPES_ENABLED
    }, se.prototype.getFormattedAmazonConsent = function(e) {
        if (void 0 === this.amazonConsent) return;
        const t = {},
            n = {};
        return void 0 !== this.amazonConsent.geo && (t[re.AIPES_AMAZON_CONSENT_GEO_FIELD_NAME] = function(e) {
            const t = {};
            return void 0 !== e.countryCode && (t[re.AIPES_AMAZON_CONSENT_COUNTRY_CODE_FIELD_NAME] = e.countryCode), void 0 !== e.ipAddress && (t[re.AIPES_AMAZON_CONSENT_IP_ADDRESS_FIELD_NAME] = e.ipAddress), t
        }(this.amazonConsent.geo)), void 0 !== this.amazonConsent.amazonConsentFormat && (n[re.AIPES_AMAZON_CONSENT_AMAZON_CONSENT_FIELD_NAME] = function(e) {
            const t = {};
            return void 0 !== e.amznAdStorage && (t[re.AIPES_AMAZON_CONSENT_AD_STORAGE_FIELD_NAME] = e.amznAdStorage), void 0 !== e.amznUserData && (t[re.AIPES_AMAZON_CONSENT_USER_DATA_FIELD_NAME] = e.amznUserData), t
        }(this.amazonConsent.amazonConsentFormat)), void 0 !== this.amazonConsent.gpp && (n[re.AIPES_AMAZON_CONSENT_GPP_FIELD_NAME] = this.amazonConsent.gpp), e && void 0 !== this.amazonConsent.tcf && (n[re.AIPES_AMAZON_CONSENT_TCF_FIELD_NAME] = this.amazonConsent.tcf), t[re.AIPES_AMAZON_CONSENT_CONSENT_FIELD_NAME] = n, t
    }, se.prototype.getTcfString = function() {
        if (void 0 !== this.amazonConsent) return this.amazonConsent.tcf
    };
    const ae = {
            NA: "https://s.amazon-adsystem.com/iu3",
            EU: "https://aax-eu.amazon-adsystem.com/s/iu3",
            FE: "https://aax-fe.amazon-adsystem.com/s/iu3"
        },
        ie = z,
        Ee = _,
        ce = $,
        _e = J,
        Ae = oe,
        de = se,
        Te = i,
        {
            MEASUREMENT_TOKEN_FETCH_COUNTRY_HEADER: ue
        } = n;
    !async function() {
        const e = new Ee,
            t = new de(e);
        t.init();
        const n = new ie(ae, t),
            o = new ce(e),
            r = new _e(o, t);
        let s = new Ae(n, r, o, void 0, t);
        if (void 0 !== window.__tcfapi) {
            const e = (e, n) => {
                n && "tcloaded" === e.eventStatus && t.setAmazonConsent({
                    tcf: e.tcString
                })
            };
            window.__tcfapi("addEventListener", 2, e)
        }
        if (void 0 !== window.__gpp) {
            const e = () => {
                const e = window.__gpp("getGPPString");
                void 0 !== e && t.setAmazonConsent({
                    gpp: e
                })
            };
            window.__gpp("addEventListener", e, "tcfeuv2")
        }
        o.removeAnyExpiredMeasurementTokens();
        try {
            const e = (await fetch(ue, {
                method: "get",
                mode: "cors",
                keepalive: !0
            })).headers.get("x-viewer-country");
            console.log("[AAT] Country code from x-viewer-country header (init):", e), e && (n.setCountryCode(e), Te.isEUCountry(e) && (n.setRegion("EU"), console.log("[AAT] Setting region to EU based on country code")))
        } catch (e) {
            console.warn("Error fetching country code from headers:", e)
        }
        window.amzn && window.amzn.q && s.processCommandQueue(window.amzn.q).catch((e => {
            console.error("Error processing event queue", e)
        })), window.amzn = async function(...e) {
            return s.processCommand(e).catch((e => {
                console.error("Error processing command", e)
            }))
        }, window.renewToken = async function(e) {
            return o.renewAmznToken(e)
        }, window.updateToken = async function(e) {
            return o.updateAmznToken(e)
        }, window.deleteToken = async function() {
            return o.deleteAmznToken()
        }
    }()
}();