(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [7327], {
        14837: function(e, t, n) {
            "use strict";
            var a = n(84599);
            n(56816);
            const r = "kl-post-identification-sync",
                s = JSON.stringify([]),
                i = () => {
                    try {
                        if ("undefined" != typeof localStorage && null !== localStorage) return localStorage
                    } catch (e) {}
                    return null
                },
                o = (e, t) => {
                    (async e => {
                        const t = i();
                        if (!t) return;
                        const n = t.getItem(r),
                            a = null === n ? [] : JSON.parse(n);
                        a.push(e), a.length > 1e4 && a.shift(), t.setItem(r, JSON.stringify(a))
                    })(e).finally((() => {
                        t && t()
                    }))
                },
                l = (e = 1e3) => (async e => {
                    const t = i();
                    if (!t) return {
                        events: [],
                        deleteCallback: async () => {}
                    };
                    const n = JSON.parse(t.getItem(r) || s),
                        a = n.slice(0, e),
                        o = n.slice(e);
                    return {
                        events: a || [],
                        deleteCallback: async () => {
                            t.setItem(r, JSON.stringify(o))
                        }
                    }
                })(e),
                c = () => (() => {
                    const e = i();
                    e && e.removeItem(r)
                })(),
                u = (e, t) => {
                    var n;
                    const a = (new Date).toISOString(),
                        r = {
                            name: e.event,
                            time: (null == (n = e.properties) ? void 0 : n.time) || a,
                            properties: e.properties || {}
                        };
                    o(r, t)
                };
            var p = n(5645),
                d = n.n(p),
                m = (n(92461), n(44159), n(60873), n(51627)),
                f = n(93641),
                y = n(28262),
                h = n(1242);
            n(70917), n(93677), n(84304), n(75723), n(20696), n(38528), n(72418);
            const v = new Set(["$exchange_id", "email", "id", "$email", "$id", "$anonymous", "$phone_number"]),
                b = ["name", "properties"];
            let g = !1;
            const _ = (e, t, n, a, r) => {
                    const s = ((e, t, n, a) => ({
                        data: {
                            type: "event-bulk-create",
                            attributes: {
                                profile: {
                                    data: {
                                        type: "profile",
                                        attributes: Object.assign({}, t)
                                    }
                                },
                                events: {
                                    data: e.map((e => {
                                        const {
                                            name: t,
                                            properties: a
                                        } = e, r = d()(e, b), s = Object.assign({}, a, n || {}), i = s.service;
                                        delete s.service;
                                        const o = "klaviyo" === i ? {
                                            name: t,
                                            service: i
                                        } : {
                                            name: t
                                        };
                                        return {
                                            type: "event",
                                            attributes: Object.assign({
                                                metric: {
                                                    data: {
                                                        type: "metric",
                                                        attributes: o
                                                    }
                                                }
                                            }, r, {
                                                properties: s
                                            })
                                        }
                                    }))
                                }
                            },
                            relationships: a
                        }
                    }))(e, n, a, r);
                    return (0, f.W)((() => ((e, t) => fetch(`https://a.klaviyo.com/client/event-bulk-create/?company_id=${e}`, {
                        method: "POST",
                        headers: Object.assign({
                            "Access-Control-Allow-Headers": "*",
                            "Content-Type": "application/json"
                        }, (0, m.h)(), {
                            revision: "2025-01-15"
                        }),
                        body: JSON.stringify(t)
                    }))(t, s)), 5, 1e3 + 1e3 * Math.random(), [429])
                },
                k = {
                    $exchange_id: "_kx",
                    email: "email",
                    $email: "email",
                    $phone_number: "phone_number",
                    phone_number: "phone_number",
                    $id: "external_id",
                    id: "id",
                    $kid: "id",
                    $anonymous: "anonymous_id"
                },
                w = e => {
                    let t = {};
                    return Object.keys(k).forEach((n => {
                        if (a = n, !Set.prototype.has.call(v, a)) return;
                        var a;
                        const r = e[n];
                        if (!r) return;
                        const s = ("$email" === n || "email" === n) && !(0, y.v)(r),
                            i = "$phone_number" === n && !(0, h.y)(r);
                        s || i || (t = Object.assign({}, t, {
                            [k[n]]: r
                        }))
                    })), t
                },
                O = async (e, t, n, a, r) => {
                    if (0 === e.events.length) return;
                    const s = await _(e.events, t, n, a, r);
                    if (429 === s.status && console.warn(`KL: Saving event cache due to rate limit. Status: ${s.status}`), s.status >= 500) throw new Error(`Saving event cache due to failed request. Status: ${s.status}`);
                    await (null == e || null == e.deleteCallback ? void 0 : e.deleteCallback());
                    const i = await l();
                    return O(i, t, n, a, r)
                },
                S = async (e, t, n, a, r) => {
                    const s = e || window.__klKey;
                    if (!s || g) return;
                    const i = w(t);
                    if (i && 0 !== Object.keys(i).length) {
                        g = !0;
                        try {
                            const e = await l();
                            await O(e, s, i, n, r), c(), null == a || a()
                        } catch (e) {
                            if (e instanceof Error) throw e;
                            throw new Error("Failed to send bulk events")
                        } finally {
                            g = !1
                        }
                    }
                };
            (() => {
                (0, a.e)("cacheEvent", u), (0, a.e)("sendCachedEvents", S)
            })()
        },
        5645: function(e) {
            e.exports = function(e, t) {
                if (null == e) return {};
                var n = {};
                for (var a in e)
                    if ({}.hasOwnProperty.call(e, a)) {
                        if (-1 !== t.indexOf(a)) continue;
                        n[a] = e[a]
                    }
                return n
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        }
    },
    function(e) {
        e.O(0, [2462], (function() {
            return t = 14837, e(e.s = t);
            var t
        }));
        e.O()
    }
]);