! function() {
    function t(t, e) {
        var o = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(t);
            e && (n = n.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), o.push.apply(o, n)
        }
        return o
    }

    function e(t, e, o) {
        return (e = function(t) {
            var e = function(t, e) {
                if ("object" != typeof t || null === t) return t;
                var o = t[Symbol.toPrimitive];
                if (void 0 !== o) {
                    var n = o.call(t, "string");
                    if ("object" != typeof n) return n;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return String(t)
            }(t);
            return "symbol" == typeof e ? e : String(e)
        }(e)) in t ? Object.defineProperty(t, e, {
            value: o,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = o, t
    }
    window.baMet = function() {
        var o = function(t, e, o, n) {
                var r = "",
                    i = "";
                if (o) {
                    var a = new Date;
                    a.setTime(a.getTime() + 60 * o * 1e3), r = "; expires=" + a.toGMTString()
                }
                n && (i = "; domain=" + n), document.cookie = t + "=" + escape(e) + r + i + "; path=/"
            },
            n = {
                urlPrefix: "",
                visitsUrl: window.Rivo.global_config.proxy_paths.app_metrics,
                baEvsUrl: window.Rivo.global_config.proxy_paths.app_metrics,
                page: null,
                useBeacon: !1,
                startOnReady: !0,
                applyVisits: !0,
                cookies: !0,
                cookieDomain: null,
                headers: {},
                visitParams: {},
                withCredentials: !1,
                pv: window.Rivo.global_config.pv,
                bam: window.Rivo.global_config.bam,
                batc: window.Rivo.global_config.batc
            },
            r = window.baMet || {};
        r.configure = function(t) {
            for (var e in t) t.hasOwnProperty(e) && (n[e] = t[e])
        }, r.configure(r);
        var i = 30,
            a = !1,
            s = [],
            c = "undefined" != typeof JSON && void 0 !== JSON.stringify,
            u = [];

        function l() {
            return n.urlPrefix + n.baEvsUrl
        }

        function d() {
            for (var t; t = s.shift();) t();
            a = !0
        }

        function g(t) {
            a ? t() : s.push(t)
        }
        r.setCookie = function(t, e, r) {
            o(t, e, r, n.cookieDomain || n.domain)
        }, r.getCookie = function(t) {
            return function(t) {
                var e, o, n = t + "=",
                    r = document.cookie.split(";");
                for (e = 0; e < r.length; e++) {
                    for (o = r[e];
                        " " === o.charAt(0);) o = o.substring(1, o.length);
                    if (0 === o.indexOf(n)) return unescape(o.substring(n.length, o.length))
                }
                return null
            }(t)
        }, r.destroyCookie = function(t) {
            o(t, "", -1)
        }, r.log = function(t) {
            r.getCookie("baMet_debug") && window.console.log(t)
        };
        const m = ["a", "div"];

        function f(t, e) {
            if (!t || !t.tagName) return !1;
            let o = t;
            var n = o.matches || o.matchesSelector || o.mozMatchesSelector || o.msMatchesSelector || o.oMatchesSelector || o.webkitMatchesSelector;
            if (n) {
                if (n.apply(o, [e])) return o;
                if (!m.includes(o.tagName ? .toLowerCase())) {
                    for (; !m.includes(o.tagName.toLowerCase());) o = o.parentElement;
                    return f(o, [e])
                }
                return !1
            }
            return r.log("Unable to match"), !1
        }

        function v(t, e) {
            var o = [];
            for (O = 0; O < e.items.length; O++) {
                var n = e.items[O];
                o.push({
                    id: n.id,
                    properties: n.properties,
                    quantity: n.quantity,
                    variant_id: n.variant_id,
                    product_id: n.product_id,
                    final_price: n.final_price,
                    image: n.image,
                    handle: n.handle,
                    title: n.title
                })
            }
            return {
                token: t,
                total_price: e.total_price,
                items: o,
                currency: e.currency
            }
        }

        function p() {
            return "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, (function(t) {
                var e = 16 * Math.random() | 0;
                return ("x" == t ? e : 3 & e | 8).toString(16)
            })) + Math.floor(Date.now()).toString()
        }

        function h() {
            n.cookies && c && r.setCookie("baMet_baEvs", JSON.stringify(u), 1)
        }

        function b(o) {
            var n = o;
            return n.common = function(o) {
                for (var n = 1; n < arguments.length; n++) {
                    var r = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? t(Object(r), !0).forEach((function(t) {
                        e(o, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(o, Object.getOwnPropertyDescriptors(r)) : t(Object(r)).forEach((function(t) {
                        Object.defineProperty(o, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return o
            }({}, window.Rivo.common), delete n.common.product, delete n.common.translations, n.api = {}, n
        }

        function w(t) {
            g((function() {
                r.sendRequest(l(), b(t), (function() {
                    for (var e = 0; e < u.length; e++)
                        if (u[e].id == t.id) {
                            u.splice(e, 1);
                            break
                        }
                    h()
                }))
            }))
        }

        function _(t) {
            var e, o;
            (n.useBeacon || n.applyNow) && (o = n.headers, 0 === Object.keys(o).length) && c && void 0 !== window.navigator.sendBeacon && !n.withCredentials ? (e = t, g((function() {
                var t, o = b(e),
                    n = (t = document.querySelector("meta[name=csrf-param]")) && t.content,
                    r = function() {
                        var t = document.querySelector("meta[name=csrf-token]");
                        return t && t.content
                    }();
                n && r && (o[n] = r), window.navigator.sendBeacon(l(), JSON.stringify(o))
            }))) : (u.push(t), h(), setTimeout((function() {
                w(t)
            }), 1e3))
        }

        function y() {
            return window.location.pathname
        }

        function C(t) {
            return t && t.length > 0 ? t : null
        }

        function k(t) {
            var e = t.target;
            return function(t) {
                for (var e in t) t.hasOwnProperty(e) && null === t[e] && delete t[e];
                return t
            }({
                tag: e.tagName.toLowerCase(),
                id: C(e.id),
                class: C(e.className),
                page: y()
            })
        }

        function x() {
            var t, e = new Date,
                o = e.toISOString().slice(0, 10),
                a = r.getBrowserInfo(),
                s = r.getVisitId() || (t = p(), r.setCookie("baMet_visit", t, i), t),
                c = {
                    shop_id: window.Rivo.common.shop.id,
                    name: "create_visit",
                    params: {
                        landing_page: window.location.href,
                        screen_width: window.screen.width,
                        screen_height: window.screen.height,
                        browser: a.browser,
                        os: a.os,
                        timezone: a.timezone,
                        is_bot: /bot|googlebot|crawler|spider|robot|crawling/i.test(navigator.userAgent)
                    },
                    timestamp: parseInt(e.getTime()),
                    date: o,
                    hour: e.getUTCHours(),
                    id: p(),
                    visit_token: s,
                    visitor_token: r.getVisitorId(),
                    app: "ba"
                };
            for (var u in document.referrer.length > 0 && (c.referrer = document.referrer), n.visitParams) n.visitParams.hasOwnProperty(u) && (c[u] = n.visitParams[u]);
            r.log(c), n.bam || _(c)
        }

        function S() {
            var t = function() {
                    var t = r.getVisitId(),
                        e = r.getVisitorId() && !t;
                    r.log("current visit_token"), r.log(t);
                    var o = new Date,
                        n = new Date;
                    n.setUTCHours(23, 59, 59, 59);
                    var a = (n - o) / 1e3,
                        s = a / 60;
                    return (s > i || a < 2) && (s = i), !t || a < 2 ? (t = p(), r.setCookie("baMet_visit", t, s), e && x()) : r.setCookie("baMet_visit", t, s), t
                }(),
                e = r.getVisitorId();
            !1 === n.cookies || !1 === n.applyVisits ? (r.log("Visit applying disabled"), d()) : t && e ? (r.log("Active visit"), d()) : r.getCookie("baMet_visit") ? (r.log("Visit started"), e || (e = p(), localStorage.setItem("baMet_visitor", e)), x(), d()) : (r.log("baCookies disabled"), d())
        }
        r.onBaEv = function(t, e, o) {
            document.addEventListener(t, (function(t) {
                const n = f(t.target, e);
                n && o({
                    target: n
                })
            }))
        }, r.sendRequest = function(t, e, o) {
            (r.fetch || fetch)(t, {
                method: "POST",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(e)
            }).then((function(t) {
                console.log(t), o(t)
            })).catch((function(t) {
                console.log(t)
            }))
        }, r.getCartData = function(t) {
            (r.fetch || fetch)("/cart.js?ba_request=1", {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                }
            }).then((function(e) {
                200 === e.status ? e.json().then((function(e) {
                    t(e)
                })) : console.log("Looks like there was a problem. Status Code: " + e.status)
            })).catch((function(t) {
                console.log(t)
            }))
        }, r.syncCsId = function() {
            var t = r.getCookie("baMet_cs_id");
            return t || (t = p()), r.setCookie("baMet_cs_id", t, 20160), t
        }, r.getVisitId = r.getVisitToken = function() {
            return r.getCookie("baMet_visit")
        }, r.getVisitorId = r.getVisitorToken = function() {
            return localStorage.getItem("baMet_visitor")
        }, r.getCustomerId = function() {
            return localStorage.getItem("baMet_customer_id")
        }, r.isAdmin = function() {
            return r.getCookie("ba_admin")
        }, r.reset = function() {
            return r.destroyCookie("baMet_visit"), localStorage.removeItem("baMet_visitor"), r.destroyCookie("baMet_baEvs"), r.destroyCookie("baMet_apply"), !0
        }, r.debug = function(t) {
            return !1 === t ? r.destroyCookie("baMet_debug") : r.setCookie("baMet_debug", "t", 525600), !0
        }, r.getBrowserInfo = function() {
            var t = {
                options: [],
                header: [navigator.platform, navigator.userAgent, navigator.appVersion, navigator.vendor, window.opera],
                dataos: [{
                    name: "Windows Phone",
                    value: "Windows Phone",
                    version: "OS"
                }, {
                    name: "Windows",
                    value: "Win",
                    version: "NT"
                }, {
                    name: "iPhone",
                    value: "iPhone",
                    version: "OS"
                }, {
                    name: "iPad",
                    value: "iPad",
                    version: "OS"
                }, {
                    name: "Android",
                    value: "Android",
                    version: "Android"
                }, {
                    name: "Mac OS",
                    value: "Mac",
                    version: "OS X"
                }, {
                    name: "Linux",
                    value: "Linux",
                    version: "rv"
                }, {
                    name: "Palm",
                    value: "Palm",
                    version: "PalmOS"
                }],
                databrowser: [{
                    name: "Chrome",
                    value: "Chrome",
                    version: "Chrome"
                }, {
                    name: "Firefox",
                    value: "Firefox",
                    version: "Firefox"
                }, {
                    name: "Safari",
                    value: "Safari",
                    version: "Version"
                }, {
                    name: "Internet Explorer",
                    value: "MSIE",
                    version: "MSIE"
                }, {
                    name: "Opera",
                    value: "Opera",
                    version: "Opera"
                }, {
                    name: "BlackBerry",
                    value: "CLDC",
                    version: "CLDC"
                }, {
                    name: "Mozilla",
                    value: "Mozilla",
                    version: "Mozilla"
                }],
                init: function() {
                    var t = this.header.join(" "),
                        e = this.matchItem(t, this.dataos),
                        o = this.matchItem(t, this.databrowser),
                        n = (new Date).getTimezoneOffset() / 60;
                    return timezone = Intl.DateTimeFormat().resolvedOptions().timeZone, {
                        os: e,
                        browser: o,
                        tz_offset: n,
                        timezone: timezone
                    }
                },
                matchItem: function(t, e) {
                    var o, n, r = 0,
                        i = 0;
                    for (r = 0; r < e.length; r += 1)
                        if (new RegExp(e[r].value, "i").test(t)) {
                            if (o = new RegExp(e[r].version + "[- /:;]([\\d._]+)", "i"), "", (n = t.match(o)) && n[1] && (n = n[1]), n)
                                for (n = n.split(/[._]+/), i = 0; i < n.length; i += 1) 0 === i ? n[i] + "." : n[i];
                            else "0";
                            return e[r].name
                        }
                    return "Unknown"
                }
            };
            return t.init()
        }, r.register = function(t, e, o) {
            try {
                var i = new Date,
                    a = i.toISOString().slice(0, 10),
                    s = {
                        shop_id: window.Rivo.common.shop.id,
                        name: t,
                        params: e || {},
                        timestamp: parseInt(i.getTime()),
                        date: a,
                        hour: i.getUTCHours(),
                        id: p(),
                        app: o
                    };
                g((function() {
                    n.cookies && !r.getVisitId() && S(), g((function() {
                        r.log(s), s.visit_token = r.getVisitId(), s.visitor_token = r.getVisitorId(), _(s)
                    }))
                }))
            } catch (t) {
                r.log(t), r.log("error applying")
            }
            return !0
        }, r.registerAppClicks = function() {
            r.onBaEv("click", ".ba-met-handler", (function(t) {
                try {
                    var e = t.target,
                        o = e.getAttribute("data-ba-met-name");
                    if (o) {
                        var n = k(t),
                            i = e.getAttribute("data-ba-met-app");
                        if (n.text = "input" == n.tag ? e.value : (e.textContent || e.innerText || e.innerHTML).replace(/[\s\r\n]+/g, " ").trim(), n.href = e.href, a = e.getAttribute("data-ba-met-extras")) {
                            var a = cleanNumbers(JSON.parse(a));
                            for (var s in a) a.hasOwnProperty(s) && (n[s] = a[s])
                        }
                        r.register(o, n, i)
                    }
                } catch (t) {
                    r.log("applyAppClicks exception"), r.log(t)
                }
            }))
        }, r.registerAtc = function() {
            r.onBaEv("click", ".product-form__cart-submit, #AddToCart-product-template, .product-atc-btn, .product-menu-button.product-menu-button-atc, .button-cart, .product-add, .add-to-cart input, .btn-addtocart, [name=add]", (function(t) {
                Date.now();
                var e = t.target,
                    o = k(t);
                o.text = "input" == o.tag ? e.value : (e.textContent || e.innerText || e.innerHTML).replace(/[\s\r\n]+/g, " ").trim(), o.href = e.href, r.register("atc", o, "ba")
            }))
        }, r.updateBaCart = function(t) {
            r.log("checking if cart is out of sync with db");
            var e = r.getCookie("cart"),
                o = r.getCookie("ba_cart_token"),
                i = localStorage.getItem("baMet_latest_cart"),
                a = localStorage.getItem("baMsg_synced_cart");
            0 != (t || i != a || e != o) ? (r.setCookie("ba_cart_token", e, 2880), n.bam || r.register("update_cart_db", {}, "ba"), localStorage.setItem("baMsg_synced_cart", i), r.log("cart token changed -posting to the API from here")) : r.log("cart is in sync with db")
        }, r.setCartAttributes = function(t, e) {
            try {
                if (r.log("setting cart attributes"), "string" == typeof e) var o = JSON.parse(e);
                else o = e;
                var n = r.getCookie("cart"),
                    i = localStorage.getItem("baMet_latest_cart");
                if (!n && !i) return;
                if (t) {
                    r.log("set cart attributes identified ajax cart update"), r.log(o);
                    var a = v(n, o);
                    window.Rivo.common.cart = a
                } else f = n, window.Rivo.common.cart = v(f, window.Rivo.common.cart), a = window.Rivo.common.cart;
                localStorage.setItem("baMet_latest_cart", JSON.stringify(a));
                var s = a.items,
                    c = r.getBaCartData();
                if (c.length > 0) {
                    var u = {
                        visit_token: r.getVisitId(),
                        visitor_token: r.getVisitorToken(),
                        items: [],
                        cart_token: n
                    };
                    for (O = 0; O < s.length; O++) {
                        var l = s[O];
                        if (l) {
                            var d = c.find((function(t) {
                                return t.id == l.id
                            }));
                            d && (l.ba_conversion_data = d, u.items.push(d), window.Rivo.common.has_ba_conversion = !0)
                        }
                    }
                    var g = JSON.stringify(u)
                }
                var m = localStorage.getItem("ba_conversion_data");
                window.Rivo.common.ba_conversion_data = u, m != g || window.Rivo.common.ba_conversion_data && "cart" == window.Rivo.common.template ? (r.log("saving ba_conversion_data"), localStorage.setItem("ba_conversion_data", g), r.updateBaCart(!0)) : r.updateBaCart(!1)
            } catch (t) {
                r.log("setCartAttributes exception"), r.log(t)
            }
            var f
        }, r.registerAll = function() {
            document.referrer.indexOf("/admin/shops/") > 0 && r.setCookie("ba_admin", 1, 1051200), r.setCartAttributes(!1, {}), r.registerAppClicks()
        };
        try {
            u = JSON.parse(r.getCookie("baMet_baEvs") || "[]")
        } catch (t) {}
        for (var O = 0; O < u.length; O++) w(u[O]);
        var M;
        return n.batc || (function() {
            r.log("awaiting ajax cart update");
            try {
                var t = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function() {
                    this.addEventListener("load", (function() {
                        var t;
                        this._url && this._url.search(/cart.*js/) >= 0 && "GET" != this._method && (r.log("its a cart endpoint thats not a get request"), (t = this)._url.indexOf("/cart/add") >= 0 ? r.getCartData((function(t) {
                            r.log(t), r.setCartAttributes(!0, t)
                        })) : r.setCartAttributes(!0, t.response))
                    })), t.apply(this, arguments)
                }
            } catch (t) {
                r.log(t), r.log("error catching ajax cart")
            }
        }(), function() {
            r.log("awaiting cart fetch update");
            try {
                let t = fetch;
                r.fetch = function(e, o) {
                    let n = !1;
                    e && "function" == typeof e.search && e.search(/cart.*js|cart\/add|cart\/change/) >= 0 && e.search("ba_request") < 0 && o && ("POST" == o.method || "PUT" == o.method) && (r.log("caught a fetch cart event", e, o), n = !0);
                    let i = t(e, o);
                    return i.then((function(t) {
                        n && r.getCartData((function(t) {
                            r.setCartAttributes(!0, t)
                        }))
                    })), i
                }
            } catch (t) {
                r.log(t), r.log("error catching cart fetch")
            }
        }()), r.start = function() {
            var t;
            n.bam && r.log("SESSIONS ARE RATE LIMITED - THE APP WILL NOT WORK UNTIL 00:00 UTC"), S(), r.start = function() {}, n.page_views && (t = r.page_hash, r.register("page_view", t, "ba")), window.Rivo.common.customer && !r.getCustomerId() && (r.register("sync_customer", {}, "ba"), localStorage.setItem("baMet_customer_id", window.Rivo.common.customer.id))
        }, M = function() {
            n.startOnReady && r.start()
        }, "interactive" === document.readyState || "complete" === document.readyState ? M() : document.addEventListener("DOMContentLoaded", M), r.page_hash = {
            url: window.location.href,
            page: y(),
            template: window.Rivo.common.template
        }, r.registerAll(), r
    }()
}();
//# sourceMappingURL=https://d15d3imw3mjndz.cloudfront.net/assets/storefront/ba_tracking.js-6cbdea333379476a2155ff8ddb924f4b9e1fc7302cf27ca484c03c884bb2d7a5.map
//!
;