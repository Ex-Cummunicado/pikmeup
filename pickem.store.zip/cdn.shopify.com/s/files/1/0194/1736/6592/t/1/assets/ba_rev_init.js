! function() {
    "use strict";

    function e(e) {
        return function(e) {
            if (Array.isArray(e)) return t(e)
        }(e) || function(e) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e)
        }(e) || function(e, r) {
            if (e) {
                if ("string" == typeof e) return t(e, r);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? t(e, r) : void 0
            }
        }(e) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function t(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var r, n, o, i, a, s = (r = ["a[href]", "area[href]", 'input:not([disabled]):not([type="hidden"]):not([aria-hidden])', "select:not([disabled]):not([aria-hidden])", "textarea:not([disabled]):not([aria-hidden])", "button:not([disabled]):not([aria-hidden])", "iframe", "object", "embed", "[contenteditable]", '[tabindex]:not([tabindex^="-"])'], n = function() {
        function t(r) {
            var n = r.targetModal,
                o = r.triggers,
                i = void 0 === o ? [] : o,
                a = r.onShow,
                s = void 0 === a ? function() {} : a,
                l = r.onClose,
                c = void 0 === l ? function() {} : l,
                d = r.openTrigger,
                u = void 0 === d ? "data-micromodal-trigger" : d,
                f = r.closeTrigger,
                p = void 0 === f ? "data-micromodal-close" : f,
                h = r.openClass,
                v = void 0 === h ? "is-open" : h,
                g = r.disableScroll,
                m = void 0 !== g && g,
                y = r.disableFocus,
                w = void 0 !== y && y,
                b = r.awaitCloseAnimation,
                _ = void 0 !== b && b,
                O = r.awaitOpenAnimation,
                E = void 0 !== O && O,
                k = r.debugMode,
                x = void 0 !== k && k;
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, t), this.modal = document.getElementById(n), this.config = {
                debugMode: x,
                disableScroll: m,
                openTrigger: u,
                closeTrigger: p,
                openClass: v,
                onShow: s,
                onClose: c,
                awaitCloseAnimation: _,
                awaitOpenAnimation: E,
                disableFocus: w
            }, i.length > 0 && this.registerTriggers.apply(this, e(i)), this.onClick = this.onClick.bind(this), this.onKeydown = this.onKeydown.bind(this)
        }
        var n;
        return (n = [{
            key: "registerTriggers",
            value: function() {
                for (var e = this, t = arguments.length, r = new Array(t), n = 0; n < t; n++) r[n] = arguments[n];
                r.filter(Boolean).forEach((function(t) {
                    t.addEventListener("click", (function(t) {
                        return e.showModal(t)
                    }))
                }))
            }
        }, {
            key: "showModal",
            value: function() {
                var e = this,
                    t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
                this.activeElement = document.activeElement, this.modal.setAttribute("aria-hidden", "false"), this.modal.classList.add(this.config.openClass), this.scrollBehaviour("disable"), this.addEventListeners(), this.config.awaitOpenAnimation ? this.modal.addEventListener("animationend", (function t() {
                    e.modal.removeEventListener("animationend", t, !1), e.setFocusToFirstNode()
                }), !1) : this.setFocusToFirstNode(), this.config.onShow(this.modal, this.activeElement, t)
            }
        }, {
            key: "closeModal",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                    t = this.modal;
                if (this.modal.setAttribute("aria-hidden", "true"), this.removeEventListeners(), this.scrollBehaviour("enable"), this.activeElement && this.activeElement.focus && this.activeElement.focus(), this.config.onClose(this.modal, this.activeElement, e), this.config.awaitCloseAnimation) {
                    var r = this.config.openClass;
                    this.modal.addEventListener("animationend", (function e() {
                        t.classList.remove(r), t.removeEventListener("animationend", e, !1)
                    }), !1)
                } else t.classList.remove(this.config.openClass)
            }
        }, {
            key: "closeModalById",
            value: function(e) {
                this.modal = document.getElementById(e), this.modal && this.closeModal()
            }
        }, {
            key: "scrollBehaviour",
            value: function(e) {
                if (this.config.disableScroll) {
                    var t = document.querySelector("body");
                    switch (e) {
                        case "enable":
                            Object.assign(t.style, {
                                overflow: ""
                            });
                            break;
                        case "disable":
                            Object.assign(t.style, {
                                overflow: "hidden"
                            })
                    }
                }
            }
        }, {
            key: "addEventListeners",
            value: function() {
                this.modal.addEventListener("touchstart", this.onClick), this.modal.addEventListener("click", this.onClick), document.addEventListener("keydown", this.onKeydown)
            }
        }, {
            key: "removeEventListeners",
            value: function() {
                this.modal.removeEventListener("touchstart", this.onClick), this.modal.removeEventListener("click", this.onClick), document.removeEventListener("keydown", this.onKeydown)
            }
        }, {
            key: "onClick",
            value: function(e) {
                (e.target.hasAttribute(this.config.closeTrigger) || e.target.parentNode.hasAttribute(this.config.closeTrigger)) && (e.preventDefault(), e.stopPropagation(), this.closeModal(e))
            }
        }, {
            key: "onKeydown",
            value: function(e) {
                27 === e.keyCode && this.closeModal(e), 9 === e.keyCode && this.retainFocus(e)
            }
        }, {
            key: "getFocusableNodes",
            value: function() {
                var t = this.modal.querySelectorAll(r);
                return Array.apply(void 0, e(t))
            }
        }, {
            key: "setFocusToFirstNode",
            value: function() {
                var e = this;
                if (!this.config.disableFocus) {
                    var t = this.getFocusableNodes();
                    if (0 !== t.length) {
                        var r = t.filter((function(t) {
                            return !t.hasAttribute(e.config.closeTrigger)
                        }));
                        r.length > 0 && r[0].focus(), 0 === r.length && t[0].focus()
                    }
                }
            }
        }, {
            key: "retainFocus",
            value: function(e) {
                var t = this.getFocusableNodes();
                if (0 !== t.length)
                    if (t = t.filter((function(e) {
                            return null !== e.offsetParent
                        })), this.modal.contains(document.activeElement)) {
                        var r = t.indexOf(document.activeElement);
                        e.shiftKey && 0 === r && (t[t.length - 1].focus(), e.preventDefault()), !e.shiftKey && t.length > 0 && r === t.length - 1 && (t[0].focus(), e.preventDefault())
                    } else t[0].focus()
            }
        }]) && function(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
            }
        }(t.prototype, n), t
    }(), o = null, i = function(e) {
        if (!document.getElementById(e)) return console.warn("MicroModal: ❗Seems like you have missed %c'".concat(e, "'"), "background-color: #f8f9fa;color: #50596c;font-weight: bold;", "ID somewhere in your code. Refer example below to resolve it."), console.warn("%cExample:", "background-color: #f8f9fa;color: #50596c;font-weight: bold;", '<div class="modal" id="'.concat(e, '"></div>')), !1
    }, a = function(e, t) {
        if (function(e) {
                e.length <= 0 && (console.warn("MicroModal: ❗Please specify at least one %c'micromodal-trigger'", "background-color: #f8f9fa;color: #50596c;font-weight: bold;", "data attribute."), console.warn("%cExample:", "background-color: #f8f9fa;color: #50596c;font-weight: bold;", '<a href="#" data-micromodal-trigger="my-modal"></a>'))
            }(e), !t) return !0;
        for (var r in t) i(r);
        return !0
    }, {
        init: function(t) {
            var r = Object.assign({}, {
                    openTrigger: "data-micromodal-trigger"
                }, t),
                i = e(document.querySelectorAll("[".concat(r.openTrigger, "]"))),
                s = function(e, t) {
                    var r = [];
                    return e.forEach((function(e) {
                        var n = e.attributes[t].value;
                        void 0 === r[n] && (r[n] = []), r[n].push(e)
                    })), r
                }(i, r.openTrigger);
            if (!0 !== r.debugMode || !1 !== a(i, s))
                for (var l in s) {
                    var c = s[l];
                    r.targetModal = l, r.triggers = e(c), o = new n(r)
                }
        },
        show: function(e, t) {
            var r = t || {};
            r.targetModal = e, !0 === r.debugMode && !1 === i(e) || (o && o.removeEventListeners(), (o = new n(r)).showModal())
        },
        close: function(e) {
            e ? o.closeModalById(e) : o.closeModal()
        }
    });
    "undefined" != typeof window && (window.MicroModal = s);
    var l = s;

    function c() {}

    function d(e) {
        return e()
    }

    function u(e) {
        e.forEach(d)
    }

    function f(e) {
        if (null == e) return c;
        for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
        var o = e.subscribe.apply(e, r);
        return o.unsubscribe ? function() {
            return o.unsubscribe()
        } : o
    }

    function p(e) {
        var t;
        return f(e, (function(e) {
            return t = e
        }))(), t
    }
    new Set, new Map;

    function h(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    new Set, new Set, "undefined" != typeof window ? window : "undefined" != typeof globalThis ? globalThis : global, new Set([].concat(["allowfullscreen", "allowpaymentrequest", "async", "autofocus", "autoplay", "checked", "controls", "default", "defer", "disabled", "formnovalidate", "hidden", "inert", "ismap", "loop", "multiple", "muted", "nomodule", "novalidate", "open", "playsinline", "readonly", "required", "reversed", "selected"])), "function" == typeof HTMLElement && HTMLElement;
    var v = [];

    function g(e) {
        var t, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : c,
            n = new Set;

        function o(r) {
            if (function(e, t) {
                    return e != e ? t == t : e !== t || e && "object" == typeof e || "function" == typeof e
                }(e, r) && (e = r, t)) {
                var o, i = !v.length,
                    a = function(e, t) {
                        var r = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                        if (!r) {
                            if (Array.isArray(e) || (r = function(e, t) {
                                    if (e) {
                                        if ("string" == typeof e) return h(e, t);
                                        var r = Object.prototype.toString.call(e).slice(8, -1);
                                        return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? h(e, t) : void 0
                                    }
                                }(e)) || t && e && "number" == typeof e.length) {
                                r && (e = r);
                                var n = 0,
                                    o = function() {};
                                return {
                                    s: o,
                                    n: function() {
                                        return n >= e.length ? {
                                            done: !0
                                        } : {
                                            done: !1,
                                            value: e[n++]
                                        }
                                    },
                                    e: function(e) {
                                        throw e
                                    },
                                    f: o
                                }
                            }
                            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                        }
                        var i, a = !0,
                            s = !1;
                        return {
                            s: function() {
                                r = r.call(e)
                            },
                            n: function() {
                                var e = r.next();
                                return a = e.done, e
                            },
                            e: function(e) {
                                s = !0, i = e
                            },
                            f: function() {
                                try {
                                    a || null == r.return || r.return()
                                } finally {
                                    if (s) throw i
                                }
                            }
                        }
                    }(n);
                try {
                    for (a.s(); !(o = a.n()).done;) {
                        var s = o.value;
                        s[1](), v.push(s, e)
                    }
                } catch (e) {
                    a.e(e)
                } finally {
                    a.f()
                }
                if (i) {
                    for (var l = 0; l < v.length; l += 2) v[l][0](v[l + 1]);
                    v.length = 0
                }
            }
        }
        return {
            set: o,
            update: function(t) {
                o(t(e))
            },
            subscribe: function(i) {
                var a = [i, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : c];
                return n.add(a), 1 === n.size && (t = r(o) || c), i(e),
                    function() {
                        n.delete(a), 0 === n.size && t && (t(), t = null)
                    }
            }
        }
    }

    function m(e, t, r) {
        var n, o = !Array.isArray(e),
            i = o ? [e] : e,
            a = t.length < 2;
        return n = function(e) {
            var r = !1,
                n = [],
                s = 0,
                l = c,
                d = function() {
                    if (!s) {
                        l();
                        var r = t(o ? n[0] : n, e);
                        a ? e(r) : l = "function" == typeof r ? r : c
                    }
                },
                p = i.map((function(e, t) {
                    return f(e, (function(e) {
                        n[t] = e, s &= ~(1 << t), r && d()
                    }), (function() {
                        s |= 1 << t
                    }))
                }));
            return r = !0, d(),
                function() {
                    u(p), l(), r = !1
                }
        }, {
            subscribe: g(r, n).subscribe
        }
    }

    function y(e, t, r, n) {
        var o, i, a = !1,
            s = "withOld" in r,
            l = m(e, ((e, r) => {
                if (o = r, s && (i = e), !a) {
                    let n = t(e, r);
                    if (!(t.length < 2)) return n;
                    r(n)
                }
                a = !1
            }), n),
            c = !Array.isArray(e),
            d = t => {
                c ? (a = !0, e.set(t)) : t.forEach(((t, r) => {
                    a = !0, e[r].set(t)
                })), a = !1
            };
        s && (r = r.withOld);
        var u = r.length >= (s ? 3 : 2),
            f = null,
            h = !1;

        function v(e) {
            var t, n, a, c;
            if (h) return c = e(p(l)), void o(c);
            var v = l.subscribe((e => {
                h ? t ? n = !0 : t = !0 : a = e
            }));
            c = e(a), h = !0, o(c), v(), h = !1, n && (c = p(l)), t && function(e) {
                if (f && (f(), f = null), s) var t = r(e, i, d);
                else t = r(e, d);
                u ? "function" == typeof t && (f = t) : d(t)
            }(c)
        }
        return {
            subscribe: l.subscribe,
            set(e) {
                v((() => e))
            },
            update: v
        }
    }

    function w(e, t) {
        if (Array.isArray(t)) {
            let r = t.concat();
            return y(e, (e => {
                for (let t = 0; t < r.length; ++t) e = e[r[t]];
                return e
            }), {
                withOld(e, t) {
                    let n = t;
                    for (let e = 0; e < r.length - 1; ++e) n = n[r[e]];
                    return n[r[r.length - 1]] = e, t
                }
            })
        }
        return y(e, (e => e[t]), {
            withOld(e, r) {
                return r[t] = e, r
            }
        })
    }

    function b(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), r.push.apply(r, n)
        }
        return r
    }

    function _(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2 ? b(Object(r), !0).forEach((function(t) {
                O(e, t, r[t])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : b(Object(r)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
            }))
        }
        return e
    }

    function O(e, t, r) {
        return (t = function(e) {
            var t = function(e, t) {
                if ("object" != typeof e || null === e) return e;
                var r = e[Symbol.toPrimitive];
                if (void 0 !== r) {
                    var n = r.call(e, "string");
                    if ("object" != typeof n) return n;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return String(e)
            }(e);
            return "symbol" == typeof t ? t : String(t)
        }(t)) in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }

    function E(e) {
        return new Proxy(e, {
            get(e, t, r) {
                const n = p(e),
                    o = Reflect.get(n, t);
                return o instanceof Function ? function() {
                    for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++) t[i] = arguments[i];
                    return o.apply(this === r ? n : this, t)
                } : o
            },
            set(e, t, r, n) {
                let o;
                return e.update((e => {
                    const n = _({}, e);
                    return o = Reflect.set(n, t, r), n
                })), o
            },
            has(e, t) {
                return Reflect.has(p(e), t)
            },
            ownKeys(e) {
                return Reflect.ownKeys(p(e))
            },
            defineProperty(e, t, r) {
                let n;
                return e.update((e => {
                    const o = _({}, e);
                    return n = Reflect.defineProperty(o, t, r), o
                })), n
            },
            deleteProperty(e, t) {
                let r;
                return t in p(e) && (e.update((e => {
                    const n = _({}, e);
                    return r = Reflect.deleteProperty(n, t), n
                })), r)
            },
            getOwnPropertyDescriptor(e, t) {
                return Object.getOwnPropertyDescriptor(p(e), t)
            },
            getPrototypeOf(e) {
                return Reflect.getPrototypeOf(p(e))
            },
            setPrototypeOf(e, t) {
                return Reflect.setPrototypeOf(e, t)
            },
            isExtensible(e) {
                return Reflect.isExtensible(p(e))
            },
            preventExtensions(e) {
                return Reflect.preventExtensions(e)
            },
            apply(e, t, r) {
                return Reflect.apply(p(e), t, r)
            },
            construct(e, t, r) {
                return Reflect.construct(p(e), t, r)
            }
        })
    }
    let k;
    try {
        k = (window.Cypress ? window : window.parent).Tydal
    } catch (e) {
        console.error(e), k = window.Tydal
    }
    const x = g(k),
        j = E(x),
        $ = w(x, "loy_config");

    function P(e, t) {
        let r = j.rev_config.widget_css.theme_star_color;
        switch (e) {
            case "full":
                return `<svg enable-background="new 0 0 24 24" height="${t}" width="${t}" fill="${r}" viewBox="3.44 3.57 17.11 16.36"><path d="m0 0h24v24h-24z" fill="none"/><path d="m0 0h24v24h-24z" fill="none"/><path d="m12 17.27 4.15 2.51c.76.46 1.69-.22 1.49-1.08l-1.1-4.72 3.67-3.18c.67-.58.31-1.68-.57-1.75l-4.83-.41-1.89-4.46c-.34-.81-1.5-.81-1.84 0l-1.89 4.45-4.83.41c-.88.07-1.24 1.17-.57 1.75l3.67 3.18-1.1 4.72c-.2.86.73 1.54 1.49 1.08z"/></svg>`;
            case "empty":
                return `<svg height="${t}" width="${t}" fill="${r}" viewBox="3.44 3.56 17.12 16.37"><path d="m0 0h24v24h-24z" fill="none"></path><path d="m19.65 9.04-4.84-.42-1.89-4.45c-.34-.81-1.5-.81-1.84 0l-1.89 4.46-4.83.41c-.88.07-1.24 1.17-.57 1.75l3.67 3.18-1.1 4.72c-.2.86.73 1.54 1.49 1.08l4.15-2.5 4.15 2.51c.76.46 1.69-.22 1.49-1.08l-1.1-4.73 3.67-3.18c.67-.58.32-1.68-.56-1.75zm-7.65 6.36-3.76 2.27 1-4.28-3.32-2.88 4.38-.38 1.7-4.03 1.71 4.04 4.38.38-3.32 2.88 1 4.28z"></path></svg>`;
            case "half":
                return `<svg height="${t}" width="${t}" fill="${r}" viewBox="3.44 3.56 17.12 16.37"><path d="M0 0h24v24H0z" fill="none"></path><path d="M19.65 9.04l-4.84-.42-1.89-4.45c-.34-.81-1.5-.81-1.84 0L9.19 8.63l-4.83.41c-.88.07-1.24 1.17-.57 1.75l3.67 3.18-1.1 4.72c-.2.86.73 1.54 1.49 1.08l4.15-2.5 4.15 2.51c.76.46 1.69-.22 1.49-1.08l-1.1-4.73 3.67-3.18c.67-.58.32-1.68-.56-1.75zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z"></path></svg>`
        }
    }

    function S(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 14,
            r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "",
            n = Math.round(2 * e) / 2;
        e % 1 > .7 && (n = Math.ceil(n));
        const o = Math.floor(n),
            i = n % 1 == .5 ? 1 : 0;
        Math.max(0, 5 - o - i);
        let a = `<div class='tydal-star-wrapper ${r}'>`;
        for (let e = 1; e <= 5; e++) a += P(e <= o ? "full" : e <= o + i ? "half" : "empty", t);
        return a + "</div>"
    }
    E($), m(x, (e => e.common.shop.money_format || "{{amount_with_comma_separator}}$")), w($, "ways_to_earn"), w($, "referral_rewards"), w($, "vip_tiers"), w(x, ["common", "customer"]), g(), g(), g(), g([]), g(), g(), g({
        bottom: void 0
    }), g();
    const M = {
        onShow: e => window.parent.document.querySelector("body").style.overflow = "hidden",
        onClose: function(e, t, r) {
            r ? .preventDefault(), r ? .stopPropagation(), window.parent.document.querySelector("body").style.overflow = ""
        },
        openClass: "shown"
    };
    var A, T, L;

    function C(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), r.push.apply(r, n)
        }
        return r
    }

    function R(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2 ? C(Object(r), !0).forEach((function(t) {
                D(e, t, r[t])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : C(Object(r)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
            }))
        }
        return e
    }

    function D(e, t, r) {
        return (t = function(e) {
            var t = function(e, t) {
                if ("object" != typeof e || null === e) return e;
                var r = e[Symbol.toPrimitive];
                if (void 0 !== r) {
                    var n = r.call(e, "string");
                    if ("object" != typeof n) return n;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return String(e)
            }(e);
            return "symbol" == typeof t ? t : String(t)
        }(t)) in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }

    function q(e) {
        return new Proxy(e, {
            get(e, t, r) {
                const n = p(e),
                    o = Reflect.get(n, t);
                return o instanceof Function ? function() {
                    for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++) t[i] = arguments[i];
                    return o.apply(this === r ? n : this, t)
                } : o
            },
            set(e, t, r, n) {
                let o;
                return e.update((e => {
                    const n = R({}, e);
                    return o = Reflect.set(n, t, r), n
                })), o
            },
            has(e, t) {
                return Reflect.has(p(e), t)
            },
            ownKeys(e) {
                return Reflect.ownKeys(p(e))
            },
            defineProperty(e, t, r) {
                let n;
                return e.update((e => {
                    const o = R({}, e);
                    return n = Reflect.defineProperty(o, t, r), o
                })), n
            },
            deleteProperty(e, t) {
                let r;
                return t in p(e) && (e.update((e => {
                    const n = R({}, e);
                    return r = Reflect.deleteProperty(n, t), n
                })), r)
            },
            getOwnPropertyDescriptor(e, t) {
                return Object.getOwnPropertyDescriptor(p(e), t)
            },
            getPrototypeOf(e) {
                return Reflect.getPrototypeOf(p(e))
            },
            setPrototypeOf(e, t) {
                return Reflect.setPrototypeOf(e, t)
            },
            isExtensible(e) {
                return Reflect.isExtensible(p(e))
            },
            preventExtensions(e) {
                return Reflect.preventExtensions(e)
            },
            apply(e, t, r) {
                return Reflect.apply(p(e), t, r)
            },
            construct(e, t, r) {
                return Reflect.construct(p(e), t, r)
            }
        })
    }
    let z;
    A = {}, window.addEventListener("click", (function(e) {
        for (var t = e.target; t && t.dataset && !t.dataset.action;) t = t.parentNode;
        if (t && t.dataset && t.dataset.action && A[t.dataset.action]) {
            e.stopPropagation(), e.preventDefault();
            var r = t.dataset.data;
            return r = r ? r.split(",").map((function(e) {
                try {
                    return JSON.parse(e)
                } catch (t) {
                    return e
                }
            })) : [], r.unshift(e), A[t.dataset.action].apply(void 0, r), !1
        }
    }), !0), T = {}, L = {
        on: function(e, t) {
            if ("object" != typeof e) L._has_clb(e, t) || (T[e] || (T[e] = []), T[e].push(t));
            else
                for (var r in e) L.on(r, e[r])
        },
        _has_clb: function(e, t) {
            return !!T[e] && -1 !== T[e].indexOf(t)
        },
        once: function(e, t) {
            if ("object" != typeof e) t.once = !0, L.on(e, t);
            else
                for (var r in e) L.once(r, e[r])
        },
        emit: function(e, t) {
            t || (t = []), T[e] && T[e].forEach((function(r) {
                r.apply(void 0, t), r.once && L.remove(e, r)
            }))
        },
        remove: function(e, t) {
            if ("object" != typeof e) {
                if (T[e]) {
                    var r = T[e].indexOf(t); - 1 !== r && T[e].splice(r, 1)
                }
            } else
                for (var n in e) L.remove(n, e[n])
        }
    };
    try {
        z = (window.Cypress ? window : window.parent).Tydal
    } catch (e) {
        console.error(e), z = R(R({}, {
            common: {},
            rev_config: {}
        }), window.Tydal)
    }
    const B = g(z),
        F = q(B),
        I = q(w(B, "rev_config")),
        H = (q(w(B, ["common", "customer"])), m(B, (e => e.common.shop.money_format || "{{amount_with_comma_separator}}$")), g());
    q(H),
        function() {
            let e, t;
            window.addEventListener("message", (function(r) {
                const n = r.data.msg_options;
                try {
                    switch (r.data.msg_action) {
                        case "ba.ratings.resize":
                            if (!t) return;
                            t.style.height = `${n.scroll_height+50}px`;
                            break;
                        case "ba.ratings.open_review":
                            l.show("tydal-reviews-iframe-wrapper", M), e.contentWindow.postMessage({
                                msg_action: "ba.ratings.open_review",
                                msg_options: {
                                    review: n.review
                                }
                            }, "*");
                            break;
                        case "ba.ratings.write_review":
                            l.show("tydal-reviews-iframe-wrapper", M), e.contentWindow.postMessage({
                                msg_action: "ba.ratings.write_review"
                            }, "*");
                            break;
                        case "ba.ratings.modal.close":
                            l.close("tydal-reviews-iframe-wrapper"), e.contentWindow.postMessage({
                                msg_action: "ba.ratings.modal.close"
                            }, "*");
                            break;
                        case "ba.ratings.open_url":
                            Object.assign(document.createElement("a"), {
                                target: "_blank",
                                href: msg.url
                            }).click()
                    }
                } catch (r) {
                    console.log(r)
                }
            }));
            const r = "\n    :root {\n      --regular-font-size: 14px;\n      --error-color: red;\n    }\n  ";

            function n() {
                return new Promise((function(e) {
                    const t = document.querySelectorAll(".tydal-reviews-star-rating, .rivo-reviews-star-rating");
                    for (var r = 0; r < t.length; ++r) {
                        let e = t[r];
                        if (e.querySelector(".tydal-star-wrapper, .rivo-star-wrapper")) continue;
                        let n = e.getAttribute("data-rating"),
                            o = e.getAttribute("data-count");
                        if (n) {
                            e.insertAdjacentHTML("afterbegin", S(n));
                            let t = e.querySelector(".tydal-reviews-rating-count, .rivo-reviews-rating-count");
                            t && t.insertAdjacentHTML("afterbegin", `(${o})`)
                        }
                    }
                    e()
                }))
            }

            function o() {
                return new Promise((function(n) {
                    let o = document.querySelector("div.tydal-reviews-iframe-panel-wrapper");
                    if (!o || !I.widget_settings.display_storefront_enabled) return void n();
                    let i = document.createElement("style");
                    i.id = "tydal-review-display-list-styles", i.innerHTML = "\n      #tydal-reviews-display-list { width: 100%; height: 100%; display: contents;}\n      iframe.tydal-reviews{\n        position: relative;\n        width: 100%;\n        height: 800px;\n        border: none;\n        overflow: hidden;\n      }", document.head.appendChild(i), o.innerHTML = '<iframe id="tydal-reviews-panel" class="tydal-reviews" name="tydal-reviews-panel" allowfullscreen="" src="about:blank" sandbox="allow-scripts allow-same-origin"></iframe>';
                    const a = `\n        .rev-write-review, #rev-load-more{border: solid 1px ${I.widget_css.theme_launcher_border_color};color: ${I.widget_css.theme_launcher_text_color};background: ${I.widget_css.theme_launcher_bg_color};}\n        .rev-write-review:hover, #rev-load-more:hover{background: ${I.widget_css.theme_launcher_hover_bg_color}; color: ${I.widget_css.theme_launcher_hover_text_color};}\n        p.first-review-text, p.first-review-text a {color: ${I.widget_css.theme_first_review_text_color||"#000"};}\n        .rev-star{color: ${I.widget_css.theme_star_color};}\n        .summary-container .summary-text{color: ${I.widget_css.theme_star_text_color};}\n        #panel-container {color: ${I.widget_css.theme_reviews_body_color};}\n        #panel-container .review-title, #panel-container .author-name{color: ${I.widget_css.theme_reviews_title_color||"inherit"};}\n      `;
                    if (t = document.getElementById("tydal-reviews-panel"), t.contentWindow.document.write(`\n        <html lang="en">\n          <head>\n            <title></title>\n            <style type="text/css">${r}</style>\n\t          <link rel="stylesheet" href="${F.global_config.asset_urls.rev.widget_css}" defer>\n            <script src="${F.global_config.asset_urls.rev.display_js}"><\/script>\n            <style type="text/css">${a}</style>\n            <style type="text/css">${I.custom_css}</style>\n          </head>\n          <body>\n            <div class="spin-wrapper ajax-interceptor ajax-loader-out"></div>\n          </body>\n          <script>window._init();<\/script>\n        </html>\n      `), t.contentWindow.document.close(), e) return;
                    document.body.insertAdjacentHTML("beforeend", '\n\t\t\t\t<div id="tydal-reviews-iframe-wrapper">\n\t\t\t\t\t<iframe class="tydal-reviews-modal" allowfullscreen="" src="about:blank" sandbox="allow-scripts allow-same-origin"></iframe>\n\t\t\t\t</div>\n\t\t\t'), e = document.querySelector("#tydal-reviews-iframe-wrapper iframe");
                    const s = `\n        .wizard-slide h3, #rev-finished h1{color: ${I.widget_css.theme_title_color};}\n        .rev-button{color: ${I.widget_css.theme_button_text_color};background-color: ${I.widget_css.theme_button_bg_color};border-color: ${I.widget_css.theme_button_border_color};}\n        .rev-button:hover,.rev-button:active{background-color: ${I.widget_css.theme_button_hover_color};}\n        .rev-star{fill: ${I.widget_css.theme_star_color};}\n        .subtitle{color: ${I.widget_css.theme_subtext_color};}\n        .rev-input{color: ${I.widget_css.theme_input_text_color};border: 1px solid ${I.widget_css.theme_input_border_color} !important;}\n        .rev-progress{border-color: ${I.widget_css.theme_progress_border_color};}\n        .rev-progress .full{background-color: ${I.widget_css.theme_progress_color};}\n        .rev-footer{color: ${I.widget_css.theme_footer_color};}\n        .rev-link, .rev-footer a{color: ${I.widget_css.theme_link_color};}\n        .rev-star-button{background: #fff;border: solid 1px ${I.widget_css.theme_rating_border_color};}\n        .rate-product-stars div.review-star-container a:hover{background: ${I.widget_css.theme_star_color}3b;}\n        .review-star-container a:after{color: ${I.widget_css.theme_star_text_color};}\n      `;
                    e.contentDocument.write(`\n\t\t\t\t<html lang="en">\n\t\t\t\t\t<head>\n\t\t\t\t\t\t<title></title>\n            <style type="text/css">${r}</style>\n\t\t\t\t\t\t<link rel="stylesheet" href="${F.global_config.asset_urls.rev.modal_css}" defer>\n            <style type="text/css">${s}</style>\n            <style type="text/css">${I.custom_css}</style>\n            <script src="${F.global_config.asset_urls.rev.modal_js}"><\/script>\n\t\t\t\t\t</head>\n\t\t\t\t\t<body></body>\n          <script>window._init();<\/script>\n\t\t\t\t</html>\n\t\t\t`), e.contentDocument.close(), n()
                }))
            }

            function i() {
                return new Promise((function(e) {
                    const t = document.querySelector(".tydal-reviews-star-rating, .rivo-reviews-star-rating");
                    null != t && t.addEventListener("click", (function() {
                        document.getElementById("tydal-reviews-panel").scrollIntoView({
                            behavior: "smooth"
                        })
                    })), e()
                }))
            }
            window.addEventListener("load", (function() {
                var e;
                (document.getElementsByTagName("head")[0].innerHTML.search("rev_" + window.Tydal.common.shop.id) > 0 || document.getElementById("rev-app-embed-init")) && I.widget_enabled && ((e = document.createElement("style")).innerHTML = "\n      #tydal-reviews-panel{width:100%;border:0px;min-height:250px;}\n      .tydal-reviews-iframe-panel-wrapper {position: relative; width: 100%; height: fit-content;}\n      #tydal-reviews-iframe-wrapper{background:#000000ab;display:none;top:0px;left:0px;width: 100%; height: 100%; position: fixed; z-index: 2147483647; transition: all 300ms cubic-bezier(0.87, 0, 0.13, 1); overflow-y: auto; opacity:0;}\n      #tydal-reviews-iframe-wrapper.shown{display:block;opacity:1;overflow: hidden;}\n      #tydal-reviews-iframe-wrapper iframe{border:0px;position:relative important;width:100% !important;min-height:100% !important;}\n      .tydal-reviews-star-rating {display: flex; cursor: pointer;}\n      div.tydal-star-wrapper {display: flex; align-items: center;}\n      div.tydal-star-wrapper svg:not(:first-child) {margin-left: 2px;}\n      .tydal-reviews-rating-count {padding-left: 5px;}", document.head.appendChild(e), new Promise((function(e) {
                    const t = F.common.product;
                    if (t) {
                        if (I.widget_settings.display_star_rating_enabled && null == document.querySelector(".shopify-app-block div.tydal-reviews-star-rating, .shopify-app-block div.rivo-reviews-star-rating")) {
                            let e;
                            e = I.widget_settings.display_product_stars_custom_selector ? document.querySelector(I.widget_settings.display_product_stars_custom_selector) : document.querySelector(".product__title, .product-single__title, .product-meta__title");
                            try {
                                e.insertAdjacentHTML("afterend", `\n              <div class="tydal-reviews-star-rating"\n                data-product-id="${t.id}"\n                data-rating="${t.review_data?.stars||0}"\n                data-count="${t.review_data?.reviews_count||0}">\n                <div class="tydal-reviews-rating-count"></div>\n              </div>\n            `)
                            } catch (e) {
                                console.log(e)
                            }
                        }
                        if (null == document.querySelector(".shopify-app-block div.tydal-reviews-iframe-panel-wrapper, .shopify-app-block div.rivo-reviews-iframe-panel-wrapper")) {
                            const e = ["main", "#shopify-section-product-template"];
                            I.widget_settings.display_panel_custom_selector && e.push(I.widget_settings.display_panel_custom_selector);
                            const t = document.querySelectorAll(e.join(","));
                            if (t.length > 0) t[t.length - 1].insertAdjacentHTML("beforeend", `<div class="tydal-reviews-iframe-panel-wrapper page-width wrapper ${I.widget_settings?.display_panel_custom_class}"></div>`);
                            else {
                                const e = document.querySelector("section.page-width");
                                e && e.insertAdjacentHTML("afterend", `<div class="tydal-reviews-iframe-panel-wrapper page-width wrapper ${F.rev_config.widget_settings?.display_panel_custom_class}"></div>`)
                            }
                        }
                    }
                    e()
                })).then(n).then(o).then(i))
            }))
        }()
}();
//# sourceMappingURL=https://d1327z4fntq4ap.cloudfront.net/assets/storefront/ba_rev_init.js-02ede96770d17f59d5e2d7e9e1f103e5dbddc990649241ac32acd331052975cd.map
//!
;