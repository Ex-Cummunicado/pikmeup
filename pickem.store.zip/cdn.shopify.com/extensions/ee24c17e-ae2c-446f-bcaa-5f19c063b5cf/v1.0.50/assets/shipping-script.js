(() => {
    "use strict";
    var __webpack_modules__ = {
            197: (e, t, n) => {
                n.d(t, {
                    $: () => o,
                    f: () => i
                });
                const i = (e, t, n) => {
                        let {
                            operator: i,
                            value: r,
                            action: s,
                            groupIndex: a = 0
                        } = t;
                        switch (i) {
                            case "contain":
                                return e.includes(r) ? o({
                                    action: s,
                                    groupIndex: a
                                }) : -1;
                            case "not contain":
                                return e.includes(r) ? -1 : o({
                                    action: s,
                                    groupIndex: a
                                });
                            case "equal":
                                return e === r ? o({
                                    action: s,
                                    groupIndex: a
                                }) : -1;
                            case "not equal":
                                return e !== r ? o({
                                    action: s,
                                    groupIndex: a
                                }) : -1;
                            default:
                                return -1
                        }
                    },
                    o = e => {
                        let {
                            action: t,
                            groupIndex: n = 0
                        } = e;
                        switch (t) {
                            case "assign-test-group":
                                return n;
                            case "assign-random":
                                return "random";
                            default:
                                return 0
                        }
                    }
            },
            533: (e, t, n) => {
                n.d(t, {
                    E: () => i
                });
                const i = "https://app.abconvert.io"
            },
            972: (e, t, n) => {
                n.d(t, {
                    N: () => i
                });
                class i {
                    constructor() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : () => {};
                        this.callback = e, this.observeCartChanges(), this.fetchCart().then((e => {
                            this.cart = e, this.addDiscountedPriceToCart()
                        }))
                    }
                    async fetchCart() {
                        return (await fetch("/cart.js")).json()
                    }
                    async addDiscountedPriceToCart() {
                        const e = this.cart.items,
                            t = [],
                            n = (window ? .Shopify ? .routes ? .root ? ? "/") + "cart/change.js";
                        for (let i = 0; i < e.length; i++) {
                            const o = e[i];
                            if (!(o.price == o.discounted_price || o.properties && o.properties._discounted_price && o.properties._discounted_price === o.discounted_price)) {
                                console.log("[LOG] Adding discounted price to cart item", o);
                                let e = o.properties || {};
                                t.push(fetch(n, {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify({
                                        line: i + 1,
                                        properties: { ...e,
                                            _discounted_price: o.discounted_price
                                        },
                                        quantity: o.quantity
                                    })
                                }))
                            }
                        }
                        await Promise.all(t).then((e => {
                            console.log("[LOG] Updated cart with discounted prices", e), window.upcartRefreshCart && window.upcartRefreshCart()
                        }))
                    }
                    async emitCartChanges() {
                        const e = await this.fetchCart();
                        this.cart = e;
                        const t = new CustomEvent("abconvert-cart-change", {
                            detail: e,
                            bubbles: !0
                        });
                        window.dispatchEvent(t)
                    }
                    isCartEqual(e, t) {
                        const n = e.items.length;
                        if (n !== t.items.length) return !1;
                        for (let i = 0; i < n; i++) {
                            const n = e.items[i],
                                o = t.items[i];
                            if (!n ? .properties ? .["_abconvert-session"]) return !1;
                            if (n.properties["_abconvert-session"] !== o.properties["_abconvert-session"]) return !1
                        }
                        return !0
                    }
                    async observeCartChanges() {
                        new PerformanceObserver((e => {
                            e.getEntries().forEach((async e => {
                                const t = ["xmlhttprequest", "fetch"].includes(e.initiatorType),
                                    n = /\/cart\/change/.test(e.name),
                                    i = /\/cart\/add/.test(e.name);
                                if (t) {
                                    if (n) {
                                        console.log("[ABConvert] Cart change detected");
                                        const e = await this.fetchCart();
                                        this.isCartEqual(this.cart, e) ? console.log("[ABConvert] Cart has not changed, no action taken") : (console.log("[ABConvert] Cart has changed"), this.cart = e, await this.emitCartChanges(), this.callback && this.callback())
                                    }
                                    i && (console.log("[ABConvert] Add to cart"), await this.emitCartChanges(), await this.addDiscountedPriceToCart(), this.callback && await this.callback())
                                }
                            }))
                        })).observe({
                            entryTypes: ["resource"]
                        })
                    }
                }
            }
        },
        __webpack_module_cache__ = {};

    function __webpack_require__(e) {
        var t = __webpack_module_cache__[e];
        if (void 0 !== t) return t.exports;
        var n = __webpack_module_cache__[e] = {
            exports: {}
        };
        return __webpack_modules__[e](n, n.exports, __webpack_require__), n.exports
    }
    __webpack_require__.d = (e, t) => {
        for (var n in t) __webpack_require__.o(t, n) && !__webpack_require__.o(e, n) && Object.defineProperty(e, n, {
            enumerable: !0,
            get: t[n]
        })
    }, __webpack_require__.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t);
    var __webpack_exports__ = {},
        _class_cart_watcher_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(972),
        _audience_filter_handler_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(197),
        _config_config_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(533);
    let shopURL, shippingTestData, shippingBannerConfig, sessionId;
    const SHIPPING_TYPE = {
            FREE_SHIPPING_THRESHOLD: "FREE_SHIPPING_THRESHOLD",
            FLAT_RATE_SHIPPING: "FLAT_RATE_SHIPPING",
            ADVANCED_SHIPPING: "ADVANCED_SHIPPING"
        },
        cookieExpireTime = 2592e6;

    function uuidV4() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(e) {
            var t = 16 * Math.random() | 0;
            return ("x" == e ? t : 3 & t | 8).toString(16)
        }))
    }
    const fetchClient = async function(e, t) {
            let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
            const i = {
                method: t,
                mode: "cors",
                headers: {
                    "Content-Type": "application/json"
                }
            };
            n && (i.body = JSON.stringify(n));
            let o = 150,
                r = 0;
            for (; r < 3;) try {
                const t = await fetch(e, i);
                if (t.ok) return t.json();
                throw new Error(await t.json())
            } catch (e) {
                if (o *= 2, r += 1, r >= 3) throw e;
                await new Promise((e => setTimeout(e, o)))
            }
            throw new Error("API Error")
        },
        getPreviewNumber = () => {
            const e = new URLSearchParams(location.search).get("preview");
            return e && !isNaN(Number(e)) ? (window.sessionStorage.setItem("abconvert-preview-number", e), e) : window.sessionStorage.getItem("abconvert-preview-number")
        },
        getPreviewCountry = () => {
            const e = new URLSearchParams(window.location.search).get("country");
            return e ? (window.sessionStorage.setItem("abconvert-preview-country", e), e) : window.sessionStorage.getItem("abconvert-preview-country")
        },
        getVariant = () => {
            const e = localStorage.getItem("abconvert-country"),
                t = getShippingTestData();
            return t ? t.country !== e ? null : t.variant : null
        },
        createInput = (e, t) => {
            const n = document.createElement("input");
            return n.type = "hidden", n.name = e, n.value = t, n
        },
        handleAddToCartSubmit = () => {
            const e = document.querySelectorAll('form[action="/cart/add"]'),
                t = getPreviewNumber(),
                n = getVariant();
            let i = getCookie("abconvert-session");
            e.forEach((e => {
                e.insertBefore(createInput("properties[_abconvert-session]", i), e.firstChild), e.insertBefore(createInput("properties[_abconvert-currency]", window ? .Shopify ? .currency ? .active), e.firstChild), e.insertBefore(createInput("properties[_abconvert-currency-rate]", window ? .Shopify ? .currency ? .rate), e.firstChild), t ? e.insertBefore(createInput("properties[_abconvert-shipping-group]", parseInt(t)), e.firstChild) : null != n && e.insertBefore(createInput("properties[_abconvert-shipping-variant]", n), e.firstChild)
            }))
        };
    async function changeLineItemProperty() {
        console.log("[LOG] ABConvert change line item property");
        const e = getPreviewNumber(),
            t = (window ? .Shopify ? .routes ? .root ? ? "/") + "cart/change.js",
            n = {
                "Content-Type": "application/json"
            },
            i = await fetch((window ? .Shopify ? .routes ? .root ? ? "/") + "cart.js"),
            o = await i.json();
        if (console.log("[LOG] ABConvert existing cart", o), !o ? .items ? .length) return;
        const r = o.items.length;
        for (let i = 0; i < r; i++) {
            let r = o ? .items[i] ? .properties ? ? {};
            if (r["_abconvert-session"] === sessionId) continue;
            const s = {
                line: i + 1,
                properties: { ...r,
                    "_abconvert-session": sessionId,
                    "_abconvert-currency": window ? .Shopify ? .currency ? .active,
                    "_abconvert-currency-rate": window ? .Shopify ? .currency ? .rate
                },
                quantity: o ? .items[i] ? .quantity
            };
            if (e) s.properties["_abconvert-shipping-group"] = parseInt(e);
            else {
                const e = getVariant();
                s.properties["_abconvert-shipping-variant"] = e
            }
            fetch(t, {
                method: "POST",
                headers: n,
                body: JSON.stringify(s)
            }).then((e => {
                console.log("[LOG] ABConvert update line item property", e), window.upcartRefreshCart && window.upcartRefreshCart()
            }))
        }
    }
    const getCookie = e => {
            const t = document.cookie.split("; ").find((t => t.startsWith(e + "=")));
            return t ? .split("=")[1] || null
        },
        loadConfig = async () => {
            try {
                setShopURL(), sessionId = await getOrCreateSessionId(), await fetchShippingConfig(sessionId)
            } catch (e) {
                console.error("An error occurred while loading the configuration:", e)
            }
        },
        setShopURL = () => {
            if (window.Shopify && window.Shopify.shop) shopURL = window.Shopify.shop;
            else {
                const e = new URLSearchParams(window.location.search);
                if (shopURL = e.get("shop"), !shopURL) return void console.error("Shop parameter not found")
            }
            localStorage.setItem("shopURL", shopURL)
        },
        getOrCreateSessionId = async () => {
            if (sessionId = getCookie("abconvert-session"), !sessionId) {
                sessionId = "undefined" != typeof crypto ? ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (e => (e ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> e / 4).toString(16))) : uuidV4();
                const e = new Date(Date.now() + 18e5).toUTCString();
                document.cookie = `abconvert-session=${sessionId}; expires=${e};path=/`, clearStoredData()
            }
            return sessionId
        },
        clearStoredData = () => {
            sessionStorage.removeItem("abconvert-preview-number"), localStorage.removeItem("abconvert-shippingxp"), localStorage.removeItem("abconvert-shipvc"), localStorage.removeItem("abconvert-shipatc"), localStorage.removeItem("abconvert-shipping-banner"), localStorage.removeItem("abconvert-shipcheckout"), document.cookie = "abconvert-has-view-shipping-banner=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;"
        },
        fetchShippingConfig = async sessionId => {
            try {
                const preview = getPreviewNumber(),
                    previewCountry = getPreviewCountry();
                if (preview) {
                    console.log("[LOG] ABConvert fetch shipping config - preview: ", preview);
                    const {
                        shipping,
                        country,
                        customScript = null,
                        isFilteredByCookie = !1,
                        cookieFilterList = [],
                        cookieFilterNotMatchAction = null,
                        testGroups = []
                    } = await fetchNewConfig(sessionId, preview, previewCountry);
                    return void(shipping && country ? (await updateLocalStorage(shipping, country), customScript && (console.log("[LOG] ABConvert shipping preview: run custom script"), eval(customScript)), await getFreeShippingBarConfig()) : clearShippingData(country))
                }
                shippingTestData = getShippingTestData();
                const currentTimestamp = Math.floor(Date.now() / 1e3);
                if (shouldFetchNewConfig(shippingTestData, currentTimestamp)) {
                    console.log("[LOG] ABConvert fetch shipping config");
                    const {
                        shipping,
                        country,
                        customScript = null,
                        isFilteredByCookie = !1,
                        cookieFilterList = [],
                        cookieFilterNotMatchAction = null,
                        testGroups = []
                    } = await fetchNewConfig(sessionId);
                    if (shipping && country) {
                        if (isFilteredByCookie) {
                            let e;
                            console.log("[LOG] ABConvert set shipping config - cookie filter"), e = -1;
                            for (let t = 0; t < cookieFilterList.length; t++) {
                                const n = cookieFilterList[t],
                                    i = n.key,
                                    o = getCookie(i);
                                if (o && (e = (0, _audience_filter_handler_js__WEBPACK_IMPORTED_MODULE_0__.f)(o, n, cookieFilterNotMatchAction)), -1 != e) break
                            } - 1 == e && (e = (0, _audience_filter_handler_js__WEBPACK_IMPORTED_MODULE_0__.$)(cookieFilterNotMatchAction)), "random" != e && (console.log("[LOG] ABConvert set shipping variant -", e), shipping.variant = e, shipping.rate = void 0 !== testGroups[e] ? .rate ? testGroups[e].rate : void 0, shipping.thresholdValue = testGroups[e] ? .hasFreeShippingThreshold || testGroups[e] ? .hasRateBelowThreshold ? testGroups[e].threshold : void 0, shipping.type === SHIPPING_TYPE.ADVANCED_SHIPPING && (shipping.advancedRates = testGroups[e] ? .advancedRates || []))
                        }
                        await updateLocalStorage(shipping, country), customScript && (console.log("[LOG] ABConvert shipping: run custom script"), window.localStorage.setItem("abconvert-shipping-custom-script", customScript), eval(customScript)), await getFreeShippingBarConfig()
                    } else clearShippingData(country)
                }
                window.localStorage.getItem("abconvert-shipping-custom-script") && (console.log("[LOG] ABConvert shipping: run custom script"), eval(window.localStorage.getItem("abconvert-shipping-custom-script")))
            } catch (e) {
                console.error("An error occurred while fetching the shipping configuration:", e)
            }
        },
        getShippingTestData = () => {
            if (shippingTestData = localStorage.getItem("abconvert-shippingxp"), shippingTestData) try {
                let e = JSON.parse(shippingTestData);
                if (e.type === SHIPPING_TYPE.ADVANCED_SHIPPING) {
                    let t = null,
                        n = null;
                    for (let i of e.advancedRates) 0 == i.price && (n ? n > i.minimum && (n = i.minimum) : n = i.minimum), t ? t > i.price && (t = i.price) : t = i.price;
                    e.rate = t, e.thresholdValue = n
                }
                return e
            } catch (e) {
                console.error("Error parsing shippingTestData:", e)
            }
            return null
        },
        shouldFetchNewConfig = (e, t) => !e || e.expirationTime < t,
        fetchNewConfig = async function(e) {
            let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
            const i = localStorage.getItem("abconvert-seed");
            return await fetchClient(_config_config_js__WEBPACK_IMPORTED_MODULE_1__.E + "/api/shipping/config", "POST", {
                seed: i,
                shop: shopURL,
                sessionId: e,
                previewCountry: n,
                preview: t
            }) || {}
        },
        updateLocalStorage = async (e, t) => {
            localStorage.setItem("abconvert-shippingxp", JSON.stringify(e)), localStorage.setItem("abconvert-country", t), e ? .seed && (localStorage.setItem("abconvert-seed", e.seed), changeLineItemProperty())
        },
        clearShippingData = e => {
            localStorage.setItem("abconvert-shippingxp", ""), localStorage.setItem("abconvert-country", e)
        },
        getFreeShippingBarConfig = async () => {
            const e = await fetchClient(_config_config_js__WEBPACK_IMPORTED_MODULE_1__.E + "/api/public/shipping-banner?shop=" + encodeURIComponent(shopURL), "GET");
            if (e && !0 === e.enable) return localStorage.setItem("abconvert-shipping-banner", JSON.stringify(e)), shippingBannerConfig = e, e;
            localStorage.removeItem("abconvert-shipping-banner")
        },
        createContainer = function(e, t, n) {
            let i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 10,
                o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 14;
            const r = document.createElement("div");
            return r.classList.add("abconvert-free-shipping-bar"), r.style.backgroundColor = t, r.style.color = n, r.style.padding = `${i}px`, r.style.boxSizing = "border-box", r.style.fontSize = `${o}px`, "top" === e ? r.style.width = "100%" : (r.style.position = "fixed", r.style.bottom = "30px", r.style.left = "50%", r.style.minWidth = "250px", r.style.transform = "translate(-50%, 50%)", r.style.borderRadius = "5px", r.style.zIndex = "999"), r.style.opacity = "1", r.style.transition = "opacity 0.5s ease-out", r
        },
        createWrapper = (e, t) => {
            const n = document.createElement("div");
            n.style.display = "flex", n.style.alignItems = "center", n.style.width = "100%", n.style.justifyContent = "space-between", n.innerHTML = `<span class="abconvert-banner-text"> ${e}</span><button class="abconvert-close-button">&times;</button>`;
            const i = n.querySelector(".abconvert-close-button"),
                o = n.querySelector(".abconvert-banner-text");
            return styleCloseButton(i, t), styleBannerText(o), n
        },
        styleBannerText = e => {
            e && (e.style.flexGrow = "1", e.style.textAlign = "center", e.style.lineHeight = "1.5em")
        },
        styleCloseButton = (e, t) => {
            e && (e.style.border = "none", e.style.background = "none", e.style.color = "#fff", e.style.fontSize = "20px", e.style.cursor = "pointer", "top" === t && (e.style.position = "absolute"), e.style.right = "5px", e.addEventListener("click", (() => {
                e.parentElement.parentElement.style.opacity = "0", setTimeout((() => {
                    e.parentElement.parentElement.style.display = "none"
                }), 500), document.cookie = "abconvert-has-view-shipping-banner=1; expires=" + new Date(Date.now() + cookieExpireTime).toUTCString() + "; path=/"
            })), e.addEventListener("mouseover", (() => {
                e.style.opacity = "0.5"
            })), e.addEventListener("mouseout", (() => {
                e.style.opacity = "1"
            })))
        };

    function getCurrencySymbol(e) {
        return new Intl.NumberFormat("en-US", {
            style: "currency",
            currency: e
        }).format(0).replace(/[\d.,\s]+/g, "")
    }
    const renderFreeShippingBar = async () => {
        const e = new URLSearchParams(window.location.search);
        let t, n, i, o, r, s;
        if (e.get("isShippingBannerPreview")) t = e.get("backgroundColor") || "#333", n = e.get("textColor") || "#333", i = e.get("text") || "This is a floating bar", o = e.get("position") || "bottom", r = e.get("fontSize") || 14, s = e.get("padding") || 10;
        else {
            if (shippingTestData = getShippingTestData(), !shippingTestData) return;
            if ("1" === getCookie("abconvert-has-view-shipping-banner")) return;
            if (shippingBannerConfig = JSON.parse(localStorage.getItem("abconvert-shipping-banner")), !shippingBannerConfig) return;
            t = shippingBannerConfig.bannerBackgroundColor, n = shippingBannerConfig.bannerTextColor, o = shippingBannerConfig.position, r = shippingBannerConfig.fontSize, s = shippingBannerConfig.padding;
            const {
                type: e,
                thresholdValue: a = "",
                rate: c,
                currency: p
            } = shippingTestData, {
                rate: l,
                active: h
            } = window ? .Shopify ? .currency || {}, g = getCurrencySymbol(h), u = window ? .Shopify ? .country;
            let d, _;
            if (p && p == h ? (_ = c, d = a) : (_ = l && c ? c * l : 0, d = l && a ? a * l : 0), e === SHIPPING_TYPE.FREE_SHIPPING_THRESHOLD) i = 0 === a ? shippingBannerConfig.bannerText.freeShipping : shippingBannerConfig.bannerText.freeShippingThreshold;
            else if (e === SHIPPING_TYPE.FLAT_RATE_SHIPPING) i = a ? shippingBannerConfig.bannerText.freeShippingThreshold : shippingBannerConfig.bannerText.flatRateNoFreeShippingThreshold;
            else {
                if (e !== SHIPPING_TYPE.ADVANCED_SHIPPING) return;
                i = 0 === a ? shippingBannerConfig.bannerText.freeShipping : a ? shippingBannerConfig.bannerText.freeShippingThreshold : shippingBannerConfig.bannerText.flatRateNoFreeShippingThreshold
            }
            if (i.includes("{threshold}")) {
                const e = (d / 100).toFixed(2);
                i = i.replace("{threshold}", `${g}${e}`)
            }
            if (i.includes("{shipping_rate}")) {
                const e = (_ / 100).toFixed(2);
                i = i.replace("{shipping_rate}", `${g}${e}`)
            }
            i.includes("{country}") && (i = i.replace("{country}", u || "")), i.includes("{currency_code}") && (i = i.replace("{currency_code}", h || ""))
        }
        const a = createContainer(o, t, n, s, r),
            c = createWrapper(i, o);
        if (a.appendChild(c), "top" === o) {
            const e = document.getElementById("abconvert-shipping"),
                t = document.getElementById("shopify-section-header"),
                n = document.getElementsByClassName("section-header")[0];
            e ? e.prepend(a) : t ? t.prepend(a) : n && n.prepend(a)
        } else document.body.appendChild(a)
    };

    function formatShippingNumber(e) {
        const t = e / 100;
        return Number.isInteger(t) ? t : t.toFixed(2)
    }
    const emitEvent = (e, t) => {
            const n = new CustomEvent(e, {
                detail: t
            });
            document.dispatchEvent(n)
        },
        postInitEvent = () => {
            emitEvent("abconvert:shipping:initialized", {
                shippingTestData
            })
        },
        initialize = async () => {
            console.log("[ABConvert] Initialize shipping script"), await Promise.all([setShopURL(), getOrCreateSessionId().then((e => fetchShippingConfig(e))).then((() => {
                const e = !!localStorage.getItem("abconvert-shippingxp");
                renderFreeShippingBar(), e && (postInitEvent(), handleAddToCartSubmit(), changeLineItemProperty(), window.cartWatcher = new _class_cart_watcher_js__WEBPACK_IMPORTED_MODULE_2__.N(changeLineItemProperty))
            }))])
        };
    console.log("[ABConvert] Running ABConvert shipping script production: 5.0.4 - cookie filtering + fix only preview running custom script + fix preview version + update discount price + update all line item properties"), "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", initialize) : initialize()
})();