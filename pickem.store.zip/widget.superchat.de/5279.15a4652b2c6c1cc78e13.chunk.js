"use strict";
(self.webpackChunk_superchat_widget_microsite = self.webpackChunk_superchat_widget_microsite || []).push([
    [5279], {
        5279: (t, e, i) => {
            i.r(e), i.d(e, {
                default: () => qo
            });
            class s {
                constructor(t) {
                    this.isMounted = !1, this.node = t
                }
                update() {}
            }
            var n = i(1264);
            const o = (0, n.ph)((() => void 0 !== window.ScrollTimeline));
            class r {
                constructor(t) {
                    this.stop = () => this.runAll("stop"), this.animations = t.filter(Boolean)
                }
                get finished() {
                    return Promise.all(this.animations.map((t => "finished" in t ? t.finished : t)))
                }
                getAll(t) {
                    return this.animations[0][t]
                }
                setAll(t, e) {
                    for (let i = 0; i < this.animations.length; i++) this.animations[i][t] = e
                }
                attachTimeline(t, e) {
                    const i = this.animations.map((i => o() && i.attachTimeline ? i.attachTimeline(t) : "function" == typeof e ? e(i) : void 0));
                    return () => {
                        i.forEach(((t, e) => {
                            t && t(), this.animations[e].stop()
                        }))
                    }
                }
                get time() {
                    return this.getAll("time")
                }
                set time(t) {
                    this.setAll("time", t)
                }
                get speed() {
                    return this.getAll("speed")
                }
                set speed(t) {
                    this.setAll("speed", t)
                }
                get startTime() {
                    return this.getAll("startTime")
                }
                get duration() {
                    let t = 0;
                    for (let e = 0; e < this.animations.length; e++) t = Math.max(t, this.animations[e].duration);
                    return t
                }
                runAll(t) {
                    this.animations.forEach((e => e[t]()))
                }
                flatten() {
                    this.runAll("flatten")
                }
                play() {
                    this.runAll("play")
                }
                pause() {
                    this.runAll("pause")
                }
                cancel() {
                    this.runAll("cancel")
                }
                complete() {
                    this.runAll("complete")
                }
            }
            class a extends r {
                then(t, e) {
                    return Promise.all(this.animations).then(t).catch(e)
                }
            }

            function l(t, e) {
                return t ? t[e] || t.default || t : void 0
            }
            const h = 2e4;

            function u(t) {
                let e = 0;
                let i = t.next(e);
                for (; !i.done && e < h;) e += 50, i = t.next(e);
                return e >= h ? 1 / 0 : e
            }

            function c(t) {
                return "function" == typeof t
            }

            function d(t, e) {
                t.timeline = e, t.onfinish = null
            }
            const p = t => Array.isArray(t) && "number" == typeof t[0],
                m = {
                    linearEasing: void 0
                };

            function f(t, e) {
                const i = (0, n.ph)(t);
                return () => {
                    var t;
                    return null !== (t = m[e]) && void 0 !== t ? t : i()
                }
            }
            const v = f((() => {
                    try {
                        document.createElement("div").animate({
                            opacity: 0
                        }, {
                            easing: "linear(0, 1)"
                        })
                    } catch (t) {
                        return !1
                    }
                    return !0
                }), "linearEasing"),
                g = (t, e, i = 10) => {
                    let s = "";
                    const o = Math.max(Math.round(e / i), 2);
                    for (let e = 0; e < o; e++) s += t((0, n.qB)(0, o - 1, e)) + ", ";
                    return `linear(${s.substring(0,s.length-2)})`
                };

            function y(t) {
                return Boolean("function" == typeof t && v() || !t || "string" == typeof t && (t in P || v()) || p(t) || Array.isArray(t) && t.every(y))
            }
            const x = ([t, e, i, s]) => `cubic-bezier(${t}, ${e}, ${i}, ${s})`,
                P = {
                    linear: "linear",
                    ease: "ease",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                    circIn: x([0, .65, .55, 1]),
                    circOut: x([.55, 0, 1, .45]),
                    backIn: x([.31, .01, .66, -.59]),
                    backOut: x([.33, 1.53, .69, .99])
                };

            function T(t, e) {
                return t ? "function" == typeof t && v() ? g(t, e) : p(t) ? x(t) : Array.isArray(t) ? t.map((t => T(t, e) || P.easeOut)) : P[t] : void 0
            }
            const S = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"],
                w = {
                    value: null,
                    addProjectionMetrics: null
                };

            function A(t, e) {
                let i = !1,
                    s = !0;
                const o = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    },
                    r = () => i = !0,
                    a = S.reduce(((t, i) => (t[i] = function(t, e) {
                        let i = new Set,
                            s = new Set,
                            n = !1,
                            o = !1;
                        const r = new WeakSet;
                        let a = {
                                delta: 0,
                                timestamp: 0,
                                isProcessing: !1
                            },
                            l = 0;

                        function h(e) {
                            r.has(e) && (u.schedule(e), t()), l++, e(a)
                        }
                        const u = {
                            schedule: (t, e = !1, o = !1) => {
                                const a = o && n ? i : s;
                                return e && r.add(t), a.has(t) || a.add(t), t
                            },
                            cancel: t => {
                                s.delete(t), r.delete(t)
                            },
                            process: t => {
                                a = t, n ? o = !0 : (n = !0, [i, s] = [s, i], i.forEach(h), e && w.value && w.value.frameloop[e].push(l), l = 0, i.clear(), n = !1, o && (o = !1, u.process(t)))
                            }
                        };
                        return u
                    }(r, e ? i : void 0), t)), {}),
                    {
                        read: l,
                        resolveKeyframes: h,
                        update: u,
                        preRender: c,
                        render: d,
                        postRender: p
                    } = a,
                    m = () => {
                        const r = n.W9.useManualTiming ? o.timestamp : performance.now();
                        i = !1, n.W9.useManualTiming || (o.delta = s ? 1e3 / 60 : Math.max(Math.min(r - o.timestamp, 40), 1)), o.timestamp = r, o.isProcessing = !0, l.process(o), h.process(o), u.process(o), c.process(o), d.process(o), p.process(o), o.isProcessing = !1, i && e && (s = !1, t(m))
                    };
                return {
                    schedule: S.reduce(((e, n) => {
                        const r = a[n];
                        return e[n] = (e, n = !1, a = !1) => (i || (i = !0, s = !0, o.isProcessing || t(m)), r.schedule(e, n, a)), e
                    }), {}),
                    cancel: t => {
                        for (let e = 0; e < S.length; e++) a[S[e]].cancel(t)
                    },
                    state: o,
                    steps: a
                }
            }
            const {
                schedule: b,
                cancel: D,
                state: E,
                steps: V
            } = A("undefined" != typeof requestAnimationFrame ? requestAnimationFrame : n.lQ, !0), {
                schedule: M,
                cancel: C
            } = A(queueMicrotask, !1);
            const R = {
                x: !1,
                y: !1
            };

            function k() {
                return R.x || R.y
            }

            function B(t, e) {
                const i = function(t, e, i) {
                        var s;
                        if (t instanceof EventTarget) return [t];
                        if ("string" == typeof t) {
                            let n = document;
                            e && (n = e.current);
                            const o = null !== (s = null == i ? void 0 : i[t]) && void 0 !== s ? s : n.querySelectorAll(t);
                            return o ? Array.from(o) : []
                        }
                        return Array.from(t)
                    }(t),
                    s = new AbortController;
                return [i, {
                    passive: !0,
                    ...e,
                    signal: s.signal
                }, () => s.abort()]
            }

            function L(t) {
                return !("touch" === t.pointerType || k())
            }

            function j(t, e) {
                const i = `${e}PointerCapture`;
                if (t.target instanceof Element && i in t.target && void 0 !== t.pointerId) try {
                    t.target[i](t.pointerId)
                } catch (t) {}
            }
            const F = (t, e) => !!e && (t === e || F(t, e.parentElement)),
                U = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary,
                O = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);
            const I = new WeakSet;

            function N(t) {
                return e => {
                    "Enter" === e.key && t(e)
                }
            }

            function G(t, e) {
                t.dispatchEvent(new PointerEvent("pointer" + e, {
                    isPrimary: !0,
                    bubbles: !0
                }))
            }

            function $(t) {
                return U(t) && !k()
            }

            function K(t, e, i = {}) {
                const [s, n, o] = B(t, i), r = t => {
                    const i = t.currentTarget;
                    if (!i || !$(t) || I.has(i)) return;
                    I.add(i), j(t, "set");
                    const s = e(i, t),
                        o = (t, e) => {
                            i.removeEventListener("pointerup", r), i.removeEventListener("pointercancel", a), j(t, "release"), $(t) && I.has(i) && (I.delete(i), "function" == typeof s && s(t, {
                                success: e
                            }))
                        },
                        r = t => {
                            const e = !!t.isTrusted && (s = t, n = i instanceof Element ? i.getBoundingClientRect() : {
                                left: 0,
                                top: 0,
                                right: window.innerWidth,
                                bottom: window.innerHeight
                            }, s.clientX < n.left || s.clientX > n.right || s.clientY < n.top || s.clientY > n.bottom);
                            var s, n;
                            o(t, !e && (!(i instanceof Element) || F(i, t.target)))
                        },
                        a = t => {
                            o(t, !1)
                        };
                    i.addEventListener("pointerup", r, n), i.addEventListener("pointercancel", a, n), i.addEventListener("lostpointercapture", a, n)
                };
                return s.forEach((t => {
                    let e = !1;
                    var s;
                    (t = i.useGlobalTarget ? window : t) instanceof HTMLElement && (e = !0, s = t, O.has(s.tagName) || -1 !== s.tabIndex || null !== t.getAttribute("tabindex") || (t.tabIndex = 0)), t.addEventListener("pointerdown", r, n), e && t.addEventListener("focus", (t => ((t, e) => {
                        const i = t.currentTarget;
                        if (!i) return;
                        const s = N((() => {
                            if (I.has(i)) return;
                            G(i, "down");
                            const t = N((() => {
                                G(i, "up")
                            }));
                            i.addEventListener("keyup", t, e), i.addEventListener("blur", (() => G(i, "cancel")), e)
                        }));
                        i.addEventListener("keydown", s, e), i.addEventListener("blur", (() => i.removeEventListener("keydown", s)), e)
                    })(t, n)), n)
                })), o
            }

            function W(t, e, i, s = {
                passive: !0
            }) {
                return t.addEventListener(e, i, s), () => t.removeEventListener(e, i)
            }

            function X(t) {
                return {
                    point: {
                        x: t.pageX,
                        y: t.pageY
                    }
                }
            }

            function q(t, e, i, s) {
                return W(t, e, (t => e => U(e) && t(e, X(e)))(i), s)
            }
            const z = (t, e) => Math.abs(t - e);
            const H = (t, e) => i => e(t(i)),
                Y = (...t) => t.reduce(H);
            var _ = i(7159);
            class Q {
                constructor(t, e, {
                    transformPagePoint: i,
                    contextWindow: s,
                    dragSnapToOrigin: n = !1
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                            if (!this.lastMoveEvent || !this.lastMoveEventInfo) return;
                            const t = tt(this.lastMoveEventInfo, this.history),
                                e = null !== this.startEvent,
                                i = function(t, e) {
                                    const i = z(t.x, e.x),
                                        s = z(t.y, e.y);
                                    return Math.sqrt(i ** 2 + s ** 2)
                                }(t.offset, {
                                    x: 0,
                                    y: 0
                                }) >= 3;
                            if (!e && !i) return;
                            const {
                                point: s
                            } = t, {
                                timestamp: n
                            } = _.uv;
                            this.history.push({ ...s,
                                timestamp: n
                            });
                            const {
                                onStart: o,
                                onMove: r
                            } = this.handlers;
                            e || (o && o(this.lastMoveEvent, t), this.startEvent = this.lastMoveEvent), r && r(this.lastMoveEvent, t)
                        }, this.handlePointerMove = (t, e) => {
                            this.lastMoveEvent = t, this.lastMoveEventInfo = Z(e, this.transformPagePoint), _.Gt.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (t, e) => {
                            this.end();
                            const {
                                onEnd: i,
                                onSessionEnd: s,
                                resumeAnimation: n
                            } = this.handlers;
                            if (this.dragSnapToOrigin && n && n(), !this.lastMoveEvent || !this.lastMoveEventInfo) return;
                            const o = tt("pointercancel" === t.type ? this.lastMoveEventInfo : Z(e, this.transformPagePoint), this.history);
                            this.startEvent && i && i(t, o), s && s(t, o)
                        }, !U(t)) return;
                    this.dragSnapToOrigin = n, this.handlers = e, this.transformPagePoint = i, this.contextWindow = s || window;
                    const o = Z(X(t), this.transformPagePoint),
                        {
                            point: r
                        } = o,
                        {
                            timestamp: a
                        } = _.uv;
                    this.history = [{ ...r,
                        timestamp: a
                    }];
                    const {
                        onSessionStart: l
                    } = e;
                    l && l(t, tt(o, this.history)), this.removeListeners = Y(q(this.contextWindow, "pointermove", this.handlePointerMove), q(this.contextWindow, "pointerup", this.handlePointerUp), q(this.contextWindow, "pointercancel", this.handlePointerUp))
                }
                updateHandlers(t) {
                    this.handlers = t
                }
                end() {
                    this.removeListeners && this.removeListeners(), (0, _.WG)(this.updatePoint)
                }
            }

            function Z(t, e) {
                return e ? {
                    point: e(t.point)
                } : t
            }

            function J(t, e) {
                return {
                    x: t.x - e.x,
                    y: t.y - e.y
                }
            }

            function tt({
                point: t
            }, e) {
                return {
                    point: t,
                    delta: J(t, it(e)),
                    offset: J(t, et(e)),
                    velocity: st(e, .1)
                }
            }

            function et(t) {
                return t[0]
            }

            function it(t) {
                return t[t.length - 1]
            }

            function st(t, e) {
                if (t.length < 2) return {
                    x: 0,
                    y: 0
                };
                let i = t.length - 1,
                    s = null;
                const o = it(t);
                for (; i >= 0 && (s = t[i], !(o.timestamp - s.timestamp > (0, n.fD)(e)));) i--;
                if (!s) return {
                    x: 0,
                    y: 0
                };
                const r = (0, n.Xu)(o.timestamp - s.timestamp);
                if (0 === r) return {
                    x: 0,
                    y: 0
                };
                const a = {
                    x: (o.x - s.x) / r,
                    y: (o.y - s.y) / r
                };
                return a.x === 1 / 0 && (a.x = 0), a.y === 1 / 0 && (a.y = 0), a
            }
            var nt = i(9522);
            const ot = (t, e, i) => t + (e - t) * i,
                rt = .9999,
                at = 1.0001,
                lt = -.01,
                ht = .01;

            function ut(t) {
                return t.max - t.min
            }

            function ct(t, e, i, s = .5) {
                t.origin = s, t.originPoint = ot(e.min, e.max, t.origin), t.scale = ut(i) / ut(e), t.translate = ot(i.min, i.max, t.origin) - t.originPoint, (t.scale >= rt && t.scale <= at || isNaN(t.scale)) && (t.scale = 1), (t.translate >= lt && t.translate <= ht || isNaN(t.translate)) && (t.translate = 0)
            }

            function dt(t, e, i, s) {
                ct(t.x, e.x, i.x, s ? s.originX : void 0), ct(t.y, e.y, i.y, s ? s.originY : void 0)
            }

            function pt(t, e, i) {
                t.min = i.min + e.min, t.max = t.min + ut(e)
            }

            function mt(t, e, i) {
                t.min = e.min - i.min, t.max = t.min + ut(e)
            }

            function ft(t, e, i) {
                mt(t.x, e.x, i.x), mt(t.y, e.y, i.y)
            }
            var vt = i(5859);

            function gt(t, e, i) {
                return {
                    min: void 0 !== e ? t.min + e : void 0,
                    max: void 0 !== i ? t.max + i - (t.max - t.min) : void 0
                }
            }

            function yt(t, e) {
                let i = e.min - t.min,
                    s = e.max - t.max;
                return e.max - e.min < t.max - t.min && ([i, s] = [s, i]), {
                    min: i,
                    max: s
                }
            }
            const xt = .35;

            function Pt(t, e, i) {
                return {
                    min: Tt(t, e),
                    max: Tt(t, i)
                }
            }

            function Tt(t, e) {
                return "number" == typeof t ? t : t[e] || 0
            }
            const St = () => ({
                    x: {
                        translate: 0,
                        scale: 1,
                        origin: 0,
                        originPoint: 0
                    },
                    y: {
                        translate: 0,
                        scale: 1,
                        origin: 0,
                        originPoint: 0
                    }
                }),
                wt = () => ({
                    x: {
                        min: 0,
                        max: 0
                    },
                    y: {
                        min: 0,
                        max: 0
                    }
                });

            function At(t) {
                return [t("x"), t("y")]
            }

            function bt({
                top: t,
                left: e,
                right: i,
                bottom: s
            }) {
                return {
                    x: {
                        min: e,
                        max: i
                    },
                    y: {
                        min: t,
                        max: s
                    }
                }
            }

            function Dt(t) {
                return void 0 === t || 1 === t
            }

            function Et({
                scale: t,
                scaleX: e,
                scaleY: i
            }) {
                return !Dt(t) || !Dt(e) || !Dt(i)
            }

            function Vt(t) {
                return Et(t) || Mt(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
            }

            function Mt(t) {
                return Ct(t.x) || Ct(t.y)
            }

            function Ct(t) {
                return t && "0%" !== t
            }

            function Rt(t, e, i) {
                return i + e * (t - i)
            }

            function kt(t, e, i, s, n) {
                return void 0 !== n && (t = Rt(t, n, s)), Rt(t, i, s) + e
            }

            function Bt(t, e = 0, i = 1, s, n) {
                t.min = kt(t.min, e, i, s, n), t.max = kt(t.max, e, i, s, n)
            }

            function Lt(t, {
                x: e,
                y: i
            }) {
                Bt(t.x, e.translate, e.scale, e.originPoint), Bt(t.y, i.translate, i.scale, i.originPoint)
            }
            const jt = .999999999999,
                Ft = 1.0000000000001;

            function Ut(t, e) {
                t.min = t.min + e, t.max = t.max + e
            }

            function Ot(t, e, i, s, n = .5) {
                Bt(t, e, i, ot(t.min, t.max, n), s)
            }

            function It(t, e) {
                Ot(t.x, e.x, e.scaleX, e.scale, e.originX), Ot(t.y, e.y, e.scaleY, e.scale, e.originY)
            }

            function Nt(t, e) {
                return bt(function(t, e) {
                    if (!e) return t;
                    const i = e({
                            x: t.left,
                            y: t.top
                        }),
                        s = e({
                            x: t.right,
                            y: t.bottom
                        });
                    return {
                        top: i.y,
                        left: i.x,
                        bottom: s.y,
                        right: s.x
                    }
                }(t.getBoundingClientRect(), e))
            }
            var Gt = i(7786),
                $t = i(2857);
            const Kt = !1,
                Wt = (t, e, i) => (((1 - 3 * i + 3 * e) * t + (3 * i - 6 * e)) * t + 3 * e) * t,
                Xt = 1e-7,
                qt = 12;

            function zt(t, e, i, s) {
                if (t === e && i === s) return n.lQ;
                const o = e => function(t, e, i, s, n) {
                    let o, r, a = 0;
                    do {
                        r = e + (i - e) / 2, o = Wt(r, s, n) - t, o > 0 ? i = r : e = r
                    } while (Math.abs(o) > Xt && ++a < qt);
                    return r
                }(e, 0, 1, t, i);
                return t => 0 === t || 1 === t ? t : Wt(o(t), e, s)
            }
            const Ht = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2,
                Yt = t => e => 1 - t(1 - e),
                _t = zt(.33, 1.53, .69, .99),
                Qt = Yt(_t),
                Zt = Ht(Qt),
                Jt = t => (t *= 2) < 1 ? .5 * Qt(t) : .5 * (2 - Math.pow(2, -10 * (t - 1))),
                te = t => 1 - Math.sin(Math.acos(t)),
                ee = Yt(te),
                ie = Ht(te),
                se = t => /^0[^.\s]+$/u.test(t);
            var ne = i(326);
            const oe = new Set(["width", "height", "top", "left", "right", "bottom", ...ne.U]);
            var re = i(6663);
            const ae = t => Math.round(1e5 * t) / 1e5,
                le = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
            const he = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
                ue = (t, e) => i => Boolean("string" == typeof i && he.test(i) && i.startsWith(t) || e && ! function(t) {
                    return null == t
                }(i) && Object.prototype.hasOwnProperty.call(i, e)),
                ce = (t, e, i) => s => {
                    if ("string" != typeof s) return s;
                    const [n, o, r, a] = s.match(le);
                    return {
                        [t]: parseFloat(n),
                        [e]: parseFloat(o),
                        [i]: parseFloat(r),
                        alpha: void 0 !== a ? parseFloat(a) : 1
                    }
                },
                de = { ...re.ai,
                    transform: t => Math.round((t => (0, vt.q)(0, 255, t))(t))
                },
                pe = {
                    test: ue("rgb", "red"),
                    parse: ce("red", "green", "blue"),
                    transform: ({
                        red: t,
                        green: e,
                        blue: i,
                        alpha: s = 1
                    }) => "rgba(" + de.transform(t) + ", " + de.transform(e) + ", " + de.transform(i) + ", " + ae(re.X4.transform(s)) + ")"
                };
            const me = {
                    test: ue("#"),
                    parse: function(t) {
                        let e = "",
                            i = "",
                            s = "",
                            n = "";
                        return t.length > 5 ? (e = t.substring(1, 3), i = t.substring(3, 5), s = t.substring(5, 7), n = t.substring(7, 9)) : (e = t.substring(1, 2), i = t.substring(2, 3), s = t.substring(3, 4), n = t.substring(4, 5), e += e, i += i, s += s, n += n), {
                            red: parseInt(e, 16),
                            green: parseInt(i, 16),
                            blue: parseInt(s, 16),
                            alpha: n ? parseInt(n, 16) / 255 : 1
                        }
                    },
                    transform: pe.transform
                },
                fe = {
                    test: ue("hsl", "hue"),
                    parse: ce("hue", "saturation", "lightness"),
                    transform: ({
                        hue: t,
                        saturation: e,
                        lightness: i,
                        alpha: s = 1
                    }) => "hsla(" + Math.round(t) + ", " + Gt.KN.transform(ae(e)) + ", " + Gt.KN.transform(ae(i)) + ", " + ae(re.X4.transform(s)) + ")"
                },
                ve = {
                    test: t => pe.test(t) || me.test(t) || fe.test(t),
                    parse: t => pe.test(t) ? pe.parse(t) : fe.test(t) ? fe.parse(t) : me.parse(t),
                    transform: t => "string" == typeof t ? t : t.hasOwnProperty("red") ? pe.transform(t) : fe.transform(t)
                },
                ge = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
            const ye = "number",
                xe = "color",
                Pe = "var",
                Te = "var(",
                Se = "${}",
                we = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

            function Ae(t) {
                const e = t.toString(),
                    i = [],
                    s = {
                        color: [],
                        number: [],
                        var: []
                    },
                    n = [];
                let o = 0;
                const r = e.replace(we, (t => (ve.test(t) ? (s.color.push(o), n.push(xe), i.push(ve.parse(t))) : t.startsWith(Te) ? (s.var.push(o), n.push(Pe), i.push(t)) : (s.number.push(o), n.push(ye), i.push(parseFloat(t))), ++o, Se))).split(Se);
                return {
                    values: i,
                    split: r,
                    indexes: s,
                    types: n
                }
            }

            function be(t) {
                return Ae(t).values
            }

            function De(t) {
                const {
                    split: e,
                    types: i
                } = Ae(t), s = e.length;
                return t => {
                    let n = "";
                    for (let o = 0; o < s; o++)
                        if (n += e[o], void 0 !== t[o]) {
                            const e = i[o];
                            n += e === ye ? ae(t[o]) : e === xe ? ve.transform(t[o]) : t[o]
                        }
                    return n
                }
            }
            const Ee = t => "number" == typeof t ? 0 : t;
            const Ve = {
                    test: function(t) {
                        var e, i;
                        return isNaN(t) && "string" == typeof t && ((null === (e = t.match(le)) || void 0 === e ? void 0 : e.length) || 0) + ((null === (i = t.match(ge)) || void 0 === i ? void 0 : i.length) || 0) > 0
                    },
                    parse: be,
                    createTransformer: De,
                    getAnimatableNone: function(t) {
                        const e = be(t);
                        return De(t)(e.map(Ee))
                    }
                },
                Me = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function Ce(t) {
                const [e, i] = t.slice(0, -1).split("(");
                if ("drop-shadow" === e) return t;
                const [s] = i.match(le) || [];
                if (!s) return t;
                const n = i.replace(s, "");
                let o = Me.has(e) ? 1 : 0;
                return s !== i && (o *= 100), e + "(" + o + n + ")"
            }
            const Re = /\b([a-z-]*)\(.*?\)/gu,
                ke = { ...Ve,
                    getAnimatableNone: t => {
                        const e = t.match(Re);
                        return e ? e.map(Ce).join(" ") : t
                    }
                };
            const Be = { ...i(604).W,
                    color: ve,
                    backgroundColor: ve,
                    outlineColor: ve,
                    fill: ve,
                    stroke: ve,
                    borderColor: ve,
                    borderTopColor: ve,
                    borderRightColor: ve,
                    borderBottomColor: ve,
                    borderLeftColor: ve,
                    filter: ke,
                    WebkitFilter: ke
                },
                Le = t => Be[t];

            function je(t, e) {
                let i = Le(t);
                return i !== ke && (i = Ve), i.getAnimatableNone ? i.getAnimatableNone(e) : void 0
            }
            const Fe = new Set(["auto", "none", "0"]);
            const Ue = t => t === re.ai || t === Gt.px,
                Oe = (t, e) => parseFloat(t.split(", ")[e]),
                Ie = (t, e) => (i, {
                    transform: s
                }) => {
                    if ("none" === s || !s) return 0;
                    const n = s.match(/^matrix3d\((.+)\)$/u);
                    if (n) return Oe(n[1], e); {
                        const e = s.match(/^matrix\((.+)\)$/u);
                        return e ? Oe(e[1], t) : 0
                    }
                },
                Ne = new Set(["x", "y", "z"]),
                Ge = ne.U.filter((t => !Ne.has(t)));
            const $e = {
                width: ({
                    x: t
                }, {
                    paddingLeft: e = "0",
                    paddingRight: i = "0"
                }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                height: ({
                    y: t
                }, {
                    paddingTop: e = "0",
                    paddingBottom: i = "0"
                }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                top: (t, {
                    top: e
                }) => parseFloat(e),
                left: (t, {
                    left: e
                }) => parseFloat(e),
                bottom: ({
                    y: t
                }, {
                    top: e
                }) => parseFloat(e) + (t.max - t.min),
                right: ({
                    x: t
                }, {
                    left: e
                }) => parseFloat(e) + (t.max - t.min),
                x: Ie(4, 13),
                y: Ie(5, 14)
            };
            $e.translateX = $e.x, $e.translateY = $e.y;
            const Ke = new Set;
            let We = !1,
                Xe = !1;

            function qe() {
                if (Xe) {
                    const t = Array.from(Ke).filter((t => t.needsMeasurement)),
                        e = new Set(t.map((t => t.element))),
                        i = new Map;
                    e.forEach((t => {
                        const e = function(t) {
                            const e = [];
                            return Ge.forEach((i => {
                                const s = t.getValue(i);
                                void 0 !== s && (e.push([i, s.get()]), s.set(i.startsWith("scale") ? 1 : 0))
                            })), e
                        }(t);
                        e.length && (i.set(t, e), t.render())
                    })), t.forEach((t => t.measureInitialState())), e.forEach((t => {
                        t.render();
                        const e = i.get(t);
                        e && e.forEach((([e, i]) => {
                            var s;
                            null === (s = t.getValue(e)) || void 0 === s || s.set(i)
                        }))
                    })), t.forEach((t => t.measureEndState())), t.forEach((t => {
                        void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
                    }))
                }
                Xe = !1, We = !1, Ke.forEach((t => t.complete())), Ke.clear()
            }

            function ze() {
                Ke.forEach((t => {
                    t.readKeyframes(), t.needsMeasurement && (Xe = !0)
                }))
            }
            class He {
                constructor(t, e, i, s, n, o = !1) {
                    this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = i, this.motionValue = s, this.element = n, this.isAsync = o
                }
                scheduleResolve() {
                    this.isScheduled = !0, this.isAsync ? (Ke.add(this), We || (We = !0, _.Gt.read(ze), _.Gt.resolveKeyframes(qe))) : (this.readKeyframes(), this.complete())
                }
                readKeyframes() {
                    const {
                        unresolvedKeyframes: t,
                        name: e,
                        element: i,
                        motionValue: s
                    } = this;
                    for (let n = 0; n < t.length; n++)
                        if (null === t[n])
                            if (0 === n) {
                                const n = null == s ? void 0 : s.get(),
                                    o = t[t.length - 1];
                                if (void 0 !== n) t[0] = n;
                                else if (i && e) {
                                    const s = i.readValue(e, o);
                                    null != s && (t[0] = s)
                                }
                                void 0 === t[0] && (t[0] = o), s && void 0 === n && s.set(t[0])
                            } else t[n] = t[n - 1]
                }
                setFinalKeyframe() {}
                measureInitialState() {}
                renderEndStyles() {}
                measureEndState() {}
                complete() {
                    this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), Ke.delete(this)
                }
                cancel() {
                    this.isComplete || (this.isScheduled = !1, Ke.delete(this))
                }
                resume() {
                    this.isComplete || this.scheduleResolve()
                }
            }
            const Ye = t => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t);
            var _e = i(5689);
            const Qe = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;

            function Ze(t, e, i = 1) {
                (0, n.V1)(i <= 4, `Max CSS variable fallback depth detected in property "${t}". This may indicate a circular fallback dependency.`);
                const [s, o] = function(t) {
                    const e = Qe.exec(t);
                    if (!e) return [, ];
                    const [, i, s, n] = e;
                    return [`--${null!=i?i:s}`, n]
                }(t);
                if (!s) return;
                const r = window.getComputedStyle(e).getPropertyValue(s);
                if (r) {
                    const t = r.trim();
                    return Ye(t) ? parseFloat(t) : t
                }
                return (0, _e.p)(o) ? Ze(o, e, i + 1) : o
            }
            const Je = t => e => e.test(t),
                ti = [re.ai, Gt.px, Gt.KN, Gt.uj, Gt.vw, Gt.vh, {
                    test: t => "auto" === t,
                    parse: t => t
                }],
                ei = t => ti.find(Je(t));
            class ii extends He {
                constructor(t, e, i, s, n) {
                    super(t, e, i, s, n, !0)
                }
                readKeyframes() {
                    const {
                        unresolvedKeyframes: t,
                        element: e,
                        name: i
                    } = this;
                    if (!e || !e.current) return;
                    super.readKeyframes();
                    for (let i = 0; i < t.length; i++) {
                        let s = t[i];
                        if ("string" == typeof s && (s = s.trim(), (0, _e.p)(s))) {
                            const n = Ze(s, e.current);
                            void 0 !== n && (t[i] = n), i === t.length - 1 && (this.finalKeyframe = s)
                        }
                    }
                    if (this.resolveNoneKeyframes(), !oe.has(i) || 2 !== t.length) return;
                    const [s, n] = t, o = ei(s), r = ei(n);
                    if (o !== r)
                        if (Ue(o) && Ue(r))
                            for (let e = 0; e < t.length; e++) {
                                const i = t[e];
                                "string" == typeof i && (t[e] = parseFloat(i))
                            } else this.needsMeasurement = !0
                }
                resolveNoneKeyframes() {
                    const {
                        unresolvedKeyframes: t,
                        name: e
                    } = this, i = [];
                    for (let e = 0; e < t.length; e++)("number" == typeof(s = t[e]) ? 0 === s : null === s || "none" === s || "0" === s || se(s)) && i.push(e);
                    var s;
                    i.length && function(t, e, i) {
                        let s, n = 0;
                        for (; n < t.length && !s;) {
                            const e = t[n];
                            "string" == typeof e && !Fe.has(e) && Ae(e).values.length && (s = t[n]), n++
                        }
                        if (s && i)
                            for (const n of e) t[n] = je(i, s)
                    }(t, i, e)
                }
                measureInitialState() {
                    const {
                        element: t,
                        unresolvedKeyframes: e,
                        name: i
                    } = this;
                    if (!t || !t.current) return;
                    "height" === i && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = $e[i](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
                    const s = e[e.length - 1];
                    void 0 !== s && t.getValue(i, s).jump(s, !1)
                }
                measureEndState() {
                    var t;
                    const {
                        element: e,
                        name: i,
                        unresolvedKeyframes: s
                    } = this;
                    if (!e || !e.current) return;
                    const n = e.getValue(i);
                    n && n.jump(this.measuredOrigin, !1);
                    const o = s.length - 1,
                        r = s[o];
                    s[o] = $e[i](e.measureViewportBox(), window.getComputedStyle(e.current)), null !== r && void 0 === this.finalKeyframe && (this.finalKeyframe = r), (null === (t = this.removedTransforms) || void 0 === t ? void 0 : t.length) && this.removedTransforms.forEach((([t, i]) => {
                        e.getValue(t).set(i)
                    })), this.resolveNoneKeyframes()
                }
            }
            let si;

            function ni() {
                si = void 0
            }
            const oi = {
                    now: () => (void 0 === si && oi.set(_.uv.isProcessing || $t.W.useManualTiming ? _.uv.timestamp : performance.now()), si),
                    set: t => {
                        si = t, queueMicrotask(ni)
                    }
                },
                ri = (t, e) => "zIndex" !== e && (!("number" != typeof t && !Array.isArray(t)) || !("string" != typeof t || !Ve.test(t) && "0" !== t || t.startsWith("url(")));

            function ai(t, e, i, s) {
                const o = t[0];
                if (null === o) return !1;
                if ("display" === e || "visibility" === e) return !0;
                const r = t[t.length - 1],
                    a = ri(o, e),
                    l = ri(r, e);
                return (0, n.$e)(a === l, `You are trying to animate ${e} from "${o}" to "${r}". ${o} is not an animatable value - to enable this animation set ${o} to a value animatable to ${r} via the \`style\` property.`), !(!a || !l) && (function(t) {
                    const e = t[0];
                    if (1 === t.length) return !0;
                    for (let i = 0; i < t.length; i++)
                        if (t[i] !== e) return !0
                }(t) || ("spring" === i || c(i)) && s)
            }
            const li = t => null !== t;

            function hi(t, {
                repeat: e,
                repeatType: i = "loop"
            }, s) {
                const n = t.filter(li),
                    o = e && "loop" !== i && e % 2 == 1 ? 0 : n.length - 1;
                return o && void 0 !== s ? s : n[o]
            }
            class ui {
                constructor({
                    autoplay: t = !0,
                    delay: e = 0,
                    type: i = "keyframes",
                    repeat: s = 0,
                    repeatDelay: n = 0,
                    repeatType: o = "loop",
                    ...r
                }) {
                    this.isStopped = !1, this.hasAttemptedResolve = !1, this.createdAt = oi.now(), this.options = {
                        autoplay: t,
                        delay: e,
                        type: i,
                        repeat: s,
                        repeatDelay: n,
                        repeatType: o,
                        ...r
                    }, this.updateFinishedPromise()
                }
                calcStartTime() {
                    return this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt
                }
                get resolved() {
                    return this._resolved || this.hasAttemptedResolve || (ze(), qe()), this._resolved
                }
                onKeyframesResolved(t, e) {
                    this.resolvedAt = oi.now(), this.hasAttemptedResolve = !0;
                    const {
                        name: i,
                        type: s,
                        velocity: n,
                        delay: o,
                        onComplete: r,
                        onUpdate: a,
                        isGenerator: l
                    } = this.options;
                    if (!l && !ai(t, i, s, n)) {
                        if (Kt || !o) return a && a(hi(t, this.options, e)), r && r(), void this.resolveFinishedPromise();
                        this.options.duration = 0
                    }
                    const h = this.initPlayback(t, e);
                    !1 !== h && (this._resolved = {
                        keyframes: t,
                        finalKeyframe: e,
                        ...h
                    }, this.onPostResolved())
                }
                onPostResolved() {}
                then(t, e) {
                    return this.currentFinishedPromise.then(t, e)
                }
                flatten() {
                    this.options.type = "keyframes", this.options.ease = "linear"
                }
                updateFinishedPromise() {
                    this.currentFinishedPromise = new Promise((t => {
                        this.resolveFinishedPromise = t
                    }))
                }
            }

            function ci(t, e, i) {
                return i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6 ? t + 6 * (e - t) * i : i < .5 ? e : i < 2 / 3 ? t + (e - t) * (2 / 3 - i) * 6 : t
            }

            function di(t, e) {
                return i => i > 0 ? e : t
            }
            const pi = (t, e, i) => {
                    const s = t * t,
                        n = i * (e * e - s) + s;
                    return n < 0 ? 0 : Math.sqrt(n)
                },
                mi = [me, pe, fe];

            function fi(t) {
                const e = (i = t, mi.find((t => t.test(i))));
                var i;
                if ((0, n.$e)(Boolean(e), `'${t}' is not an animatable color. Use the equivalent color code instead.`), !Boolean(e)) return !1;
                let s = e.parse(t);
                return e === fe && (s = function({
                    hue: t,
                    saturation: e,
                    lightness: i,
                    alpha: s
                }) {
                    t /= 360, i /= 100;
                    let n = 0,
                        o = 0,
                        r = 0;
                    if (e /= 100) {
                        const s = i < .5 ? i * (1 + e) : i + e - i * e,
                            a = 2 * i - s;
                        n = ci(a, s, t + 1 / 3), o = ci(a, s, t), r = ci(a, s, t - 1 / 3)
                    } else n = o = r = i;
                    return {
                        red: Math.round(255 * n),
                        green: Math.round(255 * o),
                        blue: Math.round(255 * r),
                        alpha: s
                    }
                }(s)), s
            }
            const vi = (t, e) => {
                    const i = fi(t),
                        s = fi(e);
                    if (!i || !s) return di(t, e);
                    const n = { ...i
                    };
                    return t => (n.red = pi(i.red, s.red, t), n.green = pi(i.green, s.green, t), n.blue = pi(i.blue, s.blue, t), n.alpha = ot(i.alpha, s.alpha, t), pe.transform(n))
                },
                gi = new Set(["none", "hidden"]);

            function yi(t, e) {
                return i => ot(t, e, i)
            }

            function xi(t) {
                return "number" == typeof t ? yi : "string" == typeof t ? (0, _e.p)(t) ? di : ve.test(t) ? vi : Si : Array.isArray(t) ? Pi : "object" == typeof t ? ve.test(t) ? vi : Ti : di
            }

            function Pi(t, e) {
                const i = [...t],
                    s = i.length,
                    n = t.map(((t, i) => xi(t)(t, e[i])));
                return t => {
                    for (let e = 0; e < s; e++) i[e] = n[e](t);
                    return i
                }
            }

            function Ti(t, e) {
                const i = { ...t,
                        ...e
                    },
                    s = {};
                for (const n in i) void 0 !== t[n] && void 0 !== e[n] && (s[n] = xi(t[n])(t[n], e[n]));
                return t => {
                    for (const e in s) i[e] = s[e](t);
                    return i
                }
            }
            const Si = (t, e) => {
                const i = Ve.createTransformer(e),
                    s = Ae(t),
                    o = Ae(e);
                return s.indexes.var.length === o.indexes.var.length && s.indexes.color.length === o.indexes.color.length && s.indexes.number.length >= o.indexes.number.length ? gi.has(t) && !o.values.length || gi.has(e) && !s.values.length ? function(t, e) {
                    return gi.has(t) ? i => i <= 0 ? t : e : i => i >= 1 ? e : t
                }(t, e) : Y(Pi(function(t, e) {
                    var i;
                    const s = [],
                        n = {
                            color: 0,
                            var: 0,
                            number: 0
                        };
                    for (let o = 0; o < e.values.length; o++) {
                        const r = e.types[o],
                            a = t.indexes[r][n[r]],
                            l = null !== (i = t.values[a]) && void 0 !== i ? i : 0;
                        s[o] = l, n[r]++
                    }
                    return s
                }(s, o), o.values), i) : ((0, n.$e)(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), di(t, e))
            };

            function wi(t, e, i) {
                if ("number" == typeof t && "number" == typeof e && "number" == typeof i) return ot(t, e, i);
                return xi(t)(t, e)
            }

            function Ai(t, e) {
                return e ? t * (1e3 / e) : 0
            }
            const bi = 5;

            function Di(t, e, i) {
                const s = Math.max(e - bi, 0);
                return Ai(i - t(s), e - s)
            }
            const Ei = {
                    stiffness: 100,
                    damping: 10,
                    mass: 1,
                    velocity: 0,
                    duration: 800,
                    bounce: .3,
                    visualDuration: .3,
                    restSpeed: {
                        granular: .01,
                        default: 2
                    },
                    restDelta: {
                        granular: .005,
                        default: .5
                    },
                    minDuration: .01,
                    maxDuration: 10,
                    minDamping: .05,
                    maxDamping: 1
                },
                Vi = .001;

            function Mi({
                duration: t = Ei.duration,
                bounce: e = Ei.bounce,
                velocity: i = Ei.velocity,
                mass: s = Ei.mass
            }) {
                let o, r;
                (0, n.$e)(t <= (0, n.fD)(Ei.maxDuration), "Spring duration must be 10 seconds or less");
                let a = 1 - e;
                a = (0, vt.q)(Ei.minDamping, Ei.maxDamping, a), t = (0, vt.q)(Ei.minDuration, Ei.maxDuration, (0, n.Xu)(t)), a < 1 ? (o = e => {
                    const s = e * a,
                        n = s * t,
                        o = s - i,
                        r = Ri(e, a),
                        l = Math.exp(-n);
                    return Vi - o / r * l
                }, r = e => {
                    const s = e * a * t,
                        n = s * i + i,
                        r = Math.pow(a, 2) * Math.pow(e, 2) * t,
                        l = Math.exp(-s),
                        h = Ri(Math.pow(e, 2), a);
                    return (-o(e) + Vi > 0 ? -1 : 1) * ((n - r) * l) / h
                }) : (o = e => Math.exp(-e * t) * ((e - i) * t + 1) - Vi, r = e => Math.exp(-e * t) * (t * t * (i - e)));
                const l = function(t, e, i) {
                    let s = i;
                    for (let i = 1; i < Ci; i++) s -= t(s) / e(s);
                    return s
                }(o, r, 5 / t);
                if (t = (0, n.fD)(t), isNaN(l)) return {
                    stiffness: Ei.stiffness,
                    damping: Ei.damping,
                    duration: t
                }; {
                    const e = Math.pow(l, 2) * s;
                    return {
                        stiffness: e,
                        damping: 2 * a * Math.sqrt(s * e),
                        duration: t
                    }
                }
            }
            const Ci = 12;

            function Ri(t, e) {
                return t * Math.sqrt(1 - e * e)
            }
            const ki = ["duration", "bounce"],
                Bi = ["stiffness", "damping", "mass"];

            function Li(t, e) {
                return e.some((e => void 0 !== t[e]))
            }

            function ji(t = Ei.visualDuration, e = Ei.bounce) {
                const i = "object" != typeof t ? {
                    visualDuration: t,
                    keyframes: [0, 1],
                    bounce: e
                } : t;
                let {
                    restSpeed: s,
                    restDelta: o
                } = i;
                const r = i.keyframes[0],
                    a = i.keyframes[i.keyframes.length - 1],
                    l = {
                        done: !1,
                        value: r
                    },
                    {
                        stiffness: c,
                        damping: d,
                        mass: p,
                        duration: m,
                        velocity: f,
                        isResolvedFromDuration: v
                    } = function(t) {
                        let e = {
                            velocity: Ei.velocity,
                            stiffness: Ei.stiffness,
                            damping: Ei.damping,
                            mass: Ei.mass,
                            isResolvedFromDuration: !1,
                            ...t
                        };
                        if (!Li(t, Bi) && Li(t, ki))
                            if (t.visualDuration) {
                                const i = t.visualDuration,
                                    s = 2 * Math.PI / (1.2 * i),
                                    n = s * s,
                                    o = 2 * (0, vt.q)(.05, 1, 1 - (t.bounce || 0)) * Math.sqrt(n);
                                e = { ...e,
                                    mass: Ei.mass,
                                    stiffness: n,
                                    damping: o
                                }
                            } else {
                                const i = Mi(t);
                                e = { ...e,
                                    ...i,
                                    mass: Ei.mass
                                }, e.isResolvedFromDuration = !0
                            }
                        return e
                    }({ ...i,
                        velocity: -(0, n.Xu)(i.velocity || 0)
                    }),
                    y = f || 0,
                    x = d / (2 * Math.sqrt(c * p)),
                    P = a - r,
                    T = (0, n.Xu)(Math.sqrt(c / p)),
                    S = Math.abs(P) < 5;
                let w;
                if (s || (s = S ? Ei.restSpeed.granular : Ei.restSpeed.default), o || (o = S ? Ei.restDelta.granular : Ei.restDelta.default), x < 1) {
                    const t = Ri(T, x);
                    w = e => {
                        const i = Math.exp(-x * T * e);
                        return a - i * ((y + x * T * P) / t * Math.sin(t * e) + P * Math.cos(t * e))
                    }
                } else if (1 === x) w = t => a - Math.exp(-T * t) * (P + (y + T * P) * t);
                else {
                    const t = T * Math.sqrt(x * x - 1);
                    w = e => {
                        const i = Math.exp(-x * T * e),
                            s = Math.min(t * e, 300);
                        return a - i * ((y + x * T * P) * Math.sinh(s) + t * P * Math.cosh(s)) / t
                    }
                }
                const A = {
                    calculatedDuration: v && m || null,
                    next: t => {
                        const e = w(t);
                        if (v) l.done = t >= m;
                        else {
                            let i = 0;
                            x < 1 && (i = 0 === t ? (0, n.fD)(y) : Di(w, t, e));
                            const r = Math.abs(i) <= s,
                                h = Math.abs(a - e) <= o;
                            l.done = r && h
                        }
                        return l.value = l.done ? a : e, l
                    },
                    toString: () => {
                        const t = Math.min(u(A), h),
                            e = g((e => A.next(t * e).value), t, 30);
                        return t + "ms " + e
                    }
                };
                return A
            }

            function Fi({
                keyframes: t,
                velocity: e = 0,
                power: i = .8,
                timeConstant: s = 325,
                bounceDamping: n = 10,
                bounceStiffness: o = 500,
                modifyTarget: r,
                min: a,
                max: l,
                restDelta: h = .5,
                restSpeed: u
            }) {
                const c = t[0],
                    d = {
                        done: !1,
                        value: c
                    },
                    p = t => void 0 === a ? l : void 0 === l || Math.abs(a - t) < Math.abs(l - t) ? a : l;
                let m = i * e;
                const f = c + m,
                    v = void 0 === r ? f : r(f);
                v !== f && (m = v - c);
                const g = t => -m * Math.exp(-t / s),
                    y = t => v + g(t),
                    x = t => {
                        const e = g(t),
                            i = y(t);
                        d.done = Math.abs(e) <= h, d.value = d.done ? v : i
                    };
                let P, T;
                const S = t => {
                    var e;
                    (e = d.value, void 0 !== a && e < a || void 0 !== l && e > l) && (P = t, T = ji({
                        keyframes: [d.value, p(d.value)],
                        velocity: Di(y, t, d.value),
                        damping: n,
                        stiffness: o,
                        restDelta: h,
                        restSpeed: u
                    }))
                };
                return S(0), {
                    calculatedDuration: null,
                    next: t => {
                        let e = !1;
                        return T || void 0 !== P || (e = !0, x(t), S(t)), void 0 !== P && t >= P ? T.next(t - P) : (!e && x(t), d)
                    }
                }
            }
            const Ui = zt(.42, 0, 1, 1),
                Oi = zt(0, 0, .58, 1),
                Ii = zt(.42, 0, .58, 1),
                Ni = {
                    linear: n.lQ,
                    easeIn: Ui,
                    easeInOut: Ii,
                    easeOut: Oi,
                    circIn: te,
                    circInOut: ie,
                    circOut: ee,
                    backIn: Qt,
                    backInOut: Zt,
                    backOut: _t,
                    anticipate: Jt
                },
                Gi = t => {
                    if (p(t)) {
                        (0, n.V1)(4 === t.length, "Cubic bezier arrays must contain four numerical values.");
                        const [e, i, s, o] = t;
                        return zt(e, i, s, o)
                    }
                    return "string" == typeof t ? ((0, n.V1)(void 0 !== Ni[t], `Invalid easing type '${t}'`), Ni[t]) : t
                };

            function $i(t, e, {
                clamp: i = !0,
                ease: s,
                mixer: o
            } = {}) {
                const r = t.length;
                if ((0, n.V1)(r === e.length, "Both input and output ranges must be the same length"), 1 === r) return () => e[0];
                if (2 === r && e[0] === e[1]) return () => e[1];
                const a = t[0] === t[1];
                t[0] > t[r - 1] && (t = [...t].reverse(), e = [...e].reverse());
                const l = function(t, e, i) {
                        const s = [],
                            o = i || wi,
                            r = t.length - 1;
                        for (let i = 0; i < r; i++) {
                            let r = o(t[i], t[i + 1]);
                            if (e) {
                                const t = Array.isArray(e) ? e[i] || n.lQ : e;
                                r = Y(t, r)
                            }
                            s.push(r)
                        }
                        return s
                    }(e, s, o),
                    h = l.length,
                    u = i => {
                        if (a && i < t[0]) return e[0];
                        let s = 0;
                        if (h > 1)
                            for (; s < t.length - 2 && !(i < t[s + 1]); s++);
                        const o = (0, n.qB)(t[s], t[s + 1], i);
                        return l[s](o)
                    };
                return i ? e => u((0, vt.q)(t[0], t[r - 1], e)) : u
            }

            function Ki(t) {
                const e = [0];
                return function(t, e) {
                    const i = t[t.length - 1];
                    for (let s = 1; s <= e; s++) {
                        const o = (0, n.qB)(0, e, s);
                        t.push(ot(i, 1, o))
                    }
                }(e, t.length - 1), e
            }

            function Wi({
                duration: t = 300,
                keyframes: e,
                times: i,
                ease: s = "easeInOut"
            }) {
                const n = (t => Array.isArray(t) && "number" != typeof t[0])(s) ? s.map(Gi) : Gi(s),
                    o = {
                        done: !1,
                        value: e[0]
                    },
                    r = function(t, e) {
                        return t.map((t => t * e))
                    }(i && i.length === e.length ? i : Ki(e), t),
                    a = $i(r, e, {
                        ease: Array.isArray(n) ? n : (l = e, h = n, l.map((() => h || Ii)).splice(0, l.length - 1))
                    });
                var l, h;
                return {
                    calculatedDuration: t,
                    next: e => (o.value = a(e), o.done = e >= t, o)
                }
            }
            const Xi = t => {
                    const e = ({
                        timestamp: e
                    }) => t(e);
                    return {
                        start: () => _.Gt.update(e, !0),
                        stop: () => (0, _.WG)(e),
                        now: () => _.uv.isProcessing ? _.uv.timestamp : oi.now()
                    }
                },
                qi = {
                    decay: Fi,
                    inertia: Fi,
                    tween: Wi,
                    keyframes: Wi,
                    spring: ji
                },
                zi = t => t / 100;
            class Hi extends ui {
                constructor(t) {
                    super(t), this.holdTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.startTime = null, this.state = "idle", this.stop = () => {
                        if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                        this.teardown();
                        const {
                            onStop: t
                        } = this.options;
                        t && t()
                    };
                    const {
                        name: e,
                        motionValue: i,
                        element: s,
                        keyframes: n
                    } = this.options, o = (null == s ? void 0 : s.KeyframeResolver) || He;
                    this.resolver = new o(n, ((t, e) => this.onKeyframesResolved(t, e)), e, i, s), this.resolver.scheduleResolve()
                }
                flatten() {
                    super.flatten(), this._resolved && Object.assign(this._resolved, this.initPlayback(this._resolved.keyframes))
                }
                initPlayback(t) {
                    const {
                        type: e = "keyframes",
                        repeat: i = 0,
                        repeatDelay: s = 0,
                        repeatType: n,
                        velocity: o = 0
                    } = this.options, r = c(e) ? e : qi[e] || Wi;
                    let a, l;
                    r !== Wi && "number" != typeof t[0] && (a = Y(zi, wi(t[0], t[1])), t = [0, 100]);
                    const h = r({ ...this.options,
                        keyframes: t
                    });
                    "mirror" === n && (l = r({ ...this.options,
                        keyframes: [...t].reverse(),
                        velocity: -o
                    })), null === h.calculatedDuration && (h.calculatedDuration = u(h));
                    const {
                        calculatedDuration: d
                    } = h, p = d + s;
                    return {
                        generator: h,
                        mirroredGenerator: l,
                        mapPercentToKeyframes: a,
                        calculatedDuration: d,
                        resolvedDuration: p,
                        totalDuration: p * (i + 1) - s
                    }
                }
                onPostResolved() {
                    const {
                        autoplay: t = !0
                    } = this.options;
                    this.play(), "paused" !== this.pendingPlayState && t ? this.state = this.pendingPlayState : this.pause()
                }
                tick(t, e = !1) {
                    const {
                        resolved: i
                    } = this;
                    if (!i) {
                        const {
                            keyframes: t
                        } = this.options;
                        return {
                            done: !0,
                            value: t[t.length - 1]
                        }
                    }
                    const {
                        finalKeyframe: s,
                        generator: n,
                        mirroredGenerator: o,
                        mapPercentToKeyframes: r,
                        keyframes: a,
                        calculatedDuration: l,
                        totalDuration: h,
                        resolvedDuration: u
                    } = i;
                    if (null === this.startTime) return n.next(0);
                    const {
                        delay: c,
                        repeat: d,
                        repeatType: p,
                        repeatDelay: m,
                        onUpdate: f
                    } = this.options;
                    this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - h / this.speed, this.startTime)), e ? this.currentTime = t : null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = Math.round(t - this.startTime) * this.speed;
                    const v = this.currentTime - c * (this.speed >= 0 ? 1 : -1),
                        g = this.speed >= 0 ? v < 0 : v > h;
                    this.currentTime = Math.max(v, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = h);
                    let y = this.currentTime,
                        x = n;
                    if (d) {
                        const t = Math.min(this.currentTime, h) / u;
                        let e = Math.floor(t),
                            i = t % 1;
                        !i && t >= 1 && (i = 1), 1 === i && e--, e = Math.min(e, d + 1);
                        Boolean(e % 2) && ("reverse" === p ? (i = 1 - i, m && (i -= m / u)) : "mirror" === p && (x = o)), y = (0, vt.q)(0, 1, i) * u
                    }
                    const P = g ? {
                        done: !1,
                        value: a[0]
                    } : x.next(y);
                    r && (P.value = r(P.value));
                    let {
                        done: T
                    } = P;
                    g || null === l || (T = this.speed >= 0 ? this.currentTime >= h : this.currentTime <= 0);
                    const S = null === this.holdTime && ("finished" === this.state || "running" === this.state && T);
                    return S && void 0 !== s && (P.value = hi(a, this.options, s)), f && f(P.value), S && this.finish(), P
                }
                get duration() {
                    const {
                        resolved: t
                    } = this;
                    return t ? (0, n.Xu)(t.calculatedDuration) : 0
                }
                get time() {
                    return (0, n.Xu)(this.currentTime)
                }
                set time(t) {
                    t = (0, n.fD)(t), this.currentTime = t, null !== this.holdTime || 0 === this.speed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.speed)
                }
                get speed() {
                    return this.playbackSpeed
                }
                set speed(t) {
                    const e = this.playbackSpeed !== t;
                    this.playbackSpeed = t, e && (this.time = (0, n.Xu)(this.currentTime))
                }
                play() {
                    if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) return void(this.pendingPlayState = "running");
                    if (this.isStopped) return;
                    const {
                        driver: t = Xi,
                        onPlay: e,
                        startTime: i
                    } = this.options;
                    this.driver || (this.driver = t((t => this.tick(t)))), e && e();
                    const s = this.driver.now();
                    null !== this.holdTime ? this.startTime = s - this.holdTime : this.startTime ? "finished" === this.state && (this.startTime = s) : this.startTime = null != i ? i : this.calcStartTime(), "finished" === this.state && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
                }
                pause() {
                    var t;
                    this._resolved ? (this.state = "paused", this.holdTime = null !== (t = this.currentTime) && void 0 !== t ? t : 0) : this.pendingPlayState = "paused"
                }
                complete() {
                    "running" !== this.state && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
                }
                finish() {
                    this.teardown(), this.state = "finished";
                    const {
                        onComplete: t
                    } = this.options;
                    t && t()
                }
                cancel() {
                    null !== this.cancelTime && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
                }
                teardown() {
                    this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
                }
                stopDriver() {
                    this.driver && (this.driver.stop(), this.driver = void 0)
                }
                sample(t) {
                    return this.startTime = 0, this.tick(t, !0)
                }
            }
            const Yi = new Set(["opacity", "clipPath", "filter", "transform"]);
            const _i = (0, n.ph)((() => Object.hasOwnProperty.call(Element.prototype, "animate")));
            const Qi = {
                anticipate: Jt,
                backInOut: Zt,
                circInOut: ie
            };
            class Zi extends ui {
                constructor(t) {
                    super(t);
                    const {
                        name: e,
                        motionValue: i,
                        element: s,
                        keyframes: n
                    } = this.options;
                    this.resolver = new ii(n, ((t, e) => this.onKeyframesResolved(t, e)), e, i, s), this.resolver.scheduleResolve()
                }
                initPlayback(t, e) {
                    let {
                        duration: i = 300,
                        times: s,
                        ease: n,
                        type: o,
                        motionValue: r,
                        name: a,
                        startTime: l
                    } = this.options;
                    if (!r.owner || !r.owner.current) return !1;
                    var h;
                    if ("string" == typeof n && v() && n in Qi && (n = Qi[n]), c((h = this.options).type) || "spring" === h.type || !y(h.ease)) {
                        const {
                            onComplete: e,
                            onUpdate: r,
                            motionValue: a,
                            element: l,
                            ...h
                        } = this.options, u = function(t, e) {
                            const i = new Hi({ ...e,
                                keyframes: t,
                                repeat: 0,
                                delay: 0,
                                isGenerator: !0
                            });
                            let s = {
                                done: !1,
                                value: t[0]
                            };
                            const n = [];
                            let o = 0;
                            for (; !s.done && o < 2e4;) s = i.sample(o), n.push(s.value), o += 10;
                            return {
                                times: void 0,
                                keyframes: n,
                                duration: o - 10,
                                ease: "linear"
                            }
                        }(t, h);
                        1 === (t = u.keyframes).length && (t[1] = t[0]), i = u.duration, s = u.times, n = u.ease, o = "keyframes"
                    }
                    const u = function(t, e, i, {
                        delay: s = 0,
                        duration: n = 300,
                        repeat: o = 0,
                        repeatType: r = "loop",
                        ease: a = "easeInOut",
                        times: l
                    } = {}) {
                        const h = {
                            [e]: i
                        };
                        l && (h.offset = l);
                        const u = T(a, n);
                        return Array.isArray(u) && (h.easing = u), t.animate(h, {
                            delay: s,
                            duration: n,
                            easing: Array.isArray(u) ? "linear" : u,
                            fill: "both",
                            iterations: o + 1,
                            direction: "reverse" === r ? "alternate" : "normal"
                        })
                    }(r.owner.current, a, t, { ...this.options,
                        duration: i,
                        times: s,
                        ease: n
                    });
                    return u.startTime = null != l ? l : this.calcStartTime(), this.pendingTimeline ? (d(u, this.pendingTimeline), this.pendingTimeline = void 0) : u.onfinish = () => {
                        const {
                            onComplete: i
                        } = this.options;
                        r.set(hi(t, this.options, e)), i && i(), this.cancel(), this.resolveFinishedPromise()
                    }, {
                        animation: u,
                        duration: i,
                        times: s,
                        type: o,
                        ease: n,
                        keyframes: t
                    }
                }
                get duration() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    const {
                        duration: e
                    } = t;
                    return (0, n.Xu)(e)
                }
                get time() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    const {
                        animation: e
                    } = t;
                    return (0, n.Xu)(e.currentTime || 0)
                }
                set time(t) {
                    const {
                        resolved: e
                    } = this;
                    if (!e) return;
                    const {
                        animation: i
                    } = e;
                    i.currentTime = (0, n.fD)(t)
                }
                get speed() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return 1;
                    const {
                        animation: e
                    } = t;
                    return e.playbackRate
                }
                set speed(t) {
                    const {
                        resolved: e
                    } = this;
                    if (!e) return;
                    const {
                        animation: i
                    } = e;
                    i.playbackRate = t
                }
                get state() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return "idle";
                    const {
                        animation: e
                    } = t;
                    return e.playState
                }
                get startTime() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return null;
                    const {
                        animation: e
                    } = t;
                    return e.startTime
                }
                attachTimeline(t) {
                    if (this._resolved) {
                        const {
                            resolved: e
                        } = this;
                        if (!e) return n.lQ;
                        const {
                            animation: i
                        } = e;
                        d(i, t)
                    } else this.pendingTimeline = t;
                    return n.lQ
                }
                play() {
                    if (this.isStopped) return;
                    const {
                        resolved: t
                    } = this;
                    if (!t) return;
                    const {
                        animation: e
                    } = t;
                    "finished" === e.playState && this.updateFinishedPromise(), e.play()
                }
                pause() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return;
                    const {
                        animation: e
                    } = t;
                    e.pause()
                }
                stop() {
                    if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                    this.resolveFinishedPromise(), this.updateFinishedPromise();
                    const {
                        resolved: t
                    } = this;
                    if (!t) return;
                    const {
                        animation: e,
                        keyframes: i,
                        duration: s,
                        type: o,
                        ease: r,
                        times: a
                    } = t;
                    if ("idle" === e.playState || "finished" === e.playState) return;
                    if (this.time) {
                        const {
                            motionValue: t,
                            onUpdate: e,
                            onComplete: l,
                            element: h,
                            ...u
                        } = this.options, c = new Hi({ ...u,
                            keyframes: i,
                            duration: s,
                            type: o,
                            ease: r,
                            times: a,
                            isGenerator: !0
                        }), d = (0, n.fD)(this.time);
                        t.setWithVelocity(c.sample(d - 10).value, c.sample(d).value, 10)
                    }
                    const {
                        onStop: l
                    } = this.options;
                    l && l(), this.cancel()
                }
                complete() {
                    const {
                        resolved: t
                    } = this;
                    t && t.animation.finish()
                }
                cancel() {
                    const {
                        resolved: t
                    } = this;
                    t && t.animation.cancel()
                }
                static supports(t) {
                    const {
                        motionValue: e,
                        name: i,
                        repeatDelay: s,
                        repeatType: n,
                        damping: o,
                        type: r
                    } = t;
                    if (!(e && e.owner && e.owner.current instanceof HTMLElement)) return !1;
                    const {
                        onUpdate: a,
                        transformTemplate: l
                    } = e.owner.getProps();
                    return _i() && i && Yi.has(i) && !a && !l && !s && "mirror" !== n && 0 !== o && "inertia" !== r
                }
            }
            const Ji = {
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                },
                ts = {
                    type: "keyframes",
                    duration: .8
                },
                es = {
                    type: "keyframes",
                    ease: [.25, .1, .35, 1],
                    duration: .3
                },
                is = (t, {
                    keyframes: e
                }) => e.length > 2 ? ts : ne.f.has(t) ? t.startsWith("scale") ? {
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === e[1] ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                } : Ji : es;
            const ss = (t, e, i, s = {}, o, r) => h => {
                    const u = l(s, t) || {},
                        c = u.delay || s.delay || 0;
                    let {
                        elapsed: d = 0
                    } = s;
                    d -= (0, n.fD)(c);
                    let p = {
                        keyframes: Array.isArray(i) ? i : [null, i],
                        ease: "easeOut",
                        velocity: e.getVelocity(),
                        ...u,
                        delay: -d,
                        onUpdate: t => {
                            e.set(t), u.onUpdate && u.onUpdate(t)
                        },
                        onComplete: () => {
                            h(), u.onComplete && u.onComplete()
                        },
                        name: t,
                        motionValue: e,
                        element: r ? void 0 : o
                    };
                    (function({
                        when: t,
                        delay: e,
                        delayChildren: i,
                        staggerChildren: s,
                        staggerDirection: n,
                        repeat: o,
                        repeatType: r,
                        repeatDelay: a,
                        from: l,
                        elapsed: h,
                        ...u
                    }) {
                        return !!Object.keys(u).length
                    })(u) || (p = { ...p,
                        ...is(t, p)
                    }), p.duration && (p.duration = (0, n.fD)(p.duration)), p.repeatDelay && (p.repeatDelay = (0, n.fD)(p.repeatDelay)), void 0 !== p.from && (p.keyframes[0] = p.from);
                    let m = !1;
                    if ((!1 === p.type || 0 === p.duration && !p.repeatDelay) && (p.duration = 0, 0 === p.delay && (m = !0)), (Kt || $t.W.skipAnimations) && (m = !0, p.duration = 0, p.delay = 0), m && !r && void 0 !== e.get()) {
                        const t = hi(p.keyframes, u);
                        if (void 0 !== t) return _.Gt.update((() => {
                            p.onUpdate(t), p.onComplete()
                        })), new a([])
                    }
                    return !r && Zi.supports(p) ? new Zi(p) : new Hi(p)
                },
                ns = ({
                    current: t
                }) => t ? t.ownerDocument.defaultView : null;
            var os = i(6199);

            function rs(t, e) {
                const i = t.getValue("willChange");
                if (s = i, Boolean((0, os.S)(s) && s.add)) return i.add(e);
                var s
            }
            const as = new WeakMap;
            class ls {
                constructor(t) {
                    this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = wt(), this.visualElement = t
                }
                start(t, {
                    snapToCursor: e = !1
                } = {}) {
                    const {
                        presenceContext: i
                    } = this.visualElement;
                    if (i && !1 === i.isPresent) return;
                    const {
                        dragSnapToOrigin: s
                    } = this.getProps();
                    this.panSession = new Q(t, {
                        onSessionStart: t => {
                            const {
                                dragSnapToOrigin: i
                            } = this.getProps();
                            i ? this.pauseAnimation() : this.stopAnimation(), e && this.snapToCursor(X(t).point)
                        },
                        onStart: (t, e) => {
                            const {
                                drag: i,
                                dragPropagation: s,
                                onDragStart: n
                            } = this.getProps();
                            if (i && !s && (this.openDragLock && this.openDragLock(), this.openDragLock = "x" === (o = i) || "y" === o ? R[o] ? null : (R[o] = !0, () => {
                                    R[o] = !1
                                }) : R.x || R.y ? null : (R.x = R.y = !0, () => {
                                    R.x = R.y = !1
                                }), !this.openDragLock)) return;
                            var o;
                            this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), At((t => {
                                let e = this.getAxisMotionValue(t).get() || 0;
                                if (Gt.KN.test(e)) {
                                    const {
                                        projection: i
                                    } = this.visualElement;
                                    if (i && i.layout) {
                                        const s = i.layout.layoutBox[t];
                                        if (s) {
                                            e = ut(s) * (parseFloat(e) / 100)
                                        }
                                    }
                                }
                                this.originPoint[t] = e
                            })), n && _.Gt.postRender((() => n(t, e))), rs(this.visualElement, "transform");
                            const {
                                animationState: r
                            } = this.visualElement;
                            r && r.setActive("whileDrag", !0)
                        },
                        onMove: (t, e) => {
                            const {
                                dragPropagation: i,
                                dragDirectionLock: s,
                                onDirectionLock: n,
                                onDrag: o
                            } = this.getProps();
                            if (!i && !this.openDragLock) return;
                            const {
                                offset: r
                            } = e;
                            if (s && null === this.currentDirection) return this.currentDirection = function(t, e = 10) {
                                let i = null;
                                Math.abs(t.y) > e ? i = "y" : Math.abs(t.x) > e && (i = "x");
                                return i
                            }(r), void(null !== this.currentDirection && n && n(this.currentDirection));
                            this.updateAxis("x", e.point, r), this.updateAxis("y", e.point, r), this.visualElement.render(), o && o(t, e)
                        },
                        onSessionEnd: (t, e) => this.stop(t, e),
                        resumeAnimation: () => At((t => {
                            var e;
                            return "paused" === this.getAnimationState(t) && (null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.play())
                        }))
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint(),
                        dragSnapToOrigin: s,
                        contextWindow: ns(this.visualElement)
                    })
                }
                stop(t, e) {
                    const i = this.isDragging;
                    if (this.cancel(), !i) return;
                    const {
                        velocity: s
                    } = e;
                    this.startAnimation(s);
                    const {
                        onDragEnd: n
                    } = this.getProps();
                    n && _.Gt.postRender((() => n(t, e)))
                }
                cancel() {
                    this.isDragging = !1;
                    const {
                        projection: t,
                        animationState: e
                    } = this.visualElement;
                    t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
                    const {
                        dragPropagation: i
                    } = this.getProps();
                    !i && this.openDragLock && (this.openDragLock(), this.openDragLock = null), e && e.setActive("whileDrag", !1)
                }
                updateAxis(t, e, i) {
                    const {
                        drag: s
                    } = this.getProps();
                    if (!i || !hs(t, s, this.currentDirection)) return;
                    const n = this.getAxisMotionValue(t);
                    let o = this.originPoint[t] + i[t];
                    this.constraints && this.constraints[t] && (o = function(t, {
                        min: e,
                        max: i
                    }, s) {
                        return void 0 !== e && t < e ? t = s ? ot(e, t, s.min) : Math.max(t, e) : void 0 !== i && t > i && (t = s ? ot(i, t, s.max) : Math.min(t, i)), t
                    }(o, this.constraints[t], this.elastic[t])), n.set(o)
                }
                resolveConstraints() {
                    var t;
                    const {
                        dragConstraints: e,
                        dragElastic: i
                    } = this.getProps(), s = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null === (t = this.visualElement.projection) || void 0 === t ? void 0 : t.layout, n = this.constraints;
                    e && (0, nt.X)(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : this.constraints = !(!e || !s) && function(t, {
                        top: e,
                        left: i,
                        bottom: s,
                        right: n
                    }) {
                        return {
                            x: gt(t.x, i, n),
                            y: gt(t.y, e, s)
                        }
                    }(s.layoutBox, e), this.elastic = function(t = xt) {
                        return !1 === t ? t = 0 : !0 === t && (t = xt), {
                            x: Pt(t, "left", "right"),
                            y: Pt(t, "top", "bottom")
                        }
                    }(i), n !== this.constraints && s && this.constraints && !this.hasMutatedConstraints && At((t => {
                        !1 !== this.constraints && this.getAxisMotionValue(t) && (this.constraints[t] = function(t, e) {
                            const i = {};
                            return void 0 !== e.min && (i.min = e.min - t.min), void 0 !== e.max && (i.max = e.max - t.min), i
                        }(s.layoutBox[t], this.constraints[t]))
                    }))
                }
                resolveRefConstraints() {
                    const {
                        dragConstraints: t,
                        onMeasureDragConstraints: e
                    } = this.getProps();
                    if (!t || !(0, nt.X)(t)) return !1;
                    const i = t.current;
                    (0, n.V1)(null !== i, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                    const {
                        projection: s
                    } = this.visualElement;
                    if (!s || !s.layout) return !1;
                    const o = function(t, e, i) {
                        const s = Nt(t, i),
                            {
                                scroll: n
                            } = e;
                        return n && (Ut(s.x, n.offset.x), Ut(s.y, n.offset.y)), s
                    }(i, s.root, this.visualElement.getTransformPagePoint());
                    let r = function(t, e) {
                        return {
                            x: yt(t.x, e.x),
                            y: yt(t.y, e.y)
                        }
                    }(s.layout.layoutBox, o);
                    if (e) {
                        const t = e(function({
                            x: t,
                            y: e
                        }) {
                            return {
                                top: e.min,
                                right: t.max,
                                bottom: e.max,
                                left: t.min
                            }
                        }(r));
                        this.hasMutatedConstraints = !!t, t && (r = bt(t))
                    }
                    return r
                }
                startAnimation(t) {
                    const {
                        drag: e,
                        dragMomentum: i,
                        dragElastic: s,
                        dragTransition: n,
                        dragSnapToOrigin: o,
                        onDragTransitionEnd: r
                    } = this.getProps(), a = this.constraints || {}, l = At((r => {
                        if (!hs(r, e, this.currentDirection)) return;
                        let l = a && a[r] || {};
                        o && (l = {
                            min: 0,
                            max: 0
                        });
                        const h = s ? 200 : 1e6,
                            u = s ? 40 : 1e7,
                            c = {
                                type: "inertia",
                                velocity: i ? t[r] : 0,
                                bounceStiffness: h,
                                bounceDamping: u,
                                timeConstant: 750,
                                restDelta: 1,
                                restSpeed: 10,
                                ...n,
                                ...l
                            };
                        return this.startAxisValueAnimation(r, c)
                    }));
                    return Promise.all(l).then(r)
                }
                startAxisValueAnimation(t, e) {
                    const i = this.getAxisMotionValue(t);
                    return rs(this.visualElement, t), i.start(ss(t, i, 0, e, this.visualElement, !1))
                }
                stopAnimation() {
                    At((t => this.getAxisMotionValue(t).stop()))
                }
                pauseAnimation() {
                    At((t => {
                        var e;
                        return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.pause()
                    }))
                }
                getAnimationState(t) {
                    var e;
                    return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.state
                }
                getAxisMotionValue(t) {
                    const e = `_drag${t.toUpperCase()}`,
                        i = this.visualElement.getProps(),
                        s = i[e];
                    return s || this.visualElement.getValue(t, (i.initial ? i.initial[t] : void 0) || 0)
                }
                snapToCursor(t) {
                    At((e => {
                        const {
                            drag: i
                        } = this.getProps();
                        if (!hs(e, i, this.currentDirection)) return;
                        const {
                            projection: s
                        } = this.visualElement, n = this.getAxisMotionValue(e);
                        if (s && s.layout) {
                            const {
                                min: i,
                                max: o
                            } = s.layout.layoutBox[e];
                            n.set(t[e] - ot(i, o, .5))
                        }
                    }))
                }
                scalePositionWithinConstraints() {
                    if (!this.visualElement.current) return;
                    const {
                        drag: t,
                        dragConstraints: e
                    } = this.getProps(), {
                        projection: i
                    } = this.visualElement;
                    if (!(0, nt.X)(e) || !i || !this.constraints) return;
                    this.stopAnimation();
                    const s = {
                        x: 0,
                        y: 0
                    };
                    At((t => {
                        const e = this.getAxisMotionValue(t);
                        if (e && !1 !== this.constraints) {
                            const i = e.get();
                            s[t] = function(t, e) {
                                let i = .5;
                                const s = ut(t),
                                    o = ut(e);
                                return o > s ? i = (0, n.qB)(e.min, e.max - s, t.min) : s > o && (i = (0, n.qB)(t.min, t.max - o, e.min)), (0, vt.q)(0, 1, i)
                            }({
                                min: i,
                                max: i
                            }, this.constraints[t])
                        }
                    }));
                    const {
                        transformTemplate: o
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = o ? o({}, "") : "none", i.root && i.root.updateScroll(), i.updateLayout(), this.resolveConstraints(), At((e => {
                        if (!hs(e, t, null)) return;
                        const i = this.getAxisMotionValue(e),
                            {
                                min: n,
                                max: o
                            } = this.constraints[e];
                        i.set(ot(n, o, s[e]))
                    }))
                }
                addListeners() {
                    if (!this.visualElement.current) return;
                    as.set(this.visualElement, this);
                    const t = q(this.visualElement.current, "pointerdown", (t => {
                            const {
                                drag: e,
                                dragListener: i = !0
                            } = this.getProps();
                            e && i && this.start(t)
                        })),
                        e = () => {
                            const {
                                dragConstraints: t
                            } = this.getProps();
                            (0, nt.X)(t) && t.current && (this.constraints = this.resolveRefConstraints())
                        },
                        {
                            projection: i
                        } = this.visualElement,
                        s = i.addEventListener("measure", e);
                    i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), _.Gt.read(e);
                    const n = W(window, "resize", (() => this.scalePositionWithinConstraints())),
                        o = i.addEventListener("didUpdate", (({
                            delta: t,
                            hasLayoutChanged: e
                        }) => {
                            this.isDragging && e && (At((e => {
                                const i = this.getAxisMotionValue(e);
                                i && (this.originPoint[e] += t[e].translate, i.set(i.get() + t[e].translate))
                            })), this.visualElement.render())
                        }));
                    return () => {
                        n(), t(), s(), o && o()
                    }
                }
                getProps() {
                    const t = this.visualElement.getProps(),
                        {
                            drag: e = !1,
                            dragDirectionLock: i = !1,
                            dragPropagation: s = !1,
                            dragConstraints: n = !1,
                            dragElastic: o = xt,
                            dragMomentum: r = !0
                        } = t;
                    return { ...t,
                        drag: e,
                        dragDirectionLock: i,
                        dragPropagation: s,
                        dragConstraints: n,
                        dragElastic: o,
                        dragMomentum: r
                    }
                }
            }

            function hs(t, e, i) {
                return !(!0 !== e && e !== t || null !== i && i !== t)
            }
            const us = t => (e, i) => {
                t && _.Gt.postRender((() => t(e, i)))
            };
            var cs = i(6070),
                ds = i(758),
                ps = i(5551),
                ms = i(8048),
                fs = i(6376);
            const vs = {
                hasAnimatedSinceResize: !0,
                hasEverUpdated: !1
            };

            function gs(t, e) {
                return e.max === e.min ? 0 : t / (e.max - e.min) * 100
            }
            const ys = {
                    correct: (t, e) => {
                        if (!e.target) return t;
                        if ("string" == typeof t) {
                            if (!Gt.px.test(t)) return t;
                            t = parseFloat(t)
                        }
                        return `${gs(t,e.target.x)}% ${gs(t,e.target.y)}%`
                    }
                },
                xs = {
                    correct: (t, {
                        treeScale: e,
                        projectionDelta: i
                    }) => {
                        const s = t,
                            n = Ve.parse(t);
                        if (n.length > 5) return s;
                        const o = Ve.createTransformer(t),
                            r = "number" != typeof n[0] ? 1 : 0,
                            a = i.x.scale * e.x,
                            l = i.y.scale * e.y;
                        n[0 + r] /= a, n[1 + r] /= l;
                        const h = ot(a, l, .5);
                        return "number" == typeof n[2 + r] && (n[2 + r] /= h), "number" == typeof n[3 + r] && (n[3 + r] /= h), o(n)
                    }
                };
            var Ps = i(7928),
                Ts = i(4831);
            class Ss extends ds.Component {
                componentDidMount() {
                    const {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i,
                        layoutId: s
                    } = this.props, {
                        projection: n
                    } = t;
                    (0, Ps.$)(As), n && (e.group && e.group.add(n), i && i.register && s && i.register(n), n.root.didUpdate(), n.addEventListener("animationComplete", (() => {
                        this.safeToRemove()
                    })), n.setOptions({ ...n.options,
                        onExitComplete: () => this.safeToRemove()
                    })), vs.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(t) {
                    const {
                        layoutDependency: e,
                        visualElement: i,
                        drag: s,
                        isPresent: n
                    } = this.props, o = i.projection;
                    return o ? (o.isPresent = n, s || t.layoutDependency !== e || void 0 === e ? o.willUpdate() : this.safeToRemove(), t.isPresent !== n && (n ? o.promote() : o.relegate() || _.Gt.postRender((() => {
                        const t = o.getStack();
                        t && t.members.length || this.safeToRemove()
                    }))), null) : null
                }
                componentDidUpdate() {
                    const {
                        projection: t
                    } = this.props.visualElement;
                    t && (t.root.didUpdate(), Ts.k.postRender((() => {
                        !t.currentAnimation && t.isLead() && this.safeToRemove()
                    })))
                }
                componentWillUnmount() {
                    const {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i
                    } = this.props, {
                        projection: s
                    } = t;
                    s && (s.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(s), i && i.deregister && i.deregister(s))
                }
                safeToRemove() {
                    const {
                        safeToRemove: t
                    } = this.props;
                    t && t()
                }
                render() {
                    return null
                }
            }

            function ws(t) {
                const [e, i] = (0, ps.xQ)(), s = (0, ds.useContext)(ms.L);
                return (0, cs.jsx)(Ss, { ...t,
                    layoutGroup: s,
                    switchLayoutGroup: (0, ds.useContext)(fs.N),
                    isPresent: e,
                    safeToRemove: i
                })
            }
            const As = {
                borderRadius: { ...ys,
                    applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                },
                borderTopLeftRadius: ys,
                borderTopRightRadius: ys,
                borderBottomLeftRadius: ys,
                borderBottomRightRadius: ys,
                boxShadow: xs
            };

            function bs(t, e) {
                -1 === t.indexOf(e) && t.push(e)
            }

            function Ds(t, e) {
                const i = t.indexOf(e);
                i > -1 && t.splice(i, 1)
            }
            class Es {
                constructor() {
                    this.subscriptions = []
                }
                add(t) {
                    return bs(this.subscriptions, t), () => Ds(this.subscriptions, t)
                }
                notify(t, e, i) {
                    const s = this.subscriptions.length;
                    if (s)
                        if (1 === s) this.subscriptions[0](t, e, i);
                        else
                            for (let n = 0; n < s; n++) {
                                const s = this.subscriptions[n];
                                s && s(t, e, i)
                            }
                }
                getSize() {
                    return this.subscriptions.length
                }
                clear() {
                    this.subscriptions.length = 0
                }
            }
            const Vs = {
                current: void 0
            };
            class Ms {
                constructor(t, e = {}) {
                    this.version = "12.3.1", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (t, e = !0) => {
                        const i = oi.now();
                        this.updatedAt !== i && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(t), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), e && this.events.renderRequest && this.events.renderRequest.notify(this.current)
                    }, this.hasAnimated = !1, this.setCurrent(t), this.owner = e.owner
                }
                setCurrent(t) {
                    var e;
                    this.current = t, this.updatedAt = oi.now(), null === this.canTrackVelocity && void 0 !== t && (this.canTrackVelocity = (e = this.current, !isNaN(parseFloat(e))))
                }
                setPrevFrameValue(t = this.current) {
                    this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
                }
                onChange(t) {
                    return this.on("change", t)
                }
                on(t, e) {
                    this.events[t] || (this.events[t] = new Es);
                    const i = this.events[t].add(e);
                    return "change" === t ? () => {
                        i(), _.Gt.read((() => {
                            this.events.change.getSize() || this.stop()
                        }))
                    } : i
                }
                clearListeners() {
                    for (const t in this.events) this.events[t].clear()
                }
                attach(t, e) {
                    this.passiveEffect = t, this.stopPassiveEffect = e
                }
                set(t, e = !0) {
                    e && this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t, e)
                }
                setWithVelocity(t, e, i) {
                    this.set(e), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - i
                }
                jump(t, e = !0) {
                    this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, e && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
                get() {
                    return Vs.current && Vs.current.push(this), this.current
                }
                getPrevious() {
                    return this.prev
                }
                getVelocity() {
                    const t = oi.now();
                    if (!this.canTrackVelocity || void 0 === this.prevFrameValue || t - this.updatedAt > 30) return 0;
                    const e = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
                    return Ai(parseFloat(this.current) - parseFloat(this.prevFrameValue), e)
                }
                start(t) {
                    return this.stop(), new Promise((e => {
                        this.hasAnimated = !0, this.animation = t(e), this.events.animationStart && this.events.animationStart.notify()
                    })).then((() => {
                        this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
                    }))
                }
                stop() {
                    this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
                }
                isAnimating() {
                    return !!this.animation
                }
                clearAnimation() {
                    delete this.animation
                }
                destroy() {
                    this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
            }

            function Cs(t, e) {
                return new Ms(t, e)
            }
            var Rs = i(1369);

            function ks(t) {
                return t.props[Rs.n]
            }
            const Bs = (t, e) => t.depth - e.depth;
            class Ls {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(t) {
                    bs(this.children, t), this.isDirty = !0
                }
                remove(t) {
                    Ds(this.children, t), this.isDirty = !0
                }
                forEach(t) {
                    this.isDirty && this.children.sort(Bs), this.isDirty = !1, this.children.forEach(t)
                }
            }

            function js(t, e) {
                const i = oi.now(),
                    s = ({
                        timestamp: n
                    }) => {
                        const o = n - i;
                        o >= e && ((0, _.WG)(s), t(o - e))
                    };
                return _.Gt.read(s, !0), () => (0, _.WG)(s)
            }
            var Fs = i(3627);
            const Us = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
                Os = Us.length,
                Is = t => "string" == typeof t ? parseFloat(t) : t,
                Ns = t => "number" == typeof t || Gt.px.test(t);

            function Gs(t, e) {
                return void 0 !== t[e] ? t[e] : t.borderRadius
            }
            const $s = Ws(0, .5, ee),
                Ks = Ws(.5, .95, n.lQ);

            function Ws(t, e, i) {
                return s => s < t ? 0 : s > e ? 1 : i((0, n.qB)(t, e, s))
            }

            function Xs(t, e) {
                t.min = e.min, t.max = e.max
            }

            function qs(t, e) {
                Xs(t.x, e.x), Xs(t.y, e.y)
            }

            function zs(t, e) {
                t.translate = e.translate, t.scale = e.scale, t.originPoint = e.originPoint, t.origin = e.origin
            }

            function Hs(t, e, i, s, n) {
                return t = Rt(t -= e, 1 / i, s), void 0 !== n && (t = Rt(t, 1 / n, s)), t
            }

            function Ys(t, e, [i, s, n], o, r) {
                ! function(t, e = 0, i = 1, s = .5, n, o = t, r = t) {
                    Gt.KN.test(e) && (e = parseFloat(e), e = ot(r.min, r.max, e / 100) - r.min);
                    if ("number" != typeof e) return;
                    let a = ot(o.min, o.max, s);
                    t === o && (a -= e), t.min = Hs(t.min, e, i, a, n), t.max = Hs(t.max, e, i, a, n)
                }(t, e[i], e[s], e[n], e.scale, o, r)
            }
            const _s = ["x", "scaleX", "originX"],
                Qs = ["y", "scaleY", "originY"];

            function Zs(t, e, i, s) {
                Ys(t.x, e, _s, i ? i.x : void 0, s ? s.x : void 0), Ys(t.y, e, Qs, i ? i.y : void 0, s ? s.y : void 0)
            }

            function Js(t) {
                return 0 === t.translate && 1 === t.scale
            }

            function tn(t) {
                return Js(t.x) && Js(t.y)
            }

            function en(t, e) {
                return t.min === e.min && t.max === e.max
            }

            function sn(t, e) {
                return Math.round(t.min) === Math.round(e.min) && Math.round(t.max) === Math.round(e.max)
            }

            function nn(t, e) {
                return sn(t.x, e.x) && sn(t.y, e.y)
            }

            function on(t) {
                return ut(t.x) / ut(t.y)
            }

            function rn(t, e) {
                return t.translate === e.translate && t.scale === e.scale && t.originPoint === e.originPoint
            }
            class an {
                constructor() {
                    this.members = []
                }
                add(t) {
                    bs(this.members, t), t.scheduleRender()
                }
                remove(t) {
                    if (Ds(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                        const t = this.members[this.members.length - 1];
                        t && this.promote(t)
                    }
                }
                relegate(t) {
                    const e = this.members.findIndex((e => t === e));
                    if (0 === e) return !1;
                    let i;
                    for (let t = e; t >= 0; t--) {
                        const e = this.members[t];
                        if (!1 !== e.isPresent) {
                            i = e;
                            break
                        }
                    }
                    return !!i && (this.promote(i), !0)
                }
                promote(t, e) {
                    const i = this.lead;
                    if (t !== i && (this.prevLead = i, this.lead = t, t.show(), i)) {
                        i.instance && i.scheduleRender(), t.scheduleRender(), t.resumeFrom = i, e && (t.resumeFrom.preserveOpacity = !0), i.snapshot && (t.snapshot = i.snapshot, t.snapshot.latestValues = i.animationValues || i.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
                        const {
                            crossfade: s
                        } = t.options;
                        !1 === s && i.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach((t => {
                        const {
                            options: e,
                            resumingFrom: i
                        } = t;
                        e.onExitComplete && e.onExitComplete(), i && i.options.onExitComplete && i.options.onExitComplete()
                    }))
                }
                scheduleRender() {
                    this.members.forEach((t => {
                        t.instance && t.scheduleRender(!1)
                    }))
                }
                removeLeadSnapshot() {
                    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
                }
            }
            const ln = {
                    type: "projectionFrame",
                    totalNodes: 0,
                    resolvedTargetDeltas: 0,
                    recalculatedProjection: 0
                },
                hn = "undefined" != typeof window && void 0 !== window.MotionDebug,
                un = ["", "X", "Y", "Z"],
                cn = {
                    visibility: "hidden"
                };
            let dn = 0;

            function pn(t, e, i, s) {
                const {
                    latestValues: n
                } = e;
                n[t] && (i[t] = n[t], e.setStaticValue(t, 0), s && (s[t] = 0))
            }

            function mn(t) {
                if (t.hasCheckedOptimisedAppear = !0, t.root === t) return;
                const {
                    visualElement: e
                } = t.options;
                if (!e) return;
                const i = ks(e);
                if (window.MotionHasOptimisedAnimation(i, "transform")) {
                    const {
                        layout: e,
                        layoutId: s
                    } = t.options;
                    window.MotionCancelOptimisedAnimation(i, "transform", _.Gt, !(e || s))
                }
                const {
                    parent: s
                } = t;
                s && !s.hasCheckedOptimisedAppear && mn(s)
            }

            function fn({
                attachResizeListener: t,
                defaultParent: e,
                measureScroll: i,
                checkIsScrollRoot: s,
                resetTransform: n
            }) {
                return class {
                    constructor(t = {}, i = (null == e ? void 0 : e())) {
                        this.id = dn++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.projectionUpdateScheduled = !1, hn && (ln.totalNodes = ln.resolvedTargetDeltas = ln.recalculatedProjection = 0), this.nodes.forEach(yn), this.nodes.forEach(bn), this.nodes.forEach(Dn), this.nodes.forEach(xn), hn && window.MotionDebug.record(ln)
                        }, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = i ? i.root || i : this, this.path = i ? [...i.path, i] : [], this.parent = i, this.depth = i ? i.depth + 1 : 0;
                        for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new Ls)
                    }
                    addEventListener(t, e) {
                        return this.eventHandlers.has(t) || this.eventHandlers.set(t, new Es), this.eventHandlers.get(t).add(e)
                    }
                    notifyListeners(t, ...e) {
                        const i = this.eventHandlers.get(t);
                        i && i.notify(...e)
                    }
                    hasListeners(t) {
                        return this.eventHandlers.has(t)
                    }
                    mount(e, i = this.root.hasTreeAnimated) {
                        if (this.instance) return;
                        var s;
                        this.isSVG = (s = e) instanceof SVGElement && "svg" !== s.tagName, this.instance = e;
                        const {
                            layoutId: n,
                            layout: o,
                            visualElement: r
                        } = this.options;
                        if (r && !r.current && r.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), i && (o || n) && (this.isLayoutDirty = !0), t) {
                            let i;
                            const s = () => this.root.updateBlockedByResize = !1;
                            t(e, (() => {
                                this.root.updateBlockedByResize = !0, i && i(), i = js(s, 250), vs.hasAnimatedSinceResize && (vs.hasAnimatedSinceResize = !1, this.nodes.forEach(An))
                            }))
                        }
                        n && this.root.registerSharedNode(n, this), !1 !== this.options.animate && r && (n || o) && this.addEventListener("didUpdate", (({
                            delta: t,
                            hasLayoutChanged: e,
                            hasRelativeLayoutChanged: i,
                            layout: s
                        }) => {
                            if (this.isTreeAnimationBlocked()) return this.target = void 0, void(this.relativeTarget = void 0);
                            const n = this.options.transition || r.getDefaultTransition() || kn,
                                {
                                    onLayoutAnimationStart: o,
                                    onLayoutAnimationComplete: a
                                } = r.getProps(),
                                h = !this.targetLayout || !nn(this.targetLayout, s),
                                u = !e && i;
                            if (this.options.layoutRoot || this.resumeFrom || u || e && (h || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(t, u);
                                const e = { ...l(n, "layout"),
                                    onPlay: o,
                                    onComplete: a
                                };
                                (r.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e)
                            } else e || An(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                            this.targetLayout = s
                        }))
                    }
                    unmount() {
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                        const t = this.getStack();
                        t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, (0, _.WG)(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
                    }
                    startUpdate() {
                        this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes && this.nodes.forEach(En), this.animationId++)
                    }
                    getTransformTemplate() {
                        const {
                            visualElement: t
                        } = this.options;
                        return t && t.getProps().transformTemplate
                    }
                    willUpdate(t = !0) {
                        if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) return void(this.options.onExitComplete && this.options.onExitComplete());
                        if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && mn(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let t = 0; t < this.path.length; t++) {
                            const e = this.path[t];
                            e.shouldResetTransform = !0, e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                        }
                        const {
                            layoutId: e,
                            layout: i
                        } = this.options;
                        if (void 0 === e && !i) return;
                        const s = this.getTransformTemplate();
                        this.prevTransformTemplateValue = s ? s(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
                    }
                    update() {
                        this.updateScheduled = !1;
                        if (this.isUpdateBlocked()) return this.unblockUpdate(), this.clearAllSnapshots(), void this.nodes.forEach(Tn);
                        this.isUpdating || this.nodes.forEach(Sn), this.isUpdating = !1, this.nodes.forEach(wn), this.nodes.forEach(vn), this.nodes.forEach(gn), this.clearAllSnapshots();
                        const t = oi.now();
                        _.uv.delta = (0, vt.q)(0, 1e3 / 60, t - _.uv.timestamp), _.uv.timestamp = t, _.uv.isProcessing = !0, _.PP.update.process(_.uv), _.PP.preRender.process(_.uv), _.PP.render.process(_.uv), _.uv.isProcessing = !1
                    }
                    didUpdate() {
                        this.updateScheduled || (this.updateScheduled = !0, Ts.k.read(this.scheduleUpdate))
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(Pn), this.sharedNodes.forEach(Vn)
                    }
                    scheduleUpdateProjection() {
                        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, _.Gt.preRender(this.updateProjection, !1, !0))
                    }
                    scheduleCheckAfterUnmount() {
                        _.Gt.postRender((() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        }))
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure(), !this.snapshot || ut(this.snapshot.measuredBox.x) || ut(this.snapshot.measuredBox.y) || (this.snapshot = void 0))
                    }
                    updateLayout() {
                        if (!this.instance) return;
                        if (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead() || this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let t = 0; t < this.path.length; t++) {
                                this.path[t].updateScroll()
                            }
                        const t = this.layout;
                        this.layout = this.measure(!1), this.layoutCorrected = wt(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                        const {
                            visualElement: e
                        } = this.options;
                        e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
                    }
                    updateScroll(t = "measure") {
                        let e = Boolean(this.options.layoutScroll && this.instance);
                        if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e) {
                            const e = s(this.instance);
                            this.scroll = {
                                animationId: this.root.animationId,
                                phase: t,
                                isRoot: e,
                                offset: i(this.instance),
                                wasRoot: this.scroll ? this.scroll.isRoot : e
                            }
                        }
                    }
                    resetTransform() {
                        if (!n) return;
                        const t = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                            e = this.projectionDelta && !tn(this.projectionDelta),
                            i = this.getTransformTemplate(),
                            s = i ? i(this.latestValues, "") : void 0,
                            o = s !== this.prevTransformTemplateValue;
                        t && (e || Vt(this.latestValues) || o) && (n(this.instance, s), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(t = !0) {
                        const e = this.measurePageBox();
                        let i = this.removeElementScroll(e);
                        var s;
                        return t && (i = this.removeTransform(i)), jn((s = i).x), jn(s.y), {
                            animationId: this.root.animationId,
                            measuredBox: e,
                            layoutBox: i,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        var t;
                        const {
                            visualElement: e
                        } = this.options;
                        if (!e) return wt();
                        const i = e.measureViewportBox();
                        if (!((null === (t = this.scroll) || void 0 === t ? void 0 : t.wasRoot) || this.path.some(Un))) {
                            const {
                                scroll: t
                            } = this.root;
                            t && (Ut(i.x, t.offset.x), Ut(i.y, t.offset.y))
                        }
                        return i
                    }
                    removeElementScroll(t) {
                        var e;
                        const i = wt();
                        if (qs(i, t), null === (e = this.scroll) || void 0 === e ? void 0 : e.wasRoot) return i;
                        for (let e = 0; e < this.path.length; e++) {
                            const s = this.path[e],
                                {
                                    scroll: n,
                                    options: o
                                } = s;
                            s !== this.root && n && o.layoutScroll && (n.wasRoot && qs(i, t), Ut(i.x, n.offset.x), Ut(i.y, n.offset.y))
                        }
                        return i
                    }
                    applyTransform(t, e = !1) {
                        const i = wt();
                        qs(i, t);
                        for (let t = 0; t < this.path.length; t++) {
                            const s = this.path[t];
                            !e && s.options.layoutScroll && s.scroll && s !== s.root && It(i, {
                                x: -s.scroll.offset.x,
                                y: -s.scroll.offset.y
                            }), Vt(s.latestValues) && It(i, s.latestValues)
                        }
                        return Vt(this.latestValues) && It(i, this.latestValues), i
                    }
                    removeTransform(t) {
                        const e = wt();
                        qs(e, t);
                        for (let t = 0; t < this.path.length; t++) {
                            const i = this.path[t];
                            if (!i.instance) continue;
                            if (!Vt(i.latestValues)) continue;
                            Et(i.latestValues) && i.updateSnapshot();
                            const s = wt();
                            qs(s, i.measurePageBox()), Zs(e, i.latestValues, i.snapshot ? i.snapshot.layoutBox : void 0, s)
                        }
                        return Vt(this.latestValues) && Zs(e, this.latestValues), e
                    }
                    setTargetDelta(t) {
                        this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
                    }
                    setOptions(t) {
                        this.options = { ...this.options,
                            ...t,
                            crossfade: void 0 === t.crossfade || t.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    forceRelativeParentToResolveTarget() {
                        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== _.uv.timestamp && this.relativeParent.resolveTargetDelta(!0)
                    }
                    resolveTargetDelta(t = !1) {
                        var e;
                        const i = this.getLead();
                        this.isProjectionDirty || (this.isProjectionDirty = i.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = i.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = i.isSharedProjectionDirty);
                        const s = Boolean(this.resumingFrom) || this !== i;
                        if (!(t || s && this.isSharedProjectionDirty || this.isProjectionDirty || (null === (e = this.parent) || void 0 === e ? void 0 : e.isProjectionDirty) || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
                        const {
                            layout: n,
                            layoutId: o
                        } = this.options;
                        if (this.layout && (n || o)) {
                            if (this.resolvedRelativeTargetAt = _.uv.timestamp, !this.targetDelta && !this.relativeTarget) {
                                const t = this.getClosestProjectingParent();
                                t && t.layout && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = wt(), this.relativeTargetOrigin = wt(), ft(this.relativeTargetOrigin, this.layout.layoutBox, t.layout.layoutBox), qs(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                            if (this.relativeTarget || this.targetDelta) {
                                var r, a, l;
                                if (this.target || (this.target = wt(), this.targetWithTransforms = wt()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), r = this.target, a = this.relativeTarget, l = this.relativeParent.target, pt(r.x, a.x, l.x), pt(r.y, a.y, l.y)) : this.targetDelta ? (Boolean(this.resumingFrom) ? this.target = this.applyTransform(this.layout.layoutBox) : qs(this.target, this.layout.layoutBox), Lt(this.target, this.targetDelta)) : qs(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                                    this.attemptToResolveRelativeTarget = !1;
                                    const t = this.getClosestProjectingParent();
                                    t && Boolean(t.resumingFrom) === Boolean(this.resumingFrom) && !t.options.layoutScroll && t.target && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = wt(), this.relativeTargetOrigin = wt(), ft(this.relativeTargetOrigin, this.target, t.target), qs(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                                }
                                hn && ln.resolvedTargetDeltas++
                            }
                        }
                    }
                    getClosestProjectingParent() {
                        if (this.parent && !Et(this.parent.latestValues) && !Mt(this.parent.latestValues)) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
                    }
                    isProjecting() {
                        return Boolean((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
                    }
                    calcProjection() {
                        var t;
                        const e = this.getLead(),
                            i = Boolean(this.resumingFrom) || this !== e;
                        let s = !0;
                        if ((this.isProjectionDirty || (null === (t = this.parent) || void 0 === t ? void 0 : t.isProjectionDirty)) && (s = !1), i && (this.isSharedProjectionDirty || this.isTransformDirty) && (s = !1), this.resolvedRelativeTargetAt === _.uv.timestamp && (s = !1), s) return;
                        const {
                            layout: n,
                            layoutId: o
                        } = this.options;
                        if (this.isTreeAnimating = Boolean(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !n && !o) return;
                        qs(this.layoutCorrected, this.layout.layoutBox);
                        const r = this.treeScale.x,
                            a = this.treeScale.y;
                        ! function(t, e, i, s = !1) {
                            const n = i.length;
                            if (!n) return;
                            let o, r;
                            e.x = e.y = 1;
                            for (let a = 0; a < n; a++) {
                                o = i[a], r = o.projectionDelta;
                                const {
                                    visualElement: n
                                } = o.options;
                                n && n.props.style && "contents" === n.props.style.display || (s && o.options.layoutScroll && o.scroll && o !== o.root && It(t, {
                                    x: -o.scroll.offset.x,
                                    y: -o.scroll.offset.y
                                }), r && (e.x *= r.x.scale, e.y *= r.y.scale, Lt(t, r)), s && Vt(o.latestValues) && It(t, o.latestValues))
                            }
                            e.x < Ft && e.x > jt && (e.x = 1), e.y < Ft && e.y > jt && (e.y = 1)
                        }(this.layoutCorrected, this.treeScale, this.path, i), !e.layout || e.target || 1 === this.treeScale.x && 1 === this.treeScale.y || (e.target = e.layout.layoutBox, e.targetWithTransforms = wt());
                        const {
                            target: l
                        } = e;
                        l ? (this.projectionDelta && this.prevProjectionDelta ? (zs(this.prevProjectionDelta.x, this.projectionDelta.x), zs(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), dt(this.projectionDelta, this.layoutCorrected, l, this.latestValues), this.treeScale.x === r && this.treeScale.y === a && rn(this.projectionDelta.x, this.prevProjectionDelta.x) && rn(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l)), hn && ln.recalculatedProjection++) : this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender())
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(t = !0) {
                        var e;
                        if (null === (e = this.options.visualElement) || void 0 === e || e.scheduleRender(), t) {
                            const t = this.getStack();
                            t && t.scheduleRender()
                        }
                        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    createProjectionDeltas() {
                        this.prevProjectionDelta = St(), this.projectionDelta = St(), this.projectionDeltaWithTransform = St()
                    }
                    setAnimationOrigin(t, e = !1) {
                        const i = this.snapshot,
                            s = i ? i.latestValues : {},
                            n = { ...this.latestValues
                            },
                            o = St();
                        this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                        const r = wt(),
                            a = (i ? i.source : void 0) !== (this.layout ? this.layout.source : void 0),
                            l = this.getStack(),
                            h = !l || l.members.length <= 1,
                            u = Boolean(a && !h && !0 === this.options.crossfade && !this.path.some(Rn));
                        let c;
                        this.animationProgress = 0, this.mixTargetDelta = e => {
                            const i = e / 1e3;
                            var l, d, p, m, f, v;
                            Mn(o.x, t.x, i), Mn(o.y, t.y, i), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (ft(r, this.layout.layoutBox, this.relativeParent.layout.layoutBox), p = this.relativeTarget, m = this.relativeTargetOrigin, f = r, v = i, Cn(p.x, m.x, f.x, v), Cn(p.y, m.y, f.y, v), c && (l = this.relativeTarget, d = c, en(l.x, d.x) && en(l.y, d.y)) && (this.isProjectionDirty = !1), c || (c = wt()), qs(c, this.relativeTarget)), a && (this.animationValues = n, function(t, e, i, s, n, o) {
                                n ? (t.opacity = ot(0, void 0 !== i.opacity ? i.opacity : 1, $s(s)), t.opacityExit = ot(void 0 !== e.opacity ? e.opacity : 1, 0, Ks(s))) : o && (t.opacity = ot(void 0 !== e.opacity ? e.opacity : 1, void 0 !== i.opacity ? i.opacity : 1, s));
                                for (let n = 0; n < Os; n++) {
                                    const o = `border${Us[n]}Radius`;
                                    let r = Gs(e, o),
                                        a = Gs(i, o);
                                    void 0 === r && void 0 === a || (r || (r = 0), a || (a = 0), 0 === r || 0 === a || Ns(r) === Ns(a) ? (t[o] = Math.max(ot(Is(r), Is(a), s), 0), (Gt.KN.test(a) || Gt.KN.test(r)) && (t[o] += "%")) : t[o] = a)
                                }(e.rotate || i.rotate) && (t.rotate = ot(e.rotate || 0, i.rotate || 0, s))
                            }(n, s, this.latestValues, i, u, h)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = i
                        }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
                    }
                    startAnimation(t) {
                        this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && ((0, _.WG)(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = _.Gt.update((() => {
                            vs.hasAnimatedSinceResize = !0, this.currentAnimation = function(t, e, i) {
                                const s = (0, os.S)(t) ? t : Cs(t);
                                return s.start(ss("", s, e, i)), s.animation
                            }(0, 1e3, { ...t,
                                onUpdate: e => {
                                    this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                                },
                                onComplete: () => {
                                    t.onComplete && t.onComplete(), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        }))
                    }
                    completeAnimation() {
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                        const t = this.getStack();
                        t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        const t = this.getLead();
                        let {
                            targetWithTransforms: e,
                            target: i,
                            layout: s,
                            latestValues: n
                        } = t;
                        if (e && i && s) {
                            if (this !== t && this.layout && s && Fn(this.options.animationType, this.layout.layoutBox, s.layoutBox)) {
                                i = this.target || wt();
                                const e = ut(this.layout.layoutBox.x);
                                i.x.min = t.target.x.min, i.x.max = i.x.min + e;
                                const s = ut(this.layout.layoutBox.y);
                                i.y.min = t.target.y.min, i.y.max = i.y.min + s
                            }
                            qs(e, i), It(e, n), dt(this.projectionDeltaWithTransform, this.layoutCorrected, e, n)
                        }
                    }
                    registerSharedNode(t, e) {
                        this.sharedNodes.has(t) || this.sharedNodes.set(t, new an);
                        this.sharedNodes.get(t).add(e);
                        const i = e.options.initialPromotionConfig;
                        e.promote({
                            transition: i ? i.transition : void 0,
                            preserveFollowOpacity: i && i.shouldPreserveFollowOpacity ? i.shouldPreserveFollowOpacity(e) : void 0
                        })
                    }
                    isLead() {
                        const t = this.getStack();
                        return !t || t.lead === this
                    }
                    getLead() {
                        var t;
                        const {
                            layoutId: e
                        } = this.options;
                        return e && (null === (t = this.getStack()) || void 0 === t ? void 0 : t.lead) || this
                    }
                    getPrevLead() {
                        var t;
                        const {
                            layoutId: e
                        } = this.options;
                        return e ? null === (t = this.getStack()) || void 0 === t ? void 0 : t.prevLead : void 0
                    }
                    getStack() {
                        const {
                            layoutId: t
                        } = this.options;
                        if (t) return this.root.sharedNodes.get(t)
                    }
                    promote({
                        needsReset: t,
                        transition: e,
                        preserveFollowOpacity: i
                    } = {}) {
                        const s = this.getStack();
                        s && s.promote(this, i), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                            transition: e
                        })
                    }
                    relegate() {
                        const t = this.getStack();
                        return !!t && t.relegate(this)
                    }
                    resetSkewAndRotation() {
                        const {
                            visualElement: t
                        } = this.options;
                        if (!t) return;
                        let e = !1;
                        const {
                            latestValues: i
                        } = t;
                        if ((i.z || i.rotate || i.rotateX || i.rotateY || i.rotateZ || i.skewX || i.skewY) && (e = !0), !e) return;
                        const s = {};
                        i.z && pn("z", t, s, this.animationValues);
                        for (let e = 0; e < un.length; e++) pn(`rotate${un[e]}`, t, s, this.animationValues), pn(`skew${un[e]}`, t, s, this.animationValues);
                        t.render();
                        for (const e in s) t.setStaticValue(e, s[e]), this.animationValues && (this.animationValues[e] = s[e]);
                        t.scheduleRender()
                    }
                    getProjectionStyles(t) {
                        var e, i;
                        if (!this.instance || this.isSVG) return;
                        if (!this.isVisible) return cn;
                        const s = {
                                visibility: ""
                            },
                            n = this.getTransformTemplate();
                        if (this.needsReset) return this.needsReset = !1, s.opacity = "", s.pointerEvents = (0, Fs.u)(null == t ? void 0 : t.pointerEvents) || "", s.transform = n ? n(this.latestValues, "") : "none", s;
                        const o = this.getLead();
                        if (!this.projectionDelta || !this.layout || !o.target) {
                            const e = {};
                            return this.options.layoutId && (e.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, e.pointerEvents = (0, Fs.u)(null == t ? void 0 : t.pointerEvents) || ""), this.hasProjected && !Vt(this.latestValues) && (e.transform = n ? n({}, "") : "none", this.hasProjected = !1), e
                        }
                        const r = o.animationValues || o.latestValues;
                        this.applyTransformsToTarget(), s.transform = function(t, e, i) {
                            let s = "";
                            const n = t.x.translate / e.x,
                                o = t.y.translate / e.y,
                                r = (null == i ? void 0 : i.z) || 0;
                            if ((n || o || r) && (s = `translate3d(${n}px, ${o}px, ${r}px) `), 1 === e.x && 1 === e.y || (s += `scale(${1/e.x}, ${1/e.y}) `), i) {
                                const {
                                    transformPerspective: t,
                                    rotate: e,
                                    rotateX: n,
                                    rotateY: o,
                                    skewX: r,
                                    skewY: a
                                } = i;
                                t && (s = `perspective(${t}px) ${s}`), e && (s += `rotate(${e}deg) `), n && (s += `rotateX(${n}deg) `), o && (s += `rotateY(${o}deg) `), r && (s += `skewX(${r}deg) `), a && (s += `skewY(${a}deg) `)
                            }
                            const a = t.x.scale * e.x,
                                l = t.y.scale * e.y;
                            return 1 === a && 1 === l || (s += `scale(${a}, ${l})`), s || "none"
                        }(this.projectionDeltaWithTransform, this.treeScale, r), n && (s.transform = n(r, s.transform));
                        const {
                            x: a,
                            y: l
                        } = this.projectionDelta;
                        s.transformOrigin = `${100*a.origin}% ${100*l.origin}% 0`, o.animationValues ? s.opacity = o === this ? null !== (i = null !== (e = r.opacity) && void 0 !== e ? e : this.latestValues.opacity) && void 0 !== i ? i : 1 : this.preserveOpacity ? this.latestValues.opacity : r.opacityExit : s.opacity = o === this ? void 0 !== r.opacity ? r.opacity : "" : void 0 !== r.opacityExit ? r.opacityExit : 0;
                        for (const t in Ps.H) {
                            if (void 0 === r[t]) continue;
                            const {
                                correct: e,
                                applyTo: i,
                                isCSSVariable: n
                            } = Ps.H[t], a = "none" === s.transform ? r[t] : e(r[t], o);
                            if (i) {
                                const t = i.length;
                                for (let e = 0; e < t; e++) s[i[e]] = a
                            } else n ? this.options.visualElement.renderState.vars[t] = a : s[t] = a
                        }
                        return this.options.layoutId && (s.pointerEvents = o === this ? (0, Fs.u)(null == t ? void 0 : t.pointerEvents) || "" : "none"), s
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach((t => {
                            var e;
                            return null === (e = t.currentAnimation) || void 0 === e ? void 0 : e.stop()
                        })), this.root.nodes.forEach(Tn), this.root.sharedNodes.clear()
                    }
                }
            }

            function vn(t) {
                t.updateLayout()
            }

            function gn(t) {
                var e;
                const i = (null === (e = t.resumeFrom) || void 0 === e ? void 0 : e.snapshot) || t.snapshot;
                if (t.isLead() && t.layout && i && t.hasListeners("didUpdate")) {
                    const {
                        layoutBox: e,
                        measuredBox: s
                    } = t.layout, {
                        animationType: n
                    } = t.options, o = i.source !== t.layout.source;
                    "size" === n ? At((t => {
                        const s = o ? i.measuredBox[t] : i.layoutBox[t],
                            n = ut(s);
                        s.min = e[t].min, s.max = s.min + n
                    })) : Fn(n, i.layoutBox, e) && At((s => {
                        const n = o ? i.measuredBox[s] : i.layoutBox[s],
                            r = ut(e[s]);
                        n.max = n.min + r, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[s].max = t.relativeTarget[s].min + r)
                    }));
                    const r = St();
                    dt(r, e, i.layoutBox);
                    const a = St();
                    o ? dt(a, t.applyTransform(s, !0), i.measuredBox) : dt(a, e, i.layoutBox);
                    const l = !tn(r);
                    let h = !1;
                    if (!t.resumeFrom) {
                        const s = t.getClosestProjectingParent();
                        if (s && !s.resumeFrom) {
                            const {
                                snapshot: n,
                                layout: o
                            } = s;
                            if (n && o) {
                                const r = wt();
                                ft(r, i.layoutBox, n.layoutBox);
                                const a = wt();
                                ft(a, e, o.layoutBox), nn(r, a) || (h = !0), s.options.layoutRoot && (t.relativeTarget = a, t.relativeTargetOrigin = r, t.relativeParent = s)
                            }
                        }
                    }
                    t.notifyListeners("didUpdate", {
                        layout: e,
                        snapshot: i,
                        delta: a,
                        layoutDelta: r,
                        hasLayoutChanged: l,
                        hasRelativeLayoutChanged: h
                    })
                } else if (t.isLead()) {
                    const {
                        onExitComplete: e
                    } = t.options;
                    e && e()
                }
                t.options.transition = void 0
            }

            function yn(t) {
                hn && ln.totalNodes++, t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = Boolean(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
            }

            function xn(t) {
                t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
            }

            function Pn(t) {
                t.clearSnapshot()
            }

            function Tn(t) {
                t.clearMeasurements()
            }

            function Sn(t) {
                t.isLayoutDirty = !1
            }

            function wn(t) {
                const {
                    visualElement: e
                } = t.options;
                e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
            }

            function An(t) {
                t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
            }

            function bn(t) {
                t.resolveTargetDelta()
            }

            function Dn(t) {
                t.calcProjection()
            }

            function En(t) {
                t.resetSkewAndRotation()
            }

            function Vn(t) {
                t.removeLeadSnapshot()
            }

            function Mn(t, e, i) {
                t.translate = ot(e.translate, 0, i), t.scale = ot(e.scale, 1, i), t.origin = e.origin, t.originPoint = e.originPoint
            }

            function Cn(t, e, i, s) {
                t.min = ot(e.min, i.min, s), t.max = ot(e.max, i.max, s)
            }

            function Rn(t) {
                return t.animationValues && void 0 !== t.animationValues.opacityExit
            }
            const kn = {
                    duration: .45,
                    ease: [.4, 0, .1, 1]
                },
                Bn = t => "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
                Ln = Bn("applewebkit/") && !Bn("chrome/") ? Math.round : n.lQ;

            function jn(t) {
                t.min = Ln(t.min), t.max = Ln(t.max)
            }

            function Fn(t, e, i) {
                return "position" === t || "preserve-aspect" === t && (s = on(e), n = on(i), o = .2, !(Math.abs(s - n) <= o));
                var s, n, o
            }

            function Un(t) {
                var e;
                return t !== t.root && (null === (e = t.scroll) || void 0 === e ? void 0 : e.wasRoot)
            }
            const On = fn({
                    attachResizeListener: (t, e) => W(t, "resize", e),
                    measureScroll: () => ({
                        x: document.documentElement.scrollLeft || document.body.scrollLeft,
                        y: document.documentElement.scrollTop || document.body.scrollTop
                    }),
                    checkIsScrollRoot: () => !0
                }),
                In = {
                    current: void 0
                },
                Nn = fn({
                    measureScroll: t => ({
                        x: t.scrollLeft,
                        y: t.scrollTop
                    }),
                    defaultParent: () => {
                        if (!In.current) {
                            const t = new On({});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), In.current = t
                        }
                        return In.current
                    },
                    resetTransform: (t, e) => {
                        t.style.transform = void 0 !== e ? e : "none"
                    },
                    checkIsScrollRoot: t => Boolean("fixed" === window.getComputedStyle(t).position)
                }),
                Gn = {
                    pan: {
                        Feature: class extends s {
                            constructor() {
                                super(...arguments), this.removePointerDownListener = n.lQ
                            }
                            onPointerDown(t) {
                                this.session = new Q(t, this.createPanHandlers(), {
                                    transformPagePoint: this.node.getTransformPagePoint(),
                                    contextWindow: ns(this.node)
                                })
                            }
                            createPanHandlers() {
                                const {
                                    onPanSessionStart: t,
                                    onPanStart: e,
                                    onPan: i,
                                    onPanEnd: s
                                } = this.node.getProps();
                                return {
                                    onSessionStart: us(t),
                                    onStart: us(e),
                                    onMove: i,
                                    onEnd: (t, e) => {
                                        delete this.session, s && _.Gt.postRender((() => s(t, e)))
                                    }
                                }
                            }
                            mount() {
                                this.removePointerDownListener = q(this.node.current, "pointerdown", (t => this.onPointerDown(t)))
                            }
                            update() {
                                this.session && this.session.updateHandlers(this.createPanHandlers())
                            }
                            unmount() {
                                this.removePointerDownListener(), this.session && this.session.end()
                            }
                        }
                    },
                    drag: {
                        Feature: class extends s {
                            constructor(t) {
                                super(t), this.removeGroupControls = n.lQ, this.removeListeners = n.lQ, this.controls = new ls(t)
                            }
                            mount() {
                                const {
                                    dragControls: t
                                } = this.node.getProps();
                                t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || n.lQ
                            }
                            unmount() {
                                this.removeGroupControls(), this.removeListeners()
                            }
                        },
                        ProjectionNode: Nn,
                        MeasureLayout: ws
                    }
                },
                $n = {
                    layout: {
                        ProjectionNode: Nn,
                        MeasureLayout: ws
                    }
                };
            var Kn = i(2577),
                Wn = i(4778);

            function Xn(t, e, i) {
                const s = t.getProps();
                return (0, Wn.a)(s, e, void 0 !== i ? i : s.custom, t)
            }
            var qn = i(5094);

            function zn(t, e, i) {
                t.hasValue(e) ? t.getValue(e).set(i) : t.addValue(e, Cs(i))
            }

            function Hn({
                protectedKeys: t,
                needsAnimating: e
            }, i) {
                const s = t.hasOwnProperty(i) && !0 !== e[i];
                return e[i] = !1, s
            }

            function Yn(t, e, {
                delay: i = 0,
                transitionOverride: s,
                type: n
            } = {}) {
                var o;
                let {
                    transition: r = t.getDefaultTransition(),
                    transitionEnd: a,
                    ...h
                } = e;
                s && (r = s);
                const u = [],
                    c = n && t.animationState && t.animationState.getState()[n];
                for (const e in h) {
                    const s = t.getValue(e, null !== (o = t.latestValues[e]) && void 0 !== o ? o : null),
                        n = h[e];
                    if (void 0 === n || c && Hn(c, e)) continue;
                    const a = {
                        delay: i,
                        ...l(r || {}, e)
                    };
                    let d = !1;
                    if (window.MotionHandoffAnimation) {
                        const i = ks(t);
                        if (i) {
                            const t = window.MotionHandoffAnimation(i, e, _.Gt);
                            null !== t && (a.startTime = t, d = !0)
                        }
                    }
                    rs(t, e), s.start(ss(e, s, n, t.shouldReduceMotion && oe.has(e) ? {
                        type: !1
                    } : a, t, d));
                    const p = s.animation;
                    p && u.push(p)
                }
                return a && Promise.all(u).then((() => {
                    _.Gt.update((() => {
                        a && function(t, e) {
                            const i = Xn(t, e);
                            let {
                                transitionEnd: s = {},
                                transition: n = {},
                                ...o
                            } = i || {};
                            o = { ...o,
                                ...s
                            };
                            for (const e in o) zn(t, e, (0, qn.K)(o[e]))
                        }(t, a)
                    }))
                })), u
            }

            function _n(t, e, i = {}) {
                var s;
                const n = Xn(t, e, "exit" === i.type ? null === (s = t.presenceContext) || void 0 === s ? void 0 : s.custom : void 0);
                let {
                    transition: o = t.getDefaultTransition() || {}
                } = n || {};
                i.transitionOverride && (o = i.transitionOverride);
                const r = n ? () => Promise.all(Yn(t, n, i)) : () => Promise.resolve(),
                    a = t.variantChildren && t.variantChildren.size ? (s = 0) => {
                        const {
                            delayChildren: n = 0,
                            staggerChildren: r,
                            staggerDirection: a
                        } = o;
                        return function(t, e, i = 0, s = 0, n = 1, o) {
                            const r = [],
                                a = (t.variantChildren.size - 1) * s,
                                l = 1 === n ? (t = 0) => t * s : (t = 0) => a - t * s;
                            return Array.from(t.variantChildren).sort(Qn).forEach(((t, s) => {
                                t.notify("AnimationStart", e), r.push(_n(t, e, { ...o,
                                    delay: i + l(s)
                                }).then((() => t.notify("AnimationComplete", e))))
                            })), Promise.all(r)
                        }(t, e, n + s, r, a, i)
                    } : () => Promise.resolve(),
                    {
                        when: l
                    } = o;
                if (l) {
                    const [t, e] = "beforeChildren" === l ? [r, a] : [a, r];
                    return t().then((() => e()))
                }
                return Promise.all([r(), a(i.delay)])
            }

            function Qn(t, e) {
                return t.sortNodePosition(e)
            }
            var Zn = i(5779);

            function Jn(t, e) {
                if (!Array.isArray(e)) return !1;
                const i = e.length;
                if (i !== t.length) return !1;
                for (let s = 0; s < i; s++)
                    if (e[s] !== t[s]) return !1;
                return !0
            }
            var to = i(2564),
                eo = i(4741);
            const io = eo._.length;

            function so(t) {
                if (!t) return;
                if (!t.isControllingVariants) {
                    const e = t.parent && so(t.parent) || {};
                    return void 0 !== t.props.initial && (e.initial = t.props.initial), e
                }
                const e = {};
                for (let i = 0; i < io; i++) {
                    const s = eo._[i],
                        n = t.props[s];
                    ((0, to.w)(n) || !1 === n) && (e[s] = n)
                }
                return e
            }
            const no = [...eo.U].reverse(),
                oo = eo.U.length;

            function ro(t) {
                return e => Promise.all(e.map((({
                    animation: e,
                    options: i
                }) => function(t, e, i = {}) {
                    let s;
                    if (t.notify("AnimationStart", e), Array.isArray(e)) {
                        const n = e.map((e => _n(t, e, i)));
                        s = Promise.all(n)
                    } else if ("string" == typeof e) s = _n(t, e, i);
                    else {
                        const n = "function" == typeof e ? Xn(t, e, i.custom) : e;
                        s = Promise.all(Yn(t, n, i))
                    }
                    return s.then((() => {
                        t.notify("AnimationComplete", e)
                    }))
                }(t, e, i))))
            }

            function ao(t) {
                let e = ro(t),
                    i = uo(),
                    s = !0;
                const n = e => (i, s) => {
                    var n;
                    const o = Xn(t, s, "exit" === e ? null === (n = t.presenceContext) || void 0 === n ? void 0 : n.custom : void 0);
                    if (o) {
                        const {
                            transition: t,
                            transitionEnd: e,
                            ...s
                        } = o;
                        i = { ...i,
                            ...s,
                            ...e
                        }
                    }
                    return i
                };

                function o(o) {
                    const {
                        props: r
                    } = t, a = so(t.parent) || {}, l = [], h = new Set;
                    let u = {},
                        c = 1 / 0;
                    for (let e = 0; e < oo; e++) {
                        const d = no[e],
                            p = i[d],
                            m = void 0 !== r[d] ? r[d] : a[d],
                            f = (0, to.w)(m),
                            v = d === o ? p.isActive : null;
                        !1 === v && (c = e);
                        let g = m === a[d] && m !== r[d] && f;
                        if (g && s && t.manuallyAnimateOnMount && (g = !1), p.protectedKeys = { ...u
                            }, !p.isActive && null === v || !m && !p.prevProp || (0, Kn.N)(m) || "boolean" == typeof m) continue;
                        const y = lo(p.prevProp, m);
                        let x = y || d === o && p.isActive && !g && f || e > c && f,
                            P = !1;
                        const T = Array.isArray(m) ? m : [m];
                        let S = T.reduce(n(d), {});
                        !1 === v && (S = {});
                        const {
                            prevResolvedValues: w = {}
                        } = p, A = { ...w,
                            ...S
                        }, b = e => {
                            x = !0, h.has(e) && (P = !0, h.delete(e)), p.needsAnimating[e] = !0;
                            const i = t.getValue(e);
                            i && (i.liveStyle = !1)
                        };
                        for (const t in A) {
                            const e = S[t],
                                i = w[t];
                            if (u.hasOwnProperty(t)) continue;
                            let s = !1;
                            s = (0, Zn.p)(e) && (0, Zn.p)(i) ? !Jn(e, i) : e !== i, s ? null != e ? b(t) : h.add(t) : void 0 !== e && h.has(t) ? b(t) : p.protectedKeys[t] = !0
                        }
                        p.prevProp = m, p.prevResolvedValues = S, p.isActive && (u = { ...u,
                            ...S
                        }), s && t.blockInitialAnimation && (x = !1);
                        x && (!(g && y) || P) && l.push(...T.map((t => ({
                            animation: t,
                            options: {
                                type: d
                            }
                        }))))
                    }
                    if (h.size) {
                        const e = {};
                        h.forEach((i => {
                            const s = t.getBaseTarget(i),
                                n = t.getValue(i);
                            n && (n.liveStyle = !0), e[i] = null != s ? s : null
                        })), l.push({
                            animation: e
                        })
                    }
                    let d = Boolean(l.length);
                    return !s || !1 !== r.initial && r.initial !== r.animate || t.manuallyAnimateOnMount || (d = !1), s = !1, d ? e(l) : Promise.resolve()
                }
                return {
                    animateChanges: o,
                    setActive: function(e, s) {
                        var n;
                        if (i[e].isActive === s) return Promise.resolve();
                        null === (n = t.variantChildren) || void 0 === n || n.forEach((t => {
                            var i;
                            return null === (i = t.animationState) || void 0 === i ? void 0 : i.setActive(e, s)
                        })), i[e].isActive = s;
                        const r = o(e);
                        for (const t in i) i[t].protectedKeys = {};
                        return r
                    },
                    setAnimateFunction: function(i) {
                        e = i(t)
                    },
                    getState: () => i,
                    reset: () => {
                        i = uo(), s = !0
                    }
                }
            }

            function lo(t, e) {
                return "string" == typeof e ? e !== t : !!Array.isArray(e) && !Jn(e, t)
            }

            function ho(t = !1) {
                return {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }

            function uo() {
                return {
                    animate: ho(!0),
                    whileInView: ho(),
                    whileHover: ho(),
                    whileTap: ho(),
                    whileDrag: ho(),
                    whileFocus: ho(),
                    exit: ho()
                }
            }
            let co = 0;
            const po = {
                animation: {
                    Feature: class extends s {
                        constructor(t) {
                            super(t), t.animationState || (t.animationState = ao(t))
                        }
                        updateAnimationControlsSubscription() {
                            const {
                                animate: t
                            } = this.node.getProps();
                            (0, Kn.N)(t) && (this.unmountControls = t.subscribe(this.node))
                        }
                        mount() {
                            this.updateAnimationControlsSubscription()
                        }
                        update() {
                            const {
                                animate: t
                            } = this.node.getProps(), {
                                animate: e
                            } = this.node.prevProps || {};
                            t !== e && this.updateAnimationControlsSubscription()
                        }
                        unmount() {
                            var t;
                            this.node.animationState.reset(), null === (t = this.unmountControls) || void 0 === t || t.call(this)
                        }
                    }
                },
                exit: {
                    Feature: class extends s {
                        constructor() {
                            super(...arguments), this.id = co++
                        }
                        update() {
                            if (!this.node.presenceContext) return;
                            const {
                                isPresent: t,
                                onExitComplete: e
                            } = this.node.presenceContext, {
                                isPresent: i
                            } = this.node.prevPresenceContext || {};
                            if (!this.node.animationState || t === i) return;
                            const s = this.node.animationState.setActive("exit", !t);
                            e && !t && s.then((() => {
                                e(this.id)
                            }))
                        }
                        mount() {
                            const {
                                register: t,
                                onExitComplete: e
                            } = this.node.presenceContext || {};
                            e && e(this.id), t && (this.unmount = t(this.id))
                        }
                        unmount() {}
                    }
                }
            };

            function mo(t, e, i) {
                const {
                    props: s
                } = t;
                t.animationState && s.whileHover && t.animationState.setActive("whileHover", "Start" === i);
                const n = s["onHover" + i];
                n && _.Gt.postRender((() => n(e, X(e))))
            }

            function fo(t, e, i) {
                const {
                    props: s
                } = t;
                t.animationState && s.whileTap && t.animationState.setActive("whileTap", "Start" === i);
                const n = s["onTap" + ("End" === i ? "" : i)];
                n && _.Gt.postRender((() => n(e, X(e))))
            }
            const vo = new WeakMap,
                go = new WeakMap,
                yo = t => {
                    const e = vo.get(t.target);
                    e && e(t)
                },
                xo = t => {
                    t.forEach(yo)
                };

            function Po(t, e, i) {
                const s = function({
                    root: t,
                    ...e
                }) {
                    const i = t || document;
                    go.has(i) || go.set(i, {});
                    const s = go.get(i),
                        n = JSON.stringify(e);
                    return s[n] || (s[n] = new IntersectionObserver(xo, {
                        root: t,
                        ...e
                    })), s[n]
                }(e);
                return vo.set(t, i), s.observe(t), () => {
                    vo.delete(t), s.unobserve(t)
                }
            }
            const To = {
                some: 0,
                all: 1
            };
            const So = {
                inView: {
                    Feature: class extends s {
                        constructor() {
                            super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                        }
                        startObserver() {
                            this.unmount();
                            const {
                                viewport: t = {}
                            } = this.node.getProps(), {
                                root: e,
                                margin: i,
                                amount: s = "some",
                                once: n
                            } = t, o = {
                                root: e ? e.current : void 0,
                                rootMargin: i,
                                threshold: "number" == typeof s ? s : To[s]
                            };
                            return Po(this.node.current, o, (t => {
                                const {
                                    isIntersecting: e
                                } = t;
                                if (this.isInView === e) return;
                                if (this.isInView = e, n && !e && this.hasEnteredView) return;
                                e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                                const {
                                    onViewportEnter: i,
                                    onViewportLeave: s
                                } = this.node.getProps(), o = e ? i : s;
                                o && o(t)
                            }))
                        }
                        mount() {
                            this.startObserver()
                        }
                        update() {
                            if ("undefined" == typeof IntersectionObserver) return;
                            const {
                                props: t,
                                prevProps: e
                            } = this.node;
                            ["amount", "margin", "root"].some(function({
                                viewport: t = {}
                            }, {
                                viewport: e = {}
                            } = {}) {
                                return i => t[i] !== e[i]
                            }(t, e)) && this.startObserver()
                        }
                        unmount() {}
                    }
                },
                tap: {
                    Feature: class extends s {
                        mount() {
                            const {
                                current: t
                            } = this.node;
                            t && (this.unmount = K(t, ((t, e) => (fo(this.node, e, "Start"), (t, {
                                success: e
                            }) => fo(this.node, t, e ? "End" : "Cancel"))), {
                                useGlobalTarget: this.node.props.globalTapTarget
                            }))
                        }
                        unmount() {}
                    }
                },
                focus: {
                    Feature: class extends s {
                        constructor() {
                            super(...arguments), this.isActive = !1
                        }
                        onFocus() {
                            let t = !1;
                            try {
                                t = this.node.current.matches(":focus-visible")
                            } catch (e) {
                                t = !0
                            }
                            t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                        }
                        onBlur() {
                            this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                        }
                        mount() {
                            this.unmount = Y(W(this.node.current, "focus", (() => this.onFocus())), W(this.node.current, "blur", (() => this.onBlur())))
                        }
                        unmount() {}
                    }
                },
                hover: {
                    Feature: class extends s {
                        mount() {
                            const {
                                current: t
                            } = this.node;
                            t && (this.unmount = function(t, e, i = {}) {
                                const [s, n, o] = B(t, i), r = t => {
                                    if (!L(t)) return;
                                    const {
                                        target: i
                                    } = t, s = e(i, t);
                                    if ("function" != typeof s || !i) return;
                                    const o = t => {
                                        L(t) && (s(t), i.removeEventListener("pointerleave", o))
                                    };
                                    i.addEventListener("pointerleave", o, n)
                                };
                                return s.forEach((t => {
                                    t.addEventListener("pointerenter", r, n)
                                })), o
                            }(t, ((t, e) => (mo(this.node, e, "Start"), t => mo(this.node, t, "End")))))
                        }
                        unmount() {}
                    }
                }
            };
            var wo = i(2879),
                Ao = i(6966);
            const bo = {
                    current: null
                },
                Do = {
                    current: !1
                };
            const Eo = [...ti, ve, Ve],
                Vo = new WeakMap;
            var Mo = i(8752);
            const Co = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
            class Ro {
                scrapeMotionValuesFromProps(t, e, i) {
                    return {}
                }
                constructor({
                    parent: t,
                    props: e,
                    presenceContext: i,
                    reducedMotionConfig: s,
                    blockInitialAnimation: n,
                    visualState: o
                }, r = {}) {
                    this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = He, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.renderScheduledAt = 0, this.scheduleRender = () => {
                        const t = oi.now();
                        this.renderScheduledAt < t && (this.renderScheduledAt = t, _.Gt.render(this.render, !1, !0))
                    };
                    const {
                        latestValues: a,
                        renderState: l,
                        onUpdate: h
                    } = o;
                    this.onUpdate = h, this.latestValues = a, this.baseTarget = { ...a
                    }, this.initialValues = e.initial ? { ...a
                    } : {}, this.renderState = l, this.parent = t, this.props = e, this.presenceContext = i, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = s, this.options = r, this.blockInitialAnimation = Boolean(n), this.isControllingVariants = (0, Mo.e)(e), this.isVariantNode = (0, Mo.O)(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = Boolean(t && t.current);
                    const {
                        willChange: u,
                        ...c
                    } = this.scrapeMotionValuesFromProps(e, {}, this);
                    for (const t in c) {
                        const e = c[t];
                        void 0 !== a[t] && (0, os.S)(e) && e.set(a[t], !1)
                    }
                }
                mount(t) {
                    this.current = t, Vo.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach(((t, e) => this.bindToMotionValue(e, t))), Do.current || function() {
                        if (Do.current = !0, Ao.B)
                            if (window.matchMedia) {
                                const t = window.matchMedia("(prefers-reduced-motion)"),
                                    e = () => bo.current = t.matches;
                                t.addListener(e), e()
                            } else bo.current = !1
                    }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || bo.current), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
                }
                unmount() {
                    this.projection && this.projection.unmount(), (0, _.WG)(this.notifyUpdate), (0, _.WG)(this.render), this.valueSubscriptions.forEach((t => t())), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this);
                    for (const t in this.events) this.events[t].clear();
                    for (const t in this.features) {
                        const e = this.features[t];
                        e && (e.unmount(), e.isMounted = !1)
                    }
                    this.current = null
                }
                bindToMotionValue(t, e) {
                    this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)();
                    const i = ne.f.has(t);
                    i && this.onBindTransform && this.onBindTransform();
                    const s = e.on("change", (e => {
                            this.latestValues[t] = e, this.props.onUpdate && _.Gt.preRender(this.notifyUpdate), i && this.projection && (this.projection.isTransformDirty = !0)
                        })),
                        n = e.on("renderRequest", this.scheduleRender);
                    let o;
                    window.MotionCheckAppearSync && (o = window.MotionCheckAppearSync(this, t, e)), this.valueSubscriptions.set(t, (() => {
                        s(), n(), o && o(), e.owner && e.stop()
                    }))
                }
                sortNodePosition(t) {
                    return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
                }
                updateFeatures() {
                    let t = "animation";
                    for (t in wo.B) {
                        const e = wo.B[t];
                        if (!e) continue;
                        const {
                            isEnabled: i,
                            Feature: s
                        } = e;
                        if (!this.features[t] && s && i(this.props) && (this.features[t] = new s(this)), this.features[t]) {
                            const e = this.features[t];
                            e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                        }
                    }
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : wt()
                }
                getStaticValue(t) {
                    return this.latestValues[t]
                }
                setStaticValue(t, e) {
                    this.latestValues[t] = e
                }
                update(t, e) {
                    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
                    for (let e = 0; e < Co.length; e++) {
                        const i = Co[e];
                        this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
                        const s = t["on" + i];
                        s && (this.propEventSubscriptions[i] = this.on(i, s))
                    }
                    this.prevMotionValues = function(t, e, i) {
                        for (const s in e) {
                            const n = e[s],
                                o = i[s];
                            if ((0, os.S)(n)) t.addValue(s, n);
                            else if ((0, os.S)(o)) t.addValue(s, Cs(n, {
                                owner: t
                            }));
                            else if (o !== n)
                                if (t.hasValue(s)) {
                                    const e = t.getValue(s);
                                    !0 === e.liveStyle ? e.jump(n) : e.hasAnimated || e.set(n)
                                } else {
                                    const e = t.getStaticValue(s);
                                    t.addValue(s, Cs(void 0 !== e ? e : n, {
                                        owner: t
                                    }))
                                }
                        }
                        for (const s in i) void 0 === e[s] && t.removeValue(s);
                        return e
                    }(this, this.scrapeMotionValuesFromProps(t, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue(), this.onUpdate && this.onUpdate(this)
                }
                getProps() {
                    return this.props
                }
                getVariant(t) {
                    return this.props.variants ? this.props.variants[t] : void 0
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
                }
                addVariantChild(t) {
                    const e = this.getClosestVariantNode();
                    if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
                }
                addValue(t, e) {
                    const i = this.values.get(t);
                    e !== i && (i && this.removeValue(t), this.bindToMotionValue(t, e), this.values.set(t, e), this.latestValues[t] = e.get())
                }
                removeValue(t) {
                    this.values.delete(t);
                    const e = this.valueSubscriptions.get(t);
                    e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
                }
                hasValue(t) {
                    return this.values.has(t)
                }
                getValue(t, e) {
                    if (this.props.values && this.props.values[t]) return this.props.values[t];
                    let i = this.values.get(t);
                    return void 0 === i && void 0 !== e && (i = Cs(null === e ? void 0 : e, {
                        owner: this
                    }), this.addValue(t, i)), i
                }
                readValue(t, e) {
                    var i;
                    let s = void 0 === this.latestValues[t] && this.current ? null !== (i = this.getBaseTargetFromProps(this.props, t)) && void 0 !== i ? i : this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
                    var n;
                    return null != s && ("string" == typeof s && (Ye(s) || se(s)) ? s = parseFloat(s) : (n = s, !Eo.find(Je(n)) && Ve.test(e) && (s = je(t, e))), this.setBaseTarget(t, (0, os.S)(s) ? s.get() : s)), (0, os.S)(s) ? s.get() : s
                }
                setBaseTarget(t, e) {
                    this.baseTarget[t] = e
                }
                getBaseTarget(t) {
                    var e;
                    const {
                        initial: i
                    } = this.props;
                    let s;
                    if ("string" == typeof i || "object" == typeof i) {
                        const n = (0, Wn.a)(this.props, i, null === (e = this.presenceContext) || void 0 === e ? void 0 : e.custom);
                        n && (s = n[t])
                    }
                    if (i && void 0 !== s) return s;
                    const n = this.getBaseTargetFromProps(this.props, t);
                    return void 0 === n || (0, os.S)(n) ? void 0 !== this.initialValues[t] && void 0 === s ? void 0 : this.baseTarget[t] : n
                }
                on(t, e) {
                    return this.events[t] || (this.events[t] = new Es), this.events[t].add(e)
                }
                notify(t, ...e) {
                    this.events[t] && this.events[t].notify(...e)
                }
            }
            class ko extends Ro {
                constructor() {
                    super(...arguments), this.KeyframeResolver = ii
                }
                sortInstanceNodePosition(t, e) {
                    return 2 & t.compareDocumentPosition(e) ? 1 : -1
                }
                getBaseTargetFromProps(t, e) {
                    return t.style ? t.style[e] : void 0
                }
                removeValueFromRenderState(t, {
                    vars: e,
                    style: i
                }) {
                    delete e[t], delete i[t]
                }
                handleChildMotionValue() {
                    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
                    const {
                        children: t
                    } = this.props;
                    (0, os.S)(t) && (this.childSubscription = t.on("change", (t => {
                        this.current && (this.current.textContent = `${t}`)
                    })))
                }
            }
            var Bo = i(8377),
                Lo = i(7973),
                jo = i(8731);
            class Fo extends ko {
                constructor() {
                    super(...arguments), this.type = "html", this.renderInstance = Lo.e
                }
                readValueFromInstance(t, e) {
                    if (ne.f.has(e)) {
                        const t = Le(e);
                        return t && t.default || 0
                    } {
                        const s = (i = t, window.getComputedStyle(i)),
                            n = ((0, _e.j)(e) ? s.getPropertyValue(e) : s[e]) || 0;
                        return "string" == typeof n ? n.trim() : n
                    }
                    var i
                }
                measureInstanceViewportBox(t, {
                    transformPagePoint: e
                }) {
                    return Nt(t, e)
                }
                build(t, e, i) {
                    (0, Bo.O)(t, e, i.transformTemplate)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return (0, jo.x)(t, e, i)
                }
            }
            var Uo = i(303),
                Oo = i(3780),
                Io = i(8104),
                No = i(8210),
                Go = i(648),
                $o = i(4680),
                Ko = i(7354);
            class Wo extends ko {
                constructor() {
                    super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = wt, this.updateDimensions = () => {
                        this.current && !this.renderState.dimensions && (0, Go.H)(this.current, this.renderState)
                    }
                }
                getBaseTargetFromProps(t, e) {
                    return t[e]
                }
                readValueFromInstance(t, e) {
                    if (ne.f.has(e)) {
                        const t = Le(e);
                        return t && t.default || 0
                    }
                    return e = Io.e.has(e) ? e : (0, Uo.I)(e), t.getAttribute(e)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return (0, Ko.x)(t, e, i)
                }
                onBindTransform() {
                    this.current && !this.renderState.dimensions && _.Gt.postRender(this.updateDimensions)
                }
                build(t, e, i) {
                    (0, Oo.B)(t, e, this.isSVGTag, i.transformTemplate)
                }
                renderInstance(t, e, i, s) {
                    (0, $o.d)(t, e, i, s)
                }
                mount(t) {
                    this.isSVGTag = (0, No.n)(t.tagName), super.mount(t)
                }
            }
            var Xo = i(7976);
            const qo = { ...{
                    renderer: (t, e) => (0, Xo.Q)(t) ? new Wo(e) : new Fo(e, {
                        allowProjection: t !== ds.Fragment
                    }),
                    ...po,
                    ...So
                },
                ...Gn,
                ...$n
            }
        }
    }
]);