(() => {
    var t = function() {
        var t = document.createElement("script");
        t.type = "text/javascript", t.async = !0, t.src = "".concat("https://widget.superchat.de", "/sdk.js"), t.onload = function() {
            window.Superchat.init({
                applicationKey: "WCW25VexmLa9Dj4dB6yO8q3AGj"
            })
        }, document.body.appendChild(t)
    };
    "complete" === document.readyState ? t() : window.addEventListener("load", t)
})();