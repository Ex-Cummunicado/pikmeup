"use strict";
(self.webpackChunk_superchat_widget_microsite = self.webpackChunk_superchat_widget_microsite || []).push([
    [4265], {
        4265: e => {
            e.exports = JSON.parse('{"ChatInputAttachment":{"failed":"Failed","deleteAttachment":"Remove attachment"},"DropzoneOverlay":{"title":"Place attachments here"},"GrowingTextarea":{"placeholder":"Write message ..."},"LivechatInput":{"fileTooBig":"File is too large (max. 15MB)","invalidFileType":"Invalid file type","maximumAttachments":"Send max. {maxNumOfAttachments} attachments at the same time."},"ChatInput":{"emojiButton":{"tooltip":"Emoji"},"attachmentButton":{"tooltip":"Attachment"}},"LivechatPrivacyPolicyBanner":{"text":"Personal data may be processed when using the live chat. Further information can be found in our <a>privacy policy</a>."},"LivechatDateLabel":{"yesterday":"Yesterday","today":"Today"},"fallback":"Missing translation","choose":"Select","Widget":{"writeOnWhatsApp":"Write on WhatsApp","select":"Select"},"scanQrCode":"Scan QR code now and chat via WhatsApp:","chatViaDesktop":"write via WhatsApp Web"}')
        }
    }
]);