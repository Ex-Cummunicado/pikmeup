((e, t, n, i, a, o, c, s) => {
    let l = "wt:integrated",
        u = "wt:attributes",
        p = "wt:cart",
        d = "wt:wtp",
        m = "wt:error",
        f = "__kla_id";
    if (!e[l]) {
        e[l] = e.WETRACKED_INTEGRATION = !0;
        try {
            let l = () => "object" == typeof e.Shopify && !!e.Shopify.shop,
                h = e => {
                    if ("undefined" != typeof URL) return new URL(n.href).searchParams.get(e);
                    let t = (n.search.match(RegExp(`[?&]${e}=([^&]*)`)) || [])[1] || null;
                    return t && (t = decodeURIComponent(t.replace(/\+/g, " "))), t
                },
                g = e => {
                    let n = `; ${t.cookie}`.split(`; ${e}=`);
                    return 2 === n.length && n.pop().split(";").shift() || null
                },
                _ = (e, i, a) => {
                    let o = `max-age=${864e5*a}`,
                        c = `domain=${n.hostname.split(".").reverse().splice(0,2).reverse().join(".")}`;
                    return t.cookie = [`${e}=${i}`, "path=/", o, c, "samesite=lax"].join(";"), i
                },
                y = () => l() ? fetch(n.pathname + ".json").then(e => e.json()).then(e => e && e.product || null).catch(() => null) : Promise.resolve(null),
                w = t => y().then(i => Object.assign({
                    sd: s,
                    loc: n.origin + n.pathname
                }, i ? {
                    val: i.variants[0].price,
                    cur: e.Shopify.currency.active,
                    pid: i.id,
                    vids: i.variants.map(e => e.id).join(",")
                } : {}, t)).then(e => fetch(`https://pixel.wetracked.io/carts/init?${new URLSearchParams(e)}`).then(e => e.ok)),
                b = e => new URLSearchParams(Object.entries(e).map(([e, t]) => [`attributes[${e}]`, t])),
                v = e => {
                    if (e) return e.split("?key=")[0];
                    let t = g("cart");
                    return t ? decodeURIComponent(t).split("?key=")[0] : null
                },
                k = t => ("object" == typeof e["wt:cart:promise"] && "then" in e["wt:cart:promise"] ? e["wt:cart:promise"] : fetch(c ? .omitNoteAttributes || e["wt:cart:attributes:omit"] ? (e.Shopify.routes ? .root || "/") + "cart/update.js" : (e.Shopify.routes ? .root || "/") + `cart/update.js?${b(t)}`).then(e => e.json())).catch(t => (e[m] = t, null)).then(e => v(e && e.token)).then(n => !!n && w(Object.assign({
                    ct: e[p] = n
                }, t))),
                E = () => {
                    if (e[u]) return e[u];
                    try {
                        let t = JSON.parse(i.getItem(u) || "{}");
                        if (!(t && "object" == typeof t) || Array.isArray(t)) return {};
                        return e[u] = t
                    } catch {
                        return {}
                    }
                },
                j = e => i.setItem(u, JSON.stringify(Object.assign(E(), e))),
                x = (e, t) => Math.floor(Math.random() * (t - e + 1)) + e,
                I = () => `fb.1.${Date.now()}.${Math.round(2147483647*Math.random())}`,
                q = e => `fb.1.${Date.now()}.${e}`,
                A = e => {
                    if (e) try {
                        return JSON.parse(atob(e)).$exchange_id
                    } catch {}
                    return null
                },
                $ = (e, t = ",") => e.replace("," === t ? /([^\\]),/g : /([^\\]):/g, "$1\v").replace(/\\/g, "").split("\v").map(e => e.trim()).filter(Boolean),
                S = (e, t) => {
                    if (!t) return !0;
                    if ("condition" in t) return 0 === t.rules.length || ("and" === t.condition ? t.rules.every(t => S(e, t)) : t.rules.some(t => S(e, t)));
                    let n = e[t.field] ? ? "";
                    if ("string" == typeof n) switch (t.operator) {
                        case "is":
                            return n == t.value;
                        case "is not":
                            return n != t.value;
                        case "in":
                            return $(t.value).includes(n);
                        case "not in":
                            return !$(t.value).includes(n)
                    }
                    if (Array.isArray(n)) switch (t.operator) {
                        case "is":
                            return n.includes(t.value);
                        case "is not":
                            return !n.includes(t.value);
                        case "in":
                            return $(t.value).some(e => n.includes(e));
                        case "not in":
                            return $(t.value).every(e => !n.includes(e))
                    }
                    switch (t.operator) {
                        case "is":
                            {
                                let [e, i] = $(t.value, ":");
                                return "[]" === i ? !n[e] : n[e] === i
                            }
                        case "is not":
                            {
                                let [e, i] = $(t.value, ":");
                                return !("[]" === i ? !n[e] : n[e] === i)
                            }
                        case "in":
                            return $(t.value).some(e => {
                                let [t, i] = $(e, ":");
                                return "[]" === i ? !n[t] : n[t] === i
                            });
                        case "not in":
                            return $(t.value).every(e => {
                                let [t, i] = $(e, ":");
                                return !("[]" === i ? !n[t] : n[t] === i)
                            })
                    }
                },
                N = () => {
                    e["wt:integrated:pixels"] = !0;
                    let n = a.filter(t => S({
                        "attributes:all": e[u] ? ? {},
                        host: e[u] ? .host ? ? "",
                        utm_source: e[u] ? .utm_source ? ? "",
                        utm_medium: e[u] ? .utm_medium ? ? "",
                        utm_campaign: e[u] ? .utm_campaign ? ? "",
                        utm_content: e[u] ? .utm_content ? ? "",
                        utm_term: e[u] ? .utm_term ? ? ""
                    }, o ? .pixelRules ? .find(e => e.id == t.id)));
                    if (0 === n.length) return;
                    let i = n.filter(e => "facebook" === e.platform);
                    i.length > 0 && (! function(e, t, n, i, a, o, c) {
                        e.fbq || (a = e.fbq = function() {
                            a.callMethod ? a.callMethod.apply(a, arguments) : a.queue.push(arguments)
                        }, e._fbq || (e._fbq = a), a.push = a, a.loaded = !0, a.version = "2.0", a.queue = [], (o = t.createElement(n)).async = !0, o.src = i, (c = t.getElementsByTagName(n)[0]).parentNode.insertBefore(o, c))
                    }(e, t, "script", "https://connect.facebook.net/en_US/fbevents.js"), i.forEach(e => fbq("init", e.pixelId)), fbq("track", "PageView"));
                    let c = n.filter(e => "tiktok" === e.platform);
                    c.length > 0 && function(e, n, i) {
                        e.TiktokAnalyticsObject = i;
                        let a = e[i] = e[i] || [];
                        a.methods = ["page", "track", "identify", "instances", "debug", "on", "off", "once", "ready", "alias", "group", "enableCookie", "disableCookie", "holdConsent", "revokeConsent", "grantConsent"], a.setAndDefer = function(e, t) {
                            e[t] = function() {
                                e.push([t].concat(Array.prototype.slice.call(arguments, 0)))
                            }
                        };
                        for (let e = 0; e < a.methods.length; e++) a.setAndDefer(a, a.methods[e]);
                        a.instance = function(e) {
                            for (var t = a._i[e] || [], n = 0; n < a.methods.length; n++) a.setAndDefer(t, a.methods[n]);
                            return t
                        }, a.load = function(e, n) {
                            let o = "https://analytics.tiktok.com/i18n/pixel/events.js";
                            n && n.partner, a._i = a._i || {}, a._i[e] = [], a._i[e]._u = o, a._t = a._t || {}, a._t[e] = +new Date, a._o = a._o || {}, a._o[e] = n || {}, (n = t.createElement("script")).type = "text/javascript", n.async = !0, n.src = o + "?sdkid=" + e + "&lib=" + i, (e = t.getElementsByTagName("script")[0]).parentNode.insertBefore(n, e)
                        }, c.forEach(e => a.load(e.pixelId)), l() || a.page()
                    }(e, 0, "ttq");
                    let s = n.filter(e => "pinterest" === e.platform);
                    s.length > 0 && (! function(n) {
                        if (!e.pintrk) {
                            e.pintrk = function() {
                                e.pintrk.queue.push(Array.prototype.slice.call(arguments))
                            };
                            let i = e.pintrk;
                            i.queue = [], i.version = "3.0";
                            let a = t.createElement("script");
                            a.async = !0, a.src = n;
                            let o = t.getElementsByTagName("script")[0];
                            o.parentNode.insertBefore(a, o)
                        }
                    }("https://s.pinimg.com/ct/core.js"), s.forEach(e => pintrk("load", e.tagId)), l() || pintrk("page"));
                    let p = n.filter(e => "snapchat" === e.platform);
                    p.length > 0 && (! function(e, t, n) {
                        if (e.snaptr) return;
                        var i = e.snaptr = function() {
                            i.handleRequest ? i.handleRequest.apply(i, arguments) : i.queue.push(arguments)
                        };
                        i.queue = [];
                        let a = "script";
                        (r = t.createElement(a)).async = !0, r.src = n;
                        let o = t.getElementsByTagName(a)[0];
                        o.parentNode.insertBefore(r, o)
                    }(e, t, "https://sc-static.net/scevent.min.js"), p.forEach(e => snaptr("init", e.pixelId)), l() || snaptr("track", "PAGE_VIEW"));
                    let d = n.filter(e => "x" === e.platform);
                    d.length > 0 && (function(e, t, n, i, a, o) {
                        e.twq || ((i = e.twq = function() {
                            i.exe ? i.exe.apply(i, arguments) : i.queue.push(arguments)
                        }).version = "1.1", i.queue = [], (a = t.createElement(n)).async = !0, a.src = "https://static.ads-twitter.com/uwt.js", (o = t.getElementsByTagName(n)[0]).parentNode.insertBefore(a, o))
                    }(e, t, "script"), d.forEach(e => twq("config", e.pixelId)), l() || d.forEach(e => twq("event", e.pageViewEventId))), n.filter(e => "google" === e.platform).forEach(n => {
                        function i() {
                            dataLayer.push(arguments)
                        }(function(e, n, i) {
                            (i = t.createElement("script")).async = !0, i.src = n, e.appendChild(i)
                        })(t.body, `https://www.googletagmanager.com/gtag/js?id=AW-${n.conversionId}`), e.dataLayer = e.dataLayer || [], i("js", new Date), i("config", `AW-${n.conversionId}`), l() || i("event", "conversion", {
                            send_to: `AW-${n.conversionId}/${n.pageViewConversionLabel}`
                        })
                    }), n.filter(e => "klaviyo" === e.platform).forEach(e => {
                        ! function(t) {
                            let n = t.createElement("script");
                            n.src = `https://static.klaviyo.com/onsite/js/klaviyo.js?company_id=${e.publicApiKey}`, n.async = !0, t.head.append(n)
                        }(t)
                    }), n.filter(e => "reddit" === e.platform).forEach(n => {
                        (function(e, t, n, i, a, o) {
                            e[i] = e[i] || function() {
                                (e[i].q = e[i].q || []).push(arguments)
                            }, (o = t.createElement(n)).async = !0, o.src = a, t.head.appendChild(o)
                        })(e, t, "script", "r", "https://www.redditstatic.com/ads/pixel.js"), e.r("init", n.pixelId), e.r("track", "PageVisit")
                    })
                },
                C = h("fbclid"),
                O = C && _("_fbc", q(C), 90) || g("_fbc"),
                T = g("_fbp") || _("_fbp", I(), 90);
            O && !/^fb\.\d+\.\d{13}\..+$/.test(O) && C && (O = _("_fbc", q(C), 90)), T && !/^fb\.\d+\.\d{13}\..+$/.test(T) && (T = _("_fbp", I(), 90));
            let R = h("ttclid"),
                B = g("_ttp") || _("_ttp", ((e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789") => Array.from({
                    length: 27
                }, () => e.charAt(x(0, e.length - 1))).join(""))(), 90),
                L = h("gclid"),
                P = h("wbraid"),
                D = h("gbraid"),
                M = h("epik"),
                U = h("ScCid"),
                F = g("_scid"),
                V = h("twclid"),
                W = h("_kx"),
                J = h("rdt_cid"),
                Y = h("utm_id"),
                G = h("utm_source"),
                K = h("utm_medium"),
                H = h("utm_campaign"),
                X = h("utm_term"),
                z = h("utm_content");
            setTimeout(function i(a = 1) {
                try {
                    let c = g("_gcl_au") ? .split(".") || [],
                        s = c.length >= 4 ? c[2] + "." + c[3] : null,
                        h = {
                            host: n.origin,
                            fbp: T,
                            ttp: B,
                            sw: String(e.screen.width),
                            sh: String(e.screen.height)
                        };
                    if (O && (h.fbc = O), R && (h.ttclid = R), M && (h.epik = M), L && (h.gclid = L), P && (h.wbraid = P), D && (h.gbraid = D), s && (h.auid = s), F && (h.scid = F), U && (h.ScCid = U), V && (h.twclid = V), W) h.kx = W;
                    else {
                        let e = A(g(f));
                        e && (h.kx = e)
                    }
                    J && (h.rdt_cid = J), Y && (h.utm_id = Y), G && (h.utm_source = G), K && (h.utm_medium = K), H && (h.utm_campaign = H), X && (h.utm_term = X), z && (h.utm_content = z), j(h);
                    let _ = e => {
                            !e && a <= 10 && setTimeout(() => i(a + 1), 1e3)
                        },
                        y = t => {
                            e[m] = t, _(!1)
                        };
                    if (l() ? k(h).then(_).catch(y) : e[d] || e[p] ? w(Object.assign({
                            ct: e[p] = e[d] || e[p]
                        }, h)).catch(y) : _(!1), !e["wt:integrated:pixels"] && S({
                            "attributes:all": e[u] ? ? {},
                            host: e[u] ? .host ? ? "",
                            utm_source: e[u] ? .utm_source ? ? "",
                            utm_medium: e[u] ? .utm_medium ? ? "",
                            utm_campaign: e[u] ? .utm_campaign ? ? "",
                            utm_content: e[u] ? .utm_content ? ? "",
                            utm_term: e[u] ? .utm_term ? ? ""
                        }, o) && (l() && e.Shopify.customerPrivacy ? .marketingAllowed ? .() === !1 ? t.addEventListener("visitorConsentCollected", e => e.detail ? .marketingAllowed && N()) : N()), h.kx) return;
                    let b = setInterval(() => requestAnimationFrame(() => {
                        let t = A(g(f));
                        t && (j({
                            kx: h.kx = t
                        }), e[p] && w({
                            ct: e[p],
                            kx: exchangeId
                        }), clearInterval(b))
                    }), 1e3)
                } catch (t) {
                    e[m] = t
                }
            }, 1e3), "connected" === h("wetracked.io") && alert("Yes, wetracked.io is connected!"), console.log("\uD83D\uDC4F %cCongratulations!%c This website is integrated with %cwetracked.io%c.", "font-weight: bold", "font-weight: normal", "font-weight: bold;background-image:linear-gradient(to right,#087EED,#52B6FF);color: #fff;padding: 0 4px;border-radius: 4px;", "font-weight: normal")
        } catch (t) {
            e[m] = t
        }
    }
})(window, document, location, localStorage, [{
    "id": "34025",
    "platform": "facebook",
    "pixelId": "1291082888978883"
}, {
    "id": "34028",
    "platform": "tiktok",
    "pixelId": "CT2E7K3C77UF4MDQNTHG"
}], null, null, "pickem-store-3373.myshopify.com");