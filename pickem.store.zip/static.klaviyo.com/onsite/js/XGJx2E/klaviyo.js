var KLAVIYO_JS_REGEX = /(\/onsite\/js\/([a-zA-Z]{6})\/klaviyo\.js\?company_id=([a-zA-Z0-9]{6}).*|\/onsite\/js\/klaviyo\.js\?company_id=([a-zA-Z0-9]{6}).*)/;

function logFailedKlaviyoJsLoad(e, t, o) {
    var n = {
        metric_group: "onsite",
        events: [{
            metric: "klaviyoJsCompanyIdMisMatch",
            log_to_statsd: !0,
            log_to_s3: !0,
            log_to_metrics_service: !1,
            event_details: {
                script: e,
                templated_company_id: t,
                fastly_forwarded: o,
                hostname: window.location.hostname
            }
        }]
    };
    fetch("https://a.klaviyo.com/onsite/track-analytics?company_id=".concat(t), {
        headers: {
            accept: "application/json",
            "content-type": "application/json"
        },
        referrerPolicy: "strict-origin-when-cross-origin",
        body: JSON.stringify(n),
        method: "POST",
        mode: "cors",
        credentials: "omit"
    })
}! function(e) {
    var t = "XGJx2E",
        o = JSON.parse("[]"),
        n = "true" === "True".toLowerCase(),
        a = JSON.parse("[]"),
        r = new Set(null != a ? a : []),
        c = "true" === "False".toLowerCase();
    if (!(document.currentScript && document.currentScript instanceof HTMLScriptElement && document.currentScript.src && document.currentScript.src.match(KLAVIYO_JS_REGEX)) || null !== (e = document.currentScript.src) && void 0 !== e && e.includes(t) || c) {
        var s = window.klaviyoModulesObject;
        if (window._learnq = window._learnq || [], window.__klKey = window.__klKey || t, s || (window._learnq.push(["account", t]), s = {
                companyId: t,
                loadTime: new Date,
                loadedModules: {},
                loadedCss: {},
                serverSideRendered: !0,
                assetSource: "",
                v2Route: n,
                extendedIdIdentifiers: o,
                env: "web",
                featureFlags: r
            }, Object.defineProperty(window, "klaviyoModulesObject", {
                value: s,
                enumerable: !1
            })), t === s.companyId && s.serverSideRendered) {
            var i, d, l, p = {},
                u = document,
                m = u.head,
                y = JSON.parse("noModule" in u.createElement("script") || function() {
                    try {
                        return new Function('import("")'), !0
                    } catch (e) {
                        return !1
                    }
                }() ? "{\u0022static\u0022: {\u0022js\u0022: [\u0022https://static\u002Dtracking.klaviyo.com/onsite/js/fender_analytics.ff84dfebf499c2db4de8.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/static.45264a1e53c737929610.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/runtime.4a7f8012fe0ec64cc69b.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.9f6e378c730aa9ab5d87.js?cb\u003D2\u0022]}, \u0022signup_forms\u0022: {\u0022js\u0022: [\u0022https://static.klaviyo.com/onsite/js/runtime.4a7f8012fe0ec64cc69b.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.9f6e378c730aa9ab5d87.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~reviews~event_adapter~telemetry~onsite\u002Dtriggering~customerHubRoot~renderFavoritesButton~renderFavoritesIconButton~renderFaqWidget.c4a654aeb90c3b558d39.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~client_identity~event_adapter~telemetry~onsite\u002Dtriggering.4768afcea6fedb2d7bdb.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~reviews~atlas.0201e888d834a3782e3a.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms.8a3c97f472337d74431f.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/default~in_app_forms~signup_forms~onsite\u002Dtriggering.dc431e4d716ef7ec1c56.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/default~in_app_forms~signup_forms.5c5de6a94296c32bd8db.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/signup_forms.9dfcc3510f2d875d87a5.js?cb\u003D2\u0022]}, \u0022post_identification_sync\u0022: {\u0022js\u0022: [\u0022https://static.klaviyo.com/onsite/js/runtime.4a7f8012fe0ec64cc69b.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.9f6e378c730aa9ab5d87.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/post_identification_sync.f03819e02b9095c10087.js?cb\u003D2\u0022]}, \u0022event_adapter\u0022: {\u0022js\u0022: [\u0022https://static.klaviyo.com/onsite/js/runtime.4a7f8012fe0ec64cc69b.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.9f6e378c730aa9ab5d87.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~reviews~event_adapter~telemetry~onsite\u002Dtriggering~customerHubRoot~renderFavoritesButton~renderFavoritesIconButton~renderFaqWidget.c4a654aeb90c3b558d39.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~client_identity~event_adapter~telemetry~onsite\u002Dtriggering.4768afcea6fedb2d7bdb.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~event_adapter~onsite\u002Dback\u002Din\u002Dstock~Render~ClientStore~.3107525c2fe4964fa98b.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/event_adapter.7e2e06539c86c133f0bc.js?cb\u003D2\u0022]}, \u0022telemetry\u0022: {\u0022js\u0022: [\u0022https://static.klaviyo.com/onsite/js/runtime.4a7f8012fe0ec64cc69b.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.9f6e378c730aa9ab5d87.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~reviews~event_adapter~telemetry~onsite\u002Dtriggering~customerHubRoot~renderFavoritesButton~renderFavoritesIconButton~renderFaqWidget.c4a654aeb90c3b558d39.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~client_identity~event_adapter~telemetry~onsite\u002Dtriggering.4768afcea6fedb2d7bdb.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/telemetry.9d4fde8cd7df7334d817.js?cb\u003D2\u0022]}}" : "{\u0022static\u0022: {\u0022js\u0022: [\u0022https://static\u002Dtracking.klaviyo.com/onsite/js/fender_analytics.53445dee2fa3d4c52002.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/static.3b591f73b42eaaaac9c7.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/runtime.7d679adcb3c75ae07fcc.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.a806fc3c335d2885707f.js?cb\u003D2\u0022]}, \u0022signup_forms\u0022: {\u0022js\u0022: [\u0022https://static.klaviyo.com/onsite/js/runtime.7d679adcb3c75ae07fcc.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.a806fc3c335d2885707f.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~reviews~event_adapter~telemetry~onsite\u002Dtriggering~customerHubRoot~renderFavoritesButton~renderFavoritesIconButton~renderFaqWidget.c4a654aeb90c3b558d39.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~post_identification_sync~web_personalization~reviews~atlas~event_adapter~telemetry.1f329085dd02ba550657.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~client_identity~event_adapter~telemetry~onsite\u002Dtriggering.5ea78d6244c07454e99c.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~reviews~atlas.48dc1c9f0f1e4f9572d4.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms.8a3c97f472337d74431f.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/default~in_app_forms~signup_forms~onsite\u002Dtriggering.3475dd583893009578a7.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/default~in_app_forms~signup_forms.3eb0d8c2b451ac065923.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/signup_forms.3232e343b37e5fb92826.js?cb\u003D2\u0022]}, \u0022post_identification_sync\u0022: {\u0022js\u0022: [\u0022https://static.klaviyo.com/onsite/js/runtime.7d679adcb3c75ae07fcc.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.a806fc3c335d2885707f.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~post_identification_sync~web_personalization~reviews~atlas~event_adapter~telemetry.1f329085dd02ba550657.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/post_identification_sync.df0692324799532523e2.js?cb\u003D2\u0022]}, \u0022event_adapter\u0022: {\u0022js\u0022: [\u0022https://static.klaviyo.com/onsite/js/runtime.7d679adcb3c75ae07fcc.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.a806fc3c335d2885707f.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~reviews~event_adapter~telemetry~onsite\u002Dtriggering~customerHubRoot~renderFavoritesButton~renderFavoritesIconButton~renderFaqWidget.c4a654aeb90c3b558d39.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~post_identification_sync~web_personalization~reviews~atlas~event_adapter~telemetry.1f329085dd02ba550657.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~client_identity~event_adapter~telemetry~onsite\u002Dtriggering.5ea78d6244c07454e99c.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/vendors~event_adapter~onsite\u002Dback\u002Din\u002Dstock~Render~ClientStore~.3107525c2fe4964fa98b.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/event_adapter.b9672b6d1b46d5afa06c.js?cb\u003D2\u0022]}, \u0022telemetry\u0022: {\u0022js\u0022: [\u0022https://static.klaviyo.com/onsite/js/runtime.7d679adcb3c75ae07fcc.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.a806fc3c335d2885707f.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~reviews~event_adapter~telemetry~onsite\u002Dtriggering~customerHubRoot~renderFavoritesButton~renderFavoritesIconButton~renderFaqWidget.c4a654aeb90c3b558d39.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~post_identification_sync~web_personalization~reviews~atlas~event_adapter~telemetry.1f329085dd02ba550657.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/vendors~in_app_forms~signup_forms~client_identity~event_adapter~telemetry~onsite\u002Dtriggering.5ea78d6244c07454e99c.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/telemetry.56aab014a1fefd79ed51.js?cb\u003D2\u0022]}}"),
                _ = s,
                f = _.loadedCss,
                v = _.loadedModules;
            for (i in y)
                if (y.hasOwnProperty(i)) {
                    var w = y[i];
                    w.js.forEach((function(e) {
                        var t = e.split("?")[0];
                        t && !v[t] && (h(e), v[t] = (new Date).toISOString())
                    }));
                    var S = w.css;
                    S && !f[S] && (d = S, l = void 0, (l = u.createElement("link")).rel = "stylesheet", l.href = d, m.appendChild(l), f[S] = (new Date).toISOString())
                }
        } else console.warn("Already loaded for account ".concat(s.companyId, ". Skipping account ").concat(t, "."))
    } else {
        console.warn("Not loading ".concat(document.currentScript.src, " for ").concat(t));
        try {
            logFailedKlaviyoJsLoad(document.currentScript.src, t, n)
        } catch (e) {
            console.warn("Error logging klaviyo.js company mismatch")
        }
    }

    function h(e) {
        if (!p[e]) {
            var t = u.createElement("script");
            t.type = "text/javascript", t.async = !0, t.src = e, t.crossOrigin = "anonymous", m.appendChild(t), p[e] = !0
        }
    }
}();