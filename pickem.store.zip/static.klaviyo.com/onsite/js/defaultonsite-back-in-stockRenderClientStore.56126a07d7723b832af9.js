"use strict";
(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [8257], {
        80650: function(t, e, n) {
            n.r(e), n.d(e, {
                createInitializer: function() {
                    return x
                },
                detectPlatform: function() {
                    return L
                }
            });
            var o = n(25598),
                r = n(12948),
                i = n(76898);
            n(19986), n(78991), n(24570), n(26650), n(92461), n(70818), n(60873), n(44159);
            var a = class {
                constructor(t = 5e3) {
                    this.cache = {}, this.ttl = void 0, this.ttl = t
                }
                get(t) {
                    const e = this.cache[t];
                    return e && Date.now() - e.timestamp < this.ttl ? e.data : (e && delete this.cache[t], null)
                }
                set(t, e) {
                    this.cache[t] = {
                        data: e,
                        timestamp: Date.now()
                    }
                }
                clear() {
                    Object.keys(this.cache).forEach((t => {
                        delete this.cache[t]
                    }))
                }
                delete(t) {
                    delete this.cache[t]
                }
            };
            const c = ".klaviyo-bis-trigger",
                u = [c, 'input#form-action-addToCart[type="submit"]', 'button[data-button-type="add-cart"]', 'button[data-action="add-to-cart"]', 'form[action*="/cart.php"] input[type="submit"]', 'form[action*="/cart.php"] button[type="submit"]', 'form[data-cart-item-add] input[type="submit"]', 'form[data-cart-item-add] button[type="submit"]', 'button[type="submit"][class*="add"]', 'button[type="submit"][class*="cart"]', 'input[type="submit"][class*="add"]', 'input[type="submit"][class*="cart"]', 'button[id*="add"]', 'input[id*="add"]'],
                s = () => "undefined" != typeof window ? window.location.hostname : "",
                d = () => `form[action$="//${s()}/cart.php"]`,
                m = 'input[name^="attribute"]',
                l = 'select[name^="attribute"] option',
                f = 'input[name="product_id"]',
                p = () => {
                    if ("undefined" == typeof document) return null;
                    const t = document.querySelector(`${d()} ${f}`);
                    return t && t instanceof HTMLInputElement && t.value || null
                },
                y = () => {
                    if ("undefined" == typeof document) return null;
                    for (const t of u) {
                        const e = document.querySelector(t);
                        if (e) return (0, o.mm)(`BigCommerce: Found add to cart button with selector: ${t}`), e
                    }
                    return (0, o.mm)("BigCommerce: No add to cart button found with any selector"), null
                },
                h = () => {
                    const t = y();
                    if (!t) return null;
                    const e = t.closest('form[action*="/cart.php"]') || t.closest("form[data-cart-item-add]") || t.closest("form");
                    if (e instanceof HTMLElement) return (0, o.mm)("BigCommerce: Found form container for add to cart button"), e;
                    const n = t.parentElement;
                    return n ? ((0, o.mm)("BigCommerce: Using parent element as container"), n) : ((0, o.mm)("BigCommerce: No suitable container found"), null)
                },
                b = () => {
                    const t = y(),
                        e = h();
                    if (!t || !e) return null;
                    const n = t.hasAttribute("disabled") || "true" === t.getAttribute("aria-disabled") || t.classList.contains("disabled");
                    return {
                        button: t,
                        container: e,
                        isDisabled: n
                    }
                },
                g = new a,
                w = async () => {
                    if ("undefined" == typeof document || "undefined" == typeof window) return null;
                    const t = d(),
                        e = `${t} ${m}:checked, ${t} ${l}:checked`,
                        n = document.querySelectorAll(e),
                        r = Array.from(n).map((t => t instanceof HTMLOptionElement && t.parentElement instanceof HTMLSelectElement ? `${t.parentElement.name}=${t.value}` : t instanceof HTMLInputElement ? `${t.name}=${t.value}` : null)).filter((t => null !== t)).sort(),
                        i = p();
                    if (!i) return (0, o.mm)("BigCommerce: No product ID found"), null;
                    const a = `//${s()}/remote/v1/product-attributes/${i}`;
                    let c = `action=add&qty[]=1&product_id=${i}`;
                    r.length > 0 && (c += `&${r.join("&")}`);
                    const u = `${a}?${c}`,
                        f = g.get(u);
                    if (null !== f) return (0, o.mm)(`BigCommerce: Cache hit for ${u}`), f;
                    (0, o.mm)(`BigCommerce: Cache miss for ${u}`);
                    try {
                        const t = (t => {
                                if ("undefined" == typeof document) return null;
                                const e = document.cookie.match(new RegExp(`${t}=([^;]+)`));
                                return (null == e ? void 0 : e[1]) || null
                            })("SF-CSRF-TOKEN"),
                            e = await fetch(a, {
                                method: "POST",
                                headers: Object.assign({
                                    "Content-Type": "application/x-www-form-urlencoded"
                                }, t && {
                                    "X-CSRF-Token": t
                                }),
                                body: c
                            });
                        if (!e.ok) return (0, o.mm)(`BigCommerce: API request failed with status ${e.status}`), g.set(u, null), null;
                        const n = await e.json();
                        if (!(t => {
                                if (!t || "object" != typeof t || !("data" in t)) return !1;
                                const {
                                    data: e
                                } = t;
                                return !(!e || "object" != typeof e) && !(!("v3_variant_id" in e) || "number" != typeof e.v3_variant_id || !("instock" in e) || "boolean" != typeof e.instock || "sku" in e && null !== e.sku && "string" != typeof e.sku || "stock" in e && null !== e.stock && "number" != typeof e.stock || "purchasable" in e && "boolean" != typeof e.purchasable)
                            })(n)) return (0, o.mm)("BigCommerce: Invalid variant data structure received"), g.set(u, null), null;
                        const r = {
                            id: (y = n.data).v3_variant_id,
                            sku: "sku" in y && "string" == typeof y.sku ? y.sku : null,
                            stock: "stock" in y && "number" == typeof y.stock ? y.stock : null,
                            instock: y.instock,
                            v3_variant_id: y.v3_variant_id,
                            price: y.price,
                            purchasable: Object.prototype.hasOwnProperty.call(y, "purchasable") && "boolean" == typeof y.purchasable ? y.purchasable : void 0
                        };
                        return g.set(u, r), r
                    } catch (t) {
                        const e = t instanceof Error ? t.message : String(t);
                        return (0, o.mm)(`BigCommerce: Error fetching variant details: ${e}`), g.set(u, null), null
                    }
                    var y
                },
                k = () => {
                    if ("undefined" != typeof document) {
                        if (document.querySelector("a.klaviyo-bis-trigger")) return !0;
                        try {
                            const t = document.querySelector("meta[property='og:type']");
                            if (t && "product" === t.getAttribute("content")) return !0
                        } catch (t) {
                            return (0, o.mm)(`BigCommerce: Error checking meta tags: ${t}`), !1
                        }
                    }
                    return !1
                },
                v = async () => {
                    (0, o.mm)("BigCommerce: Initialization (no-op)")
                },
                S = async () => {
                    try {
                        const t = await w();
                        if (!t) return (0, o.mm)("BigCommerce: No variant details found, assuming out of stock"), !0;
                        const e = !t.instock;
                        return (0, o.mm)("BigCommerce: Product stock status - " + (e ? "out of stock" : "in stock")), e
                    } catch (t) {
                        const e = t instanceof Error ? t.message : String(t);
                        return (0, o.mm)(`BigCommerce: Error checking product stock: ${e}`), (0, r.T)(t instanceof Error ? t : new Error(String(t)), {
                            tags: {
                                platform: "bigcommerce",
                                component: "back-in-stock",
                                operation: "stock-check"
                            },
                            extra: {
                                hostname: s(),
                                productId: p()
                            }
                        }), !0
                    }
                },
                $ = () => w();
            n(84618), n(39265), n(61099), n(60624), n(75479);
            const P = () => {
                    const t = (() => {
                        if ("undefined" == typeof window || !window.location.search) return null;
                        try {
                            return new URLSearchParams(window.location.search).get("variant")
                        } catch (t) {
                            return null
                        }
                    })();
                    if (t) return t;
                    return (() => {
                        if ("undefined" == typeof document) return null;
                        try {
                            const t = document.querySelector('input[name="id"], select[name="id"]');
                            return (null == t ? void 0 : t.value) || null
                        } catch (t) {
                            return null
                        }
                    })()
                },
                E = [c, 'button[name="add"]:not([type="button"])', "button.product-form__submit", 'input[name="add"][type="submit"]', 'button[type="submit"][form*="product-form"]', 'button[data-testid="add-to-cart"]', 'button[type="submit"][data-product-form]', 'form[action*="/cart/add"] button[type="submit"]', 'form[action*="/cart/add"] input[type="submit"]', 'button[type="submit"][class*="add"]', 'button[type="submit"][class*="cart"]', 'input[type="submit"][class*="add"]', 'input[type="submit"][class*="cart"]', 'button[id*="add"]', 'input[id*="add"]'],
                C = () => {
                    if ("undefined" != typeof document && document.querySelector("a.klaviyo-bis-trigger")) return !0;
                    if ("undefined" != typeof window) try {
                        const {
                            pathname: t
                        } = window.location;
                        return /\/products\//.test(t)
                    } catch (t) {
                        return (0, o.mm)(`Error checking if product page: ${t}`), !1
                    }
                    return !1
                },
                O = () => {
                    if ("undefined" == typeof document) return null;
                    for (const t of E) {
                        const e = document.querySelector(t);
                        if (e) return (0, o.mm)(`Shopify: Found add to cart button with selector: ${t}`), e
                    }
                    return (0, o.mm)("Shopify: No add to cart button found with any selector"), null
                },
                T = () => {
                    const t = O();
                    if (!t) return null;
                    const e = t.closest('form[action*="/cart/add"]') || t.closest("form[data-product-form]") || t.closest("form");
                    if (e instanceof HTMLElement) return (0, o.mm)("Shopify: Found form container for add to cart button"), e;
                    const n = t.parentElement;
                    return n ? ((0, o.mm)("Shopify: Using parent element as container"), n) : ((0, o.mm)("Shopify: No suitable container found"), null)
                },
                _ = () => {
                    const t = O(),
                        e = T();
                    if (!t || !e) return null;
                    const n = t.hasAttribute("disabled") || "true" === t.getAttribute("aria-disabled") || t.classList.contains("disabled");
                    return {
                        button: t,
                        container: e,
                        isDisabled: n
                    }
                },
                B = t => !(!t || "object" != typeof t) && ("id" in t && "number" == typeof t.id && "available" in t && "boolean" == typeof t.available && "price" in t && "number" == typeof t.price),
                I = new a,
                A = async () => {
                    const t = (() => {
                            if ("undefined" == typeof window) throw new Error("Window is not available to determine URL");
                            const {
                                hostname: t,
                                pathname: e
                            } = window.location, n = (t => {
                                var e;
                                const n = t.match(/\/products\/([^/?#]+)/);
                                return null != (e = null == n ? void 0 : n[1]) ? e : null
                            })(e);
                            return n ? `//${t}/products/${n}.js` : `//${t}${e.endsWith("/")?e.slice(0,-1):e}.js`
                        })(),
                        e = I.get(t);
                    if (e) return (0, o.mm)(`Shopify: Cache hit for ${t}`), e;
                    (0, o.mm)(`Shopify: Cache miss for ${t}`);
                    try {
                        const e = await fetch(t);
                        if (!e.ok) throw new Error(`Failed to fetch product JSON. Status: ${e.status}`);
                        const n = await e.json();
                        if (!(t => {
                                if (!t || "object" != typeof t) return !1;
                                if (!("id" in t && "number" == typeof t.id && "title" in t && "string" == typeof t.title && "variants" in t && Array.isArray(t.variants) && t.variants.every(B) && "tags" in t && Array.isArray(t.tags) && t.tags.every((t => "string" == typeof t)))) return !1;
                                if ("product" in t && t.product) {
                                    const e = t.product;
                                    if ("object" != typeof e) return !1;
                                    if (!("id" in e && "number" == typeof e.id && "title" in e && "string" == typeof e.title && "variants" in e && Array.isArray(e.variants) && e.variants.every(B) && "tags" in e && Array.isArray(e.tags) && e.tags.every((t => "string" == typeof t)))) return !1
                                }
                                return !0
                            })(n)) throw new Error("Invalid product data structure received from Shopify");
                        return n.product ? (I.set(t, n.product), n.product) : (I.set(t, n), n)
                    } catch (e) {
                        const n = e instanceof Error ? e.message : String(e);
                        throw new Error(`Shopify: Failed to get product data from ${t}. Reason: ${n}`)
                    }
                },
                z = async () => {
                    (0, o.mm)("Shopify: Initialization (no-op)")
                },
                q = async t => {
                    const e = t || await A(),
                        n = P();
                    let o;
                    if (null != n) {
                        const t = "string" == typeof n ? parseInt(n, 10) : Number(n);
                        Number.isNaN(t) || (o = e.variants.find((e => e.id === t)))
                    }
                    var r;
                    o || (o = null != (r = e.variants.find((t => t.available))) ? r : e.variants[0]);
                    return o
                },
                N = async () => q(),
                j = (t = {}) => ({
                    platform: "shopify",
                    initialize: z,
                    isProductOutOfStock: () => (async t => {
                        try {
                            var e, n;
                            const r = await A(),
                                i = await q(r);
                            if (!i) return (0, o.mm)("Shopify: No variant found for stock check."), !0;
                            const a = i.available,
                                c = r.tags || [];
                            return null != (e = t.excludeOnTags) && e.length && t.excludeOnTags.some((t => c.includes(t))) ? ((0, o.mm)("Shopify: Product has an exclude_on_tag. Treating as IN STOCK."), !1) : null != (n = t.includeOnTags) && n.length && !t.includeOnTags.some((t => c.includes(t))) ? ((0, o.mm)("Shopify: Product missing required include_on_tag. Treating as IN STOCK."), !1) : ((0, o.mm)(`Shopify: Default stock check. Variant available: ${a}. Out of stock: ${!a}`), !a)
                        } catch (e) {
                            return (0, o.mm)(`Failed to check Shopify product stock: ${e}`), (0, r.T)(e instanceof Error ? e : new Error(String(e)), {
                                tags: {
                                    platform: "shopify",
                                    component: "back-in-stock",
                                    operation: "stock-check"
                                },
                                extra: {
                                    options: t,
                                    hostname: "undefined" != typeof window ? window.location.hostname : "unknown",
                                    pathname: "undefined" != typeof window ? window.location.pathname : "unknown"
                                }
                            }), !0
                        }
                    })(t),
                    isProductPage: C,
                    getAddToCartButton: O,
                    getAddToCartButtonContainer: T,
                    getButtonPlacementInfo: _,
                    getProductVariantData: N
                });
            class D extends Error {
                constructor(t) {
                    super(`Unsupported platform: ${t}`), this.name = "UnsupportedPlatformError"
                }
            }
            const F = (t, e = {}) => {
                    switch (t) {
                        case "shopify":
                            return j(e);
                        case "bigcommerce":
                            return {
                                platform: "bigcommerce",
                                initialize: v,
                                isProductOutOfStock: S,
                                isProductPage: k,
                                getAddToCartButton: y,
                                getAddToCartButtonContainer: h,
                                getButtonPlacementInfo: b,
                                getProductVariantData: $
                            };
                        default:
                            throw new D(t)
                    }
                },
                L = () => {
                    if ("undefined" == typeof document || "undefined" == typeof window) return "custom";
                    const t = !!document.querySelector('meta[name="shopify-digital-wallet"]') || !!document.querySelector('meta[name="shopify-checkout-api-token"]'),
                        e = void 0 !== window.Shopify,
                        n = !!document.querySelector('script[src*="cdn.shopify.com"],link[href*="cdn.shopify.com"]');
                    return t || e || n ? "shopify" : document.querySelector('meta[property="og:type"][content="product"]') && document.querySelector('input[name="product_id"]') ? "bigcommerce" : "custom"
                },
                x = t => {
                    let e = {
                        isInitialized: !1,
                        currentOptions: t || {},
                        currentPlatform: null
                    };
                    const n = async ({
                        platform: t,
                        initOptions: n = {}
                    } = {}) => {
                        if (e.isInitialized && t === e.currentPlatform && (0, i.Z)(n, e.currentOptions)) return !0;
                        try {
                            const r = t || L();
                            return await (async (t, e = {}) => {
                                const n = F(t, e);
                                await n.initialize()
                            })(r, n), e = {
                                isInitialized: !0,
                                currentPlatform: r,
                                currentOptions: n
                            }, (0, o.mm)("initialized"), !0
                        } catch (i) {
                            return e = {
                                isInitialized: !1,
                                currentPlatform: null,
                                currentOptions: {}
                            }, (0, o.mm)("failed to initialize"), i instanceof D ? console.error(`Klaviyo Back in Stock: Unsupported platform: ${t}`, {
                                component: "back-in-stock",
                                operation: "initialize",
                                requestedPlatform: t,
                                detectedPlatform: t || L(),
                                options: n,
                                hostname: "undefined" != typeof window ? window.location.hostname : "unknown"
                            }) : (0, r.T)(i instanceof Error ? i : new Error(String(i)), {
                                tags: {
                                    component: "back-in-stock",
                                    operation: "initialize"
                                },
                                extra: {
                                    requestedPlatform: t,
                                    detectedPlatform: t || L(),
                                    options: n,
                                    hostname: "undefined" != typeof window ? window.location.hostname : "unknown"
                                }
                            }), !1
                        }
                    };
                    return {
                        initialize: n,
                        isProductOutOfStock: async () => {
                            if (!e.isInitialized) {
                                if (!await n({})) return !0
                            }
                            try {
                                if (!e.currentPlatform) return (0, o.mm)("No platform detected or initialized, assuming in stock."), !1;
                                const t = F(e.currentPlatform, e.currentOptions);
                                if (!await t.getProductVariantData()) return (0, o.mm)("No product variant data found, assuming in stock."), !1;
                                const n = await t.isProductOutOfStock();
                                return (0, o.mm)(`Product OOS status: ${n}`), n
                            } catch (t) {
                                return (0, o.mm)(`Error checking product stock, assuming in stock: ${t instanceof Error?t.message:String(t)}`), !1
                            }
                        },
                        getPlatform: () => {
                            const t = e.currentPlatform || L();
                            return F(t, e.currentOptions)
                        },
                        getProductVariantData: async () => {
                            if (!e.isInitialized) {
                                if (!await n({})) return null
                            }
                            try {
                                if (!e.currentPlatform) return (0, o.mm)("No platform detected or initialized"), null;
                                const t = F(e.currentPlatform, e.currentOptions);
                                return await t.getProductVariantData()
                            } catch (t) {
                                return (0, o.mm)(`Error getting product variant data: ${t instanceof Error?t.message:String(t)}`), null
                            }
                        }
                    }
                }
        }
    }
]);