"use strict";
(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [135], {
        69299: function(e, t, n) {
            const o = {
                ref: () => {},
                attributes: {},
                listeners: {},
                collected: {},
                className: ""
            };
            t.Z = ({
                children: e
            }) => e(o)
        },
        68133: function(e, t, n) {
            n.d(t, {
                c: function() {
                    return Ht
                }
            });
            var o = n(46091),
                i = n(67895),
                r = n.n(i),
                s = n(18359),
                a = n.n(s),
                l = n(24567),
                d = n(5645),
                c = n.n(d),
                m = n(98355),
                u = n(54883),
                f = n(57829);
            const p = ["children", "actionId", "formVersionCId"];
            var h = e => {
                let {
                    children: t,
                    actionId: n,
                    formVersionCId: o
                } = e, i = c()(e, p);
                const [r, a] = (0, s.useState)(!1), l = (0, f.Z)((e => {
                    var t;
                    return e.formsState.actions && n ? null == (t = e.formsState.actions[n]) ? void 0 : t.actionType : void 0
                })), d = (0, f.Z)((e => {
                    var t;
                    return e.formsState.actions && n ? null == (t = e.formsState.actions[n]) || null == (t = t.data) ? void 0 : t.newWindow : void 0
                })), h = (0, f.Z)((e => {
                    var t;
                    return e.formsState.actions && n ? null == (t = e.formsState.actions[n]) || null == (t = t.data) ? void 0 : t.redirectUrl : void 0
                })), v = (0, s.useMemo)((() => n && l ? (0, u.l9)(l, {
                    newWindow: d,
                    redirectUrl: h
                }) : {}), [n, l, d, h]);
                if (!n) return t(Object.assign({
                    onClick: void 0,
                    handlingFormAction: r,
                    ariaProps: v
                }, i));
                const g = (0, m.j)({
                    actionId: n,
                    formVersionCId: o,
                    getState: f.Z.getState
                });
                if (!g) return t(Object.assign({
                    onClick: void 0,
                    handlingFormAction: r,
                    ariaProps: v
                }, i));
                const y = new g({
                    actionId: n,
                    formVersionCId: o,
                    getState: f.Z.getState
                });
                return t(Object.assign({
                    onClick: n ? () => {
                        g.formActionType && u.NB.has(g.formActionType) && a(!0), y.runAction().catch((() => {
                            a(!1);
                            const e = document.querySelector(`.klaviyo-form-version-cid_${o} [aria-invalid="true"]`);
                            e && e.focus()
                        }))
                    } : void 0,
                    handlingFormAction: r,
                    ariaProps: v
                }, i))
            };
            const v = () => null;
            var g = ({
                    formVersionCId: e,
                    componentId: t,
                    a11yIdentifierBlock: n
                }) => {
                    const o = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        i = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.styling
                        })),
                        s = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.image
                        })),
                        d = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.altText
                        })),
                        c = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) ? void 0 : n.actionId
                        })),
                        m = c ? l.aG : l.Ei,
                        u = (null == i ? void 0 : i.width) || 100;
                    return a().createElement(l.ZC, {
                        style: {
                            display: "flex",
                            alignItems: "center",
                            width: "100%",
                            height: "auto"
                        },
                        a11yIdentifier: n
                    }, o && !s ? a().createElement(v, null) : s && a().createElement(h, {
                        actionId: c,
                        formVersionCId: e
                    }, (({
                        onClick: e,
                        handlingFormAction: t,
                        ariaProps: i
                    }) => a().createElement(l.ZC, {
                        className: t ? "klaviyo-spinner" : "",
                        style: {
                            position: "relative",
                            display: "flex",
                            alignItems: "center",
                            width: "100%",
                            height: "auto"
                        },
                        onClick: e,
                        a11yIdentifier: n
                    }, a().createElement(m, r()({
                        a11yIdentifier: n,
                        style: {
                            maxWidth: "100%",
                            width: u,
                            height: "auto",
                            cursor: e ? "pointer" : "initial"
                        },
                        src: s.url,
                        tabIndex: o || !c ? -1 : 0
                    }, d && d.length > 0 ? {
                        alt: d
                    } : {}, i))))))
                },
                y = (n(26650), n(92461), n(39265), n(80101)),
                I = n(23409),
                b = n(23034),
                S = n(74963),
                w = n(71721),
                C = n(24186),
                x = n(3440),
                E = n(53610),
                _ = n(26655),
                k = n(40910),
                V = n(96288),
                T = n(62223),
                $ = n(74872),
                Z = n(59769),
                F = n(46458);
            let O, A = e => e;
            var M = ({
                    formVersionCId: e,
                    componentId: t,
                    theme: n,
                    a11yIdentifierStyles: i
                }) => {
                    var r;
                    const d = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        c = (0, f.Z)((n => {
                            var o;
                            const i = null == (o = n.onsiteState.openFormVersions[e]) ? void 0 : o.components[t];
                            return !!n.onsiteState.client.isDesignWorkflow || !i || i.valid || void 0 === i.valid
                        })),
                        m = (0, f.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.metadata
                        }), b.X),
                        u = (0, f.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.validationErrorType
                        })),
                        p = (0, f.Z)((n => (0, Z.HN)(n, e, t))),
                        h = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.required
                        })),
                        v = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.label
                        })),
                        g = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.showLabel
                        })),
                        M = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.placeholder
                        })),
                        B = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) ? void 0 : n.componentType
                        })),
                        D = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.fieldId
                        })),
                        N = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.format
                        })),
                        j = (0, f.Z)((e => {
                            var n;
                            return (null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.delimiter) || ""
                        })),
                        R = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.prefill
                        })),
                        P = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formId
                        })),
                        z = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                        })),
                        H = (0, f.Z)((e => e.onsiteState.client.klaviyoCompanyId)),
                        W = (0, f.Z)((t => (0, Z.wf)(t, e))),
                        L = (0, f.Z)((e => {
                            const n = e.formsState.components[t];
                            return void 0 !== n && (0, F.En)(n)
                        })),
                        q = (0, s.useMemo)((() => B === o.ZW || B === o.Ys), [B]),
                        U = (0, s.useMemo)((() => `${null==D?void 0:D.replace(/ /g,"_").replace(/\$/g,"")}_${t}`), [D, t]),
                        K = (0, s.useMemo)((() => B === o.eC ? "one-time-code" : D && o.no[D] ? o.no[D] : void 0), [D, B]),
                        {
                            current: G
                        } = (0, s.useRef)((0, y.Z)("klaviyo_ariaid_")),
                        [Y, X] = (0, s.useState)(!1),
                        [J, Q] = (0, s.useState)(),
                        ee = ({
                            value: n,
                            validate: o,
                            hasChangedSinceLastValidation: i
                        }) => {
                            var r;
                            const s = void 0 !== n ? n : "";
                            Q(s), X(!!i), (0, _.hX)({
                                formVersionCId: e,
                                componentId: t,
                                value: q ? null == (r = S.Tb.find((({
                                    format: e
                                }) => JSON.stringify(e) === JSON.stringify(N)))) ? void 0 : r.formatDate(s, j) : s,
                                validate: o
                            })
                        };
                    (0, s.useEffect)((() => {
                        const e = (0, w.FU)();
                        if (R && e && B === o.xC && !d) {
                            const {
                                [o.HD]: t
                            } = e;
                            ee({
                                value: t,
                                validate: !1
                            })
                        }
                    }), []), (0, s.useEffect)((() => {
                        L && !d && P && e && W && ((0, T.WN)(P), H && (0, k.M)({
                            metric: $.mC,
                            formVersionCId: e,
                            formId: P,
                            companyId: H
                        }))
                    }), [L, d, P, H, e, W, z]);
                    const te = (0, s.useMemo)((() => `label-${U}`), [U]),
                        ne = (0, s.useMemo)((() => v ? void 0 : M), [v, M]),
                        oe = Y || c,
                        ie = q && !M ? null == (r = S.Tb.find((({
                            format: e
                        }) => JSON.stringify(e) === JSON.stringify(N)))) ? void 0 : r.label.replace(/ /g, j) : M,
                        re = q ? C.n : l.II;
                    return a().createElement(l.ZC, {
                        style: {
                            display: "flex",
                            flexGrow: 1,
                            flexDirection: "column",
                            alignSelf: "flex-end"
                        },
                        a11yIdentifier: i
                    }, a().createElement(x.Z, {
                        id: te,
                        a11yIdentifier: i,
                        theme: n,
                        htmlFor: U,
                        showLabel: !(void 0 !== g || !v) || g
                    }, v), a().createElement(re, {
                        id: U,
                        className: (0, I.iv)(O || (O = A `
          &&& {
            &::placeholder {
              color: ${0};
              font-family: ${0};
              font-size: ${0};
              font-weight: ${0};
              letter-spacing: ${0}px;
            }
            &::-moz-placeholder {
              line-height: ${0}px;
            }
            &:hover {
              border-color: ${0} !important;
            }
            &:focus-visible {
              outline-width: 2px;
              outline-style: auto;
              outline-color: ${0};
              outline-offset: 0;
            }
          }
        `), n.inputStyles.textStyles.placeholderColor, n.inputStyles.textStyles.fontFamily, n.inputStyles.textStyles.fontSize, n.inputStyles.textStyles.fontWeight, n.inputStyles.textStyles.letterSpacing, n.inputStyles.textStyles.height, n.inputStyles.border.activeColor, oe ? n.inputStyles.border.activeColor || n.focusColor : n.inputStyles.border.errorColor),
                        style: {
                            boxSizing: "border-box",
                            borderRadius: n.inputStyles.borderRadius,
                            paddingLeft: 16,
                            paddingRight: 0,
                            paddingTop: 0,
                            paddingBottom: 0,
                            height: n.inputStyles.textStyles.height,
                            textAlign: "left",
                            color: n.inputStyles.textStyles.formInputTextColor,
                            fontFamily: n.inputStyles.textStyles.fontFamily,
                            fontSize: n.inputStyles.textStyles.fontSize,
                            fontWeight: n.inputStyles.textStyles.fontWeight,
                            letterSpacing: n.inputStyles.textStyles.letterSpacing,
                            backgroundColor: n.inputStyles.inputBackgroundColor,
                            border: "1px solid",
                            borderColor: n.inputStyles.border[oe ? "defaultColor" : "errorColor"]
                        },
                        type: (e => {
                            switch (e) {
                                case o.xC:
                                    return "email";
                                case o.J8:
                                    return "tel";
                                default:
                                    return "text"
                            }
                        })(B),
                        autoComplete: K,
                        name: B === o.xC ? "email" : void 0,
                        tabIndex: d ? -1 : 0,
                        placeholder: ie,
                        "aria-label": ne,
                        "aria-required": h || void 0,
                        "aria-invalid": !oe,
                        "aria-describedby": oe ? void 0 : G,
                        onInit: () => {
                            d || (0, _.DK)({
                                formVersionCId: e,
                                componentId: t
                            })
                        },
                        onBlur: e => ee({
                            value: e.target.value,
                            validate: !1,
                            hasChangedSinceLastValidation: !1
                        }),
                        onChange: e => {
                            (0, V.l)(), ee({
                                value: e.target.value,
                                validate: !1,
                                hasChangedSinceLastValidation: !0
                            })
                        },
                        options: q ? {
                            date: !0,
                            datePattern: N,
                            delimiter: j
                        } : {
                            delimiter: ""
                        },
                        value: J || "",
                        a11yIdentifier: i
                    }), !d && !Y && a().createElement(E.Z, {
                        theme: n,
                        formVersionCId: e,
                        componentAriaID: G,
                        metadata: m,
                        validationErrorType: u,
                        validationErrorMessage: p,
                        a11yIdentifier: i
                    }))
                },
                B = n(78212);
            let D, N = e => e;
            const {
                THEME_KEY: j
            } = B.default;
            var R = ({
                    componentId: e,
                    formVersionCId: t,
                    theme: n,
                    a11yIdentifierBlock: o
                }) => {
                    const i = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.content
                        })),
                        r = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) ? void 0 : n.actionId
                        })),
                        s = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        d = (0, I.iv)(D || (D = N `
    &&& {
      ${0}
      &:focus-visible {
        outline-width: 2px;
        outline-style: auto;
        outline-color: ${0};
        outline-offset: 0;
      }
    }
  `), !1 !== n[j].specifyHoverBackgroundColor ? `\n            &:hover {\n              background-color: ${n[j].hoverBackgroundColor} !important;\n              ${n[j].hoverTextColor||n[j].textColor?`color: ${n[j].hoverTextColor||n[j].textColor} !important;`:""}\n            }` : "", n.inputStyles.border.activeColor || n.focusColor);
                    return a().createElement(h, {
                        formVersionCId: t,
                        actionId: r
                    }, (({
                        onClick: e,
                        handlingFormAction: t
                    }) => a().createElement(l.zx, {
                        a11yIdentifier: o,
                        className: t ? `klaviyo-spinner ${d}` : d,
                        style: Object.assign({
                            background: n[j].backgroundColor,
                            borderRadius: n[j].borderRadius,
                            borderStyle: n[j].borderStyle,
                            borderColor: n[j].borderColor,
                            borderWidth: n[j].borderWidth,
                            color: n[j].textStyles.color,
                            fontFamily: n[j].textStyles.fontFamily,
                            fontSize: n[j].textStyles.fontSize,
                            fontWeight: n[j].textStyles.fontWeight,
                            letterSpacing: n[j].textStyles.letterSpacing,
                            lineHeight: 1,
                            fontStyle: n[j].textStyles.fontStyle,
                            textDecoration: n[j].textStyles.textDecoration,
                            whiteSpace: "normal",
                            paddingTop: n[j].paddingTop,
                            paddingBottom: n[j].paddingBottom,
                            textAlign: "center",
                            wordBreak: "break-word",
                            alignSelf: "flex-end",
                            cursor: "pointer",
                            pointerEvents: t ? "none" : "auto",
                            height: n[j].height
                        }, n[j].fullWidth ? {
                            width: "100%"
                        } : {
                            paddingLeft: 10,
                            paddingRight: 10
                        }),
                        type: "button",
                        disabled: t,
                        onClick: e,
                        tabIndex: s ? -1 : 0
                    }, i)))
                },
                P = n(23760);
            const z = `\n  color: #000000;\n  line-height: normal;\n\n  p {\n    margin: 0px;\n  }\n  span {\n    display: inline;\n  }\n  ol,\n  ul {\n    padding: 0 0 0 48px;\n    margin: 0;\n  }\n  ul {\n    list-style-type: disc;\n  }\n  li {\n    line-height: 18px;\n  }\n  a {\n    color: ${n(68216).Z.blue};\n    text-decoration: underline;\n    border-bottom: none;\n  }\n`,
                H = (0, I.iv)(z),
                W = ["html"],
                L = e => {
                    let {
                        html: t
                    } = e, n = c()(e, W);
                    return a().createElement("div", r()({}, t ? {
                        dangerouslySetInnerHTML: {
                            __html: t
                        }
                    } : {}, {
                        style: {
                            width: "100%"
                        },
                        className: `${o.Tc} ${H}`
                    }, n))
                },
                {
                    A11yWrapper: q = (() => null),
                    useRecursivelySetA11yAttribute: U = (() => "")
                } = {},
                K = ({
                    a11yIdentifierBlock: e,
                    id: t,
                    html: n
                }) => {
                    const o = U({
                        a11yIdentifier: e || "",
                        html: n
                    });
                    return e ? a().createElement(q, {
                        identifier: e
                    }, a().createElement(L, {
                        id: t,
                        html: o
                    })) : a().createElement(L, {
                        id: t,
                        html: n
                    })
                };
            var G = ({
                itemId: e,
                parentType: t = P.A,
                a11yIdentifierBlock: n
            }) => {
                const o = (0, f.Z)((n => {
                        var o, i;
                        return t === P.p && n.formsState.teasers ? null == (o = n.formsState.teasers[e]) || null == (o = o.data) || null == (o = o.content) ? void 0 : o.html : null == (i = n.formsState.components[e]) || null == (i = i.data) || null == (i = i.content) ? void 0 : i.html
                    })),
                    i = (0, s.useMemo)((() => `rich-text-${e}`), [e]);
                return a().createElement(K, {
                    a11yIdentifierBlock: n,
                    id: i,
                    html: o
                })
            };
            n(70818), n(60873), n(83362);
            const Y = ["selectorType", "fillColor", "formVersionCId", "id"],
                X = ({
                    fillColor: e,
                    id: t
                }) => a().createElement("g", {
                    id: t,
                    stroke: "none",
                    strokeWidth: "1",
                    fill: "none",
                    fillRule: "evenodd"
                }, a().createElement("g", {
                    id: `checkbox-on-${t}`,
                    transform: "translate(3.000000, 4.000000)",
                    fill: "#303B43"
                }, a().createElement("polygon", {
                    id: `shape-${t}`,
                    fill: e,
                    points: "4.45454545 9.20149254 1.11363636 5.75373134 0 6.90298507 4.45454545 11.5 14 1.64925373 12.8863636 0.5"
                }))),
                J = ({
                    fillColor: e,
                    id: t
                }) => a().createElement("g", {
                    id: t,
                    stroke: "none",
                    strokeWidth: "1",
                    fill: "none",
                    fillRule: "evenodd"
                }, a().createElement("g", {
                    id: `shape-${t}`,
                    transform: "translate(4.000000, 4.000000)",
                    fill: "#303B43"
                }, a().createElement("circle", {
                    fill: e,
                    id: `oval-${t}`,
                    cx: "6",
                    cy: "6",
                    r: "5.55555556"
                })));
            var Q = e => {
                let {
                    selectorType: t,
                    fillColor: n,
                    id: o
                } = e, i = c()(e, Y);
                return a().createElement("svg", r()({
                    style: {
                        cursor: "pointer",
                        display: "none",
                        position: "absolute",
                        margin: 0
                    },
                    width: "20px",
                    height: "20px",
                    viewBox: "0 0 20 20",
                    version: "1.1",
                    xmlns: "http://www.w3.org/2000/svg",
                    "aria-hidden": "true"
                }, i), a().createElement("defs", null), "radio" === t ? a().createElement(J, {
                    id: `radio_inner_${o}`,
                    fillColor: n
                }) : a().createElement(X, {
                    id: `checkbox_inner_${o}`,
                    fillColor: n
                }))
            };
            const ee = ["selectorType", "valid", "theme", "formVersionCId"],
                te = ({
                    backgroundColor: e
                }) => a().createElement("g", null, a().createElement("g", null, a().createElement("rect", {
                    strokeWidth: "1",
                    x: "0.5",
                    y: "0.5",
                    width: "19",
                    height: "19",
                    rx: "2.22222222",
                    fill: e
                }))),
                ne = ({
                    backgroundColor: e
                }) => a().createElement("g", null, a().createElement("g", null, a().createElement("circle", {
                    strokeWidth: "1",
                    cx: "10",
                    cy: "10",
                    r: "9.5",
                    fill: e
                })));
            var oe = e => {
                let {
                    selectorType: t,
                    valid: n,
                    theme: o
                } = e, i = c()(e, ee);
                return a().createElement("svg", r()({
                    style: {
                        stroke: n ? o.inputStyles.border.defaultColor : o.inputStyles.border.errorColor,
                        marginRight: 8,
                        minWidth: 20,
                        width: "auto",
                        height: "auto",
                        borderRadius: "radio" === t ? "50%" : void 0
                    },
                    width: "20px",
                    height: "20px",
                    viewBox: "0 0 20 20",
                    version: "1.1",
                    xmlns: "http://www.w3.org/2000/svg",
                    "aria-hidden": "true"
                }, i), "radio" === t ? a().createElement(ne, {
                    backgroundColor: o.inputStyles.inputBackgroundColor
                }) : a().createElement(te, {
                    backgroundColor: o.inputStyles.inputBackgroundColor
                }))
            };
            let ie, re = e => e;
            var se = ({
                name: e,
                label: t,
                isValid: n,
                componentAriaID: i,
                componentType: r,
                onChange: d,
                tabIndex: c,
                theme: m,
                formVersionCId: u,
                a11yIdentifierStyles: f,
                a11yIdentifierBlock: p,
                alignCheckbox: h,
                ariaRequired: v
            }) => {
                const {
                    current: g
                } = (0, s.useRef)((0, y.Z)(`${e}__`)), b = r === o.hD ? "radio" : "checkbox";
                return a().createElement(a().Fragment, null, a().createElement(l.II, {
                    className: "klaviyo-sr-only",
                    tabIndex: c,
                    type: b,
                    id: g,
                    name: e,
                    onChange: d,
                    "aria-invalid": !n,
                    "aria-label": t,
                    "aria-describedby": n ? void 0 : i,
                    "aria-required": v,
                    a11yIdentifier: p
                }), a().createElement(l.__, {
                    className: (0, I.iv)(ie || (ie = re `
          &&&& {
            &:hover {
              svg {
                stroke: ${0} !important;
              }
            }
          }
        `), m.inputStyles.border.activeColor),
                    style: {
                        display: "flex",
                        alignItems: null != h ? h : "center",
                        flex: m.inputStyles.arrangement === o.ZC ? " 1 0 100%" : " 0 0 auto",
                        paddingBottom: 8,
                        wordBreak: "break-word",
                        maxWidth: "100%",
                        cursor: "pointer"
                    },
                    htmlFor: g,
                    a11yIdentifier: f
                }, a().createElement(oe, {
                    valid: n,
                    selectorType: b,
                    "aria-hidden": "true",
                    theme: m,
                    formVersionCId: u
                }), a().createElement(Q, {
                    selectorType: b,
                    "aria-hidden": "true",
                    formVersionCId: u,
                    fillColor: m.inputStyles.textStyles.formInputTextColor,
                    id: g
                }), a().createElement(l.ZC, {
                    style: {
                        cursor: "pointer",
                        color: m.inputStyles.textStyles.color,
                        fontFamily: m.inputStyles.textStyles.fontFamily,
                        fontSize: m.inputStyles.textStyles.fontSize,
                        fontWeight: m.inputStyles.textStyles.fontWeight,
                        letterSpacing: m.inputStyles.textStyles.letterSpacing,
                        marginRight: 24,
                        display: "flex",
                        position: "relative",
                        top: 1
                    },
                    a11yIdentifier: f
                }, t)))
            };
            let ae, le = e => e;
            const de = ["selected", "id", "label"],
                ce = {
                    right: "flex-end",
                    left: "flex-start",
                    center: "center"
                },
                me = ({
                    options: e,
                    componentType: t,
                    toggledOptionIndex: n
                }) => e.reduce(((e, i, r) => {
                    let {
                        selected: s,
                        id: a,
                        label: l
                    } = i, d = c()(i, de), m = t !== o.hD && s;
                    return n === r && (m = !m), e.push(Object.assign({
                        selected: m,
                        label: l,
                        id: a || (0, y.Z)(`${l}__`)
                    }, d)), e
                }), []);
            var ue = ({
                    formVersionCId: e,
                    componentId: t,
                    theme: n,
                    a11yIdentifierStyles: i,
                    a11yIdentifierBlock: r
                }) => {
                    const d = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        c = (0, f.Z)((n => {
                            var o;
                            const i = null == (o = n.onsiteState.openFormVersions[e]) ? void 0 : o.components[t];
                            return !!n.onsiteState.client.isDesignWorkflow || !i || i.valid || void 0 === i.valid
                        })),
                        m = (0, f.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.metadata
                        }), b.X),
                        u = (0, f.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.validationErrorType
                        })),
                        p = (0, f.Z)((n => (0, Z.HN)(n, e, t))),
                        h = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) ? void 0 : n.componentType
                        })),
                        v = (0, f.Z)((e => {
                            var n;
                            return (null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.options) || []
                        }), b.X),
                        g = (0, f.Z)((e => {
                            var n;
                            return (null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.fieldId) || ""
                        })),
                        S = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.required
                        })),
                        w = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.label
                        })),
                        C = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.showLabel
                        })),
                        k = (0, f.Z)((e => {
                            var n;
                            const o = null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.styling) ? void 0 : n.innerAlignment;
                            return o ? ce[o] : "flex-start"
                        })),
                        [T, $] = (0, s.useState)([]);
                    (0, s.useEffect)((() => {
                        $(me({
                            options: v,
                            componentType: h
                        }))
                    }), [v]);
                    const {
                        inputName: F,
                        labelId: O
                    } = (0, s.useMemo)((() => {
                        const e = (0, y.Z)(`${encodeURIComponent(g)}__`);
                        return {
                            inputName: e,
                            labelId: `kl_${e}_label`
                        }
                    }), []), A = 1 === T.length;
                    return a().createElement(l.ZC, {
                        style: {
                            width: "100%",
                            justifyContent: k,
                            display: "flex"
                        }
                    }, a().createElement(l.C3, {
                        className: (0, I.iv)(ae || (ae = le `
          &&& {
            input:focus-visible + label > svg {
              outline-width: 2px;
              outline-style: auto;
              outline-color: ${0};
              outline-offset: 0;
            }
          }
        `), n.inputStyles.border.activeColor || n.focusColor),
                        style: Object.assign({
                            alignSelf: "flex-end"
                        }, n.inputStyles.arrangement === o.ZC ? {
                            display: "block"
                        } : {
                            flexDirection: "column",
                            flexWrap: "wrap"
                        }),
                        a11yIdentifier: i,
                        "aria-required": !A && S || void 0
                    }, a().createElement(x.Z, {
                        a11yIdentifier: i,
                        id: O,
                        theme: n,
                        style: {
                            marginRight: 8,
                            marginBottom: 8
                        },
                        showLabel: !(void 0 !== C || !w) || C,
                        asLegend: !0
                    }, w), a().createElement(l.ZC, {
                        style: Object.assign({}, n.inputStyles.arrangement === o.ZC ? {
                            display: "block"
                        } : {
                            display: "inline-flex",
                            justifyContent: "flex-start",
                            flexWrap: "wrap"
                        }),
                        role: h === o.hD ? "radiogroup" : "group",
                        a11yIdentifier: i
                    }, T.map((({
                        label: s,
                        id: l
                    }, m) => a().createElement(se, {
                        key: l,
                        formVersionCId: e,
                        theme: n,
                        name: F,
                        label: s,
                        isValid: c,
                        componentType: h,
                        componentAriaID: O,
                        onChange: () => (n => {
                            (0, V.l)();
                            const i = me({
                                options: T,
                                componentType: h,
                                toggledOptionIndex: n
                            });
                            $(i);
                            const r = (e => e.filter((({
                                selected: e
                            }) => e)).map((e => e.value || e.label)))(i);
                            (0, _.hX)({
                                formVersionCId: e,
                                componentId: t,
                                value: h === o.hD ? r.toString() : r
                            })
                        })(m),
                        tabIndex: d ? -1 : 0,
                        a11yIdentifierStyles: i,
                        a11yIdentifierBlock: r,
                        ariaRequired: A && S || void 0
                    })))), !d && a().createElement(E.Z, {
                        theme: n,
                        formVersionCId: e,
                        componentAriaID: O,
                        validationErrorType: u,
                        validationErrorMessage: p,
                        metadata: m,
                        a11yIdentifier: i
                    })))
                },
                fe = (n(60624), n(75479), n(49889)),
                pe = n.n(fe),
                he = n(85198),
                ve = n(99385);
            let ge, ye = e => e;
            const Ie = "rgb(96, 106, 114)",
                be = "white",
                Se = "copy",
                we = "applied",
                Ce = {
                    [Se]: {
                        message: "Copied!",
                        couponTooltipRectangleWidth: 80
                    },
                    [we]: {
                        message: "Coupon applied to checkout!",
                        couponTooltipRectangleWidth: 196
                    }
                };
            var xe, Ee, _e = ({
                show: e,
                theme: t,
                type: n,
                a11yIdentifier: o,
                successMessage: i
            }) => {
                const r = i || Ce[n].message,
                    s = Ce[n].couponTooltipRectangleWidth;
                return a().createElement(l.ZC, {
                    style: {
                        width: "100%",
                        position: "relative"
                    },
                    a11yIdentifier: o
                }, e && a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        backgroundColor: "transparent",
                        position: "absolute",
                        zIndex: 1,
                        height: "37px",
                        minWidth: `${s}px`,
                        left: "50%",
                        transform: "translate(-50%, 0)",
                        bottom: "-21px",
                        borderRadius: 4,
                        animationName: "klaviyo-fadein, klaviyo-fadeout",
                        animationDuration: "0.4s, 0.4s",
                        animationDelay: "0s, 1.6s"
                    }
                }, a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    className: (0, I.iv)(ge || (ge = ye `
              &&& {
                &::after {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  bottom: ${0}px;
                  left: calc(50% - ${0}px);
                  border-style: solid;
                  border-width: ${0}px;
                  border-top-color: ${0};
                  border-right-color: transparent;
                  border-bottom-color: transparent;
                  border-left-color: transparent;
                }
                &::before {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  bottom: ${0}px;
                  left: calc(50% - ${0}px);
                  border-style: solid;
                  border-width: ${0}px;
                  border-top-color: ${0};
                  border-right-color: transparent;
                  border-bottom-color: transparent;
                  border-left-color: transparent;
                }
              }
            `), -6, 6, 6, Ie, -8, 7, 7, be),
                    style: {
                        borderRadius: 4,
                        boxShadow: "1px 1px 4px 0 rgba(0, 0, 0, 0.26)",
                        border: "1px solid white",
                        backgroundColor: Ie
                    }
                }, a().createElement(l.Dr, {
                    a11yIdentifier: o,
                    style: {
                        fontSize: 14,
                        fontFamily: t.inputStyles.textStyles.fontFamily,
                        textAlign: "center",
                        color: be,
                        padding: 8,
                        height: "30px",
                        boxSizing: "border-box",
                        whiteSpace: "nowrap"
                    },
                    role: "alert"
                }, r))))
            };

            function ke() {
                return ke = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, ke.apply(null, arguments)
            }
            var Ve, Te, $e = function(e) {
                return s.createElement("svg", ke({
                    width: 32,
                    height: 33,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), xe || (xe = s.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M3.602 1.1a3 3 0 0 0-3 3v18.4a3 3 0 0 0 3 3H8v-2H3.602a1 1 0 0 1-1-1V4.1a1 1 0 0 1 1-1h15.2a1 1 0 0 1 1 1v1.2h2V4.1a3 3 0 0 0-3-3h-15.2Z",
                    fill: "currentColor"
                })), Ee || (Ee = s.createElement("rect", {
                    x: 11.199,
                    y: 8.5,
                    width: 19.2,
                    height: 22.4,
                    rx: 2,
                    stroke: "currentColor",
                    strokeWidth: 2
                })))
            };

            function Ze() {
                return Ze = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, Ze.apply(null, arguments)
            }
            var Fe = function(e) {
                return s.createElement("svg", Ze({
                    width: 32,
                    height: 33,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), Ve || (Ve = s.createElement("g", {
                    clipPath: "url(#check_svg__a)"
                }, s.createElement("path", {
                    d: "m11.16 18.992-4.493-4.494a1.73 1.73 0 0 0-2.45 2.443l5.512 6.144c.79.844 2.133.834 2.912-.021l13.321-14.13a1.678 1.678 0 0 0-2.446-2.299L11.16 18.992Z",
                    fill: "#2CB46F",
                    stroke: "#fff"
                }))), Te || (Te = s.createElement("defs", null, s.createElement("clipPath", {
                    id: "check_svg__a"
                }, s.createElement("path", {
                    fill: "#fff",
                    transform: "translate(0 .5)",
                    d: "M0 0h32v32H0z"
                })))))
            };
            var Oe = ({
                copied: e,
                color: t,
                a11yIdentifier: n
            }) => e ? a().createElement(l.ny, {
                style: {
                    height: 32,
                    width: 32,
                    paddingLeft: "16px",
                    cursor: "pointer",
                    flexShrink: 0
                },
                a11yIdentifier: n
            }, a().createElement(Fe, null)) : a().createElement(l.ny, {
                style: {
                    color: t,
                    height: 32,
                    width: 32,
                    paddingLeft: "16px",
                    cursor: "pointer",
                    flexShrink: 0
                },
                a11yIdentifier: n
            }, a().createElement($e, null));
            let Ae, Me = e => e;
            const {
                THEME_KEY: Be
            } = he.default;
            var De = ({
                    theme: e,
                    a11yIdentifier: t
                }) => {
                    const n = (0, I.iv)(Ae || (Ae = Me `
    &&& .klaviyo-spinner {
      &.overlay {
        &:before {
          background-color: ${0};
        }
      }
      &:after {
        top: auto;
        bottom: 0;
        width: 30px;
        height: 30px;
        margin-top: -15px;
        margin-left: -15px;
        border-top-color: ${0};
        border-left-color: ${0};
      }
    }
  `), e[Be].backgroundColor, e[Be].textStyles.color, e[Be].textStyles.color);
                    return a().createElement(l.ZC, {
                        a11yIdentifier: t,
                        className: n,
                        style: {
                            height: 32,
                            width: "100%",
                            paddingTop: "16px",
                            position: "relative"
                        }
                    }, a().createElement(l.ZC, {
                        a11yIdentifier: t,
                        className: "klaviyo-spinner"
                    }))
                },
                Ne = n(82191),
                je = n(30118),
                Re = n(89160);
            let Pe, ze = e => e;
            const {
                THEME_KEY: He
            } = he.default, We = () => null;
            var Le = ({
                formVersionCId: e,
                componentId: t,
                theme: n,
                a11yIdentifierBlock: o,
                a11yIdentifierStyles: i
            }) => {
                const r = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    d = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.couponType
                    })),
                    c = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.text
                    })),
                    m = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.successMessage
                    })),
                    u = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.name
                    })),
                    p = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.fallback
                    })),
                    h = (0, f.Z)((e => e.onsiteState.couponCodes[t])),
                    v = (0, f.Z)((e => e.onsiteState.datadomeCaptchaUrls[t])),
                    g = (0, f.Z)((e => e.onsiteState.client.showingShopLogin)),
                    [y, b] = (0, s.useState)(!1),
                    [S, w] = (0, s.useState)(!1),
                    [C, x] = (0, s.useState)(!1),
                    [E, k] = (0, s.useState)(Se),
                    V = (0, s.useMemo)((() => d === Ne.$i.STATIC ? c || Ne.I4 : d === Ne.$i.UNIQUE && r ? u ? (0, Ne.xB)(u) : void 0 : h || p), [d, h, p, u, r, c]),
                    T = v && !C;
                return (0, s.useEffect)((() => {
                    "https://static.klaviyo-dev.com/index.html" === window.location.href || "localhost" === window.location.hostname && "static_page" === new URL(window.location.href).searchParams.get("env") || r || d !== Ne.$i.UNIQUE || h || (w(!0), (0, _.zS)({
                        formVersionCId: e
                    }))
                }), [C, d, h, e, r]), (0, s.useEffect)((() => {
                    const t = () => {
                            x(!0)
                        },
                        n = () => {
                            (0, _.Cm)({
                                id: e,
                                changes: {
                                    errorViewMessage: je.w5
                                }
                            })
                        };
                    return window.addEventListener(Re.H, t, !1), window.addEventListener(Re.vT, n, !1), () => {
                        window.removeEventListener(Re.H, t, !1), window.removeEventListener(Re.vT, n, !1)
                    }
                }), []), (0, s.useEffect)((() => {
                    (T || V) && S && w(!1)
                }), [T, V, S]), (0, s.useEffect)((() => {
                    window.Shopify && !S && V && E !== we && (k(we), fetch(`/discount/${V}`))
                }), [E, V, S]), a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        alignItems: "center",
                        justifyContent: "center",
                        width: "100%",
                        height: "auto"
                    }
                }, r && !V ? a().createElement(We, null) : a().createElement(a().Fragment, null, !!V && !S && a().createElement(_e, {
                    a11yIdentifier: o,
                    show: y,
                    theme: n,
                    type: E,
                    successMessage: m
                }), T ? a().createElement("iframe", {
                    title: "Recaptcha",
                    src: v,
                    frameBorder: "0",
                    width: "100%",
                    height: "600px"
                }) : a().createElement(l.zx, {
                    role: "button",
                    "aria-label": "Copy coupon code",
                    a11yIdentifier: o,
                    onClick: e => {
                        e.preventDefault(), V && pe()(V), b(!0);
                        const t = setTimeout((() => {
                            b(!1)
                        }), 2e3);
                        return () => clearTimeout(t)
                    },
                    className: (0, I.iv)(Pe || (Pe = ze `
                &&& {
                  &:focus-visible {
                    outline-width: 2px;
                    outline-style: auto;
                    outline-color: ${0};
                    outline-offset: 0;
                  }
                }
              `), n.inputStyles.border.activeColor || n.focusColor),
                    style: {
                        position: "relative",
                        display: "flex",
                        flexDirection: "row",
                        flex: "1 1",
                        alignItems: "center",
                        justifyContent: "center",
                        background: n[He].backgroundColor,
                        borderRadius: n[He].borderRadius,
                        borderStyle: n[He].borderStyle,
                        borderColor: n[He].borderColor,
                        borderWidth: n[He].borderWidth,
                        color: n[He].textStyles.color,
                        lineHeight: 1,
                        whiteSpace: "normal",
                        paddingTop: n[He].paddingTop,
                        paddingBottom: n[He].paddingBottom,
                        paddingLeft: n[He].paddingLeft,
                        paddingRight: n[He].paddingRight,
                        textAlign: "center",
                        wordBreak: "break-word",
                        alignSelf: "flex-end",
                        cursor: S ? "auto" : "pointer",
                        boxSizing: "border-box",
                        width: "100%"
                    }
                }, S || g === ve.K.SHOWING ? a().createElement(l.ZC, {
                    a11yIdentifier: o
                }, a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    style: {
                        flex: "1 1",
                        fontFamily: n.inputStyles.textStyles.fontFamily,
                        fontSize: 18,
                        fontWeight: n.inputStyles.textStyles.fontWeight,
                        letterSpacing: n.inputStyles.textStyles.letterSpacing
                    }
                }, "Loading Coupon"), a().createElement(De, {
                    a11yIdentifier: o,
                    theme: n
                })) : a().createElement(a().Fragment, null, a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        flex: "1 1",
                        fontFamily: n[He].textStyles.fontFamily,
                        fontSize: n[He].textStyles.fontSize,
                        fontWeight: n[He].textStyles.fontWeight,
                        letterSpacing: n[He].textStyles.letterSpacing
                    }
                }, V), a().createElement(Oe, {
                    copied: y,
                    color: n[He].textStyles.color,
                    a11yIdentifier: o
                })))))
            };
            let qe, Ue = e => e;
            const Ke = ["html", "textStyles"];
            var Ge = e => {
                let {
                    html: t,
                    textStyles: n
                } = e, i = c()(e, Ke);
                return n ? a().createElement("div", r()({}, t ? {
                    dangerouslySetInnerHTML: {
                        __html: t
                    }
                } : {}, {
                    style: {
                        width: "100%"
                    },
                    className: (0, I.iv)(qe || (qe = Ue `
        &&& {
          :not(a) {
            color: ${0};
            font-family: ${0};
            font-size: ${0}px;
          }
          a {
            color: ${0};
            font-family: ${0};
            font-size: ${0}px;
          }
        }
        ${0}
        ${0}
      `), n.text.color, n.text.fontFamily, n.text.fontSize, n.link.color, n.link.fontFamily, n.link.fontSize, o.Tc, H)
                }, i)) : null
            };
            const {
                A11yWrapper: Ye = (() => null),
                useRecursivelySetA11yAttribute: Xe = (() => "")
            } = {};
            var Je = ({
                    componentId: e,
                    formVersionCId: t,
                    a11yIdentifierBlock: n
                }) => {
                    const o = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.content) ? void 0 : n.html
                        })),
                        i = (0, f.Z)((n => {
                            var o;
                            const i = null == (o = n.onsiteState.openFormVersions[t]) ? void 0 : o.currentViewId;
                            if (!i) return;
                            const {
                                formSMSDisclosure: r
                            } = (0, F.su)(n, e, i);
                            return null == r ? void 0 : r.textStyles
                        }), b.X),
                        r = Xe({
                            html: o,
                            a11yIdentifier: n || ""
                        });
                    return n ? a().createElement(Ye, {
                        identifier: n
                    }, a().createElement(Ge, {
                        html: r,
                        textStyles: i
                    })) : a().createElement(Ge, {
                        html: o,
                        textStyles: i
                    })
                },
                Qe = n(18735);
            n(78991), n(24570);
            const et = e => {
                    const t = new Intl.DateTimeFormat("en-GB", {
                            hour: "2-digit",
                            minute: "2-digit",
                            second: "2-digit",
                            hour12: !1
                        }).formatToParts(e),
                        n = `${t[0].value}:${t[2].value}:${t[4].value}`;
                    if (!(e => /[0-9]{2}:[0-9]{2}:[0-9]{2}/.test(e))(n)) throw new Error("The provided Date was not able to be converted to a valid ISO Time string.");
                    return n
                },
                tt = e => et(e);
            var nt = n(69780);
            const ot = ["text", "theme", "a11yIdentifierBlock"],
                {
                    THEME_KEY: it
                } = nt.default;
            var rt = e => {
                let {
                    text: t,
                    theme: n,
                    a11yIdentifierBlock: o
                } = e, i = c()(e, ot);
                return a().createElement(l.ZC, r()({
                    a11yIdentifier: o
                }, i), a().createElement(l.Dr, {
                    className: "klaviyo-sr-only"
                }, t.startsWith("0") ? t.substring(1) : t), a().createElement(l.Dr, {
                    "aria-hidden": "true",
                    style: {
                        color: n[it].textStyles.color,
                        fontFamily: n[it].textStyles.fontFamily,
                        fontSize: n[it].textStyles.fontSize,
                        fontWeight: n[it].textStyles.fontWeight
                    }
                }, t))
            };
            let st, at, lt, dt, ct, mt = e => e;
            const {
                THEME_KEY: ut
            } = nt.default, ft = "0.72em", pt = "0.15em";
            var ht = ({
                text: e,
                prevText: t = "00",
                animate: n = !1,
                theme: o,
                a11yIdentifierBlock: i
            }) => {
                const r = (0, s.useMemo)((() => ({
                    card: (0, I.iv)(st || (st = mt `
        &&& {
          & {
            text-align: center;
            display: inline-block;
            margin: 0 5px;
            display: block;
            position: relative;
            font-size: ${0};
          }

          *,
          *:before,
          *:after {
            box-sizing: border-box;
          }
        }
      `), o[ut].textStyles.fontSize),
                    card_top: (0, I.iv)(at || (at = mt `
        &&& {
          & {
            display: block;
            height: ${0};
            border-radius: ${0} ${0} 0 0;
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }

          &::after {
            display: block;
            content: '${0}';
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), ft, pt, pt, o[ut].cardColor, o[ut].textStyles.color, o[ut].textStyles.fontFamily, o[ut].textStyles.fontSize, o[ut].textStyles.fontWeight, e, o[ut].textStyles.color, o[ut].textStyles.fontFamily, o[ut].textStyles.fontSize, o[ut].textStyles.fontWeight),
                    card_bottom: (0, I.iv)(lt || (lt = mt `
        &&& {
          & {
            border-top: solid 1px #fff;
            border-radius: 0 0 ${0} ${0};

            display: block;
            height: ${0};
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }

          &::after {
            display: block;
            margin-top: -${0};
            content: '${0}';
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), pt, pt, ft, o[ut].cardColor, o[ut].textStyles.color, o[ut].textStyles.fontFamily, o[ut].textStyles.fontSize, o[ut].textStyles.fontWeight, ft, n ? t : e, o[ut].textStyles.color, o[ut].textStyles.fontFamily, o[ut].textStyles.fontSize, o[ut].textStyles.fontWeight),
                    card_animate: (0, I.iv)(dt || (dt = mt `
        &&& {
          & {
            position: absolute;
            top: 0;
            height: 100%;
            left: 0%;
            pointer-events: none;

            z-index: 2;
          }

          &::before {
            content: '${0}';
            z-index: -1;
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            animation: klaviyo-flipTop 0.3s cubic-bezier(0.37, 0.01, 0.94, 0.35)
              1;
            animation-fill-mode: both;
            transform-origin: center bottom;

            display: block;
            height: ${0};
            border-radius: ${0} ${0} 0 0;
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), t, ft, pt, pt, o[ut].cardColor, o[ut].textStyles.color, o[ut].textStyles.fontFamily, o[ut].textStyles.fontSize, o[ut].textStyles.fontWeight),
                    card_animate_bottom: (0, I.iv)(ct || (ct = mt `
        &&& {
          & {
            border-top: solid 1px #fff;
            border-radius: 0 0 ${0} ${0};

            display: block;
            height: ${0};
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }

          &::after {
            display: block;
            margin-top: -${0};
            content: '${0}';
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), pt, pt, ft, o[ut].cardColor, o[ut].textStyles.color, o[ut].textStyles.fontFamily, o[ut].textStyles.fontSize, o[ut].textStyles.fontWeight, ft, e, o[ut].textStyles.color, o[ut].textStyles.fontFamily, o[ut].textStyles.fontSize, o[ut].textStyles.fontWeight)
                })), [o, e, t, n]);
                return a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    className: r.card
                }, a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    className: r.card_top
                }), a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    className: r.card_bottom
                }), n && a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    className: r.card_animate,
                    key: e
                }, a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    className: r.card_animate_bottom,
                    style: {
                        transformOrigin: "center top",
                        animationFillMode: "both",
                        animation: "klaviyo-flipBottom 0.6s cubic-bezier(.15,.45,.28,1) 1"
                    }
                })))
            };
            const {
                THEME_KEY: vt
            } = nt.default;
            var gt = ({
                text: e,
                clockFace: t = "simple",
                theme: n,
                a11yIdentifierBlock: o
            }) => {
                const i = (0, s.useMemo)((() => "flip" === t ? n[vt].cardColor : n[vt].textStyles.color), [t, n]);
                return a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        color: i,
                        fontFamily: n[vt].textStyles.fontFamily,
                        fontSize: n[vt].textStyles.labelFontSize,
                        fontWeight: n[vt].textStyles.labelFontWeight,
                        justifyContent: "center",
                        justifySelf: "center"
                    }
                }, e)
            };
            const yt = {
                    name: "none",
                    duration: 0
                },
                It = {
                    name: "flash",
                    duration: 1
                },
                bt = {
                    name: "heartbeat",
                    duration: 1.3
                },
                St = {
                    name: "pulse",
                    duration: 1
                },
                wt = "fixed",
                Ct = "variable",
                xt = "full",
                Et = "shortened",
                _t = "single_char",
                kt = "double_char";
            var Vt = ({
                componentId: e,
                formVersionCId: t,
                theme: n,
                a11yIdentifierBlock: o
            }) => {
                const i = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    r = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.dateType
                    })),
                    d = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.date) ? void 0 : n.variable
                    })),
                    c = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.date) ? void 0 : n.fixed
                    })),
                    m = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.clockFace
                    })),
                    u = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.timerAnimation
                    })),
                    p = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.labelFormat
                    })),
                    h = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.opened
                    })),
                    {
                        dateInUserTimezoneISOString: v
                    } = (0, s.useMemo)((() => function(e, t) {
                        if (!e) return {
                            dateInUserTimezoneISOString: null,
                            timeInUserTimezone: null,
                            timezone: null != t ? t : "US/Eastern"
                        };
                        const n = (0, Qe.Z)(new Date(e), null != t ? t : "US/Eastern");
                        return {
                            dateInUserTimezoneISOString: n.toISOString(),
                            timeInUserTimezone: tt(n),
                            timezone: null != t ? t : "US/Eastern"
                        }
                    }(null == c ? void 0 : c.utcIsoString, Intl.DateTimeFormat().resolvedOptions().timeZone)), [c]),
                    g = (0, s.useMemo)((() => {
                        if (r === Ct) return {
                            days: d.days > 0 ? `${d.days.toString().padStart(2,"0")}` : void 0,
                            hours: d.days > 0 || d.hours > 0 ? `${d.hours.toString().padStart(2,"0")}` : void 0,
                            minutes: `${d.minutes.toString().padStart(2,"0")}`,
                            seconds: "00"
                        };
                        if (r === wt) {
                            if (!v) return {
                                minutes: "00",
                                seconds: "00"
                            };
                            const e = new Date(v),
                                t = new Date,
                                n = e.getTime() - t.getTime();
                            if (n <= 0) return {
                                minutes: "00",
                                seconds: "00"
                            };
                            const o = Math.floor(n / 864e5),
                                r = Math.floor(n % 864e5 / 36e5),
                                s = Math.floor(n % 36e5 / 6e4),
                                a = Math.floor(n % 6e4 / 1e3);
                            return i ? {
                                days: o > 0 ? "00" : void 0,
                                hours: o > 0 || r > 0 ? "00" : void 0,
                                minutes: "00",
                                seconds: "00"
                            } : {
                                days: o > 0 ? `${o.toString().padStart(2,"0")}` : void 0,
                                hours: o > 0 || r > 0 ? `${r.toString().padStart(2,"0")}` : void 0,
                                minutes: `${s.toString().padStart(2,"0")}`,
                                seconds: `${a.toString().padStart(2,"0")}`
                            }
                        }
                        return {
                            minutes: "00",
                            seconds: "00"
                        }
                    }), [r, d, v, i]),
                    [y, I] = (0, s.useState)(g),
                    [b, S] = (0, s.useState)(y),
                    [w, C] = (0, s.useState)(!1),
                    [x, E] = (0, s.useState)(0);
                (0, s.useEffect)((() => {
                    if (i) return S(y), I(g), () => {};
                    if (r === Ct && h && !w) {
                        const e = new Date;
                        e.setDate(e.getDate() + d.days), e.setHours(e.getHours() + d.hours), e.setMinutes(e.getMinutes() + d.minutes), E(e.getTime()), C(!0)
                    }
                    if (r === wt && !w && v) {
                        const e = new Date(v);
                        E(e.getTime()), C(!0)
                    }
                    const e = setInterval((() => {
                        if (w && (Number(y.seconds) > 0 || Number(y.minutes) > 0 || Number(y.hours) > 0 || Number(y.days) > 0)) {
                            const e = new Date,
                                t = x - e.getTime();
                            if (t < 0) return S(y), void I({
                                minutes: "00",
                                seconds: "00"
                            });
                            S(y), I((e => {
                                const t = Math.floor(e / 864e5),
                                    n = Math.floor(e % 864e5 / 36e5),
                                    o = Math.floor(e % 36e5 / 6e4),
                                    i = Math.floor(e % 6e4 / 1e3);
                                return {
                                    days: t > 0 ? `${t.toString().padStart(2,"0")}` : void 0,
                                    hours: t > 0 || n > 0 ? `${n.toString().padStart(2,"0")}` : void 0,
                                    minutes: `${o.toString().padStart(2,"0")}`,
                                    seconds: `${i.toString().padStart(2,"0")}`
                                }
                            })(t))
                        }
                    }), 1e3);
                    return () => {
                        clearInterval(e)
                    }
                }), [i, r, h, w, g, d, v, x, y]);
                const _ = (0, s.useRef)(u),
                    [k, V] = (0, s.useState)(!1);
                (0, s.useEffect)((() => {
                    V(_.current !== u), _.current = u
                }), [u]);
                const T = (0, s.useMemo)((() => {
                        if (i && !k) return "";
                        if (!i && (Number(y.seconds) > 0 || Number(y.minutes) > 0 || Number(y.hours) > 0 || Number(y.days) > 0) || u === yt.name) return "";
                        let e = "";
                        return u === It.name ? e = `klaviyo-${It.name} ${It.duration}s` : u === bt.name ? e = `klaviyo-${bt.name} ${bt.duration}s` : u === St.name && (e = `klaviyo-${St.name} ${St.duration}s`), i ? `${e} 1` : `${e} 1s infinite`
                    }), [u, i, y, k]),
                    $ = (0, s.useMemo)((() => {
                        switch (p) {
                            case xt:
                                return {
                                    days: "days",
                                    hours: "hours",
                                    minutes: "minutes",
                                    seconds: "seconds"
                                };
                            case Et:
                                return {
                                    days: "days",
                                    hours: "hrs",
                                    minutes: "mins",
                                    seconds: "secs"
                                };
                            case kt:
                                return {
                                    days: "DD",
                                    hours: "HH",
                                    minutes: "MM",
                                    seconds: "SS"
                                };
                            case _t:
                                return {
                                    days: "D",
                                    hours: "H",
                                    minutes: "M",
                                    seconds: "S"
                                };
                            default:
                                return {
                                    days: "days",
                                    hours: "hours",
                                    minutes: "minutes",
                                    seconds: "seconds"
                                }
                        }
                    }), [p]);
                return "simple" === m ? a().createElement(l.ZC, {
                    className: "klaviyo-countdown",
                    a11yIdentifier: o,
                    "data-testid": "klaviyo-countdown",
                    role: "timer",
                    "aria-live": "polite",
                    "aria-atomic": "true",
                    style: {
                        width: "100%",
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "flex",
                        animation: `${T}`,
                        fontVariantNumeric: "tabular-nums"
                    }
                }, a().createElement(l.Dr, {
                    className: "klaviyo-sr-only"
                }, "Countdown ends in:"), (null == y ? void 0 : y.days) && a().createElement(a().Fragment, null, a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "grid"
                    }
                }, a().createElement(rt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == y ? void 0 : y.days
                }), a().createElement(gt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.days
                })), a().createElement(rt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: " "
                })), (null == y ? void 0 : y.hours) && a().createElement(a().Fragment, null, a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "grid"
                    }
                }, a().createElement(rt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == y ? void 0 : y.hours
                }), a().createElement(gt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.hours
                })), a().createElement(rt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: ":"
                })), a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, a().createElement(rt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == y ? void 0 : y.minutes
                }), a().createElement(gt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.minutes
                })), a().createElement(rt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: ":"
                }), a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    },
                    "aria-hidden": "true"
                }, a().createElement(rt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == y ? void 0 : y.seconds
                }), a().createElement(gt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.seconds
                }))) : "flip" === m ? a().createElement(l.ZC, {
                    className: "klaviyo-countdown",
                    a11yIdentifier: o,
                    "data-testid": "klaviyo-countdown",
                    role: "timer",
                    "aria-live": "polite",
                    "aria-atomic": "true",
                    style: {
                        width: "100%",
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "flex",
                        animation: `${T}`,
                        fontVariantNumeric: "tabular-nums"
                    }
                }, a().createElement(l.Dr, {
                    className: "klaviyo-sr-only"
                }, "Countdown ends in:"), (null == y ? void 0 : y.days) && a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, a().createElement(ht, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == y ? void 0 : y.days,
                    prevText: null == b ? void 0 : b.days,
                    animate: !i
                }), a().createElement(gt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.days
                })), (null == y ? void 0 : y.hours) && a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, a().createElement(ht, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == y ? void 0 : y.hours,
                    prevText: null == b ? void 0 : b.hours,
                    animate: !i
                }), a().createElement(gt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.hours
                })), a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, a().createElement(ht, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == y ? void 0 : y.minutes,
                    prevText: null == b ? void 0 : b.minutes,
                    animate: !i
                }), a().createElement(gt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.minutes
                })), a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    },
                    "aria-hidden": "true"
                }, a().createElement(ht, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == y ? void 0 : y.seconds,
                    prevText: null == b ? void 0 : b.seconds,
                    animate: !i
                }), a().createElement(gt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.seconds
                }))) : a().createElement(l.ZC, null)
            };
            var Tt = ({
                itemId: e,
                a11yIdentifierBlock: t
            }) => {
                const n = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    o = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.content) ? void 0 : n.html
                    })),
                    i = (0, s.useMemo)((() => `engagement-counter-${e}`), [e]),
                    r = /{{ *(&nbsp; *)*form_submit_count *(&nbsp; *)*}}/,
                    l = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.dynamicInfoState) || null == (n = n.results) ? void 0 : n[e].submits
                    }));
                let d = null;
                const c = (0, f.Z)((t => {
                    var n;
                    return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.minThreshold
                }));
                return n ? d = a().createElement(K, {
                    a11yIdentifierBlock: t,
                    id: i,
                    html: o
                }) : "number" == typeof l && l >= c && (d = a().createElement(K, {
                    a11yIdentifierBlock: t,
                    id: i,
                    html: o.replace(r, null == l ? void 0 : l.toString())
                })), d
            };
            let $t, Zt = e => e;
            const Ft = {
                right: "flex-end",
                left: "flex-start",
                center: "center"
            };
            var Ot = ({
                    componentId: e,
                    a11yIdentifierBlock: t,
                    formVersionCId: n,
                    theme: i,
                    a11yIdentifierStyles: r
                }) => {
                    const d = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        c = (0, f.Z)((t => {
                            var n;
                            return (null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.fieldId) || ""
                        })),
                        m = (0, f.Z)((t => {
                            var n;
                            return (null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.label) || ""
                        })),
                        u = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.showLabel
                        })),
                        p = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.checkboxLabel
                        })),
                        h = (0, f.Z)((t => {
                            var n;
                            const o = null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.styling) ? void 0 : n.innerAlignment;
                            return o ? Ft[o] : "flex-start"
                        })),
                        {
                            inputName: v,
                            labelId: g
                        } = (0, s.useMemo)((() => {
                            const e = (0, y.Z)(`${encodeURIComponent(c)}__`);
                            return {
                                inputName: e,
                                labelId: `kl_${e}_label`
                            }
                        }), [c]);
                    (0, s.useEffect)((() => {
                        (0, _.hX)({
                            formVersionCId: n,
                            componentId: e,
                            value: "false"
                        })
                    }), [e, n]);
                    return a().createElement(l.ZC, {
                        a11yIdentifier: t,
                        style: {
                            width: "100%",
                            justifyContent: h,
                            display: "flex"
                        }
                    }, a().createElement(l.C3, {
                        className: (0, I.iv)($t || ($t = Zt `
          &&& {
            input:focus-visible + label > svg {
              outline: 2px solid;
              outline-color: ${0};
              outline-offset: 0;
              box-shadow: 0 0 0 4px #ffffff;
            }
          }
        `), i.inputStyles.border.activeColor || i.focusColor),
                        style: {
                            alignSelf: "flex-end",
                            display: "block"
                        },
                        a11yIdentifier: r
                    }, a().createElement(x.Z, {
                        a11yIdentifier: r,
                        id: g,
                        theme: i,
                        style: {
                            marginRight: 8,
                            marginBottom: 8
                        },
                        showLabel: !(void 0 !== u || !m) || u,
                        asLegend: !0
                    }, m), a().createElement(se, {
                        formVersionCId: n,
                        theme: i,
                        name: v,
                        label: p,
                        alignCheckbox: "flex-start",
                        isValid: !0,
                        componentType: o.OV,
                        componentAriaID: g,
                        onChange: t => {
                            (0, V.l)(), (0, _.hX)({
                                formVersionCId: n,
                                componentId: e,
                                value: t.target.checked.toString()
                            })
                        },
                        tabIndex: d ? -1 : 0,
                        a11yIdentifierStyles: r
                    })))
                },
                At = n(10431),
                Mt = n(36444),
                Bt = n(55092);
            const Dt = () => null,
                {
                    THEME_KEY: Nt
                } = Mt.default,
                jt = {
                    blue: "https://d3k81ch9hvuctc.cloudfront.net/assets/email/review-block/verified.png",
                    dark: "https://d3k81ch9hvuctc.cloudfront.net/assets/email/review-block/verified-dark.png",
                    light: "https://d3k81ch9hvuctc.cloudfront.net/assets/email/review-block/verified-light.png"
                },
                Rt = e => "center" === e ? "center" : "right" === e ? "flex-end" : "flex-start";
            var Pt = ({
                componentId: e,
                theme: t,
                a11yIdentifierBlock: n
            }) => {
                var o, i, r, s, d, c, m, u, p, h, v, g, y, I, b, S, w, C, x;
                const E = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    _ = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.reviewData
                    })),
                    k = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.reviewDisplayOptions
                    })),
                    V = !!_,
                    T = null != (o = null == _ ? void 0 : _.rating) ? o : 5,
                    $ = null != (i = null == _ ? void 0 : _.content) ? i : "",
                    Z = (null == _ ? void 0 : _.author) || "",
                    F = "stacked" === (null == (r = t[Nt].reviewerNameStyle) ? void 0 : r.layout),
                    O = !F && Z ? `- ${Z}` : Z,
                    A = null != (s = null == _ ? void 0 : _.verified) && s,
                    M = null == (d = null == k ? void 0 : k.showRating) || d,
                    B = null == (c = null == k ? void 0 : k.showAuthor) || c,
                    D = null == (m = null == k ? void 0 : k.showVerified) || m,
                    N = {
                        color: t[Nt].ratingStyle.color,
                        fontSize: t[Nt].ratingStyle.fontSize
                    },
                    j = {
                        color: t[Nt].ratingStyle.emptyColor,
                        fontSize: t[Nt].ratingStyle.fontSize
                    },
                    R = (e => {
                        switch (e) {
                            case Bt.B.STAR:
                                return "★";
                            case Bt.B.HEART:
                                return "♥";
                            case Bt.B.CIRCLE:
                                return "●";
                            default:
                                return "★"
                        }
                    })(t[Nt].ratingStyle.shape),
                    P = () => {
                        var e;
                        return a().createElement("span", {
                            "data-a11y-identifier": n,
                            style: {
                                color: null == (e = t[Nt].reviewerNameStyle) ? void 0 : e.textColor,
                                display: "inline-flex",
                                alignItems: "center",
                                gap: "4px"
                            }
                        }, a().createElement("span", {
                            "data-a11y-identifier": n
                        }, O), A && D && a().createElement("img", {
                            "data-a11y-identifier": n,
                            src: jt[t[Nt].verifiedBadgeStyle.colorAsset],
                            alt: "Verified",
                            style: {
                                width: t[Nt].verifiedBadgeStyle.size,
                                height: t[Nt].verifiedBadgeStyle.size
                            }
                        }))
                    };
                return E && !V ? a().createElement(Dt, null) : a().createElement(l.ZC, {
                    a11yIdentifier: n,
                    "data-testid": "reviews-component",
                    style: {
                        alignItems: "center",
                        justifyContent: "center",
                        width: "100%",
                        height: "auto"
                    }
                }, M && a().createElement("div", {
                    "data-a11y-identifier": n,
                    style: {
                        display: "flex",
                        justifyContent: Rt(t[Nt].ratingStyle.alignment),
                        gap: `${t[Nt].ratingStyle.characterSpacing}px`,
                        marginBottom: "12px"
                    }
                }, a().createElement("span", {
                    "data-a11y-identifier": n,
                    style: T >= 1 ? N : j
                }, R), a().createElement("span", {
                    style: T >= 2 ? N : j
                }, R), a().createElement("span", {
                    style: T >= 3 ? N : j
                }, R), a().createElement("span", {
                    style: T >= 4 ? N : j
                }, R), a().createElement("span", {
                    "data-a11y-identifier": n,
                    style: T >= 5 ? N : j
                }, R)), a().createElement("div", {
                    style: {
                        marginBottom: "8px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: Rt(F ? t[Nt].quoteStyle.alignment : null == (u = t[Nt].reviewerNameStyle) ? void 0 : u.alignment),
                        gap: "8px",
                        flexDirection: F ? "column" : "row",
                        width: "100%"
                    }
                }, F ? a().createElement(a().Fragment, null, a().createElement("span", {
                    style: {
                        fontFamily: t[Nt].quoteStyle.fontFamily,
                        fontSize: t[Nt].quoteStyle.fontSize,
                        color: t[Nt].quoteStyle.textColor,
                        letterSpacing: `${t[Nt].quoteStyle.characterSpacing}px`,
                        fontWeight: t[Nt].quoteStyle.fontWeight,
                        lineHeight: t[Nt].quoteStyle.lineHeight,
                        display: "block",
                        width: "100%",
                        textAlign: t[Nt].quoteStyle.alignment
                    }
                }, a().createElement("span", {
                    "data-a11y-identifier": n
                }, "“", $, "”")), B && Z && a().createElement("div", {
                    style: {
                        display: "flex",
                        alignItems: "center",
                        justifyContent: Rt(null == (p = t[Nt].reviewerNameStyle) ? void 0 : p.alignment),
                        gap: "4px",
                        width: "100%",
                        lineHeight: null == (h = t[Nt].reviewerNameStyle) ? void 0 : h.lineHeight,
                        fontFamily: null == (v = t[Nt].reviewerNameStyle) ? void 0 : v.fontFamily,
                        fontSize: null == (g = t[Nt].reviewerNameStyle) ? void 0 : g.fontSize,
                        fontWeight: null == (y = t[Nt].reviewerNameStyle) ? void 0 : y.fontWeight,
                        letterSpacing: `${null==(I=t[Nt].reviewerNameStyle)?void 0:I.characterSpacing}px`
                    }
                }, P())) : a().createElement("span", {
                    style: {
                        fontFamily: t[Nt].quoteStyle.fontFamily,
                        fontSize: t[Nt].quoteStyle.fontSize,
                        color: t[Nt].quoteStyle.textColor,
                        letterSpacing: `${t[Nt].quoteStyle.characterSpacing}px`,
                        fontWeight: t[Nt].quoteStyle.fontWeight,
                        lineHeight: t[Nt].quoteStyle.lineHeight,
                        display: "block",
                        width: "100%",
                        textAlign: t[Nt].quoteStyle.alignment
                    }
                }, a().createElement("span", {
                    "data-a11y-identifier": n
                }, "“", $, "”"), B && Z && a().createElement("span", {
                    style: {
                        display: "inline",
                        lineHeight: null == (b = t[Nt].reviewerNameStyle) ? void 0 : b.lineHeight,
                        fontFamily: null == (S = t[Nt].reviewerNameStyle) ? void 0 : S.fontFamily,
                        fontSize: null == (w = t[Nt].reviewerNameStyle) ? void 0 : w.fontSize,
                        fontWeight: null == (C = t[Nt].reviewerNameStyle) ? void 0 : C.fontWeight,
                        letterSpacing: `${null==(x=t[Nt].reviewerNameStyle)?void 0:x.characterSpacing}px`
                    }
                }, " ", P()))))
            };
            var zt = (e, t = (() => a().createElement(a().Fragment, null))) => {
                function n(n) {
                    const [o, i] = a().useState(0), r = a().useCallback((() => i((e => e < 5 ? e + 1 : e))), []), s = a().useMemo((() => a().lazy((() => e().catch((() => ({
                        default: () => (r(), a().createElement(a().Fragment, null))
                    })))))), [e, o]);
                    return a().createElement(a().Suspense, {
                        fallback: a().createElement(t, null)
                    }, a().createElement(s, n))
                }
                return n.displayName = "LazyLoader", n
            };
            const Ht = {
                [o.Ct]: g,
                [o.jR]: G,
                [o.qn]: M,
                [o.xC]: M,
                [o.J8]: zt((() => Promise.all([n.e(2462), n.e(9734), n.e(4371), n.e(6908)]).then(n.bind(n, 59643)))),
                [o.YQ]: R,
                [o.zV]: ue,
                [o.hD]: ue,
                [o.ZW]: M,
                [o.UO]: zt((() => Promise.all([n.e(2462), n.e(9734), n.e(4983)]).then(n.bind(n, 60761)))),
                [o.B1]: Le,
                [o.Xe]: Je,
                [o.Ys]: M,
                [o._2]: Vt,
                [o.eC]: M,
                [o.rY]: Tt,
                [o.OV]: Ot,
                [o.sZ]: Ot,
                [o.K0]: At.ZP,
                [o.SO]: R,
                [o.ye]: Pt
            }
        },
        3440: function(e, t, n) {
            var o = n(67895),
                i = n.n(o),
                r = n(5645),
                s = n.n(r),
                a = n(18359),
                l = n.n(a),
                d = n(24567);
            const c = ["children", "theme", "showLabel", "style", "asLegend"];
            t.Z = e => {
                let {
                    children: t,
                    theme: n,
                    showLabel: o,
                    style: r,
                    asLegend: a
                } = e, m = s()(e, c);
                if (!t) return null;
                const u = a ? d.De : d.__;
                return l().createElement(u, i()({
                    className: o ? "" : "klaviyo-sr-only",
                    style: Object.assign({
                        color: n.inputStyles.textStyles.color,
                        fontFamily: n.inputStyles.textStyles.fontFamily,
                        fontSize: n.inputStyles.textStyles.fontSize,
                        fontWeight: n.inputStyles.textStyles.labelFontWeight,
                        letterSpacing: n.inputStyles.textStyles.letterSpacing,
                        paddingBottom: 6
                    }, r)
                }, m), t)
            }
        },
        10431: function(e, t, n) {
            n.d(t, {
                Rd: function() {
                    return _
                }
            });
            n(92461), n(39265), n(60873), n(83362);
            var o = n(18359),
                i = n.n(o),
                r = n(23409),
                s = n(20152),
                a = n(24567),
                l = n(57829),
                d = n(72397),
                c = n(46458),
                m = n(51163);
            let u, f, p, h, v, g, y, I, b, S, w, C, x = e => e;
            const E = 1e3,
                _ = 8e3,
                k = e => {
                    let t = 0;
                    e > 75 ? t = 270 : e > 50 ? t = 180 : e > 25 && (t = 90);
                    const n = 3.6 * e - t,
                        o = (90 - n) * (Math.PI / 180),
                        i = 50 * Math.sin(o),
                        r = n * (Math.PI / 180),
                        s = 50 * Math.sin(r);
                    let a = `\n    50% 50%,\n    50% 0%,\n    100% 0%,\n    ${e<=25?`${50+s}% ${50-i}%`:"100% 50%"}\n  `;
                    return e > 25 && (a = `${a},\n      100% 100%,\n      ${e<=50?`${50+i}% ${50+s}%`:"50% 100%"}\n    `), e > 50 && (a = `${a},\n      0% 100%,\n      ${e<=75?`${50-s}% ${50+i}%`:"0% 100%"}\n    `), e > 75 && (a = `${a},\n      0% 0%,\n      ${e<=100?`${50-i}% ${50-s}%`:"50% 0%"}\n    `), `polygon(${a})`
                };
            t.ZP = ({
                componentId: e,
                a11yIdentifierBlock: t
            }) => {
                const n = (0, l.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.wheelLogic
                    })),
                    _ = (0, l.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.wheelStyle
                    })),
                    V = (0, l.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.sliceStyles
                    })) || [],
                    T = (0, l.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.textStyle
                    })),
                    $ = (0, o.useMemo)((() => {
                        let e = [];
                        return e = null != n && n.duplicate ? null != n && n.slices ? [...null == n ? void 0 : n.slices, ...null == n ? void 0 : n.slices] : [] : null != n && n.slices ? [...n.slices] : [], e.map(((e, t) => Object.assign({}, e, {
                            key: `slice_${t}`
                        })))
                    }), [n]),
                    Z = (0, l.Z)((t => {
                        var n;
                        const o = (0, c.Hp)(t, e);
                        if (!o) return null;
                        const i = null == (n = t.formsState.views[o]) ? void 0 : n.formVersionId;
                        return i ? (0, m.Tf)(t, i) : null
                    })),
                    F = (0, l.Z)((e => Z ? (0, d.L)(e, Z) : "")),
                    O = (0, o.useMemo)((() => null != n && n.slices && F ? n.slices.find((e => e.childViewId === F)) : null), [n, F]),
                    A = (0, o.useMemo)((() => {
                        if (!O) return null;
                        const e = ((e, t) => {
                            const n = ((e, t) => e.reduce(((e, n, o) => (n.childViewId === t && e.push(o), e)), []))(e, t);
                            return n.length ? n[Math.floor(Math.random() * n.length)] : null
                        })($, O.childViewId);
                        if ((0, s.x)(e)) return null;
                        const {
                            anticipation: t,
                            acceleration: n,
                            deceleration: o,
                            overshoot: i
                        } = ((e, t) => {
                            const n = 360 / t,
                                o = e * n,
                                i = (e => 90 - 360 / e / 2)(t),
                                s = i - o + 3240,
                                a = s - (Math.floor(Math.random() * n / 2) - n / 2) + 720;
                            return {
                                anticipation: (0, r.F4)(u || (u = x `
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(-8deg);
      }
    `)),
                                acceleration: (0, r.F4)(f || (f = x `
      0% {
        transform: rotate(-8deg);
      }
      100% {
        transform: rotate(${0}deg);
      }
    `), s),
                                deceleration: (0, r.F4)(p || (p = x `
      0% {
        transform: rotate(${0}deg);
      }
      100% {
        transform: rotate(${0}deg);
      }
    `), s, a),
                                overshoot: (0, r.F4)(h || (h = x `
      0% {
        transform: rotate(${0}deg);
      }
      100% {
        transform: rotate(${0}deg);
      }
    `), a, a - 4)
                            }
                        })(e, $.length);
                        return `${t} 500ms cubic-bezier(0.35, 0, 0.50, 1) forwards,\n            ${n} 2750ms cubic-bezier(0.36, 0, 0.52, 0.70) 500ms forwards,\n            ${o} 3000ms cubic-bezier(0.3, 0.8, 0.5, 0.99) 3250ms forwards,\n            ${i} 1000ms cubic-bezier(0.75, 0.2, 0.67, 1) 6250ms forwards`
                    }), [O, $]),
                    M = (0, o.useMemo)((() => {
                        var e, t;
                        let n = null != (e = null == _ ? void 0 : _.wheelSize) ? e : 400,
                            o = n / 2,
                            i = n / 5,
                            s = n / 5;
                        n > E && (n = E, o = 500, i = 200, s = 200);
                        let a = null != (t = null == _ ? void 0 : _.outlineThickness) ? t : 0;
                        return a > 100 && (a = 100), {
                            container: (0, r.iv)(v || (v = x `
        &&& {
          & {
            position: relative;
            width: ${0}px;
            height: ${0}px;
            display: flex;
            justify-content: center;
            align-items: center;
          }
        }
      `), n, n + a),
                            innerContainer: (0, r.iv)(g || (g = x `
        &&& {
          & {
            width: ${0}px;
            height: ${0}px;
            display: flex;
            justify-content: center;
            align-items: center;
            ${0};
          }
        }
      `), n, n, A ? `@media (prefers-reduced-motion: no-preference) {\n                  animation: ${A};\n                }` : ""),
                            slice: (0, r.iv)(y || (y = x `
        &&& {
          & {
            position: absolute;
            width: ${0}px;
            height: ${0}px;
            transform-origin: center;
            border-radius: 50%;
            border: ${0}px solid ${0};
          }
        }
      `), n, n, a, null == _ ? void 0 : _.outlineColor),
                            sliceLabelContainer: (0, r.iv)(I || (I = x `
        &&& {
          & {
            width: ${0}px;
            margin: 0 auto;
            transform: rotate(-90deg) translate(-80px);
            transform-origin: center;
          }
        }
      `), o),
                            sliceLabel: (0, r.iv)(b || (b = x `
        &&& {
          & {
            text-align: center;
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
            transform: rotate(${0}deg);
            transform-origin: left;
            padding-left: 20px;
            text-overflow: ellipsis;
            overflow: hidden;
          }
        }
      `), null == T ? void 0 : T.fontFamily, null == T ? void 0 : T.fontSize, null == T ? void 0 : T.fontWeight, 180 / $.length),
                            center: (0, r.iv)(S || (S = x `
        &&& {
          & {
            position: absolute;
            width: ${0}px;
            height: ${0}px;
            background-color: ${0};
            border-radius: 50%;
            display: flex;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2),
              0 6px 20px 0 rgba(0, 0, 0, 0.2);
          }
        }
      `), i, i, null == _ ? void 0 : _.centerColor),
                            pin: (0, r.iv)(w || (w = x `
        &&& {
          & {
            position: absolute;
            right: 1px;
            width: ${0}px;
            height: ${0}px;
            background-color: ${0};
            clip-path: polygon(100% 0%, 50% 50%, 100% 100%);
            border-radius: 20%;
            display: flex;
          }
        }
      `), s, s, null == _ ? void 0 : _.pinColor),
                            pinOutline: (0, r.iv)(C || (C = x `
        &&& {
          & {
            position: absolute;
            width: ${0}px;
            height: ${0}px;
            border-radius: 49%;
            display: flex;
            background: radial-gradient(
              circle at center,
              transparent 69%,
              ${0} 25%
            );
          }
        }
      `), n, n, null == _ ? void 0 : _.pinColor)
                        }
                    }), [_, T, $, A]);
                return i().createElement(a.ZC, {
                    className: "klaviyo-spintowin",
                    a11yIdentifier: t,
                    "data-testid": "klaviyo-spintowin",
                    style: {
                        width: "100%",
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "flex"
                    }
                }, i().createElement(a.ZC, {
                    className: M.container,
                    a11yIdentifier: t
                }, i().createElement(a.ZC, {
                    className: M.innerContainer,
                    a11yIdentifier: t
                }, $.map(((e, n) => {
                    var o, r;
                    return i().createElement(a.ZC, {
                        key: e.key,
                        className: M.slice,
                        a11yIdentifier: t,
                        style: {
                            clipPath: k(100 / $.length),
                            transform: `rotate(${n*(360/$.length)}deg)`,
                            backgroundColor: null == (o = V[n % V.length]) ? void 0 : o.backgroundColor
                        }
                    }, i().createElement(a.ZC, {
                        className: M.sliceLabelContainer,
                        a11yIdentifier: t
                    }, i().createElement(a.ZC, {
                        className: M.sliceLabel,
                        a11yIdentifier: t,
                        style: {
                            color: null == (r = V[n % V.length]) ? void 0 : r.textColor
                        }
                    }, e.label)))
                }))), i().createElement(a.ZC, {
                    className: M.center,
                    a11yIdentifier: t
                }), i().createElement(a.ZC, {
                    className: M.pin,
                    a11yIdentifier: t
                }), i().createElement(a.ZC, {
                    className: M.pinOutline,
                    a11yIdentifier: t
                })))
            }
        },
        53610: function(e, t, n) {
            var o = n(18359),
                i = n.n(o),
                r = n(23409),
                s = n(24567),
                a = n(64618),
                l = n(69829),
                d = n(23570),
                c = n(64466),
                m = n(34779),
                u = n(74192),
                f = n(57829);
            let p, h = e => e;
            t.Z = ({
                formVersionCId: e,
                validationErrorType: t,
                validationErrorMessage: n,
                metadata: o,
                componentAriaID: v,
                theme: g,
                a11yIdentifier: y
            }) => {
                const I = (0, f.Z)((t => {
                        var n;
                        const o = t.onsiteState.openFormVersions[e];
                        return o ? null == (n = t.formsState.formVersions[o.formVersionId]) ? void 0 : n.formTypeDirection : void 0
                    })),
                    b = !(null == I || !I.startsWith("BOTTOM")),
                    S = g.inputStyles.textStyles.errorColor;
                return i().createElement(s.ZC, {
                    style: {
                        width: "100%",
                        position: "relative"
                    },
                    a11yIdentifier: y
                }, t && i().createElement(s.ZC, {
                    a11yIdentifier: y,
                    style: Object.assign({
                        backgroundColor: "white",
                        position: "absolute",
                        zIndex: 1,
                        right: 0,
                        borderRadius: 4,
                        animation: "klaviyo-fadein 0.4s",
                        pointerEvents: "none"
                    }, b ? {
                        bottom: 47
                    } : {
                        top: 9
                    })
                }, i().createElement(s.ZC, {
                    a11yIdentifier: y,
                    className: (0, r.iv)(p || (p = h `
              &&& {
                &::after {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  border-style: solid;
                  left: 8px;
                  border-width: 8px;
                  ${0}
                }
                &::before {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  border-style: solid;
                  border-width: 9px;
                  left: 7px;
                  ${0};
                }
              }
            `), b ? "bottom: -15px;\n                  border-color: rgb(255, 244, 240) transparent transparent transparent;" : "top: -15px;\n                  border-color: transparent transparent rgb(255, 244, 240) transparent;", b ? `bottom: -17px;\n                    border-color: ${S} transparent transparent transparent;` : `top: -17px;\n                    border-color: transparent transparent ${S} transparent;`),
                    style: {
                        borderRadius: 4,
                        boxShadow: "1px 1px 4px 0 rgba(0, 0, 0, 0.26)",
                        border: `1px solid ${g.inputStyles.textStyles.errorColor}`,
                        backgroundColor: "rgb(255, 244, 240)",
                        pointerEvents: "none"
                    }
                }, i().createElement(s.Dr, {
                    style: {
                        fontSize: 14,
                        padding: 8,
                        fontFamily: g.inputStyles.textStyles.fontFamily,
                        color: g.inputStyles.textStyles.errorColor,
                        pointerEvents: "none"
                    },
                    role: "alert",
                    id: v,
                    a11yIdentifier: y
                }, (({
                    validationErrorType: e,
                    validationErrorMessage: t,
                    metadata: n
                }) => {
                    if (t) return t;
                    switch (e) {
                        case a.d:
                            return "This field is required";
                        case l.d:
                            return "This email is invalid";
                        case d.d:
                            return "The date format is invalid";
                        case c.d:
                            return n ? `Must be ${n.smsMinimumAge||21} or older.` : "";
                        case m.d:
                            return "This number is invalid";
                        case u.pv:
                            return "This code is invalid";
                        default:
                            return ""
                    }
                })({
                    validationErrorType: t,
                    validationErrorMessage: n,
                    metadata: o
                })))))
            }
        },
        61391: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return C
                }
            });
            var o = n(67895),
                i = n.n(o),
                r = n(18359),
                s = n.n(r),
                a = n(62945),
                l = n(23409),
                d = n(23034),
                c = n(57829),
                m = n(24567),
                u = n(68216),
                f = n(77156),
                p = n(76166),
                h = n(58423),
                v = n(51163),
                g = n(69299);
            let y, I = e => e;
            const b = () => null,
                S = {
                    right: 0,
                    top: 0
                },
                w = g.Z;
            var C = ({
                title: e,
                onClick: t,
                viewId: n,
                buttonStyling: o,
                positionalStyles: g = S,
                isTeaser: C = !1,
                designerFunctions: x,
                designerInfo: E
            }) => {
                const _ = (0, c.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    k = (0, c.Z)((e => {
                        if (n) return (0, v.l)(e, n)
                    }), d.X),
                    [V, T] = (0, r.useState)(!1),
                    $ = null == E ? void 0 : E.activeSidebar,
                    Z = (0, r.useMemo)((() => (null == $ ? void 0 : $.type) === p.cn || (null == $ ? void 0 : $.type) === p.iy), [$]),
                    F = C ? p.iy : p.cn,
                    O = () => {
                        x && x.setActiveSidebar({
                            type: F
                        })
                    },
                    A = C ? h.Z.dismissButtonStyles : u.Z.dismissButtonStyles,
                    M = (0, a.Z)({}, A, o),
                    B = M.size,
                    D = V || Z,
                    N = g === S,
                    j = (0, r.useMemo)((() => _ ? "dismiss:dismiss:form" : void 0), [_]),
                    R = (0, c.Z)(v.ek);
                return s().createElement(s().Fragment, null, D && s().createElement(b, {
                    size: B,
                    isSelected: Z,
                    $margin: N ? M.margin : {},
                    positionalStyles: g,
                    closeButton: !0
                }), s().createElement(w, {
                    isIAMEditor: R,
                    componentId: p.cn,
                    readonly: !0
                }, (n => s().createElement(m.CI, i()({
                    dndElProps: n,
                    a11yIdentifier: j,
                    width: B,
                    height: B,
                    tabIndex: 0,
                    alt: "Close dialog",
                    style: Object.assign({}, g, {
                        position: "absolute",
                        zIndex: 6,
                        cursor: "pointer",
                        height: `${B}px`,
                        width: `${B}px`,
                        borderRadius: "50%"
                    }, N && {
                        marginRight: `${M.margin.right}px`,
                        marginTop: `${M.margin.top}px`
                    }),
                    className: `${_?"":"klaviyo-close-form"} ${(0,l.iv)(y||(y=I`
              &&& {
                &:focus-visible {
                  outline-width: 2px;
                  outline-style: auto;
                  outline-color: ${0};
                  outline-offset: 0;
                }
              }
            `),(null==k?void 0:k.focusColor)||f.Z.theme.focusColor)}`,
                    viewBox: "0 0 20 20",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    onClick: t,
                    "aria-label": e,
                    "aria-hidden": "true"
                }, _ && !R && {
                    onClick: O,
                    onMouseOver: () => {
                        T(!0)
                    },
                    onMouseLeave: () => T(!1)
                }), s().createElement("title", {
                    id: `title-${e.split(" ").join("-")}`
                }, e), s().createElement("circle", {
                    style: {
                        cursor: "pointer"
                    },
                    cx: "10",
                    cy: "10",
                    r: "9.5",
                    fill: M.backgroundColor,
                    stroke: M.borderColor
                }), s().createElement("path", {
                    style: {
                        cursor: "pointer"
                    },
                    d: "M6 6L14 14M6 14L14 6L6 14Z",
                    stroke: M.xColor,
                    strokeWidth: M.xStroke,
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                })))))
            }
        },
        65047: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return me
                }
            });
            var o = n(67895),
                i = n.n(o),
                r = (n(92461), n(39265), n(18359)),
                s = n.n(r),
                a = n(23409),
                l = n(23034),
                d = n(22314),
                c = n(65916);
            var m = () => (0, d.Z)() && !window.klaviyoForceMobile && window.screen.availHeight < window.screen.availWidth,
                u = n(38799);
            var f = (e, t) => {
                    var n, o, i;
                    let r = e.formType === u.nq && [u.Gi, u.qK].includes(null == (n = e.data) || null == (n = n.flyoutOptions) ? void 0 : n.docking);
                    m() && (r = !1);
                    let s = e.formTypeDirection || null;
                    var a;
                    r && t && (s = (null == (a = e.data) || null == (a = a.flyoutOptions) ? void 0 : a.docking) === u.Gi ? u.DA : u.qS);
                    return {
                        isDocked: r && t,
                        evaluatedFormTypeDirection: s,
                        dockedDirection: (null == (o = e.data) || null == (o = o.flyoutOptions) ? void 0 : o.docking) === u.kW || null == (i = e.data) || null == (i = i.flyoutOptions) ? void 0 : i.docking
                    }
                },
                p = n(21623),
                h = n(77156),
                v = n(76166),
                g = n(82874),
                y = n(69914),
                I = n(80101),
                b = n(12083),
                S = n.n(b),
                w = n(46753),
                C = n(29676),
                x = n(57829),
                E = n(24567),
                _ = n(74872),
                k = n(40910);

            function V() {
                return V = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, V.apply(null, arguments)
            }
            var T, $, Z, F = function(e) {
                return r.createElement("svg", V({
                    width: 160,
                    height: 24,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), r.createElement("path", {
                    d: "M0 4a4 4 0 0 1 4-4h152a4 4 0 0 1 4 4v20H0V4Z",
                    fill: "#373D44",
                    style: {
                        fill: "color(display-p3 .2157 .2392 .2667)",
                        fillOpacity: 1
                    }
                }), r.createElement("path", {
                    d: "M25.109 16.183c-.702 0-1.309-.165-1.82-.495-.513-.329-.909-.796-1.188-1.401-.276-.606-.413-1.324-.413-2.154v-.01c0-.835.137-1.555.413-2.16.28-.605.673-1.073 1.182-1.402.512-.33 1.119-.494 1.82-.494.545 0 1.039.107 1.483.322.448.211.816.507 1.106.886.29.376.473.811.548 1.306l-.005.01h-.972l-.006-.01a2.123 2.123 0 0 0-.435-.86 2.074 2.074 0 0 0-.746-.564 2.313 2.313 0 0 0-.973-.198c-.494 0-.923.128-1.289.386-.361.258-.64.623-.837 1.096-.197.473-.296 1.033-.296 1.681v.01c0 .645.099 1.204.296 1.677.197.472.476.838.837 1.095.366.258.797.387 1.295.387.361 0 .69-.057.983-.172.293-.118.54-.284.741-.5.2-.218.34-.476.419-.773l.01-.01h.978v.01a2.673 2.673 0 0 1-.558 1.236c-.287.347-.65.617-1.09.81-.438.194-.932.29-1.483.29ZM29.744 16v-5.79h.935v.86h.086c.11-.305.299-.541.564-.71.265-.168.592-.252.983-.252.089 0 .177.005.263.016.09.007.157.014.204.021v.908a2.713 2.713 0 0 0-.285-.037 2.45 2.45 0 0 0-.29-.017c-.297 0-.56.06-.79.178-.229.118-.41.283-.542.494a1.395 1.395 0 0 0-.193.741V16h-.935Zm6.392.102c-.552 0-1.026-.122-1.424-.365a2.418 2.418 0 0 1-.913-1.031c-.21-.448-.317-.974-.317-1.58v-.005c0-.598.106-1.123.317-1.574.215-.45.518-.804.908-1.058s.847-.381 1.37-.381c.526 0 .977.122 1.353.365.38.244.67.584.87 1.02.204.434.306.939.306 1.515v.366h-4.64v-.747h4.162l-.462.682v-.37c0-.455-.067-.83-.204-1.123a1.441 1.441 0 0 0-.564-.655 1.552 1.552 0 0 0-.827-.22c-.311 0-.59.076-.838.23-.243.15-.436.375-.58.672-.143.297-.215.662-.215 1.095v.371c0 .412.07.765.21 1.058.14.29.338.514.596.672.258.154.562.23.913.23.262 0 .489-.035.682-.107.194-.072.353-.163.478-.274.126-.11.213-.224.264-.338l.021-.049h.935l-.011.043a1.78 1.78 0 0 1-.269.575c-.125.183-.288.35-.488.5-.201.146-.44.265-.715.354a3.042 3.042 0 0 1-.918.13Zm5.51 0c-.365 0-.694-.07-.988-.21a1.703 1.703 0 0 1-.693-.596 1.633 1.633 0 0 1-.252-.913v-.01c0-.516.182-.919.548-1.209.369-.294.89-.46 1.563-.5l2.127-.128v.746l-2.014.13c-.44.024-.763.115-.967.273-.2.158-.301.38-.301.666v.01c0 .294.11.524.333.688.222.161.501.242.838.242.318 0 .601-.063.848-.188a1.49 1.49 0 0 0 .58-.521c.144-.218.215-.466.215-.741v-1.805c0-.358-.109-.63-.327-.816-.215-.19-.54-.285-.972-.285-.348 0-.632.063-.854.188a.909.909 0 0 0-.446.521l-.006.016h-.934l.005-.032c.05-.304.176-.57.376-.795.204-.23.467-.406.79-.532.322-.129.689-.193 1.1-.193.473 0 .873.077 1.199.23.329.155.578.377.746.667.172.286.258.63.258 1.031V16h-.935v-.854h-.085c-.122.204-.27.378-.446.521a1.844 1.844 0 0 1-.586.328 2.3 2.3 0 0 1-.72.107Zm6.537-.059c-.594 0-1.026-.12-1.294-.36-.265-.24-.398-.636-.398-1.187v-3.513h-.913v-.773h.913V8.711h.967v1.499h1.268v.773h-1.268v3.277c0 .34.065.585.193.736.13.146.344.22.645.22.082 0 .152-.002.21-.006.06-.003.134-.009.22-.016v.795c-.09.015-.18.027-.269.038-.09.01-.18.016-.274.016Zm4.227.06c-.551 0-1.026-.123-1.423-.366a2.418 2.418 0 0 1-.913-1.031c-.212-.448-.317-.974-.317-1.58v-.005c0-.598.105-1.123.317-1.574.215-.45.517-.804.907-1.058s.847-.381 1.37-.381c.526 0 .978.122 1.354.365.38.244.67.584.87 1.02.204.434.306.939.306 1.515v.366h-4.64v-.747h4.162l-.462.682v-.37c0-.455-.068-.83-.204-1.123a1.44 1.44 0 0 0-.564-.655 1.553 1.553 0 0 0-.827-.22c-.312 0-.591.076-.838.23-.244.15-.437.375-.58.672-.143.297-.215.662-.215 1.095v.371c0 .412.07.765.21 1.058.139.29.338.514.596.672.257.154.562.23.913.23.261 0 .488-.035.682-.107.193-.072.353-.163.478-.274.125-.11.213-.224.263-.338l.022-.049h.934l-.01.043c-.05.197-.14.389-.27.575-.125.183-.288.35-.488.5-.2.146-.439.265-.714.354a3.042 3.042 0 0 1-.919.13Zm6.059 0c-.487 0-.913-.125-1.279-.372a2.412 2.412 0 0 1-.848-1.041c-.2-.452-.301-.978-.301-1.58v-.01c0-.605.1-1.132.3-1.58.201-.447.482-.794.844-1.041.365-.248.793-.371 1.284-.371.397 0 .757.093 1.08.28.325.182.567.427.724.735h.086V7.911h.935V16h-.935v-.924h-.086a1.93 1.93 0 0 1-.73.758c-.312.178-.67.268-1.074.268Zm.215-.828c.35 0 .653-.088.907-.263.255-.176.45-.425.586-.747.136-.326.204-.71.204-1.155v-.01c0-.448-.068-.833-.204-1.155a1.668 1.668 0 0 0-.586-.747 1.559 1.559 0 0 0-.907-.263c-.351 0-.654.088-.908.263-.25.172-.444.42-.58.742-.133.322-.199.708-.199 1.16v.01c0 .448.066.835.199 1.16.136.323.33.572.58.747.254.172.557.258.908.258Zm8.615.725-1.622-5.79h.934l1.139 4.63h.086l1.294-4.63h.887l1.294 4.63h.086l1.139-4.63h.929L71.843 16h-.94l-1.295-4.48h-.086L68.233 16H67.3Zm7.423 0v-5.79h.934V16h-.934Zm.472-6.907a.633.633 0 0 1-.456-.188.633.633 0 0 1-.188-.457c0-.179.063-.331.188-.456a.633.633 0 0 1 .456-.188c.18 0 .332.062.457.188a.622.622 0 0 1 .188.456.633.633 0 0 1-.188.457.622.622 0 0 1-.457.188Zm4.281 6.95c-.594 0-1.026-.12-1.294-.36-.265-.24-.398-.636-.398-1.187v-3.513h-.913v-.773h.913V8.711h.967v1.499h1.268v.773H78.75v3.277c0 .34.064.585.193.736.13.146.344.22.645.22.082 0 .152-.002.21-.006.06-.003.134-.009.22-.016v.795c-.09.015-.18.027-.269.038-.09.01-.18.016-.274.016ZM81.468 16V7.911h.934v3.17h.086c.147-.309.358-.547.634-.715.276-.172.627-.258 1.053-.258.433 0 .8.084 1.1.252.302.165.53.407.688.725.158.32.237.708.237 1.166V16h-.935v-3.523c0-.523-.11-.91-.333-1.16-.218-.255-.558-.382-1.02-.382-.308 0-.575.066-.8.199-.226.132-.402.32-.527.564a1.938 1.938 0 0 0-.183.875V16h-.934ZM117.901 7c0-.267.102-.524.285-.715a.984.984 0 0 1 .691-.307 1 1 0 0 1 .705.304c.187.192.294.452.297.723a1.033 1.033 0 0 1-.303.708.97.97 0 0 1-1.388-.007 1.02 1.02 0 0 1-.287-.706Zm7.78 2.168c.472 0 .782.271.782.861 0 .332-.133.89-.413 1.677a85.436 85.436 0 0 0-1.209 3.638c-.191-.663-.56-1.721-1.016-2.932l-.391-1.115c-.221-.619-.34-1.102-.34-1.42 0-.438.207-.684.605-.724v-.196h-3.349v.196c.457.045.825.483 1.311 1.813l2.122 5.753c.281.755.251 1.434-.088 2.053-.251.544-.589.815-1.002.815-.515 0-.782-.226-.782-.695 0-.18.34-.543.34-.89 0-.483-.368-.71-.781-.71-.573 0-.954.408-.954 1.026.014.907.763 1.677 1.768 1.677.516.045.929-.227 1.208-.468.178-.136.398-.604.516-.83.09-.18.164-.367.221-.56.104-.257.163-.468.207-.604.043-.136.132-.362.235-.71l.236-.77a91.748 91.748 0 0 1 1.812-5.285c.34-.86.778-1.369.999-1.48.12-.065.248-.11.382-.135v-.196h-2.416l-.003.21ZM102.42 16.31c-.428-.075-.796-.468-.796-1.299V5l-2.432.544v.21c.413-.044.826.333.826 1.134v8.124c0 .782-.413 1.239-.826 1.3a1.271 1.271 0 0 1-.732-.097 1.857 1.857 0 0 1-.83-.794l-1.125-1.845a2.082 2.082 0 0 0-1.005-.852 2.022 2.022 0 0 0-1.302-.067l1.266-1.435c.96-1.087 1.843-1.783 2.683-2.069v-.196H95.36v.196c.722.286.679.921-.147 1.918l-1.782 2.13V5L91 5.544v.21c.413 0 .825.424.825 1.164v8.094c0 .892-.398 1.239-.825 1.3v.195h3.227v-.196c-.53-.075-.795-.498-.795-1.299v-1.495l.692-.782 1.68 2.824c.398.684.763.95 1.356.95h5.603v-.154s-.156-.014-.343-.044Zm7.48.024v.195s-1.654.612-2.154-.424a2.14 2.14 0 0 1-.209-.88c-.456.966-1.458 1.48-2.402 1.48-1.193 0-2.048-.574-2.048-1.827.001-.315.093-.623.266-.885.353-.543.763-.83 1.533-1.132.381-.151.706-.257.953-.332.248-.075.573-.152.954-.227l.737-.18v-.911c0-1.51-.634-2.19-1.518-2.19-.692 0-1.09.468-1.09 1.012 0 .302.206.74.206 1.057 0 .423-.368.725-.884.725-.486 0-.781-.408-.781-.951 0-.56.265-1.042.81-1.467a2.903 2.903 0 0 1 1.828-.634c2.068 0 2.972 1.006 3.004 3.214v3.371c.011.22.071 1.104.795.986Zm-2.363-3.991c-.088.046-.294.121-.633.257l-.678.257c-.17.08-.295.15-.545.287a1.807 1.807 0 0 0-.516.377 1.714 1.714 0 0 0-.412 1.042c0 .892.471 1.375 1.193 1.375.369 0 .722-.152 1.061-.438.354-.288.53-.695.53-1.193v-1.964Zm27.283.391a4.01 4.01 0 0 1-.277 1.521c-.19.483-.473.923-.83 1.293-.339.367-.748.66-1.201.86a3.547 3.547 0 0 1-2.868 0 3.627 3.627 0 0 1-1.2-.86 4.02 4.02 0 0 1-1.091-2.816 3.997 3.997 0 0 1 .272-1.511c.188-.48.466-.918.82-1.287a3.585 3.585 0 0 1 1.197-.872 3.515 3.515 0 0 1 2.875 0c.453.203.86.5 1.197.872.358.366.641.803.832 1.284.19.48.284.995.275 1.514l-.001.002Zm-2.409-2.675c-.291-.586-.676-.926-1.124-1.018-.912-.188-1.717.772-2.018 2.299a7.36 7.36 0 0 0-.095 2.08 5.85 5.85 0 0 0 .556 1.997c.292.586.676.927 1.125 1.018.912.19 1.741-.813 2.043-2.355.257-1.29.129-2.86-.487-4.02Zm-12.679 4.952V8.957h-5.187v.181c.693.106 1.022.642.707 1.51-1.622 4.516-1.518 4.313-1.622 4.675-.103-.347-.338-1.202-.722-2.274-.383-1.072-.635-1.781-.731-2.1-.397-1.252-.265-1.72.382-1.796v-.196h-3.364v.196c.502.106.944.695 1.312 1.752l.516 1.375c.567 1.484 1.233 3.534 1.456 4.228h1.117c.36-1.076 1.802-5.363 1.995-5.8.208-.496.444-.873.708-1.133a1.48 1.48 0 0 1 1.001-.428s.81-.036.81.802v5.063c0 .847-.398 1.239-.81 1.3v.195h3.212v-.196c-.427-.06-.78-.452-.78-1.299ZM140 5h-5.638v3.957H140l-1.112-1.978L140 5Z",
                    fill: "#fff",
                    style: {
                        fill: "#fff",
                        fillOpacity: 1
                    }
                }))
            };

            function O() {
                return O = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, O.apply(null, arguments)
            }
            var A = function(e) {
                    return r.createElement("svg", O({
                        width: 160,
                        height: 24,
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, e), T || (T = r.createElement("path", {
                        d: "M0 0h160v22a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V0Z",
                        fill: "#373F47"
                    })), $ || ($ = r.createElement("path", {
                        d: "M24.728 15.144c1.416 0 2.376-.672 3.048-1.596l-.84-.456a2.723 2.723 0 0 1-2.208 1.164c-1.752 0-3.084-1.356-3.084-3.252 0-1.92 1.332-3.252 3.084-3.252.912 0 1.752.48 2.208 1.164l.828-.468c-.636-.912-1.62-1.584-3.036-1.584-2.304 0-4.116 1.68-4.116 4.14s1.812 4.14 4.116 4.14ZM29.909 15v-4.104c.264-.468 1.02-.924 1.584-.924.132 0 .24.012.348.024v-.924c-.792 0-1.464.456-1.932 1.056v-.924h-.9V15h.9Zm5.69.144c.935 0 1.715-.324 2.303-.9l-.432-.588a2.522 2.522 0 0 1-1.8.744c-1.248 0-2.004-.912-2.076-2.004h4.68v-.228c0-1.74-1.032-3.108-2.784-3.108-1.656 0-2.856 1.356-2.856 3.036 0 1.812 1.236 3.048 2.964 3.048Zm1.787-3.42h-3.804c.048-.876.66-1.92 1.896-1.92 1.32 0 1.896 1.068 1.908 1.92ZM44.256 15v-3.984c0-1.404-1.008-1.956-2.244-1.956-.948 0-1.692.312-2.316.96l.42.624c.516-.564 1.08-.804 1.776-.804.84 0 1.464.444 1.464 1.212v1.044c-.468-.528-1.128-.78-1.92-.78-.984 0-2.016.6-2.016 1.908 0 1.26 1.044 1.92 2.016 1.92.78 0 1.452-.276 1.92-.804V15h.9Zm-2.484-.504c-.852 0-1.44-.528-1.44-1.272 0-.732.588-1.26 1.44-1.26.624 0 1.236.24 1.584.708v1.104c-.348.48-.96.72-1.584.72Zm5.776.648c.516 0 .84-.156 1.068-.372l-.264-.684a.852.852 0 0 1-.612.252c-.384 0-.576-.312-.576-.744v-3.6h1.176v-.792h-1.176V7.62h-.912v1.584h-.96v.792h.96v3.792c0 .864.432 1.356 1.296 1.356Zm4.68 0c.935 0 1.715-.324 2.303-.9l-.432-.588a2.522 2.522 0 0 1-1.8.744c-1.248 0-2.004-.912-2.076-2.004h4.68v-.228c0-1.74-1.032-3.108-2.784-3.108-1.656 0-2.856 1.356-2.856 3.036 0 1.812 1.236 3.048 2.964 3.048Zm1.787-3.42h-3.804c.048-.876.66-1.92 1.896-1.92 1.32 0 1.896 1.068 1.908 1.92ZM61.461 15V6.996h-.9v3.084c-.468-.636-1.176-1.02-1.956-1.02-1.512 0-2.58 1.188-2.58 3.048 0 1.884 1.068 3.036 2.58 3.036a2.44 2.44 0 0 0 1.956-1.008V15h.9Zm-2.628-.66c-1.176 0-1.872-.948-1.872-2.232 0-1.284.696-2.244 1.872-2.244.708 0 1.416.432 1.728.936v2.616c-.312.504-1.02.924-1.728.924Zm13.464.66 1.848-5.796h-.948l-1.416 4.62-1.512-4.62h-.78l-1.524 4.62-1.416-4.62h-.936L67.46 15h.9l1.512-4.656L71.385 15h.912Zm3.34-6.624c.336 0 .6-.264.6-.6a.604.604 0 0 0-.6-.612.615.615 0 0 0-.612.612c0 .336.276.6.612.6ZM76.081 15V9.204h-.9V15h.9Zm3.272.144c.516 0 .84-.156 1.068-.372l-.264-.684a.852.852 0 0 1-.612.252c-.384 0-.576-.312-.576-.744v-3.6h1.176v-.792h-1.176V7.62h-.912v1.584h-.96v.792h.96v3.792c0 .864.432 1.356 1.296 1.356ZM86.228 15v-4.092c0-1.26-.636-1.848-1.848-1.848-.876 0-1.668.492-2.064.984V6.996h-.9V15h.9v-4.236c.336-.468 1.008-.9 1.704-.9.792 0 1.308.288 1.308 1.32V15h.9ZM119.251 7.717a.956.956 0 0 0 .684-.287 1.03 1.03 0 0 0 .296-.703 1.052 1.052 0 0 0-.29-.717.973.973 0 0 0-.69-.301.959.959 0 0 0-.676.307c-.178.19-.277.446-.276.711.002.262.103.513.281.698.178.185.419.29.671.292ZM125.909 8.667h2.363v.195c-.131.024-.257.07-.375.135-.216.105-.648.614-.979 1.468-.562 1.483-1.152 3.235-1.772 5.242l-.23.762c-.102.344-.188.569-.231.704-.043.136-.101.344-.202.599-.057.19-.13.376-.219.554-.116.224-.332.685-.505.824-.274.24-.677.509-1.181.464-.98 0-1.714-.761-1.729-1.662 0-.614.375-1.019.937-1.019.403 0 .763.229.763.704 0 .345-.331.704-.331.884 0 .464.259.685.764.685.402 0 .732-.27.979-.809.331-.614.36-1.288.086-2.037l-2.074-5.706c-.476-1.318-.836-1.751-1.282-1.798v-.195h3.27v.195c-.389.045-.591.285-.591.719 0 .314.115.794.331 1.408l.389 1.108c.447 1.199.806 2.247.995 2.906a81.428 81.428 0 0 1 1.181-3.61c.274-.778.403-1.332.403-1.662 0-.584-.302-.854-.763-.854l.003-.204ZM103.166 15.963c-.418-.076-.778-.465-.778-1.288v-9.93l-2.377.538v.21c.404-.045.806.33.806 1.123v8.059c0 .778-.404 1.227-.806 1.288a1.221 1.221 0 0 1-.715-.096c-.319-.145-.585-.403-.81-.788l-1.1-1.828a2.043 2.043 0 0 0-.981-.846 1.95 1.95 0 0 0-1.274-.067l1.24-1.423c.935-1.078 1.8-1.767 2.62-2.052v-.195h-2.725v.195c.706.285.663.914-.146 1.903l-1.743 2.112V4.744L92 5.284v.21c.403 0 .805.418.805 1.152v8.029c0 .883-.388 1.227-.805 1.288v.195h3.158v-.195c-.519-.076-.778-.494-.778-1.288v-1.483l.677-.779 1.638 2.8c.39.675.75.945 1.326.945h5.485v-.153s-.157-.011-.34-.042ZM109.707 15.014v-3.35c-.032-2.19-.915-3.188-2.938-3.188a2.808 2.808 0 0 0-1.786.63c-.533.419-.792.898-.792 1.453 0 .539.288.943.763.943.505 0 .865-.3.865-.719 0-.314-.202-.749-.202-1.048 0-.54.389-1.004 1.066-1.004.865 0 1.484.674 1.484 2.172v.898l-.72.18a10.01 10.01 0 0 0-.937.228c-.245.076-.561.18-.936.33-.75.3-1.152.584-1.499 1.123a1.62 1.62 0 0 0-.259.884c0 1.242.836 1.812 2.003 1.812.922 0 1.904-.51 2.348-1.468.006.302.076.6.204.871.488 1.028 2.106.42 2.106.42v-.195c-.708.115-.767-.76-.77-.972Zm-1.538-1.037c0 .494-.173.899-.519 1.183-.331.285-.676.435-1.037.435-.706 0-1.167-.48-1.167-1.364 0-.418.22-.808.404-1.033.145-.155.316-.282.504-.374.245-.135.366-.204.533-.285l.659-.254c.331-.135.533-.21.619-.255l.004 1.947ZM140 8.668h-5.603V4.744H140l-1.176 1.962L140 8.668ZM128.61 15.203a4.018 4.018 0 0 1-1.068-2.79 4.01 4.01 0 0 1 .266-1.5c.183-.476.456-.91.802-1.276.707-.78 1.572-1.17 2.583-1.17.995 0 1.861.39 2.568 1.17.351.363.627.796.813 1.273.186.477.278.988.269 1.503a4.04 4.04 0 0 1-.27 1.508 3.9 3.9 0 0 1-.812 1.282c-.707.761-1.573 1.155-2.568 1.155-1.011 0-1.876-.39-2.583-1.155Zm3.881-5.441c-.285-.58-.659-.92-1.098-1.01-.892-.187-1.679.765-1.973 2.28a7.466 7.466 0 0 0-.09 2.062c.064.689.248 1.36.543 1.98.286.58.659.918 1.099 1.01.891.186 1.701-.806 1.997-2.336.246-1.278.121-2.835-.482-3.987h.004Z",
                        fill: "#fff"
                    })), Z || (Z = r.createElement("path", {
                        d: "M120.085 14.675V8.67h-5.071v.18c.678.105 1 .637.692 1.499-1.584 4.478-1.483 4.277-1.584 4.636-.101-.345-.332-1.192-.706-2.255-.374-1.063-.62-1.768-.721-2.082-.389-1.243-.259-1.708.375-1.782V8.67h-3.285v.195c.49.105.922.689 1.282 1.737l.505 1.363c.554 1.472 1.205 3.502 1.423 4.194h1.092c.351-1.066 1.761-5.32 1.95-5.752.204-.492.435-.866.692-1.124.125-.139.276-.248.445-.322a1.24 1.24 0 0 1 .532-.102s.792 0 .792.794v5.022c0 .838-.389 1.228-.792 1.288v.195h3.14v-.195c-.415-.06-.761-.449-.761-1.288Z",
                        fill: "#fff"
                    })))
                },
                M = n(69299),
                B = n(51163);
            const D = () => null,
                N = () => null,
                j = M.Z;
            var R = ({
                    openFormVersion: e,
                    designerFunctions: t,
                    designerInfo: n,
                    formType: o,
                    abTestValue: r
                }) => {
                    const a = "FULLSCREEN" === o,
                        l = (0, x.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        d = (0, x.Z)((e => e.onsiteState.client.klaviyoCompanyId)),
                        c = (0, x.Z)(B.ek),
                        [m, u] = s().useState(!1),
                        f = null == n ? void 0 : n.activeSidebar,
                        p = (null == f ? void 0 : f.type) === v.zQ,
                        h = {
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            cursor: "pointer",
                            marginTop: a ? "4px" : 0,
                            marginBottom: "0px"
                        },
                        g = s().createElement(j, {
                            isIAMEditor: c,
                            componentId: v.zQ,
                            readonly: !0
                        }, (e => s().createElement(E.ZC, i()({
                            ref: e.ref
                        }, e.listeners, e.attributes, {
                            className: e.className,
                            style: h
                        }), s().createElement(A, null)))),
                        y = s().createElement(E.ZC, {
                            style: h,
                            onMouseLeave: () => u(!1),
                            onMouseEnter: () => u(!0),
                            onClick: () => {
                                D("F2P | Experiment 1G - Clicked Created with Klaviyo logo in forms editor", {
                                    formType: o,
                                    experiment: "1G",
                                    abTestValue: r
                                }), t && t.setActiveSidebar({
                                    type: v.zQ
                                })
                            }
                        }, s().createElement(N, {
                            isHovering: m,
                            isSelected: p,
                            isFullPage: a,
                            shouldWrap: p || m
                        }, a ? s().createElement(F, null) : s().createElement(A, null))),
                        I = s().createElement("a", {
                            style: h,
                            href: "https://klaviyo.com/features/forms-web-personalization?utm_medium=referral&utm_source=plgform",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            "aria-label": "Created with Klaviyo - opens in a new tab",
                            onClick: () => {
                                (0, k.M)({
                                    metric: _.tr,
                                    formVersionCId: e.formVersionCId,
                                    formId: e.formId,
                                    companyId: d
                                })
                            }
                        }, a ? s().createElement(F, null) : s().createElement(A, null));
                    return s().createElement(E.ZC, {
                        style: Object.assign({
                            display: "flex",
                            justifyContent: "center"
                        }, a ? {
                            zIndex: 10,
                            position: "absolute",
                            bottom: "0px",
                            left: "0px",
                            right: "0px",
                            margin: "0 auto",
                            width: "100%",
                            overflow: "hidden"
                        } : {})
                    }, c && g, !c && l && y, !c && !l && I)
                },
                P = n(5645),
                z = n.n(P),
                H = n(16639),
                W = n(26655);
            const L = ["animatingOut", "touchStartHandler", "touchMoveHandler", "touchEndHandler", "dragOffset", "useTransition", "transitionSpeed", "isSwipeToDismissEnabled", "formVersionCId", "designerInfo", "isA11y"],
                q = {
                    LEFT: "slideinleft",
                    TOP_CENTER: "slideinup",
                    BOTTOM_CENTER: "slideindown",
                    RIGHT: "slideinright"
                },
                U = {
                    POPUP: "fadeinup",
                    FULLSCREEN: "fadein"
                },
                K = ({
                    formType: e,
                    formTypeDirection: t,
                    teaserAnimationExists: n = !1,
                    animatingOut: o = !1,
                    isDesignWorkflow: i,
                    isA11y: r
                }) => {
                    const s = o || !o && n ? "both" : "forwards",
                        a = e === u.DV || e === u.UW ? U[e] : q[Object.keys(q).find((e => t && t.endsWith(e)))];
                    return Object.assign({}, H.s, {
                        animationFillMode: s
                    }, i ? {} : {
                        animationDelay: !o && n ? "0.25s" : "0s"
                    }, {
                        animationName: `klaviyo-${a}`
                    }, o ? {
                        animationDirection: "reverse",
                        animationDuration: e === u.DV || e === u.UW ? "0.35s" : ".5s"
                    } : {
                        animationDirection: "normal",
                        animationDuration: e === u.DV || e === u.UW ? "0.35s" : "1s"
                    }, r ? {
                        animationDelay: "0s",
                        animationDuration: "0s"
                    } : {})
                },
                G = ({
                    formTypeDirection: e,
                    modalScale: t
                }) => {
                    const n = {
                            TOP: {
                                top: 0
                            },
                            CENTER: {
                                top: "50%",
                                transform: `scale(${t}) translateY(-50%)`,
                                marginTop: "auto",
                                marginBottom: "auto"
                            },
                            BOTTOM: {
                                bottom: 0
                            }
                        },
                        o = {
                            LEFT: {
                                left: 0
                            },
                            CENTER: {
                                left: "50%",
                                transform: `scale(${t}) translateX(-50%)`,
                                marginLeft: "auto",
                                marginRight: "auto"
                            },
                            RIGHT: {
                                right: 0
                            }
                        };
                    return Object.assign({}, n[Object.keys(n).find((t => e && e.startsWith(t)))], o[Object.keys(o).find((t => e && e.endsWith(t)))])
                },
                Y = e => {
                    let {
                        animatingOut: t = !1,
                        touchStartHandler: n,
                        touchMoveHandler: o,
                        touchEndHandler: a,
                        dragOffset: l = 0,
                        useTransition: c = !1,
                        transitionSpeed: m = .5,
                        isSwipeToDismissEnabled: p = !1,
                        formVersionCId: h,
                        designerInfo: g,
                        isA11y: y
                    } = e, I = z()(e, L);
                    const b = (0, x.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[h]) ? void 0 : t.teaserAnimationInProgress
                        })),
                        S = (0, x.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[h]) ? void 0 : t.formAnimationInProgress
                        })),
                        w = (0, x.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[h]) ? void 0 : t.formVersionId
                        })),
                        C = (0, x.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[h]) ? void 0 : t.currentViewId
                        })),
                        _ = (0, x.Z)((e => {
                            var t;
                            return w ? null == (t = e.formsState.formVersions[w]) ? void 0 : t.formType : void 0
                        })),
                        k = (0, x.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        V = (0, x.Z)((e => {
                            const t = w ? e.formsState.formVersions[w] : void 0;
                            if (t) return f(t, k ? (null == g ? void 0 : g.mobileDesktopType) === v.Jq : (0, d.Z)()).evaluatedFormTypeDirection
                        })),
                        [T, $] = (0, r.useState)(!1);
                    (0, r.useEffect)((() => {
                        b && !T && $(!0)
                    }), [T, b]);
                    const Z = (0, r.useMemo)((() => k ? `${v.Sq}:${v.Pg}:${C}` : void 0), [k, C]);
                    return s().createElement(E.ZC, i()({
                        a11yIdentifier: Z
                    }, I, {
                        onAnimationEnd: () => {
                            (0, W.fK)({
                                id: h,
                                changes: {
                                    formAnimationInProgress: !1
                                }
                            }), (0, W.sd)({
                                formVersionCId: h
                            })
                        },
                        onTouchStart: e => {
                            n && n(e)
                        },
                        onTouchMove: e => {
                            o && o(e)
                        },
                        onTouchEnd: e => {
                            a && a(e)
                        },
                        onAnimationStart: () => {
                            (0, W.fK)({
                                id: h,
                                changes: {
                                    hideFormBeforeAnimation: !1
                                }
                            })
                        },
                        style: Object.assign({
                            flex: 1,
                            minHeight: _ === u.UW ? "100%" : void 0
                        }, p ? Object.assign({
                            bottom: -1 * l + "px",
                            position: "relative"
                        }, c ? {
                            transition: `bottom ${m}s`
                        } : {}) : {}, (S || k || t) && K({
                            formType: _,
                            formTypeDirection: V,
                            teaserAnimationExists: T,
                            animatingOut: t,
                            isDesignWorkflow: k,
                            isA11y: y
                        }) || {})
                    }))
                };
            var X = n(99385),
                J = n(59769),
                Q = n(61391),
                ee = n(91853),
                te = n(2534);
            let ne, oe, ie = e => e;
            const re = e => !!e.id.includes("downshift") || !("FORM" === e.tagName || !e.parentElement) && re(e.parentElement);
            var se = ({
                closePortal: e,
                formVersionCId: t,
                style: n,
                setOverlayDismissalPercentage: o,
                designerFunctions: c,
                designerInfo: m,
                isA11y: p = !1,
                a11yViewId: g,
                className: y
            }) => {
                var b, _, k, V, T, $;
                const Z = (0, x.Z)((e => e.onsiteState.openFormVersions[t]), l.X),
                    F = (0, x.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.modalIsClosing
                    })),
                    O = (0, x.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.closePortal
                    })),
                    A = (0, x.Z)((e => Z ? e.formsState.formVersions[Z.formVersionId] : void 0), l.X),
                    M = (0, x.Z)((e => {
                        var t;
                        return Z ? null == (t = e.formsState.formVersions[Z.formVersionId]) || null == (t = t.data) ? void 0 : t.ignoreOverlayDismissal : void 0
                    })),
                    B = (0, x.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    D = (0, x.Z)((e => e.onsiteState.client.showingShopLogin)),
                    N = (0, r.useMemo)((() => null == A ? void 0 : A.formType), [null == A ? void 0 : A.formType]),
                    j = N === u.UW,
                    P = N === u.nq,
                    z = N === u.DV,
                    H = (0, x.Z)((e => {
                        const t = Z ? e.formsState.forms[Z.formId] : void 0;
                        return !!t && t.showKlaviyoBrandingFullpageAndFlyoutForms
                    })),
                    L = (0, x.Z)((e => {
                        const t = Z ? e.formsState.forms[Z.formId] : void 0;
                        return z ? !!t && (t.showKlaviyoBranding || !0 === H) : !(!j && !P) && H
                    })),
                    q = (0, x.Z)((e => (0, J.FK)(e))),
                    U = (0, x.Z)((e => {
                        var n;
                        return p && g ? g : null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.currentViewId
                    })),
                    K = null == A || null == (b = A.data) ? void 0 : b.styling,
                    G = null == A || null == (_ = A.data) || null == (_ = _.styling) ? void 0 : _.borderRadius,
                    se = null == A || null == (k = A.data) || null == (k = k.styling) ? void 0 : k.dropShadow,
                    ae = null == A || null == (V = A.data) || null == (V = V.styling) ? void 0 : V.isReflow,
                    le = null == m ? void 0 : m.mobileDesktopType,
                    {
                        isDocked: de,
                        evaluatedFormTypeDirection: ce,
                        dockedDirection: me
                    } = A ? f(A, B ? le === v.Jq : (0, d.Z)()) : {
                        isDocked: void 0,
                        evaluatedFormTypeDirection: void 0,
                        dockedDirection: void 0
                    },
                    [ue, fe] = (0, r.useState)(),
                    pe = (0, r.useRef)(null);
                (0, r.useEffect)((() => {
                    fe((0, I.Z)("modal_animation_key"))
                }), [null == A ? void 0 : A.formType, null == A ? void 0 : A.formTypeDirection, le]);
                const he = () => {
                        (0, W.et)({
                            formVersionCId: t
                        })
                    },
                    [ve, ge] = (0, r.useState)(0),
                    [ye, Ie] = (0, r.useState)(0),
                    [be, Se] = (0, r.useState)(!1),
                    [we, Ce] = (0, r.useState)(.5),
                    [xe, Ee] = (0, r.useState)(new Date),
                    _e = (e, t = !1) => {
                        o && o(e, t)
                    };
                (0, r.useEffect)((() => {
                    !O && (null == Z || !Z.modalIsClosing || null != Z && Z.formAnimationInProgress || !Z.closeModalWhenAnimationCompletes) && (null != Z && Z.modalIsClosing || null != Z && Z.teaserAnimationInProgress || null == Z || !Z.closeModalWhenAnimationCompletes || Z.currentTeaserId) || e()
                }), [O, Z]), (0, r.useEffect)((() => {
                    const n = n => {
                        var o;
                        null != (o = pe.current) && o.contains(n.target) || B || t !== q || null === e || null != Z && Z.currentTeaserId || !((e, t, n) => !(!e || n === X.K.SHOWING || void 0 !== t && e === u.DV && ((0, d.Z)() ? !0 === (null == t ? void 0 : t.mobile) : !0 === (null == t ? void 0 : t.desktop))))(null == A ? void 0 : A.formType, M, D) || he()
                    };
                    return document.addEventListener("mousedown", n), document.addEventListener("touchstart", n), () => {
                        document.removeEventListener("mousedown", n), document.removeEventListener("touchstart", n)
                    }
                }), [B, t, q, e, M, Z, D]);
                const ke = null == A || null == (T = A.data) || null == (T = T.styling) ? void 0 : T.margin,
                    Ve = (0, r.useMemo)((() => B ? `${v.Sq}:${v.Pg}:${U}` : void 0), [B, U]),
                    Te = !B && de,
                    $e = (0, a.iv)(oe || (oe = ie `
    &&& {
      &::before {
        content: '';
        height: 100%;
        background-color: ${0};
        top: ${0};
        width: 100%;
        position: absolute;
      }
    }
  `), (null == K ? void 0 : K.backgroundColor) || h.Z.theme.backgroundColor, me === u.qK ? "50%" : "-50%"),
                    Ze = (0, r.useMemo)((() => (null == A ? void 0 : A.formType) !== u.Mk || void 0 === (null == A ? void 0 : A.data.showCloseButton) || (null == A ? void 0 : A.data.showCloseButton)), [null == A ? void 0 : A.data.showCloseButton, null == A ? void 0 : A.formType]),
                    Fe = (0, ee.C)();
                return ue ? s().createElement(E.ZC, {
                    a11yIdentifier: Ve,
                    ref: pe,
                    style: Object.assign({}, n, {
                        borderRadius: `${G||h.Z.theme.borderRadius}px`,
                        position: "relative",
                        display: "flex",
                        justifyContent: "center"
                    }, !ae && {
                        flex: "0 0 auto"
                    }, (null == A ? void 0 : A.formType) === u.DV ? {
                        alignSelf: "center"
                    } : {}, (null == A ? void 0 : A.formType) === u.UW || (null == A ? void 0 : A.formType) === u.Mk ? {
                        alignSelf: "stretch",
                        flex: 1
                    } : {}, p ? {
                        position: "absolute",
                        zIndex: 1
                    } : {}),
                    "data-testid": le,
                    className: y
                }, s().createElement(r.Suspense, {
                    fallback: s().createElement(E.ZC, null)
                }, s().createElement(Y, i()({
                    key: ue,
                    formVersionCId: t,
                    animatingOut: F,
                    "data-testid": null == A ? void 0 : A.formType,
                    isSwipeToDismissEnabled: Te
                }, Te ? {
                    touchStartHandler: e => {
                        re(e.target) || (Ce(.5), Se(!1), Ie(e.touches[0].clientY), Ee(new Date))
                    },
                    touchMoveHandler: e => {
                        if (re(e.target)) return;
                        e.preventDefault();
                        const t = Math.abs(e.touches[0].clientY - ye);
                        if (me === u.qK)
                            if (ye <= e.touches[0].clientY) {
                                const e = window.innerHeight - ye;
                                _e(t / e), ge(t)
                            } else {
                                const e = .8 * window.innerHeight;
                                if (Ce(.1), t < e) {
                                    ge(-1 * t / (10 / 2 ** (-1 * t / e)))
                                }
                            }
                        else if (ye >= e.touches[0].clientY) {
                            _e(t / ye), ge(-1 * t)
                        } else {
                            const e = .8 * window.innerHeight;
                            if (t < e) {
                                ge(t / (10 / 2 ** (-1 * t / e)))
                            }
                        }
                    },
                    touchEndHandler: e => {
                        if (re(e.target)) return;
                        Se(!0);
                        const t = (new Date).getTime() - xe.getTime(),
                            n = Math.abs(e.changedTouches[0].clientY - ye),
                            o = n / t,
                            i = me === u.qK ? e.changedTouches[0].clientY > ye : e.changedTouches[0].clientY < ye,
                            r = me === u.qK ? .9 : .1;
                        (me === u.qK ? e.changedTouches[0].clientY / window.innerHeight > r : e.changedTouches[0].clientY / window.innerHeight < r) && n > .2 * window.innerHeight || Math.abs(o) > .8 && i && n >= .2 * window.innerHeight ? (ge(me === u.qK ? window.innerHeight : -1 * window.innerHeight), _e(1, !0), setTimeout((() => he()), 500)) : (ge(0), _e(0, !0)), Ie(0)
                    },
                    dragOffset: ve,
                    useTransition: be,
                    transitionSpeed: we
                } : {}, {
                    designerInfo: m,
                    isA11y: p
                }), (Oe = s().createElement(E.ZC, {
                    a11yIdentifier: Ve,
                    className: S()(!B && de ? $e : "", z ? Fe : ""),
                    style: (null == A ? void 0 : A.formType) === u.UW ? {
                        display: "flex",
                        flex: 1,
                        alignSelf: "stretch"
                    } : void 0
                }, s().createElement(E.ZC, {
                    inert: !(!(0, d.Z)() || null == Z || !Z.currentTeaserId) || void 0,
                    a11yIdentifier: Ve,
                    style: Object.assign({
                        position: "relative",
                        display: "flex"
                    }, {
                        flex: 1,
                        alignSelf: "stretch"
                    }, se && se.enabled ? {
                        boxShadow: `0px 0px ${se.blur}px ${se.color}`
                    } : {}, G ? {
                        borderRadius: `${G}px`
                    } : {})
                }, Ze && !!U && s().createElement(te.y, {
                    formType: N,
                    style: {
                        position: "absolute"
                    }
                }, s().createElement(Q.Z, {
                    viewId: U,
                    buttonStyling: null == A || null == ($ = A.data) || null == ($ = $.styling) ? void 0 : $.dismissButtonStyles,
                    title: "Close dialog",
                    onClick: he,
                    designerFunctions: c,
                    designerInfo: m
                })), null != Z && Z.errorViewMessage || null == Z || !Z.formVersionId || !U ? s().createElement(C.Z, {
                    errorViewMessage: null == Z ? void 0 : Z.errorViewMessage,
                    isFullscreen: (null == A ? void 0 : A.formType) === u.UW
                }) : s().createElement(w.Z, {
                    formVersionCId: t,
                    formVersionId: null == Z ? void 0 : Z.formVersionId,
                    viewId: U,
                    isDocked: de,
                    formTypeDirection: ce,
                    designerFunctions: c,
                    designerInfo: m
                }), L && !!Z && j && s().createElement(R, {
                    openFormVersion: Z,
                    designerFunctions: c,
                    designerInfo: m,
                    formType: N,
                    abTestValue: H
                })), L && !!Z && !j && s().createElement(R, {
                    openFormVersion: Z,
                    designerFunctions: c,
                    designerInfo: m,
                    formType: N,
                    abTestValue: H
                })), de ? Oe : s().createElement(E.ZC, {
                    a11yIdentifier: Ve,
                    className: (0, a.iv)(ne || (ne = ie `
            &&& {
              &::before {
                content: '';
                display: block;
                min-height: ${0}px;
                width: 100%;
              }
              &::after {
                content: '';
                display: block;
                min-height: ${0}px;
                width: 100%;
              }
            }
          `), (null == ke ? void 0 : ke.top) || 0, (null == ke ? void 0 : ke.bottom) || 0),
                    style: {
                        position: "relative",
                        flexDirection: "column",
                        display: "flex",
                        marginLeft: null == ke ? void 0 : ke.left,
                        marginRight: null == ke ? void 0 : ke.right,
                        flex: 1,
                        alignSelf: "stretch",
                        minHeight: (null == A ? void 0 : A.formType) === u.UW ? "100%" : void 0
                    }
                }, Oe))))) : null;
                var Oe
            };
            let ae, le, de = e => e;
            const ce = 'button, [href], input:not([tabindex="-1"]), select, textarea, details, [tabindex]:not([tabindex="-1"])';
            var me = ({
                formVersionCId: e,
                closePortal: t,
                className: n,
                designerFunctions: o,
                designerInfo: m,
                isA11y: I = !1,
                a11yViewId: b,
                portalNode: S
            }) => {
                var w, C, _;
                const k = (0, x.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    V = (0, x.Z)(B.ek),
                    T = (0, x.Z)((t => {
                        var n;
                        return I && b ? b : null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentViewId
                    })),
                    $ = (0, x.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentTeaserId
                    })),
                    Z = (0, x.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                    })),
                    F = (0, x.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.teaserAnimationInProgress
                    })),
                    O = (0, x.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formAnimationInProgress
                    })),
                    A = (0, x.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.closeModalWhenAnimationCompletes
                    })),
                    M = (0, x.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.hideFormBeforeAnimation
                    })),
                    D = (0, x.Z)((e => Z ? e.formsState.formVersions[Z] : void 0), l.X);
                let N = (0, x.Z)((e => {
                    var t;
                    return (Z ? null == (t = e.formsState.formVersions[Z]) || null == (t = t.data) || null == (t = t.styling) ? void 0 : t.size : void 0) || h.Z.theme.size
                }));
                const j = (0, x.Z)((e => {
                        var t;
                        return Z ? null == (t = e.formsState.formVersions[Z]) || null == (t = t.data) ? void 0 : t.sideImage : void 0
                    }), l.X),
                    R = (0, x.Z)((e => {
                        var t;
                        return (Z ? null == (t = e.formsState.formVersions[Z]) || null == (t = t.data) || null == (t = t.styling) ? void 0 : t.overlayColor : void 0) || h.Z.theme.overlayColor
                    })),
                    P = (0, x.Z)((e => {
                        var t;
                        return (Z ? null == (t = e.formsState.formVersions[Z]) || null == (t = t.data) || null == (t = t.styling) ? void 0 : t.mobileOverlay : void 0) || h.Z.theme.mobileOverlay
                    }), l.X),
                    z = (0, x.Z)((e => e.onsiteState.client.isFetchingForms)),
                    H = (0, x.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.modalIsClosing
                    })),
                    L = (0, x.Z)((e => Object.values(e.formsState.columns).find((e => (null == e ? void 0 : e.position) === (null == j ? void 0 : j.position) && (null == e ? void 0 : e.viewId) === T))), l.X),
                    q = (e => {
                        const t = (0, r.useRef)(!1),
                            n = (0, r.useRef)(null),
                            [o, i] = (0, r.useState)(null);
                        return (0, r.useEffect)((() => (t.current = !0, () => {
                            t.current = !1
                        })), []), (0, r.useEffect)((() => {
                            if (!e) return;
                            const t = new ResizeObserver((e => {
                                var t;
                                const o = null == e || null == (t = e[0]) || null == (t = t.contentRect) ? void 0 : t.width;
                                o && o !== n.current && i(o)
                            }));
                            return t.observe(e, {
                                box: "content-box"
                            }), () => t.disconnect()
                        }), [e]), o
                    })(S),
                    U = (0, r.useRef)(null),
                    [K, Y] = (0, r.useState)(0),
                    [X, Q] = (0, r.useState)(!1),
                    [ee, te] = (0, r.useState)("none"),
                    ne = null == j || null == (w = j.data) || null == (w = w.styling) ? void 0 : w.sizeMultiplier,
                    oe = ne ? (0, c.Z)(ne, N) : 0,
                    ie = null == m ? void 0 : m.mobileDesktopType,
                    re = k && ie === v.Jq,
                    {
                        isDocked: me,
                        evaluatedFormTypeDirection: ue
                    } = D ? f(D, k ? ie === v.Jq : (0, d.Z)()) : {
                        isDocked: void 0,
                        evaluatedFormTypeDirection: void 0
                    };
                ((0, d.Z)() || re) && j && !(0, p.V)(j, k, ie || v.q5, L) && (N -= oe);
                const fe = null == D || null == (C = D.data) || null == (C = C.styling) ? void 0 : C.margin,
                    pe = me ? 0 : (null == fe ? void 0 : fe.left) || 0,
                    he = me ? 0 : (null == fe ? void 0 : fe.right) || 0,
                    ve = null == D || null == (_ = D.data) || null == (_ = _.styling) ? void 0 : _.isReflow,
                    ge = Math.max(Math.min(parseInt(N.toString(), 10), g.Ez), g.Gg) + he + pe,
                    [ye, Ie] = (0, r.useState)(1),
                    be = (0, a.iv)(ae || (ae = de `
    &&& {
      [data-testid='form-row'] {
        margin-bottom: calc((${0} - 1) * 1%);
      }
    }
  `), ye),
                    Se = (0, r.useMemo)((() => k ? be : void 0), [be, k]),
                    [we, Ce] = (0, r.useState)(!1);
                (0, r.useEffect)((() => {
                    F && !we && Ce(!0)
                }), [we, F]);
                const xe = Object.assign({
                        animationTimingFunction: "ease",
                        animationPlayState: "running",
                        animationIterationCount: 1,
                        animationFillMode: !H && we ? "both" : "forwards"
                    }, I ? {
                        animationDelay: "0s",
                        animationDuration: "0s"
                    } : {
                        animationDelay: H || !we || k ? "0s" : "0.25s",
                        animationDuration: "0.35s"
                    }),
                    Ee = Object.assign({}, xe, {
                        animationName: "klaviyo-fadeout"
                    }),
                    _e = Object.assign({}, xe, {
                        animationName: "klaviyo-fadein"
                    });
                (0, r.useEffect)((() => {
                    if (ve) return () => {};
                    const e = () => {
                        if ((null == D ? void 0 : D.formType) !== u.UW && (null == D ? void 0 : D.formType) !== u.Mk) {
                            var e;
                            const t = (null == (e = document) || null == (e = e.documentElement) ? void 0 : e.clientWidth) || window.innerWidth,
                                n = re ? v.aH : Math.min(t, q || 1 / 0),
                                o = me ? n / ge : Math.min(n / ge, 1);
                            Ie(o)
                        }
                    };
                    return window.addEventListener("resize", e), e(), () => {
                        window.removeEventListener("resize", e)
                    }
                }), [ve, q, ge, ie]);
                const ke = (0, x.Z)((t => (0, J.JZ)(t, e)));
                ((e, t, n, o, i, s, a) => {
                    const l = (0, r.useRef)(!1);
                    (0, r.useEffect)((() => {
                        l.current = !!i
                    }), [i]), (0, r.useEffect)((() => {
                        let o;
                        if (!t && (a === u.DV || a === u.UW) && n && !l.current) {
                            const t = null == e ? void 0 : e.querySelectorAll(ce);
                            if (e && t)
                                if (t.length > 1) {
                                    const e = Array.from(t).find((e => "INPUT" === e.nodeName));
                                    null == e || e.focus()
                                } else if (t.length) {
                                var i;
                                null == (i = t[0]) || i.focus()
                            }
                            o = null == e ? void 0 : e.addEventListener("keydown", (t => {
                                if ("Tab" !== t.key && 9 !== t.keyCode) return;
                                const n = e.querySelectorAll(ce),
                                    o = null == n ? void 0 : n[0],
                                    i = null == n ? void 0 : n[n.length - 1];
                                o !== i && (t.shiftKey ? document.activeElement === o && (null == i || i.focus(), t.preventDefault()) : document.activeElement === i && (null == o || o.focus(), t.preventDefault()))
                            }))
                        }
                        return () => o ? null == e ? void 0 : e.removeEventListener("keydown", o) : void 0
                    }), [e, t, a, n, o, s])
                })(U.current, k, ke, !!F, H, T, null == D ? void 0 : D.formType);
                let Ve = Object.assign({
                    display: ee,
                    zIndex: k ? 0 : y.B
                }, M ? {
                    opacity: 0
                } : {});
                if (ie === v.Jq && k && (null == D ? void 0 : D.formType) !== u.Mk) Ve = Object.assign({}, Ve, {
                    position: "relative",
                    justifyContent: "center",
                    alignItems: (Oe = null == D ? void 0 : D.formType, Ae = ue, Oe === u.nq && Ae ? Ae.startsWith("BOTTOM") ? "flex-end" : Ae.startsWith("CENTER") ? "center" : "flex-start" : "center"),
                    backgroundColor: (null == D ? void 0 : D.formType) === u.nq ? (null == P ? void 0 : P.enabled) && (null == P ? void 0 : P.color) || "transparent" : R,
                    alignSelf: "center",
                    height: "100%",
                    width: "100%",
                    overflowY: "auto",
                    overflowX: "clip"
                });
                else if ((re || (0, d.Z)()) && (null == D ? void 0 : D.formType) === u.Mk) {
                    var Te, $e;
                    Ve = Object.assign({}, Ve, {
                        width: "100%",
                        position: k || null == D || null == (Te = D.data.bannerOptions) || !Te.scrollWithPage ? "absolute" : "fixed",
                        overflow: k ? "initial" : "visible"
                    }, (null == D || null == ($e = D.data) || null == ($e = $e.bannerOptions) ? void 0 : $e.mobileBannerPosition) === u.ko ? {
                        top: 0
                    } : {
                        bottom: 0
                    })
                } else if ((null == D ? void 0 : D.formType) === u.nq) Ve = Object.assign({}, Ve, Object.assign({
                    maxHeight: k ? "100%" : 100 / ye + "%",
                    position: k ? "absolute" : "fixed",
                    transform: `scale(${ye})`,
                    transformOrigin: `${ue&&ue.endsWith("RIGHT")?"right":"left"} ${ue&&ue.startsWith("BOTTOM")?"bottom":"top"}`,
                    overflow: k ? "initial" : "visible"
                }, G({
                    formTypeDirection: ue,
                    modalScale: ye
                })));
                else if ((null == D ? void 0 : D.formType) === u.Mk) {
                    var Ze, Fe;
                    Ve = Object.assign({}, Ve, {
                        width: "100%",
                        position: k || null == D || null == (Ze = D.data.bannerOptions) || !Ze.scrollWithPage ? "absolute" : "fixed"
                    }, (null == D || null == (Fe = D.data) || null == (Fe = Fe.bannerOptions) ? void 0 : Fe.desktopBannerPosition) === u.ko ? {
                        top: 0
                    } : {
                        bottom: 0
                    })
                } else Ve = Object.assign({}, Ve, {
                    position: k ? "initial" : "fixed",
                    left: 0,
                    top: 0,
                    width: "100%",
                    height: V ? "initial" : "100%",
                    justifyContent: "center",
                    alignItems: k ? "flex-start" : "center",
                    overflow: V ? "initial" : "auto",
                    backgroundColor: R,
                    overflowX: "clip"
                }, H ? Ee : _e);
                var Oe, Ae;
                let Me = {};
                ie === v.Jq && k ? Me = Object.assign({
                    position: "absolute",
                    transform: `scale(${ye})`,
                    transformOrigin: (null == D ? void 0 : D.formType) === u.nq && ue ? "" + (ue.startsWith("BOTTOM") ? "bottom" : "top") : "center",
                    maxHeight: 100 / ye + "%"
                }, (null == D ? void 0 : D.formType) !== u.nq || me || 1 !== ye ? {} : G({
                    formTypeDirection: ue,
                    modalScale: ye
                })) : (null == D ? void 0 : D.formType) !== u.DV && (null == D ? void 0 : D.formType) !== u.UW || (Me = {
                    overflow: k ? "initial" : "visible",
                    transform: `scale(${ye})`,
                    transformOrigin: "center",
                    maxHeight: k ? "100%" : 100 / ye + "%"
                });
                const Be = null == P ? void 0 : P.enabled,
                    De = (0, a.iv)(le || (le = de `
    &&& {
      &::before {
        content: '';
        background-color: ${0};
        height: 100%;
        width: 100%;
        left: 0;
        top: 0;
        bottom: 0;
        right: 0;
        position: fixed;
        z-index: ${0};
        ${0};
        opacity: ${0};
      }
    }
  `), (null == P ? void 0 : P.color) || h.Z.theme.mobileOverlay.color, y.B, X ? "transition: opacity .5s ease;" : "", K ? 1 - K : 1),
                    Ne = (0, r.useMemo)((() => k ? `${v.Pg}:${v.Pg}:${T}` : void 0), [k, T]);
                return (0, r.useEffect)((() => {
                    !$ || F || O ? te(!$ && F && A ? "none" : "flex") : (!k && H && (0, W.fK)({
                        id: e,
                        changes: {
                            modalIsClosing: !1,
                            modalWasDismissed: !0
                        }
                    }), te("none"))
                }), [$, F, O, H]), je = (null == D ? void 0 : D.formType) === u.nq && (0, d.Z)() && (null == P ? void 0 : P.enabled) && "none" !== Ve.display, Re = s().createElement(E.ZC, {
                    a11yIdentifier: Ne,
                    ref: U,
                    role: "dialog",
                    "aria-modal": "true",
                    "aria-label": `${null==D?void 0:D.formType} Form`,
                    className: n || "",
                    style: Object.assign({}, Ve, I ? {
                        position: "absolute",
                        transform: "scale(0.001)",
                        zIndex: 1
                    } : {})
                }, z ? s().createElement(E.P, null, "Loading...") : s().createElement(se, i()({
                    closePortal: t,
                    formVersionCId: e,
                    style: Me,
                    designerFunctions: o,
                    designerInfo: m
                }, Be ? {
                    setOverlayDismissalPercentage: (e, t = !1) => {
                        Y(e), Q(t)
                    }
                } : {}, {
                    isA11y: I,
                    a11yViewId: b,
                    className: Se
                }))), k ? Re : s().createElement(E.ZC, {
                    style: Object.assign({}, I ? {
                        position: "absolute",
                        transform: "scale(0.001)",
                        zIndex: 1
                    } : {}),
                    a11yIdentifier: Ne
                }, s().createElement(E.ZC, {
                    a11yIdentifier: Ne,
                    className: De,
                    style: Be && je ? Object.assign({}, H ? Ee : _e) : {
                        display: "none"
                    }
                }), Re);
                var je, Re
            }
        },
        24186: function(e, t, n) {
            n.d(t, {
                n: function() {
                    return u
                }
            });
            var o = n(67895),
                i = n.n(o),
                r = n(5645),
                s = n.n(r),
                a = n(18359),
                l = n.n(a),
                d = n(46091);
            const c = ["a11yIdentifier"],
                m = l().lazy((() => n.e(4077).then(n.t.bind(n, 84420, 23)))),
                u = e => {
                    let {
                        a11yIdentifier: t
                    } = e, n = s()(e, c);
                    return l().createElement(a.Suspense, {
                        fallback: l().createElement("div", null)
                    }, l().createElement(m, i()({}, n, {
                        "data-a11y-identifier": t,
                        className: `needsclick ${n.className} ${d.Tc}`
                    })))
                }
        },
        24567: function(e, t, n) {
            n.d(t, {
                C3: function() {
                    return T
                },
                CI: function() {
                    return N
                },
                De: function() {
                    return $
                },
                Dr: function() {
                    return A
                },
                Ei: function() {
                    return O
                },
                II: function() {
                    return B
                },
                P: function() {
                    return F
                },
                ZC: function() {
                    return k
                },
                __: function() {
                    return j
                },
                aG: function() {
                    return D
                },
                l0: function() {
                    return V
                },
                ny: function() {
                    return M
                },
                zx: function() {
                    return Z
                }
            });
            var o = n(67895),
                i = n.n(o),
                r = n(5645),
                s = n.n(r),
                a = n(18359),
                l = n.n(a),
                d = n(12083),
                c = n.n(d),
                m = n(46091);
            n(55478);
            const u = ["a11yIdentifier"],
                f = ["a11yIdentifier"],
                p = ["a11yIdentifier"],
                h = ["a11yIdentifier"],
                v = ["a11yIdentifier"],
                g = ["a11yIdentifier"],
                y = ["a11yIdentifier"],
                I = ["a11yIdentifier"],
                b = ["a11yIdentifier"],
                S = ["a11yIdentifier"],
                w = ["a11yIdentifier"],
                C = ["tabIndex", "className", "alt", "a11yIdentifier"],
                x = ["tabIndex", "className", "style", "alt", "onClick", "a11yIdentifier", "aria-label", "children", "dndElProps"],
                E = ["a11yIdentifier"],
                _ = ({
                    children: e
                }) => e,
                k = l().forwardRef(((e, t) => {
                    let {
                        a11yIdentifier: n
                    } = e, o = s()(e, u);
                    return l().createElement("div", i()({
                        ref: t
                    }, o, {
                        "data-a11y-identifier": n,
                        className: `needsclick ${o.className||""} ${m.Tc}`
                    }))
                }));
            k.displayName = "Div";
            const V = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, f);
                return l().createElement("form", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            V.displayName = "Form";
            const T = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, p);
                return l().createElement("fieldset", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            T.displayName = "FieldSet";
            const $ = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, h);
                return l().createElement("legend", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            $.displayName = "Legend";
            const Z = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, v);
                return l().createElement("button", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }), o.children)
            }));
            Z.displayName = "Button";
            const F = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, g);
                return l().createElement("p", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            F.displayName = "P";
            l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, y);
                return l().createElement("a", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            })).displayName = "A";
            const O = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, I);
                return l().createElement("img", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            O.displayName = "Img";
            const A = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, b);
                return l().createElement("span", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            A.displayName = "Span";
            const M = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, S);
                return l().createElement("svg", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            M.displayName = "Svg";
            const B = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, w);
                return l().createElement("input", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            B.displayName = "Input";
            const D = e => {
                    let {
                        tabIndex: t,
                        className: n,
                        alt: o,
                        a11yIdentifier: r
                    } = e, a = s()(e, C);
                    return l().createElement(Z, {
                        type: "button",
                        tabIndex: t,
                        className: n
                    }, l().createElement(O, i()({
                        alt: o
                    }, a, {
                        a11yIdentifier: r
                    })))
                },
                N = e => {
                    let {
                        tabIndex: t,
                        className: n,
                        style: o,
                        onClick: r,
                        a11yIdentifier: a,
                        "aria-label": d,
                        children: m,
                        dndElProps: u
                    } = e, f = s()(e, x);
                    return l().createElement(Z, i()({
                        tabIndex: t,
                        className: c()(n, u.className),
                        style: o,
                        onClick: r,
                        "aria-label": d,
                        ref: u.ref
                    }, u.listeners, u.attributes), l().createElement(M, i()({
                        role: "img"
                    }, f, {
                        "data-a11y-identifier": a
                    }), a && m ? l().createElement(_, {
                        identifier: a
                    }, l().createElement(l().Fragment, null, m)) : m))
                },
                j = l().forwardRef(((e, t) => {
                    let {
                        a11yIdentifier: n
                    } = e, o = s()(e, E);
                    return l().createElement("label", i()({
                        ref: t
                    }, o, {
                        "data-a11y-identifier": n,
                        className: `needsclick ${o.className||""} ${m.Tc}`
                    }))
                }));
            j.displayName = "Label"
        },
        2534: function(e, t, n) {
            n.d(t, {
                y: function() {
                    return l
                }
            });
            var o = n(18359),
                i = n.n(o),
                r = n(24567),
                s = n(91853),
                a = n(38799);
            const l = ({
                formType: e,
                style: t,
                children: n
            }) => {
                const o = (0, s.C)();
                return e === a.UW ? i().createElement(r.ZC, {
                    className: o,
                    style: Object.assign({
                        width: "100%"
                    }, t)
                }, n) : n
            }
        },
        91853: function(e, t, n) {
            n.d(t, {
                C: function() {
                    return m
                }
            });
            var o = n(23409),
                i = n(51163),
                r = n(57829);
            let s, a, l = e => e;
            const d = (0, o.iv)(s || (s = l `
  margin-top: env(safe-area-inset-top);
  margin-bottom: env(safe-area-inset-bottom);
  margin-left: env(safe-area-inset-left);
  margin-right: env(safe-area-inset-right);
`)),
                c = (0, o.iv)(a || (a = l `
  margin-top: 47px;
  margin-bottom: 34px;
  margin-left: 0px;
  margin-right: 0px;
`)),
                m = () => {
                    var e;
                    const t = "in-app" === (null == (e = window) || null == (e = e.klaviyoModulesObject) ? void 0 : e.env);
                    let n;
                    return n = (0, r.Z)(i.ek) ? c : t ? d : void 0, n
                }
        },
        12698: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return z
                }
            });
            var o = n(67895),
                i = n.n(o),
                r = (n(92461), n(70818), n(39265), n(18359)),
                s = n.n(r),
                a = n(80101),
                l = n(23409),
                d = n(23034),
                c = n(22314),
                m = n(57829),
                u = n(24567),
                f = n(68133),
                p = n(23760),
                h = n(76166);
            var v = ({
                    formVersionCId: e,
                    designerInfo: t
                }) => {
                    const n = (0, m.Z)((t => {
                            var n, o;
                            const i = null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId;
                            return i ? null == (o = t.formsState.formVersions[i]) ? void 0 : o.formType : void 0
                        })),
                        o = (0, m.Z)((t => {
                            var n, o;
                            const i = null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId;
                            return i ? null == (o = t.formsState.formVersions[i]) ? void 0 : o.formTypeDirection : void 0
                        })),
                        i = (0, m.Z)((t => {
                            var n;
                            const o = null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId;
                            return t.formsState.teasers && Object.values(t.formsState.teasers).filter((e => (null == e ? void 0 : e.formVersionId) === o))[0]
                        }), d.X),
                        l = (0, m.Z)((e => e.onsiteState.client.isDesignWorkflow)),
                        c = null == t ? void 0 : t.mobileDesktopType,
                        [v, g] = (0, r.useState)();
                    (0, r.useEffect)((() => {
                        g((0, a.Z)("modal_animation_key"))
                    }), [n, o, c]);
                    const y = f.c.TEXT,
                        I = (0, r.useMemo)((() => l ? `${h.KI}:${h.s4}:${null==i?void 0:i.teaserId}` : void 0), [l, null == i ? void 0 : i.teaserId]);
                    return v && i ? s().createElement(u.ZC, {
                        a11yIdentifier: I
                    }, s().createElement(r.Suspense, {
                        fallback: s().createElement(u.ZC, null)
                    }, s().createElement(y, {
                        itemId: i.teaserId,
                        parentType: p.p,
                        formVersionCId: e,
                        a11yIdentifierBlock: I
                    }))) : null
                },
                g = n(26655),
                y = n(18367),
                I = n(69914),
                b = n(67789),
                S = n(38799),
                w = n(58423);
            let C;
            const x = 16,
                E = {
                    [b.GE]: {
                        [S.MG]: {},
                        [S.DA]: {},
                        [S.pz]: {},
                        [S.pq]: {},
                        [S.j$]: {},
                        [S.kB]: {},
                        [S.qS]: {},
                        [S.tC]: {}
                    },
                    [b.uv]: {
                        [S.MG]: {},
                        [S.DA]: {},
                        [S.pz]: {},
                        [S.pq]: {},
                        [S.j$]: {},
                        [S.kB]: {},
                        [S.qS]: {},
                        [S.tC]: {}
                    },
                    [b.aR]: {
                        [S.MG]: {
                            clipPath: "polygon(100% 0, 0 100%, 0 0)"
                        },
                        [S.pz]: {
                            clipPath: "polygon(100% 100%, 0 0, 100% 0)"
                        },
                        [S.kB]: {
                            clipPath: "polygon(0 0, 0 100%, 100% 100%)"
                        },
                        [S.tC]: {
                            clipPath: "polygon(100% 100%, 0 100%, 100% 0)"
                        }
                    }
                },
                _ = ({
                    type: e,
                    direction: t,
                    dismissButtonMargin: n
                }) => {
                    var o, i;
                    const r = null != (o = null == n ? void 0 : n.top) ? o : w.Z.dismissButtonStyles.margin.top,
                        s = -1 * r,
                        a = -1 * (null != (i = null == n ? void 0 : n.right) ? i : w.Z.dismissButtonStyles.margin.right);
                    return {
                        [b.GE]: {
                            [S.MG]: {
                                bottom: s,
                                right: a
                            },
                            [S.DA]: {
                                bottom: s,
                                right: a
                            },
                            [S.pz]: {
                                bottom: s,
                                left: a
                            },
                            [S.pq]: {
                                bottom: s,
                                right: a
                            },
                            [S.j$]: {
                                bottom: s,
                                right: a
                            },
                            [S.kB]: {
                                top: s,
                                right: a
                            },
                            [S.qS]: {
                                top: s,
                                right: a
                            },
                            [S.tC]: {
                                top: s,
                                left: a
                            }
                        },
                        [b.uv]: {
                            [S.MG]: {
                                bottom: s,
                                right: a
                            },
                            [S.DA]: {
                                bottom: s,
                                right: a
                            },
                            [S.pz]: {
                                bottom: s,
                                left: a
                            },
                            [S.pq]: {
                                top: s,
                                right: a
                            },
                            [S.j$]: {
                                top: s,
                                left: a
                            },
                            [S.kB]: {
                                top: s,
                                right: a
                            },
                            [S.qS]: {
                                top: s,
                                right: a
                            },
                            [S.tC]: {
                                top: s,
                                left: a
                            }
                        },
                        [b.aR]: {
                            [S.MG]: {
                                top: r,
                                right: a
                            },
                            [S.pz]: {
                                top: r,
                                left: a
                            },
                            [S.kB]: {
                                bottom: r,
                                right: a
                            },
                            [S.tC]: {
                                bottom: r,
                                left: a
                            }
                        }
                    }[e][t]
                },
                k = ({
                    theme: e,
                    type: t,
                    direction: n
                }) => {
                    const o = Math.sqrt(e.size * e.size * 2) / 2,
                        i = Math.sqrt(e.size * e.size - o * o);
                    return {
                        [b.GE]: {
                            [S.DA]: {},
                            [S.pq]: {},
                            [S.j$]: {},
                            [S.qS]: {}
                        },
                        [b.uv]: {
                            [S.pq]: {},
                            [S.j$]: {}
                        },
                        [b.aR]: {
                            [S.MG]: {
                                width: Math.sqrt(e.size * e.size * 2),
                                transform: "rotate(-45deg)",
                                transformOrigin: "top left",
                                top: e.size / 2,
                                left: -1 * e.size / 2,
                                position: "relative",
                                height: i,
                                display: "flex",
                                flexDirection: "column-reverse",
                                alignItems: "center"
                            },
                            [S.pz]: {
                                width: Math.sqrt(e.size * e.size * 2),
                                transform: "rotate(45deg)",
                                transformOrigin: "top left",
                                top: -1 * e.size / 2,
                                left: e.size / 2,
                                position: "relative",
                                height: i,
                                display: "flex",
                                flexDirection: "column-reverse",
                                alignItems: "center"
                            },
                            [S.kB]: {
                                height: e.size - x,
                                width: Math.sqrt(e.size * e.size * 2),
                                transform: "rotate(45deg)",
                                transformOrigin: "top left"
                            },
                            [S.tC]: {
                                height: e.size - x,
                                width: Math.sqrt(e.size * e.size * 2),
                                position: "relative",
                                top: e.size,
                                left: 0,
                                transform: "rotate(-45deg)",
                                transformOrigin: "top left"
                            }
                        }
                    }[t][n] || {}
                },
                V = e => {
                    var t;
                    return Object.assign({
                        backgroundColor: e.backgroundColor
                    }, e.backgroundImage ? {
                        backgroundImage: e.backgroundImage && `url(${e.backgroundImage.url})`,
                        backgroundRepeat: "no-repeat",
                        backgroundSize: e.backgroundImage && ("custom" === e.backgroundImage.position ? `${e.backgroundImage.customWidth}px` : e.backgroundImage.position),
                        backgroundPositionX: e.backgroundImage && e.backgroundImage.alignment,
                        backgroundPositionY: (null == (t = e.backgroundImage) ? void 0 : t.verticalAlignment) || "center"
                    } : {})
                },
                T = (0, l.iv)(C || (C = (e => e)
                    `
  > div {
    padding-bottom: 8px;
    padding-top: 8px;
  }
`));
            var $ = n(5645),
                Z = n.n($),
                F = n(16639);
            const O = ["teaserType", "teaserDirection", "teaserDisplayOrder", "animatingOut", "endAnimationCallback", "formVersionCId", "style", "isA11y", "a11yTeaserId"],
                A = {
                    [b.GE]: {
                        CENTER_LEFT: "slideinup",
                        TOP: "slideinup",
                        BOTTOM: "slideindown",
                        CENTER_RIGHT: "slideinup"
                    },
                    [b.uv]: {
                        CENTER_LEFT: "slideinleft",
                        TOP: "slideinup",
                        BOTTOM: "slideindown",
                        CENTER_RIGHT: "slideinright"
                    },
                    [b.aR]: {
                        TOP_LEFT: "slideintopleft",
                        BOTTOM_LEFT: "slideinbottomleft",
                        TOP_RIGHT: "slideintopright",
                        BOTTOM_RIGHT: "slideinbottomright"
                    }
                },
                M = ({
                    teaserType: e,
                    teaserDirection: t,
                    animatingOut: n = !1,
                    isDesignWorkflow: o,
                    isFirstRender: i,
                    isA11y: r
                }) => {
                    const s = A[e],
                        a = s[Object.keys(s).find((e => t && t.startsWith(e)))];
                    let l = "0s",
                        d = "forwards";
                    return o ? l = "0.35s" : i && !n && (l = "2s", d = "both"), Object.assign({}, F.s, {
                        animationDelay: l,
                        animationFillMode: d,
                        animationDuration: ".4s",
                        animationName: `klaviyo-${a}`
                    }, n ? {
                        animationDirection: "reverse"
                    } : {
                        animationDirection: "normal"
                    }, r ? {
                        animationDelay: "0s",
                        animationDuration: "0s"
                    } : {})
                },
                B = e => {
                    let {
                        teaserType: t,
                        teaserDirection: n,
                        animatingOut: o = !1,
                        endAnimationCallback: a = (() => {}),
                        formVersionCId: l,
                        style: d = {},
                        isA11y: c,
                        a11yTeaserId: f
                    } = e, p = Z()(e, O);
                    const [v, y] = (0, r.useState)(!1), I = (0, m.Z)((e => !!e.onsiteState.client.isDesignWorkflow)), b = (0, m.Z)((e => {
                        var t;
                        return null == (t = e.onsiteState.openFormVersions[l]) ? void 0 : t.teaserIsFirstRender
                    }));
                    (0, r.useEffect)((() => {
                        o && y(!1)
                    }), [o]);
                    const S = (0, r.useMemo)((() => I ? `${h.KI}:${h.s4}:${f}` : void 0), [I, f]);
                    return s().createElement(u.ZC, i()({
                        a11yIdentifier: S
                    }, p, {
                        onAnimationEnd: () => {
                            (0, g.fK)({
                                id: l,
                                changes: {
                                    teaserAnimationInProgress: !1
                                }
                            }), y(!0), a()
                        },
                        onAnimationStart: () => {
                            (0, g.ng)({
                                formVersionCId: l
                            }), o && (0, g.fK)({
                                id: l,
                                changes: {
                                    teaserAnimationInProgress: !0,
                                    formAnimationInProgress: !0
                                }
                            }), (0, g.fK)({
                                id: l,
                                changes: {
                                    hideTeaserBeforeAnimation: !1
                                }
                            })
                        },
                        style: Object.assign({
                            height: "100%",
                            width: "100%"
                        }, d, (!v || o) && M({
                            teaserType: t,
                            teaserDirection: n,
                            animatingOut: o,
                            isDesignWorkflow: I,
                            isFirstRender: !!b,
                            isA11y: c
                        }) || {})
                    }))
                };
            var D = n(62945),
                N = n(23806);
            var j = n(61391);
            let R, P = e => e;
            var z = ({
                formVersionCId: e,
                className: t,
                designerFunctions: n,
                designerInfo: o,
                isA11y: f = !1,
                a11yTeaserId: p
            }) => {
                var w, C, $, Z, F, O;
                const A = (0, m.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.closeModalWhenAnimationCompletes
                    })),
                    M = (0, m.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    z = (0, m.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                    })),
                    H = (0, m.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formId
                    })),
                    W = (0, m.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.hideTeaserBeforeAnimation
                    })),
                    L = (0, m.Z)((t => {
                        var n;
                        return f && p ? p : null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentTeaserId
                    })),
                    q = (0, m.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.teaserAnimationInProgress
                    })),
                    U = (0, m.Z)((e => e.formsState.teasers && Object.values(e.formsState.teasers).filter((e => (null == e ? void 0 : e.formVersionId) === z))[0]), d.X),
                    K = (0, m.Z)((e => {
                        const t = Object.values(e.onsiteState.triggerGroups).find((e => (null == e ? void 0 : e.formVersionId) === z));
                        return t && void 0 !== t[y.w1] || !1
                    })),
                    G = (0, c.Z)() || (null == o ? void 0 : o.mobileDesktopType) === h.Jq,
                    Y = (0, r.useRef)(null),
                    [X, J] = (0, r.useState)(!1),
                    Q = (0, r.useMemo)((() => M ? `${h.KI}:${h.s4}:${null==U?void 0:U.teaserId}` : void 0), [M, null == U ? void 0 : U.teaserId]),
                    [ee, te] = (0, r.useState)(),
                    [ne, oe] = (0, r.useState)(!1),
                    ie = (0, r.useCallback)((() => {
                        ne && !M && (A || (0, g.$J)({
                            formVersionCId: e
                        }), oe(!1))
                    }), [ne]);
                if ((0, r.useEffect)((() => {
                        te((0, a.Z)("teaser_animation_key"))
                    }), [null == U ? void 0 : U.type, null == U ? void 0 : U.direction]), (0, r.useEffect)((() => {
                        U && L && X && !ne && !q && Y.current && (Y.current.focus(), J(!1))
                    }), [e, L, q, X, ne, U]), !U || !L && !q) return null;
                const re = null == (w = U.data) || null == (w = w.styling) || null == (w = w.dismissButtonStyles) ? void 0 : w.margin,
                    se = U.type === b.GE && ((null == (C = U.direction) ? void 0 : C.includes("TOP")) || (null == ($ = U.direction) ? void 0 : $.includes("BOTTOM"))) && G,
                    ae = (({
                        teaserStyling: e,
                        teaserType: t
                    }) => {
                        const n = b.ds[t];
                        return (0, D.Z)({}, Object.assign({}, N.al, {
                            size: n
                        }), e)
                    })({
                        teaserStyling: null == (Z = U.data) ? void 0 : Z.styling,
                        teaserType: U.type
                    }),
                    le = {
                        theme: ae,
                        type: U.type,
                        direction: U.direction
                    },
                    de = Object.assign({
                        zIndex: M ? 0 : I.B
                    }, f ? {
                        transform: "scale(0.001)",
                        zIndex: 1
                    } : {}, {
                        position: M ? "absolute" : "fixed"
                    }, ae.dropShadow.enabled ? {
                        filter: `drop-shadow(0px 0px ${ae.dropShadow.blur}px ${ae.dropShadow.color})`
                    } : {}, (({
                        theme: e,
                        type: t,
                        direction: n
                    }) => {
                        const o = e.margin.left,
                            i = e.margin.top;
                        return {
                            [b.GE]: {
                                [S.MG]: {
                                    top: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.DA]: {
                                    top: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [S.pz]: {
                                    top: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.pq]: {
                                    top: "50%",
                                    left: 0,
                                    transform: "rotate(-90deg) translate(-50%, 0)",
                                    transformOrigin: "top left",
                                    marginLeft: `${i}px`
                                },
                                [S.j$]: {
                                    top: "50%",
                                    right: 0,
                                    transform: "rotate(90deg) translate(50%, 0)",
                                    transformOrigin: "top right",
                                    marginRight: `${i}px`
                                },
                                [S.kB]: {
                                    bottom: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.qS]: {
                                    bottom: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [S.tC]: {
                                    bottom: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                }
                            },
                            [b.uv]: {
                                [S.MG]: {
                                    top: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.DA]: {
                                    top: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [S.pz]: {
                                    top: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.pq]: {
                                    left: 0,
                                    margin: `${i}px ${o}px`,
                                    top: `calc(50% - ${i}px)`,
                                    transform: "translateY(-50%)"
                                },
                                [S.j$]: {
                                    right: 0,
                                    margin: `${i}px ${o}px`,
                                    top: `calc(50% - ${i}px)`,
                                    transform: "translateY(-50%)"
                                },
                                [S.kB]: {
                                    bottom: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.qS]: {
                                    bottom: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [S.tC]: {
                                    bottom: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                }
                            },
                            [b.aR]: {
                                [S.MG]: {
                                    top: 0,
                                    left: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                },
                                [S.pz]: {
                                    top: 0,
                                    right: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                },
                                [S.kB]: {
                                    bottom: 0,
                                    left: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                },
                                [S.tC]: {
                                    bottom: 0,
                                    right: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                }
                            }
                        }[t][n]
                    })(le), (({
                        theme: e,
                        type: t,
                        direction: n
                    }) => ({
                        [b.GE]: {
                            [S.MG]: {
                                width: e.size - x
                            },
                            [S.DA]: {
                                width: e.size - x
                            },
                            [S.pz]: {
                                width: e.size - x
                            },
                            [S.pq]: {
                                width: e.size - x
                            },
                            [S.j$]: {
                                width: e.size - x
                            },
                            [S.kB]: {
                                width: e.size - x
                            },
                            [S.qS]: {
                                width: e.size - x
                            },
                            [S.tC]: {
                                width: e.size - x
                            }
                        },
                        [b.uv]: {
                            [S.MG]: {
                                height: e.size - x,
                                width: e.size - x
                            },
                            [S.DA]: {
                                height: e.size - x,
                                width: e.size - x
                            },
                            [S.pz]: {
                                height: e.size - x,
                                width: e.size - x
                            },
                            [S.pq]: {
                                width: e.size - x,
                                height: e.size - x
                            },
                            [S.j$]: {
                                width: e.size - x,
                                height: e.size - x
                            },
                            [S.kB]: {
                                height: e.size - x,
                                width: e.size - x
                            },
                            [S.qS]: {
                                height: e.size - x,
                                width: e.size - x
                            },
                            [S.tC]: {
                                height: e.size - x,
                                width: e.size - x
                            }
                        },
                        [b.aR]: {
                            [S.MG]: {},
                            [S.pz]: {},
                            [S.kB]: {},
                            [S.tC]: {}
                        }
                    }[t][n] || {}))(le), se ? {
                        width: `calc(100% - ${2*ae.margin.left}px)`
                    } : {}, W && M ? {
                        opacity: 0
                    } : {}),
                    ce = Object.assign({
                        overflow: "hidden",
                        boxSizing: "border-box"
                    }, E[U.type][U.direction] || {}, ((e, t, n) => {
                        const o = {};
                        switch (t) {
                            case b.GE:
                                o.borderRadius = ((e, t) => {
                                    const n = e.margin.top,
                                        o = e.margin.left;
                                    let [i, r, s, a] = [e.borderRadius, e.borderRadius, e.borderRadius, e.borderRadius];
                                    return null != t && t.includes("BOTTOM") && 0 === n && (s = 0, a = 0), null != t && t.includes("TOP") && 0 === n && (r = 0, i = 0), null != t && t.includes("LEFT") && 0 === o && (i = 0, a = 0), null != t && t.includes("RIGHT") && 0 === o && (r = 0, s = 0), null != t && t.includes("CENTER") && null != t && t.includes("LEFT") && 0 === n && (i = 0, r = 0), null != t && t.includes("CENTER") && null != t && t.includes("RIGHT") && 0 === n && (i = 0, r = 0), `${i}px ${r}px ${s}px ${a}px`
                                })(e, n);
                                break;
                            case b.uv:
                                o.borderRadius = "50%"
                        }
                        return o
                    })(ae, U.type, U.direction), U.type !== b.aR ? V(ae) : {}, b.GE === U.type ? {
                        minHeight: 50,
                        height: "100%",
                        padding: 8
                    } : {}, b.uv === U.type ? {
                        height: "100%",
                        padding: 8
                    } : {
                        height: "100%"
                    }, U.type === b.aR ? {
                        display: "block"
                    } : {
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center"
                    }),
                    me = (0, l.iv)(R || (R = P `
    cursor: pointer;
    * {
      cursor: pointer;
    }
  `));
                return s().createElement(u.ZC, i()({}, null != (F = U.data.content) && F.html ? {} : {
                    "aria-label": "Open Form"
                }, {
                    a11yIdentifier: Q,
                    ref: Y,
                    className: `kl-teaser-${H} ${t}`,
                    tabIndex: M ? -1 : 0,
                    style: de
                }, M ? {} : {
                    onClick: () => {
                        oe(!0), J(!0)
                    }
                }), s().createElement(B, {
                    key: ee,
                    teaserType: U.type,
                    teaserDirection: U.direction,
                    teaserDisplayOrder: U.displayOrder,
                    animatingOut: q && !L || ne,
                    endAnimationCallback: ie,
                    formVersionCId: e,
                    "data-testid": "animated-teaser",
                    isA11y: f,
                    a11yTeaserId: p
                }, s().createElement(u.Dr, {
                    a11yIdentifier: Q,
                    style: ce,
                    className: M ? "" : me
                }, s().createElement(u.ZC, {
                    a11yIdentifier: Q,
                    style: Object.assign({}, k(le), U.type === b.aR ? V(ae) : {}),
                    className: U.type === b.aR ? T : ""
                }, s().createElement(v, {
                    formVersionCId: e,
                    designerInfo: o
                }))), K && !q && s().createElement(j.Z, {
                    buttonStyling: null == (O = U.data) || null == (O = O.styling) ? void 0 : O.dismissButtonStyles,
                    title: "Close teaser",
                    onClick: () => {
                        (0, g.YW)({
                            formVersionCId: e
                        })
                    },
                    positionalStyles: _(Object.assign({}, le, {
                        dismissButtonMargin: re
                    })),
                    isTeaser: !0,
                    designerFunctions: n,
                    designerInfo: o
                })))
            }
        },
        29676: function(e, t, n) {
            var o = n(18359),
                i = n.n(o),
                r = n(30118),
                s = n(24567);
            t.Z = ({
                errorViewMessage: e,
                isEmbed: t = !1,
                isFullscreen: n = !1
            }) => i().createElement(s.ZC, {
                role: "status",
                "aria-live": "polite",
                style: Object.assign({
                    height: 165,
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    background: "#ffffff"
                }, t ? {
                    width: "100%"
                } : Object.assign({}, n ? {
                    width: "100%",
                    overflow: "auto",
                    height: "fit-content",
                    minHeight: "100%"
                } : {
                    width: 450
                }))
            }, i().createElement(s.ZC, {
                style: {
                    textAlign: "center",
                    width: 300
                }
            }, e || r.xl))
        },
        46753: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return H
                }
            });
            n(19986), n(92461), n(70818), n(39265), n(44159), n(60873), n(83362);
            var o = n(18359),
                i = n.n(o),
                r = n(23409),
                s = n(23034),
                a = n(98355),
                l = n(54883),
                d = n(76166),
                c = n(82874),
                m = n(67895),
                u = n.n(m);
            const f = "top",
                p = "bottom";
            var h = n(12083),
                v = n.n(h),
                g = n(62945),
                y = n(35777),
                I = n(57829),
                b = n(68133),
                S = n(24567),
                w = n(40582),
                C = n(21623),
                x = n(51163),
                E = n(46458),
                _ = n(69299);
            const k = {
                    right: "0 0 0 auto",
                    left: "0 auto 0 0",
                    center: "0 auto"
                },
                V = ({
                    children: e
                }) => e,
                T = _.Z;
            var $ = ({
                componentId: e,
                componentPosition: t,
                formVersionCId: n,
                rowDroppableHover: r,
                setDragState: a,
                dragFinished: l,
                designerFunctions: c,
                designerInfo: m,
                isA11y: f = !1
            }) => {
                var p, h;
                const [_, $] = (0, o.useState)(!1), Z = (0, o.useRef)(null), F = (0, I.Z)((t => t.formsState.components[e]), s.X), O = (0, I.Z)((e => !!e.onsiteState.client.isDesignWorkflow)), A = (0, I.Z)(x.ek), M = (0, I.Z)((e => {
                    var t;
                    return null == (t = e.onsiteState.openFormVersions[n]) ? void 0 : t.currentViewId
                })), B = (0, I.Z)((t => M ? (0, E.su)(t, e, M) : {}), s.X), D = (0, I.Z)((e => M ? (0, x.l)(e, M) : {}), s.X), N = (0, I.Z)((t => {
                    var n, o;
                    const i = null == (n = t.formsState.components[e]) ? void 0 : n.actionId;
                    return t.formsState.actions && i ? null == (o = t.formsState.actions[i]) ? void 0 : o.actionType : void 0
                })), j = (0, o.useMemo)((() => O ? (null == m ? void 0 : m.mobileDesktopType) || d.q5 : (0, w.Z)()), [O, null == m ? void 0 : m.mobileDesktopType]), R = (null == m ? void 0 : m.activeComponentId) || (null == m ? void 0 : m.activeA11yComponentId), P = (0, o.useMemo)((() => {
                    var e;
                    return (0, g.Z)({}, D, B, {
                        [y.Z.THEME_KEY]: null == F || null == (e = F.data) ? void 0 : e.styling
                    })
                }), [D, B, null == F || null == (p = F.data) ? void 0 : p.styling]), z = (0, o.useMemo)((() => O ? `${d.f2}:${d.j1}:${e}` : void 0), [e, O]), H = (0, o.useMemo)((() => O ? `${d.f2}:${d.Pg}:${e}` : void 0), [e, O]), W = (0, o.useMemo)((() => {
                    if (!F) return null;
                    const t = b.c[F.componentType];
                    return t ? i().createElement(t, {
                        theme: P,
                        componentId: e,
                        formVersionCId: n,
                        itemId: e,
                        a11yIdentifierBlock: z,
                        a11yIdentifierStyles: H
                    }) : null
                }), [z, H, F, e, n, P]);
                if (null != F && null != (h = F.data) && null != (h = h.styling) && h.hidden) return null;
                const L = R === e,
                    q = Object.assign({
                        component: F
                    }, O && !A ? {
                        onClick: () => {
                            null == c || c.setActiveSidebar({
                                type: d.NV,
                                key: e
                            })
                        },
                        onMouseOver: () => {
                            l ? a(!1) : $(!0)
                        },
                        onMouseLeave: () => $(!1),
                        onDragStart: () => $(!1),
                        onDragEnd: () => {
                            a(!0)
                        },
                        ref: Z
                    } : {}),
                    U = (0, C.C)(F, j, N);
                return F && U ? i().createElement(T, {
                    isIAMEditor: A,
                    componentId: e,
                    componentRef: Z
                }, (({
                    ref: o,
                    attributes: s,
                    listeners: a,
                    className: l
                }) => {
                    var d, p, h, g;
                    return i().createElement(S.ZC, u()({
                        a11yIdentifier: z,
                        style: Object.assign({
                            display: "flex",
                            justifyContent: "flex-start",
                            padding: `${P[y.Z.THEME_KEY].padding.top||0}px ${P[y.Z.THEME_KEY].padding.right||0}px ${P[y.Z.THEME_KEY].padding.bottom||0}px ${P[y.Z.THEME_KEY].padding.left||0}px`,
                            position: "relative"
                        }, P[y.Z.THEME_KEY].blockBackgroundColor ? {
                            backgroundColor: P[y.Z.THEME_KEY].blockBackgroundColor
                        } : {}, _ ? {
                            cursor: "pointer"
                        } : {}, {
                            flex: !1 !== (null == F || null == (d = F.data) || null == (d = d.styling) ? void 0 : d.fullWidth) ? "1 0 0" : "0 1 auto"
                        }, !1 === (null == F || null == (p = F.data) || null == (p = p.styling) ? void 0 : p.fullWidth) && {
                            margin: k[null != (h = null == F || null == (g = F.data) ? void 0 : g.styling.alignment) ? h : "center"]
                        })
                    }, q, {
                        ref: A ? o : Z
                    }, s, a, {
                        "data-testid": "form-component",
                        className: v()({
                            notranslate: !1
                        }, l)
                    }), O && c && m && !f ? i().createElement(V, {
                        theme: P,
                        active: L,
                        componentId: e,
                        componentPosition: t,
                        componentRef: Z.current,
                        formVersionCId: n,
                        isHovering: _,
                        rowDroppableHover: r,
                        setIsHovering: $,
                        designerFunctions: c,
                        designerInfo: m
                    }, W) : W)
                })) : null
            };
            var Z = ({
                rowId: e,
                formVersionCId: t,
                designerFunctions: n,
                designerInfo: r,
                isA11y: a
            }) => {
                const l = (0, I.Z)((t => {
                        var n;
                        return (null == (n = t.formsState.rows[e]) ? void 0 : n.components) || []
                    }), s.X),
                    c = (0, I.Z)((e => e.onsiteState.client.isDesignWorkflow)),
                    [m, u] = (0, o.useState)(!1),
                    [h, v] = (0, o.useState)(!1),
                    [g, y] = (0, o.useState)(!1),
                    b = (m ? f : h && p) || !1,
                    w = (0, o.useMemo)((() => c ? `${d.Vs}:${d.ij}:${e}` : void 0), [c, e]);
                return l.length ? i().createElement(S.ZC, {
                    a11yIdentifier: w,
                    "data-testid": "form-row",
                    style: Object.assign({
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "stretch",
                        position: "relative"
                    }, b ? Object.assign({}, "bottom" === b ? {
                        borderBottom: "2px",
                        borderBottomStyle: "solid",
                        borderBottomColor: "#2B98D3",
                        marginBottom: "-2px"
                    } : {
                        borderTop: "2px",
                        borderTopStyle: "solid",
                        borderTopColor: "#2B98D3",
                        marginTop: "-2px"
                    }) : {})
                }, l.map(((e, o) => i().createElement($, {
                    key: e,
                    componentId: e,
                    componentPosition: o,
                    formVersionCId: t,
                    rowDroppableHover: (e, t) => {
                        e === f ? u(t) : v(t)
                    },
                    setDragState: e => y(e),
                    dragFinished: g,
                    designerFunctions: n,
                    designerInfo: r,
                    isA11y: a
                }))), null) : null
            };
            const F = ({
                    children: e
                }) => e,
                O = {
                    .5: "35%",
                    1: "50%",
                    2: "65%"
                };
            var A = ({
                    columnId: e,
                    formVersionCId: t,
                    formVersionId: n,
                    viewId: r,
                    sideImageExistsAndHidden: a,
                    isFullscreen: l,
                    designerFunctions: c,
                    designerInfo: m,
                    isA11y: f
                }) => {
                    var p, h, v, g, y;
                    const b = (0, o.useRef)(null),
                        [w, E] = (0, o.useState)(!1),
                        _ = (0, I.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        k = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) || null == (t = t.data) ? void 0 : t.sideImage
                        }), s.X),
                        V = (0, I.Z)((t => {
                            var n;
                            return (null == (n = t.formsState.columns[e]) ? void 0 : n.rows) || []
                        }), s.X),
                        T = (0, I.Z)((t => t.formsState.columns[e]), s.X),
                        $ = (0, I.Z)((e => (0, x.l)(e, r)), s.X),
                        A = (0, o.useMemo)((() => _ ? `${d.PF}:${d.k_}:${e}` : void 0), [_, e]);
                    if (!T) return null;
                    const M = null == m ? void 0 : m.activeColumnId,
                        {
                            padding: B,
                            minimumHeight: D
                        } = $,
                        N = void 0 !== (null == (p = T.data) || null == (p = p.styling) ? void 0 : p.sizeMultiplier) && 0 === T.rows.length,
                        {
                            columnMargin: j,
                            columnPadding: R
                        } = ((e, t, n, o) => {
                            const i = {
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0
                                },
                                r = {
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0
                                };
                            return o || void 0 !== n && (e ? (i.top = t && t.top ? -1 * t.top : 0, i.bottom = t && t.bottom ? -1 * t.bottom : 0, 0 === n ? i.left = t && t.left ? -1 * t.left : 0 : 1 === n && (i.right = t && t.right ? -1 * t.right : 0)) : 0 === n ? r.left = (null == t ? void 0 : t.left) || 0 : 1 === n && (r.right = (null == t ? void 0 : t.right) || 0)), {
                                columnMargin: i,
                                columnPadding: r
                            }
                        })(N, B, null == k ? void 0 : k.position, a),
                        P = null == (h = T.data) || null == (h = h.styling) ? void 0 : h.sizeMultiplier,
                        z = null == $ ? void 0 : $.size,
                        H = P && z ? ((e, t, n) => {
                            const o = e / (e + 1) * t;
                            return n ? o : t - o
                        })(P, z, N) : 0,
                        W = M === T.columnId,
                        L = (null == $ ? void 0 : $.borderStyle) && "none" !== (null == $ ? void 0 : $.borderStyle) && (null == $ ? void 0 : $.borderWidth) || 0,
                        q = null == (v = T.data) || null == (v = v.styling) ? void 0 : v.backgroundImage,
                        U = null == (g = T.data) || null == (g = g.styling) ? void 0 : g.backgroundColor,
                        K = Object.assign({}, _ && N ? {
                            onClick: () => {
                                c && c.setActiveSidebar({
                                    type: d.aC,
                                    key: e
                                })
                            },
                            onMouseOver: () => {
                                E(!0)
                            },
                            onMouseLeave: () => E(!1),
                            ref: b
                        } : {}),
                        G = null == m ? void 0 : m.mobileDesktopType,
                        Y = (null == (y = T.rows) ? void 0 : y.length) > 0 || k && (0, C.V)(k, _, G || d.q5, T),
                        X = N ? Object.assign({
                            borderColor: "transparent",
                            borderStyle: "solid",
                            borderWidth: $.borderWidth
                        }, 1 === (null == k ? void 0 : k.position) ? {
                            borderBottomRightRadius: $.borderRadius,
                            borderTopRightRadius: $.borderRadius,
                            marginRight: j.right - $.borderWidth,
                            borderLeft: 0
                        } : {
                            borderBottomLeftRadius: $.borderRadius,
                            borderTopLeftRadius: $.borderRadius,
                            marginLeft: j.left - $.borderWidth,
                            borderRight: 0
                        }, {
                            marginBottom: j.bottom - $.borderWidth,
                            marginTop: j.top - $.borderWidth,
                            overflow: "hidden"
                        }) : {},
                        J = e => {
                            switch (e) {
                                case "center":
                                    return "center";
                                case "left":
                                case "top":
                                    return "start";
                                case "right":
                                case "bottom":
                                    return "end";
                                default:
                                    return
                            }
                        },
                        Q = e => {
                            switch (e) {
                                case "center":
                                    return "50%";
                                case "right":
                                case "top":
                                    return "0";
                                default:
                                    return
                            }
                        };
                    return Y ? i().createElement(S.ZC, u()({
                        a11yIdentifier: A,
                        title: N || null == q ? void 0 : q.altText,
                        style: Object.assign({
                            display: "flex",
                            flexDirection: "column",
                            width: H ? `${H}px` : "100%",
                            marginTop: `${j.top}px`,
                            marginBottom: `${j.bottom}px`,
                            marginLeft: `${j.left}px`,
                            marginRight: `${j.right}px`,
                            paddingTop: `${R.top}px`,
                            paddingBottom: `${R.bottom}px`,
                            paddingLeft: `${R.left}px`,
                            paddingRight: `${R.right}px`
                        }, X, {
                            backgroundColor: U
                        }, w && {
                            cursor: "pointer"
                        }, H && {
                            minWidth: `${H}px`
                        }, void 0 !== D && !l && {
                            minHeight: `${D}px`
                        }, !N && {
                            justifyContent: "center"
                        }, l && !N && {
                            margin: "0 auto",
                            minWidth: "100px",
                            maxWidth: `${z}px`,
                            width: `${z}px`
                        }, l && P && {
                            position: "relative",
                            maxWidth: O[P],
                            width: "100%"
                        })
                    }, K), N && q && i().createElement(S.ZC, {
                        a11yIdentifier: A,
                        style: Object.assign({
                            width: "100%",
                            height: "100%",
                            position: "relative"
                        }, "custom" === (null == q ? void 0 : q.position) && (null == q ? void 0 : q.customWidth) < H && {
                            display: "flex",
                            justifyContent: J(null == q ? void 0 : q.alignment) || "center",
                            alignItems: J(null == q ? void 0 : q.verticalAlignment) || "center"
                        })
                    }, i().createElement(S.Ei, {
                        src: null == q ? void 0 : q.url,
                        alt: null == q ? void 0 : q.altText,
                        style: q && Object.assign({}, "custom" === (null == q ? void 0 : q.position) ? Object.assign({
                            width: `${null==q?void 0:q.customWidth}px`,
                            height: "auto"
                        }, (null == q ? void 0 : q.customWidth) > H && {
                            position: "absolute",
                            left: "left" === (null == q ? void 0 : q.alignment) ? 0 : void 0,
                            right: Q(null == q ? void 0 : q.alignment),
                            top: Q(null == q ? void 0 : q.verticalAlignment),
                            bottom: "bottom" === (null == q ? void 0 : q.verticalAlignment) ? 0 : void 0,
                            transform: `translate(${"center"===(null==q?void 0:q.alignment)?"50%":0}, ${"center"===(null==q?void 0:q.verticalAlignment)?"-50%":0})`
                        }) : {
                            width: "100%",
                            height: "100%",
                            objectFit: null == q ? void 0 : q.position,
                            objectPosition: `${(null==q?void 0:q.alignment)||"center"} ${(null==q?void 0:q.verticalAlignment)||"center"}`
                        })
                    })), i().createElement(F, {
                        backgroundColorExists: !!U,
                        backgroundImageExists: !!q,
                        calculatedWidth: H,
                        column: T,
                        isDesignWorkflow: _,
                        isHovering: w,
                        isSelected: W,
                        isSideImageColumn: N,
                        viewBorderWidth: L,
                        viewSize: z,
                        isFullscreen: l
                    }, null == V ? void 0 : V.map((e => i().createElement(Z, {
                        key: e,
                        rowId: e,
                        formVersionCId: t,
                        designerFunctions: c,
                        designerInfo: m,
                        isA11y: f
                    }))))) : null
                },
                M = n(65916),
                B = n(38799),
                D = n(2534);
            let N, j = e => e;
            const R = {
                    left: {
                        float: "left"
                    },
                    center: {
                        margin: "0 auto"
                    },
                    right: {
                        float: "right"
                    }
                },
                P = (e, t, n) => t ? null != n && n.includes("BOTTOM") ? `${e}px ${e}px 0 0` : `0 0 ${e}px ${e}px` : `${e}px`;
            var z = ({
                    viewId: e,
                    isEmbed: t,
                    formVersionId: n,
                    formVersionCId: m,
                    isDocked: u,
                    formTypeDirection: f,
                    designerFunctions: p,
                    designerInfo: h,
                    isA11y: v
                }) => {
                    var g, y;
                    const b = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) ? void 0 : t.formId
                        })),
                        w = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) ? void 0 : t.formType
                        })),
                        E = (0, I.Z)((t => t.formsState.views[e] ? Object.values(t.formsState.columns).filter((e => !!e)).filter((n => {
                            var o;
                            return null == (o = t.formsState.views[e]) ? void 0 : o.columns.includes(n.columnId)
                        })).sort(((e, t) => e.position - t.position)) : []), s.X),
                        _ = (0, I.Z)((e => {
                            const t = E.reduce(((e, t) => (t.rows.forEach((t => {
                                e.push(t)
                            })), e)), []).reduce(((t, n) => {
                                var o;
                                return null == (o = e.formsState.rows[n]) || o.components.forEach((e => {
                                    t.push(e)
                                })), t
                            }), []).map((t => e.formsState.components[t]));
                            return Object.values(e.formsState.actions || {}).filter((e => !!e && t.find((t => (null == t ? void 0 : t.actionId) === e.actionId && l.Fz.has(e.actionType)))))
                        }), s.X),
                        k = (0, I.Z)((t => (0, x.l)(t, e)), s.X),
                        V = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) || null == (t = t.data) ? void 0 : t.sideImage
                        }), s.X),
                        T = (0, I.Z)((t => Object.values(t.formsState.columns).filter((t => (null == t ? void 0 : t.viewId) === e)).find((e => (null == e ? void 0 : e.position) === (null == V ? void 0 : V.position))))),
                        $ = null == V || null == (g = V.data) || null == (g = g.styling) ? void 0 : g.sizeMultiplier,
                        Z = $ ? (0, M.Z)($, k.size) : 0,
                        F = (0, I.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        O = null == h ? void 0 : h.mobileDesktopType,
                        z = V && !(0, C.V)(V, F, O || d.q5, T),
                        H = k.isReflow,
                        W = z ? k.size - Z : void 0,
                        L = (0, o.useMemo)((() => F ? `${d.Sq}:${d.Pg}:${e}` : void 0), [F, e]),
                        q = w === B.DV && H ? {
                            minWidth: `${c.Gg}px`,
                            maxWidth: `${W||k.size}px`
                        } : {
                            width: `${W||k.size}px`,
                            minWidth: `${c.Gg}px`,
                            maxWidth: `${c.Ez}px`
                        };
                    return i().createElement(S.l0, {
                        a11yIdentifier: L,
                        "aria-live": "polite",
                        style: Object.assign({
                            display: "flex",
                            flexDirection: "row",
                            boxSizing: "border-box"
                        }, t ? Object.assign({
                            width: "100%",
                            overflow: "visible"
                        }, k.isMaxWidth ? {
                            maxWidth: `${k.size}px`
                        } : {}, k.embedAlignment ? R[k.embedAlignment] : {}) : Object.assign({}, w !== B.UW && w !== B.Mk ? q : {
                            overflow: "auto",
                            height: "fit-content",
                            minHeight: "100%"
                        }), {
                            borderRadius: `${P(k.borderRadius,u,f)}`,
                            borderStyle: k.borderStyle,
                            borderWidth: `${k.borderWidth||0}px`,
                            borderColor: k.borderColor,
                            backgroundColor: k.backgroundColor,
                            backgroundImage: k.backgroundImage ? `url(${k.backgroundImage.url})` : void 0,
                            backgroundRepeat: "no-repeat",
                            backgroundSize: k.backgroundImage && ("custom" === k.backgroundImage.position ? `${k.backgroundImage.customWidth}px` : k.backgroundImage.position) || void 0,
                            backgroundPositionX: k.backgroundImage ? k.backgroundImage.alignment : void 0,
                            backgroundPositionY: (null == (y = k.backgroundImage) ? void 0 : y.verticalAlignment) || "center",
                            paddingTop: `${k.padding.top}px`,
                            paddingRight: `${k.padding.right}px`,
                            paddingBottom: `${k.padding.bottom}px`,
                            paddingLeft: `${k.padding.left}px`,
                            flex: 1
                        }),
                        className: `klaviyo-form klaviyo-form-version-cid_${m} ${(0,r.iv)(N||(N=j`
        &&& {
          [href]:focus-visible {
            outline-width: 2px;
            outline-style: auto;
            outline-color: ${0};
          }
        }
      `),k.focusColor)}`,
                        "data-testid": `klaviyo-form-${b}`,
                        noValidate: !0,
                        onSubmit: async e => {
                            if (e.preventDefault(), 1 !== _.length) return !1;
                            const t = _[0];
                            if (!t) return !1;
                            const {
                                actionId: n
                            } = t, o = (0, a.j)({
                                actionId: n,
                                formVersionCId: m,
                                getState: I.Z.getState
                            });
                            return await new o({
                                actionId: n,
                                formVersionCId: m,
                                getState: I.Z.getState
                            }).runAction(), !0
                        }
                    }, i().createElement(D.y, {
                        formType: w,
                        style: {
                            display: "flex"
                        }
                    }, E.map((t => i().createElement(A, {
                        key: t.columnId,
                        columnId: t.columnId,
                        formVersionCId: m,
                        formVersionId: n,
                        viewId: e,
                        sideImageExistsAndHidden: z,
                        isFullscreen: w === B.UW,
                        designerFunctions: p,
                        designerInfo: h,
                        isA11y: v
                    }))), i().createElement("input", {
                        style: {
                            display: "none"
                        },
                        type: "submit",
                        tabIndex: -1,
                        value: "Submit"
                    })))
                },
                H = z
        },
        63946: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return X
                }
            });
            var o = n(23409),
                i = n(81955),
                r = n(18359),
                s = n.n(r),
                a = n(67895),
                l = n.n(a),
                d = (n(92461), n(70818), n(60873), n(61099), n(23034)),
                c = n(57829),
                m = n(38799),
                u = n(78446),
                f = (n(39265), n(80101)),
                p = n(40910),
                h = n(20323),
                v = n(74872),
                g = n(32737),
                y = n(24567);
            let I, b, S = e => e;
            var w = ({
                dynamicButtonId: e,
                a11yIdentifierBlock: t,
                onClick: n
            }) => {
                const i = (0, c.Z)((t => {
                        var n;
                        return t.formsState.dynamicButtons && (null == (n = t.formsState.dynamicButtons[e]) || null == (n = n.data) ? void 0 : n.label)
                    })),
                    a = (0, c.Z)((t => {
                        var n;
                        return t.formsState.dynamicButtons && (null == (n = t.formsState.dynamicButtons[e]) || null == (n = n.data) ? void 0 : n.textStyles)
                    })),
                    l = (0, c.Z)((t => {
                        var n;
                        return t.formsState.dynamicButtons && (null == (n = t.formsState.dynamicButtons[e]) || null == (n = n.data) ? void 0 : n.buttonStyles)
                    })),
                    d = (0, r.useMemo)((() => null != l && l.alignment ? "left" === (null == l ? void 0 : l.alignment) ? "justify-self: left; align-self: start;" : "right" === (null == l ? void 0 : l.alignment) ? "justify-self: right; align-self: end;" : "justify-self: center; align-self: center;" : "justify-self: center; align-self: center;"), [l]),
                    m = (0, r.useMemo)((() => {
                        var e, t, n, i, r, s, c, m, u, f, p, h, v, g, y, w, C, x, E, _;
                        return {
                            outerDiv: (0, o.iv)(I || (I = S `
        &&& {
          & {
            ${0}
          }
        }
      `), "fitToText" === (null == l ? void 0 : l.width) ? d : ""),
                            button: (0, o.iv)(b || (b = S `
        &&& {
          & {
            text-align: center;
            color: ${0};
            font-family: ${0};
            font-size: ${0}px;
            font-style: ${0};
            font-weight: ${0};
            letter-spacing: ${0}px;
            text-decoration: ${0};

            background-color: ${0};
            border-radius: ${0}px;
            height: ${0}px;

            width: ${0};
            ${0}
            cursor: pointer;

            ${0}

            ${0}
          }
        }
      `), null != (e = null == a ? void 0 : a.fontColor) ? e : "#FFFFFF", null != (t = null == a ? void 0 : a.fontFamily) ? t : "", null != (n = null == a ? void 0 : a.fontSize) ? n : 16, null != (i = null == a ? void 0 : a.fontStyle) ? i : "", null != (r = null == a ? void 0 : a.fontWeight) ? r : "", null != (s = null == a ? void 0 : a.letterSpacing) ? s : 0, null != (c = null == a ? void 0 : a.textDecoration) ? c : "", null != (m = null == l ? void 0 : l.color) ? m : "#000000", null != (u = null == l ? void 0 : l.borderRadius) ? u : 4, null != (f = null == l ? void 0 : l.height) ? f : 44, "fitToText" === (null == l ? void 0 : l.width) ? "fit-content" : "100%", "fitToText" === (null == l ? void 0 : l.width) ? "padding: 0 10px;" : "", null != l && null != (p = l.border) && p.enabled ? `\n                  border-style: ${null!=(h=null==l||null==(v=l.border)?void 0:v.style)?h:"solid"};\n                  border-width: ${null!=(g=null==l||null==(y=l.border)?void 0:y.width)?g:1}px;\n                  border-color: ${null!=(w=null==l||null==(C=l.border)?void 0:C.color)?w:"#000000"};\n                ` : "", null != l && null != (x = l.dropShadow) && x.enabled ? `\n                  filter: drop-shadow(0px 0px 15px ${null!=(E=null==l||null==(_=l.dropShadow)?void 0:_.color)?E:"#000000"});\n                ` : "")
                        }
                    }), [a, l, d]);
                return s().createElement(y.ZC, {
                    a11yIdentifier: t,
                    className: m.outerDiv
                }, s().createElement(y.zx, {
                    a11yIdentifier: t,
                    type: "button",
                    className: m.button,
                    onClick: n
                }, i))
            };
            var C = () => {
                    const e = (0, c.Z)((e => e.onsiteState.bisPortalConfig));
                    (0, r.useEffect)((() => {
                        e && !document.getElementById(g.M) && (0, h.m)()
                    }), [e]);
                    const t = (0, r.useCallback)((() => {
                        if (e) {
                            const t = c.Z.getState(),
                                n = t.onsiteState.client.klaviyoCompanyId;
                            if (n) {
                                const o = (0, f.Z)(),
                                    i = e.formVersionId,
                                    r = Object.values(t.formsState.formVersions).find((e => (null == e ? void 0 : e.formVersionId) === i)),
                                    s = null == r ? void 0 : r.formId;
                                s && (0, p.M)({
                                    metric: v.qA,
                                    formVersionCId: o,
                                    formId: s,
                                    companyId: n
                                })
                            }
                        }
                        null == e || null == e.onClick || e.onClick()
                    }), [e]);
                    if (!e) return null;
                    const n = document.getElementById(g.M);
                    return n ? s().createPortal(s().createElement(w, {
                        dynamicButtonId: e.dynamicButtonId,
                        a11yIdentifierBlock: `bis-button-${e.formVersionId}`,
                        onClick: t
                    }), n) : null
                },
                x = n(46753),
                E = n(29676),
                _ = n(76166);
            var k = e => {
                    const [t, n] = (0, r.useState)(!1), [o, i] = (0, r.useState)(!1), s = (0, r.useRef)(null);
                    return (0, r.useEffect)((() => {
                        const t = s.current,
                            r = new IntersectionObserver((e => {
                                const [t] = e;
                                n(t.isIntersecting), t.isIntersecting && !o && i(!0)
                            }), e);
                        return t && r.observe(t), () => {
                            t && r.unobserve(t)
                        }
                    }), [e, o]), [s, {
                        isInView: t,
                        hasBeenViewed: o
                    }]
                },
                V = n(51163);
            var T = ({
                    node: e,
                    formVersionCId: t,
                    designerFunctions: n,
                    designerInfo: o,
                    isA11y: i = !1,
                    a11yViewId: a
                }) => {
                    const [l, {
                        hasBeenViewed: d
                    }] = k({
                        threshold: .1
                    }), m = (0, c.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.closed
                    })), u = (0, c.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.formId
                    })), f = (0, c.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.currentViewId
                    })), h = (0, c.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.errorViewMessage
                    })), g = (0, c.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.formVersionId
                    })), I = (0, c.Z)((e => e.onsiteState.client.klaviyoCompanyId));
                    (0, r.useEffect)((() => {
                        if (!d || !g) return;
                        const e = c.Z.getState(),
                            n = (0, V.Xk)(e, g);
                        n && ((0, p.M)({
                            metric: v.PZ,
                            formVersionCId: t,
                            logCustomEvent: !0,
                            formId: null != u ? u : "",
                            companyId: null != I ? I : "",
                            allowReTriggering: !1
                        }), (0, p.M)({
                            metric: v.n5,
                            formVersionCId: t,
                            logCustomEvent: !0,
                            formId: null != u ? u : "",
                            companyId: null != I ? I : "",
                            step_name: (0, V.E5)(e, n.viewId),
                            step_number: 1
                        }))
                    }), [u, t, d, I, g]);
                    const b = e || document.querySelector(`div.klaviyo-form-${u}.form-version-cid-${t}`),
                        S = (0, r.useMemo)((() => n ? `${_.Sq}:${_.Pg}:${f}` : void 0), [n, f]);
                    return b && !m ? (0, r.createPortal)(f && g ? s().createElement(s().Fragment, null, h ? s().createElement(E.Z, {
                        isEmbed: !0,
                        errorViewMessage: h
                    }) : s().createElement(y.ZC, {
                        ref: l,
                        a11yIdentifier: S,
                        style: Object.assign({
                            transform: "translate(0, 0)"
                        }, i ? {
                            position: "absolute",
                            transform: "scale(0.001)",
                            zIndex: 1
                        } : {})
                    }, s().createElement(x.Z, {
                        formVersionCId: t,
                        formVersionId: g,
                        viewId: a || f,
                        isEmbed: !0,
                        key: t,
                        designerFunctions: n,
                        designerInfo: o
                    }))) : null, b) : null
                },
                $ = n(67453);
            var Z = n(65047).Z,
                F = n(26655);
            var O, A, M, B, D, N, j = n(12698).Z;

            function R() {
                return R = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, R.apply(null, arguments)
            }
            var P, z = function(e) {
                return r.createElement("svg", R({
                    width: 167,
                    height: 182,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), O || (O = r.createElement("path", {
                    d: "M103.52 3.036C88.562 8.51 70.961 5.635 61.51 2.751c-1.859-.567-3.876-.444-5.586.478L5.884 30.212a6.744 6.744 0 0 0-3.122 8.281l7.907 21.32a6.744 6.744 0 0 0 6.323 4.4H27.06a6.744 6.744 0 0 1 6.744 6.743v96.876c0 2.882 1.827 5.464 4.59 6.286 34.048 10.129 71.284 4.898 89.945-.094 2.833-.757 4.708-3.363 4.708-6.294V70.956a6.744 6.744 0 0 1 6.744-6.744h10.067a6.744 6.744 0 0 0 6.323-4.398l7.884-21.256a6.743 6.743 0 0 0-3.192-8.317L109.514 3.316c-1.849-.97-4.033-.997-5.994-.28Z",
                    fill: "#E9E9E9"
                })), A || (A = r.createElement("path", {
                    d: "M55.124 1.746C57.272.587 59.76.456 62 1.139c9.305 2.839 26.483 5.603 40.94.315 2.339-.856 5.025-.853 7.356.369l51.359 26.925a8.429 8.429 0 0 1 3.989 10.397l-7.883 21.256a8.43 8.43 0 0 1-7.904 5.498h-10.067a5.058 5.058 0 0 0-5.058 5.058v96.773c0 3.644-2.34 6.956-5.958 7.923-18.824 5.035-56.403 10.333-90.862.081-3.515-1.046-5.795-4.314-5.795-7.902V70.957a5.058 5.058 0 0 0-5.058-5.058H16.992A8.43 8.43 0 0 1 9.089 60.4L1.18 39.08a8.43 8.43 0 0 1 3.902-10.351l50.04-26.983Zm5.893 2.618c-1.476-.45-3.022-.336-4.293.35L6.684 31.697a5.058 5.058 0 0 0-2.342 6.21l7.908 21.321a5.058 5.058 0 0 0 4.742 3.299H27.06a8.43 8.43 0 0 1 8.43 8.43v96.875c0 2.177 1.375 4.072 3.385 4.67 33.637 10.007 70.53 4.842 89.029-.106 2.046-.547 3.457-2.446 3.457-4.666V70.957a8.43 8.43 0 0 1 8.43-8.43h10.067a5.057 5.057 0 0 0 4.742-3.299l7.884-21.255a5.057 5.057 0 0 0-2.394-6.239L108.731 4.81c-1.368-.717-3.049-.768-4.632-.189-15.46 5.656-33.483 2.673-43.082-.256Z",
                    fill: "#FEFEFE"
                })), M || (M = r.createElement("path", {
                    d: "m47.798 7.494 8.058-3.172c27.568 8.906 44.674 2.115 52.591 0l9.33 3.172c-29.264 13.368-58.104 5.287-69.979 0ZM140.68 65.395l14.723-38.17 9.452 6.362-11.451 30.536-12.724 1.272ZM26.169 65.395l-13.572-38.17L.72 33.863l10.18 28.988 15.268 2.544Z",
                    fill: "#D5D5D6"
                })), B || (B = r.createElement("path", {
                    d: "M55.124 1.746C57.272.587 59.76.456 62 1.139c9.305 2.839 26.483 5.603 40.94.315 2.339-.856 5.025-.853 7.356.369l51.359 26.925a8.429 8.429 0 0 1 3.989 10.397l-7.883 21.256a8.43 8.43 0 0 1-7.904 5.498h-10.067a5.058 5.058 0 0 0-5.058 5.058v96.773c0 3.644-2.34 6.956-5.958 7.923-18.824 5.035-56.403 10.333-90.862.081-3.515-1.046-5.795-4.314-5.795-7.902V70.957a5.058 5.058 0 0 0-5.058-5.058H16.992A8.43 8.43 0 0 1 9.089 60.4L1.18 39.08a8.43 8.43 0 0 1 3.902-10.351l50.04-26.983Zm5.893 2.618c-1.476-.45-3.022-.336-4.293.35L6.684 31.697a5.058 5.058 0 0 0-2.342 6.21l7.908 21.321a5.058 5.058 0 0 0 4.742 3.299H27.06a8.43 8.43 0 0 1 8.43 8.43v96.875c0 2.177 1.375 4.072 3.385 4.67 33.637 10.007 70.53 4.842 89.029-.106 2.046-.547 3.457-2.446 3.457-4.666V70.957a8.43 8.43 0 0 1 8.43-8.43h10.067a5.057 5.057 0 0 0 4.742-3.299l7.884-21.255a5.057 5.057 0 0 0-2.394-6.239L108.731 4.81c-1.368-.717-3.049-.768-4.632-.189-15.46 5.656-33.483 2.673-43.082-.256Z",
                    fill: "#DEE2E4"
                })), D || (D = r.createElement("path", {
                    d: "M112.689 76.847c0 16.162-13.102 29.264-29.264 29.264-16.163 0-29.265-13.102-29.265-29.264s13.102-29.264 29.264-29.264c16.163 0 29.265 13.102 29.265 29.264Z",
                    fill: "#D5D5D6"
                })), N || (N = r.createElement("path", {
                    d: "M82.195 59.008c.388-1.193 2.075-1.193 2.463 0l3.334 10.261c.173.534.67.895 1.231.895h10.79c1.254 0 1.776 1.605.761 2.342l-8.729 6.342c-.454.33-.644.914-.47 1.448l3.334 10.26c.387 1.194-.978 2.186-1.993 1.448l-8.728-6.341a1.295 1.295 0 0 0-1.523 0l-8.728 6.341c-1.015.738-2.38-.254-1.993-1.447l3.334-10.261a1.295 1.295 0 0 0-.47-1.448l-8.729-6.342c-1.015-.737-.493-2.342.761-2.342h10.79c.56 0 1.058-.361 1.231-.895l3.334-10.261Z",
                    fill: "#FEFEFE"
                })))
            };

            function H() {
                return H = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, H.apply(null, arguments)
            }
            var W, L = function(e) {
                return r.createElement("svg", H({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, e), P || (P = r.createElement("path", {
                    fill: "currentColor",
                    fillRule: "evenodd",
                    d: "M11 3a8 8 0 1 0 4.906 14.32l3.887 3.887 1.414-1.414-3.887-3.887A8 8 0 0 0 11 3Zm-6 8a6 6 0 1 1 12 0 6 6 0 0 1-12 0Z",
                    clipRule: "evenodd"
                })))
            };

            function q() {
                return q = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, q.apply(null, arguments)
            }
            var U = function(e) {
                return r.createElement("svg", q({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, e), W || (W = r.createElement("path", {
                    fill: "currentColor",
                    fillRule: "evenodd",
                    d: "M2.5 3a1 1 0 0 1 1-1h3.28l.5 2h10.334c2.095 0 3.544 2.092 2.809 4.053L18.193 14H7.118l-.276.553A1 1 0 0 0 7.736 16H18.5a3 3 0 1 1-2.83 2h-5.34a3 3 0 1 1-4.94-1.131 2.984 2.984 0 0 1-.337-3.21L5.882 12h1.337l-2-8H3.5a1 1 0 0 1-1-1Zm16 15a1 1 0 1 0 0 2 1 1 0 0 0 0-2ZM7.78 6l1.5 6h7.527l1.743-4.649A1 1 0 0 0 17.614 6H7.781ZM6.5 19a1 1 0 1 1 2 0 1 1 0 0 1-2 0Z",
                    clipRule: "evenodd"
                })))
            };
            var K = ({
                dynamicButtonId: e
            }) => s().createElement("div", {
                style: {
                    zIndex: "1",
                    display: "flex",
                    flex: 1,
                    width: "100%",
                    alignItems: "flex-start",
                    justifyContent: "center",
                    padding: "96px 0px",
                    backgroundColor: "var(--color-surface-app-background)"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexDirection: "column",
                    width: "100%",
                    maxWidth: "880px",
                    overflow: "hidden",
                    borderRadius: "12px",
                    border: "1px solid var(--color-border-general-subtle)",
                    backgroundColor: "var(--color-surface-primary-base)"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%",
                    height: "60px",
                    alignItems: "center",
                    padding: "0px 24px",
                    backgroundColor: "var(--color-background-default-base)"
                }
            }, s().createElement("div", {
                style: {
                    width: "10%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            })), s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    width: "100%",
                    padding: "16px 24px",
                    alignItems: "center",
                    gap: "12px",
                    backgroundColor: "var(--color-background-neutral-subtle-base)",
                    color: "var(--color-background-neutral-subtle-selected)"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    height: "8px",
                    width: "44px",
                    borderRadius: "var(--unit-border-radius-lg)",
                    backgroundColor: "var(--color-background-neutral-subtle-focused)"
                }
            }), s().createElement("div", {
                style: {
                    display: "flex",
                    height: "8px",
                    width: "44px",
                    borderRadius: "var(--unit-border-radius-lg)",
                    backgroundColor: "var(--color-background-neutral-subtle-focused)"
                }
            }), s().createElement("div", {
                style: {
                    display: "flex",
                    height: "8px",
                    width: "44px",
                    borderRadius: "var(--unit-border-radius-lg)",
                    backgroundColor: "var(--color-background-neutral-subtle-focused)"
                }
            }), s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexGrow: "0.95"
                }
            }), s().createElement("span", {
                style: {
                    width: "20px",
                    height: "20px"
                }
            }, s().createElement(L, null)), s().createElement("span", {
                style: {
                    width: "20px",
                    height: "20px",
                    paddingRight: "5px"
                }
            }, s().createElement(U, null))), s().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexDirection: "row",
                    backgroundColor: "var(--color-background-default-base)"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    width: "100%",
                    padding: "48px 0 64px 48px",
                    alignItems: "center",
                    justifyContent: "center"
                }
            }, s().createElement("div", {
                style: {
                    padding: "48px",
                    borderRadius: "var(--unit-border-radius-xl)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, s().createElement(z, null))), s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexDirection: "column",
                    padding: "48px 64px 24px 24px",
                    gap: "12px"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, " "), s().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, " "), s().createElement("div", {
                style: {
                    display: "flex",
                    width: "30%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, " "), s().createElement(w, {
                dynamicButtonId: e
            }))))));
            var G = ({
                formVersionCId: e,
                node: t,
                designerFunctions: n,
                designerInfo: o
            }) => {
                const i = (0, c.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    r = (0, c.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                    })),
                    a = (0, c.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentTeaserId
                    })),
                    l = (0, c.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentDynamicButtonId
                    })),
                    d = (0, c.Z)((e => {
                        const t = e.formsState.teasers ? Object.values(e.formsState.teasers).filter((e => (null == e ? void 0 : e.formVersionId) === r)) : [];
                        return !!(t.length > 0 && t[0])
                    }));
                if (i && null === t) return null;
                const m = r => {
                    const c = s().createElement(j, {
                            formVersionCId: e,
                            closePortal: i ? () => {} : r,
                            designerFunctions: n,
                            designerInfo: o
                        }),
                        m = s().createElement(Z, {
                            formVersionCId: e,
                            closePortal: i ? () => {} : r,
                            designerFunctions: n,
                            designerInfo: o,
                            portalNode: t
                        });
                    return i ? l ? s().createElement(K, {
                        dynamicButtonId: l
                    }) : a ? c : m : s().createElement(s().Fragment, null, d && c, m)
                };
                return s().createElement($.Z, {
                    key: e,
                    defaultOpen: !0,
                    onClose: () => {
                        (0, F.zd)({
                            formVersionCId: e
                        })
                    },
                    closeOnEsc: !i,
                    node: i ? t : void 0
                }, (({
                    closePortal: e,
                    portal: t
                }) => [t(m(e))]))
            };
            var Y = () => {
                const e = (0, c.Z)((e => Object.keys(e.onsiteState.openFormVersions)), d.X),
                    t = (0, c.Z)((e => Object.values(e.onsiteState.openFormVersions).filter((e => !!e)).filter((({
                        formVersionId: t
                    }) => {
                        var n;
                        return (null == (n = e.formsState.formVersions[t]) ? void 0 : n.formType) === m.LP
                    })).map((({
                        formVersionCId: e
                    }) => e))), d.X),
                    n = (0, c.Z)((e => {
                        const t = e.formsState.dynamicButtons;
                        return !!t && Object.values(t).some((e => (null == e ? void 0 : e.type) === u.I))
                    }), d.X);
                return s().createElement(r.Suspense, {
                    fallback: s().createElement("div", null)
                }, n && s().createElement(C, null), e.map((e => {
                    const n = {
                        formVersionCId: e
                    };
                    return t.includes(e) ? s().createElement(T, l()({
                        key: e
                    }, n)) : s().createElement(G, l()({
                        key: e
                    }, n))
                })))
            };
            (0, o.cY)(i.h);
            var X = () => {
                if (document.getElementById("dynamic-react-root")) return;
                const e = document.createElement("div");
                e.setAttribute("id", "dynamic-react-root"), document.body.appendChild(e), (0, r.render)(s().createElement(Y, null), e)
            }
        },
        98355: function(e, t, n) {
            n.d(t, {
                j: function() {
                    return nt
                }
            });
            var o = n(5645),
                i = n.n(o),
                r = n(54883),
                s = n(25598),
                a = n(8638);
            class l {
                constructor({
                    formVersionCId: e,
                    actionId: t,
                    getState: n
                }) {
                    this.currentHandlerStep = "INSTANTIATED", this.formActionType = void 0, this.actionId = void 0, this.formVersionCId = void 0, this.formAction = void 0, this.formId = void 0, this.companyId = void 0, this.messageBus = void 0, this.profileEvents = void 0;
                    const o = n();
                    this.actionId = t, this.formVersionCId = e, this.formAction = (o.formsState.actions || {})[t];
                    const i = o.onsiteState.openFormVersions[e];
                    if (this.messageBus = (0, a.c)(o), !i) throw new Error("Open Form Version does not exist");
                    this.formId = i.formId, this.companyId = o.onsiteState.client.klaviyoCompanyId, this.profileEvents = {
                        formSubmitted: null,
                        formCompleted: null
                    }
                }
                runAction() {
                    return this.currentHandlerStep = "PREHANDLER", new Promise((e => e())).then((e => this.__preHandler(e))).then((e => this.__identify(e))).then((e => this.__createProfileEvents(e))).then((e => (this.currentHandlerStep = "HANDLER", e))).then((e => this.__handler(e))).then((e => (this.currentHandlerStep = "POSTHANDLER", e))).then((e => this.__postHandler(e))).catch((e => this.__errorHandler(e)))
                }
                __preHandler(e) {}
                __handler(e) {}
                __postHandler(e) {}
                __errorHandler(e) {
                    (0, s.qB)(e.toString(), {
                        formActionType: this.formActionType,
                        currentHandlerStep: this.currentHandlerStep
                    })
                }
                __identify(e) {}
                __createProfileEvents(e) {}
            }
            l.formActionType = void 0;
            var d = n(26655);
            const c = ["isSubmit"];
            class m extends l {
                constructor(e) {
                    let {
                        isSubmit: t
                    } = e;
                    super(i()(e, c)), this.isSubmit = void 0, this.isSubmit = t, this.formActionType = r.Pj
                }
                __handler() {
                    return (0, d.fK)({
                        id: this.formVersionCId,
                        changes: {
                            logCloseMetric: !this.isSubmit
                        }
                    }), (0, d.et)({
                        formVersionCId: this.formVersionCId,
                        isSubmit: this.isSubmit
                    })
                }
            }
            m.formActionType = r.Pj;
            var u = m,
                f = n(94097),
                p = (n(22923), n(92461), n(70818), n(39265), n(44159), n(71721)),
                h = n(93641),
                v = n(88449),
                g = n(20152),
                y = n(40910),
                I = n(57676),
                b = n(66510),
                S = n(38189),
                w = n(46458),
                C = n(59769),
                x = n(51163),
                E = n(74872),
                _ = n(46091),
                k = n(52534),
                V = n(30118),
                T = n(89160),
                $ = n(11371);
            var Z = (e, t, n, o) => e === r.pt || !!t[_.HD] || !!t[_.lL] && n && o,
                F = n(75455),
                O = n(40582),
                A = n(83802),
                M = n(94660);
            var B = ({
                    email: e,
                    exchangeId: t,
                    phoneNumber: n,
                    metricName: o,
                    formId: i,
                    formVersionId: r,
                    pageUrl: s,
                    deviceType: a,
                    utmParams: l,
                    isClientEvent: d = !1,
                    successStepName: c
                }) => {
                    if (!e && !n) return null;
                    const m = {
                        form: {
                            data: {
                                id: i,
                                type: "form"
                            }
                        },
                        "form-version": {
                            data: {
                                id: r,
                                type: "form-version"
                            }
                        }
                    };
                    return {
                        type: "event",
                        attributes: {
                            metric: {
                                data: {
                                    type: "metric",
                                    attributes: {
                                        name: o,
                                        service: "api"
                                    }
                                }
                            },
                            profile: {
                                data: {
                                    type: "profile",
                                    attributes: {
                                        email: e,
                                        phone_number: n,
                                        properties: {
                                            $email: e,
                                            $phone_number: n,
                                            $exchange_id: t
                                        },
                                        _kx: t
                                    }
                                }
                            },
                            properties: Object.assign({
                                form_id: i,
                                form_version_id: r,
                                page: s,
                                device_type: a,
                                $use_ip: !0,
                                $is_session_activity: !0,
                                $is_client_event: d
                            }, c ? {
                                $success_step_name: c
                            } : {}, l)
                        },
                        relationships: m
                    }
                },
                D = n(82233);
            const N = () => {
                var e, t;
                return !(null == (e = window.Shopify) || null == (e = e.analytics) || !e.visitor) && "function" == typeof(null == (t = window.Shopify) || null == (t = t.analytics) ? void 0 : t.visitor)
            };
            n(51778), n(61099), n(70917), n(93677), n(84304), n(75723), n(20696), n(38528), n(72418);
            var j = n(12948),
                R = n(83187),
                P = n(87100);
            n(60873);
            var z = n(93111),
                H = n(57829),
                W = n(72397);
            var L = n(10431),
                q = n(51627),
                U = n(96288);
            const K = "form-view",
                G = "form-version";
            class Y extends Error {
                constructor() {
                    super(), this.constructor = Y, Object.setPrototypeOf(this, Y.prototype), this.message = "No outcome_view_id return in in response from API"
                }
            }
            const X = ({
                    formVersionId: e,
                    formViewId: t,
                    profile: n,
                    companyId: o
                }) => {
                    const i = (({
                        formVersionId: e,
                        formViewId: t,
                        profile: n
                    }) => ({
                        data: {
                            type: "form-outcome-view",
                            attributes: {
                                profile: {
                                    data: {
                                        type: "profile",
                                        attributes: {
                                            email: n.email,
                                            phone_number: n.phoneNumber,
                                            _kx: n._kx
                                        }
                                    }
                                }
                            },
                            relationships: {
                                [G]: {
                                    data: {
                                        type: G,
                                        id: e
                                    }
                                },
                                [K]: {
                                    data: {
                                        type: K,
                                        id: t
                                    }
                                }
                            }
                        }
                    }))({
                        formVersionId: e,
                        formViewId: t,
                        profile: n
                    });
                    return (0, h.W)((() => ((e, t) => fetch(`https://a.klaviyo.com/client/form-outcome-views/?company_id=${e}`, {
                        method: "POST",
                        headers: Object.assign({
                            "Access-Control-Allow-Headers": "*",
                            "Content-Type": "application/json"
                        }, (0, q.h)(), {
                            revision: "2025-01-15"
                        }),
                        body: JSON.stringify(t)
                    }))(o, i)), 5, 1e3 + 1e3 * Math.random(), [429])
                },
                J = async e => {
                    var t;
                    let n;
                    const o = e => {
                        var t, o;
                        (t = e) instanceof CustomEvent && (null == (o = t.detail) ? void 0 : o.captchaUrl) && (window.DataDomeCaptchaDisplayed = !0, n = e.detail.captchaUrl)
                    };
                    window.addEventListener(T.Pp, o, !1), await (0, U.l)();
                    const i = await X(e);
                    if (window.removeEventListener(T.Pp, o, !1), n) throw new A.a({
                        captchaUrl: n
                    });
                    if (429 === i.status) throw new A.TT;
                    if (202 !== i.status) throw new Y;
                    const r = await i.json();
                    if (null == r || null == (t = r.data) || null == (t = t.attributes) || !t.outcome_view_id) throw new Y;
                    return r
                };
            var Q = n(40270);
            class ee {
                constructor(e, t) {
                    this.openFormVersion = void 0, this.identifiers = void 0, this.profile = {}, this.openFormVersion = e, this.identifiers = t
                }
                checkForViewSideEffects(e) {
                    return {
                        componentSideEffects: this.getComponentSideEffects(e)
                    }
                }
                runViewSideEffects(e) {
                    return e.componentSideEffects.map((({
                        component: e,
                        viewIds: t
                    }) => this.handleComponentSideEffect({
                        component: e,
                        viewIds: t
                    })))
                }
                checkAndRunViewSideEffects(e) {
                    const t = this.checkForViewSideEffects(e);
                    return this.runViewSideEffects(t)
                }
                getComponentSideEffects({
                    state: e
                }) {
                    const t = this.openFormVersion.currentViewId,
                        n = (0, x.nC)(e, t);
                    return (0, z.Z)(n.map((t => {
                        if (!t) return null;
                        const n = (0, W.D)(e, t.componentId);
                        return n.length < 1 ? null : {
                            component: t,
                            viewIds: n
                        }
                    })))
                }
                handleComponentSideEffect({
                    component: e,
                    viewIds: t
                }) {
                    return "SPIN_TO_WIN" === e.componentType ? this.handleSpinToWin({
                        component: e,
                        viewIds: t
                    }) : console.warn(`Unhandled component type: ${e.componentType}`)
                }
                async handleSpinToWin({
                    component: e,
                    viewIds: t
                }) {
                    var n, o;
                    if ("SPIN_TO_WIN" !== e.componentType) throw new Error("Invalid component type");
                    const i = H.Z.getState(),
                        r = i.onsiteState.client.klaviyoCompanyId,
                        {
                            formVersionId: s,
                            currentViewId: a
                        } = this.openFormVersion,
                        l = (0, p.zy)();
                    if (this.profile = {
                            email: null != (n = this.identifiers.$email) ? n : l.$email,
                            phoneNumber: null != (o = this.identifiers.$phone_number) ? o : l.$phone_number,
                            _kx: l.$exchange_id
                        }, !r || !s || !a) return null;
                    try {
                        var c, m;
                        const e = await J({
                                companyId: r,
                                formVersionId: s,
                                formViewId: a,
                                profile: this.profile
                            }),
                            n = null == e || null == (c = e.data) || null == (c = c.attributes) ? void 0 : c.outcome_view_id,
                            o = null == e || null == (m = e.data) || null == (m = m.attributes) ? void 0 : m.coupon_code;
                        if (t.forEach((e => {
                                H.Z.setState((t => ((e, {
                                    parentViewId: t,
                                    childViewId: n
                                }) => t && n ? Object.assign({}, e, {
                                    onsiteState: Object.assign({}, e.onsiteState, {
                                        dynamicViewOverrides: Object.assign({}, e.onsiteState.dynamicViewOverrides, {
                                            [t]: n
                                        })
                                    })
                                }) : e)(t, {
                                    parentViewId: e,
                                    childViewId: n
                                })))
                            })), n) {
                            const e = (0, w.bc)(i, n);
                            o && e && H.Z.setState((t => (0, Q.W)({
                                componentId: e,
                                couponCode: o
                            }, t))), this.trackOutcomeViewCalculation({
                                outcomeViewId: n,
                                couponCode: o
                            })
                        }
                        return new Promise((e => {
                            setTimeout((() => e()), L.Rd)
                        }))
                    } catch (e) {
                        return e instanceof Error && (0, j.T)(e, {
                            extra: {
                                companyId: r,
                                formVersionId: s,
                                formViewId: a,
                                profileIdentifiers: JSON.stringify(this.profile)
                            }
                        }), (0, d.Cm)({
                            id: this.openFormVersion.formVersionCId,
                            changes: {
                                errorViewMessage: V.xl
                            }
                        }), null
                    }
                }
                trackOutcomeViewCalculation({
                    outcomeViewId: e,
                    couponCode: t
                }) {
                    var n;
                    const o = H.Z.getState();
                    (0, y.M)(Object.assign({
                        metric: t ? E.JO : E.Q$,
                        formVersionCId: this.openFormVersion.formVersionCId,
                        formId: this.openFormVersion.formId,
                        companyId: null != (n = o.onsiteState.client.klaviyoCompanyId) ? n : "",
                        currentViewId: this.openFormVersion.currentViewId,
                        outcomeViewId: e
                    }, t && {
                        couponCode: t
                    }))
                }
            }
            const te = e => e instanceof A.TT,
                ne = new Set;
            var oe = class extends l {
                    constructor(e) {
                        super(e), this.hiddenFieldsComponentId = void 0, this.getState = void 0, this.composedFields = void 0;
                        const t = e.getState();
                        this.getState = e.getState, this.hiddenFieldsComponentId = (0, w.cA)(t, e.actionId), this.composedFields = (0, C.$f)({
                            state: t,
                            formVersionCId: this.formVersionCId,
                            hiddenFieldsComponentId: this.hiddenFieldsComponentId,
                            formActionType: this.formAction.actionType
                        })
                    }
                    get previousListRelationships() {
                        var e;
                        const t = this.getState(),
                            {
                                previousFormSubmitBody: n
                            } = t.onsiteState.client,
                            o = null == n || null == (e = n.data) || null == (e = e.relationships) || null == (e = e.list) || null == (e = e.data) ? void 0 : e.id;
                        return o ? {
                            list: {
                                data: {
                                    type: k._,
                                    id: o
                                }
                            }
                        } : {}
                    }
                    get listRelationships() {
                        return this.formAction.listId ? {
                            list: {
                                data: {
                                    type: k._,
                                    id: this.formAction.listId
                                }
                            }
                        } : {}
                    }
                    get formRelationships() {
                        const e = this.getState().onsiteState.openFormVersions[this.formVersionCId];
                        return this.formId && null != e && e.formVersionId ? {
                            form: {
                                data: {
                                    type: "form",
                                    id: this.formId
                                }
                            },
                            "form-version": {
                                data: {
                                    type: "form-version",
                                    id: null == e ? void 0 : e.formVersionId
                                }
                            }
                        } : {}
                    }
                    async __preHandler() {
                        if (this.formAction.actionType && r.NB.has(this.formAction.actionType)) {
                            const e = await (0, d.eN)({
                                formVersionCId: this.formVersionCId
                            });
                            if (e && e.some((({
                                    valid: e
                                }) => !e))) throw new A.mN({
                                type: "form"
                            });
                            const t = this.getState(),
                                n = t.onsiteState.openFormVersions[this.formVersionCId];
                            if (null == n || !n.currentViewId) return !0;
                            const o = n.currentViewId;
                            if (ne.has(o)) return !0;
                            const i = new ee(n, this.composedFields).checkAndRunViewSideEffects({
                                state: t
                            });
                            return ne.add(o), await Promise.allSettled(i), !0
                        }
                        return !0
                    }
                    __requestUniqueID() {
                        (e => {
                            const t = {
                                method: "POST",
                                headers: {
                                    "content-type": "application/json",
                                    "Access-Control-Allow-Origin": "*"
                                },
                                body: JSON.stringify((0, R.Y)(e))
                            };
                            return (0, P.Z)("https://a.klaviyo.com/ajax/sms/subscribe_unique_id", t).then((e => {
                                if (e.status >= 500) throw Error(`Error sending request: ${e.url}`);
                                return e
                            })).then((e => e.json())).then((e => (0, R._)(e)))
                        })({
                            companyId: this.companyId,
                            form_id: this.formId,
                            email: this.composedFields[_.HD]
                        }).then((({
                            data: {
                                uniqueId: e
                            }
                        }) => {
                            void 0 !== e && (0, S.UY)({
                                smsSubscriptionUniqueId: e
                            })
                        })).catch((() => {}))
                    }
                    __errorHandler(e) {
                        const {
                            composedFields: t,
                            formId: n,
                            companyId: o,
                            formAction: i
                        } = this;
                        if (l.prototype.__errorHandler.call(this, e), (e => [A.vS, A.mN, A.a, A.FR].some((t => e instanceof t)))(e)) throw e;
                        (0, d.Cm)({
                            id: this.formVersionCId,
                            changes: {
                                errorViewMessage: te(e) ? V.gl : V.xl
                            }
                        }), (0, y.M)({
                            metric: te(e) ? E.yH : E.DF,
                            formVersionCId: this.formVersionCId,
                            formId: n,
                            companyId: o,
                            submittedFields: t,
                            listId: null == i ? void 0 : i.listId,
                            isProgressEventError: (0, A.pS)(e),
                            errorName: e.name,
                            errorMessage: e.message
                        }), (0, A.pS)(e) || te(e) || (0, j.T)(e, {
                            tags: {
                                onSubmit: "True"
                            },
                            extra: {
                                submitAction: !0,
                                formId: this.formId,
                                companyId: this.companyId
                            }
                        })
                    }
                },
                ie = n(9622),
                re = n(88013);
            var se = class extends oe {
                    constructor(e) {
                        super(e), this.getState = void 0, this.getState = e.getState, this.__handler = this.__handler.bind(this), this.__postHandler = this.__postHandler.bind(this), this.__baseSubmitToList = this.__baseSubmitToList.bind(this), this.__createProfileEvents = this.__createProfileEvents.bind(this), this.saveProfileEventsToClass = this.saveProfileEventsToClass.bind(this)
                    }
                    submitMetric({
                        state: e,
                        isSubscribe: t = !1,
                        submitMetric: n = E.dm,
                        submitMetricActionType: o = "Submit Form"
                    }) {
                        const i = e.onsiteState.openFormVersions[this.formVersionCId];
                        if (!i) throw new Error("Open Form Version does not exist");
                        const {
                            currentViewId: r
                        } = i, s = (0, ie.f8)(e, this.formVersionCId, t), a = (0, x.E5)(e, r), l = e.formsState.views[r], c = l ? (0, x.O)(e, l) : void 0, m = [(0, y.M)({
                            metric: E.AH,
                            formVersionCId: this.formVersionCId,
                            logCustomEvent: !0,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: Object.assign({}, this.composedFields, {
                                $step_name: a
                            }),
                            step_name: a,
                            step_number: void 0 !== c ? c + 1 : c,
                            action_type: "Submit Step"
                        })];
                        if ((0, x.Qe)(e, r)) {
                            const t = this._trackSpinToWinSubmit(e, i, a, c);
                            t && m.push(t)
                        }
                        return (t || (0, C.Gt)(e, this.formVersionCId, s)) && m.push((0, y.M)({
                            metric: n,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: this.composedFields,
                            action_type: o
                        })), i && E.us.indexOf(s) < E.us.indexOf(i.topHierarchySubmitted) && (0, d.fK)({
                            id: this.formVersionCId,
                            changes: {
                                topHierarchySubmitted: s
                            }
                        }), Promise.all(m)
                    }
                    __identify() {
                        const e = (0, p.Un)();
                        let t;
                        const n = new Promise((e => {
                                t = e
                            })),
                            o = this.getState(),
                            i = (0, C.jo)(o, this.formVersionCId, void 0, this.composedFields);
                        let r = Object.assign({}, this.composedFields);
                        return i.opt_in_promotional_whatsapp && (r = Object.assign({}, r, {
                            opt_in_promotional_whatsapp: i.opt_in_promotional_whatsapp
                        }), delete r.opt_in_promotional_sms), delete r.opt_in_promotional_email, !0 !== e ? Promise.resolve(null) : ((0, p.ro)({
                            fields: r,
                            relationships: this.formRelationships,
                            callback: () => (t(!0), !0)
                        }), n)
                    }
                    __handler() {
                        var e;
                        const t = this.getState(),
                            n = t.onsiteState.openFormVersions[this.formVersionCId];
                        if (!n) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: o
                        } = n;
                        !!Object.values(t.formsState.views).filter((e => (null == e ? void 0 : e.formVersionId) === o)).find((e => !!e && (0, x.nC)(t, e.viewId).find((e => {
                            const n = e ? t.formsState.components[e.componentId] : void 0;
                            return !!n && (0, w.FW)(t, n)
                        })))) && this.composedFields[_.HD] && this.__requestUniqueID();
                        const i = (0, w.B0)(t, o),
                            r = void 0 !== (0, w.CW)(t, this.formVersionCId);
                        if (!Z(this.formActionType, this.composedFields, i, r)) return this.submitMetric({
                            state: t
                        }), void(0, b.$k)({
                            formId: this.formId,
                            successActionType: this.formAction.actionType
                        });
                        const s = (0, C.jo)(t, this.formVersionCId, void 0, this.composedFields);
                        return this.composedFields = Object.assign({}, this.composedFields, s || {}), null != (e = t.formsState.formVersions[o]) && e.data.storeUtmParams && (this.composedFields = Object.assign({}, this.composedFields, (0, F.Z)())), this.__submitToList()
                    }
                    async __postHandler(e) {
                        var t, n;
                        const o = this.getState(),
                            i = o.onsiteState.openFormVersions[this.formVersionCId];
                        if (!i) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: r
                        } = i, s = (0, O.Z)(), a = !(null == (t = o.onsiteState.createdProfileEvents[this.formId]) || !t.formSubmitted);
                        a || (0, ie.LY)({
                            formId: this.formId,
                            formVersionId: r,
                            pageUrl: window.location.href,
                            deviceType: s,
                            hasSubmittedEventBeenCreated: a,
                            utmParams: (0, F.Z)()
                        });
                        const l = o.formsState.formVersions[r];
                        if (l) {
                            var d;
                            const e = (0, x.sb)(o, l.formVersionId, s, (0, C.wf)(o, this.formVersionCId)) === i.currentViewId,
                                t = !(null == (d = o.onsiteState.createdProfileEvents[this.formId]) || !d.formCompleted);
                            !t && e && (0, ie.ej)({
                                state: H.Z.getState(),
                                formId: this.formId,
                                formVersionId: r,
                                pageUrl: window.location.href,
                                deviceType: s,
                                hasCompletedEventBeenCreated: t,
                                utmParams: (0, F.Z)()
                            })
                        }
                        const c = null == o || null == (n = o.onsiteState) || null == (n = n.formSettings) ? void 0 : n.shopifyVisitorApi;
                        if (null != e && e.status && (null == e ? void 0 : e.status) >= 200 && (null == e ? void 0 : e.status) < 300 && c && N()) {
                            const {
                                syncSMSConsent: e,
                                syncEmailConsent: t
                            } = c, {
                                [_.HD]: n,
                                [_.lL]: o
                            } = this.composedFields;
                            if (!n && !o) return;
                            (({
                                email: e,
                                phone: t
                            }) => {
                                if ((e || t) && N()) {
                                    var n;
                                    let o = {};
                                    return e && (o = Object.assign({}, o, {
                                        email: e
                                    })), t && (o = Object.assign({}, o, {
                                        phone: t
                                    })), null == (n = window.Shopify) || null == (n = n.analytics) ? void 0 : n.visitor(o, {
                                        appId: D.cY.shopify.visitorApi.appId
                                    })
                                }
                            })(Object.assign({}, n && t ? {
                                email: n
                            } : {}, o && e ? {
                                phone: o
                            } : {}))
                        }
                    }
                    __submitHandlerCheck(e) {
                        const {
                            composedFields: t,
                            formId: n,
                            companyId: o,
                            formAction: i
                        } = this;
                        if (e !== k.Sz && e !== k.dl) throw (0, d.Cm)({
                            id: this.formVersionCId,
                            changes: {
                                errorViewMessage: V.xl
                            }
                        }), (0, y.M)({
                            metric: E.DF,
                            formVersionCId: this.formVersionCId,
                            formId: n,
                            companyId: o,
                            submittedFields: t,
                            listId: i.listId
                        }), new A.vS
                    }
                    __handlePassedCaptchaChallenge() {}
                    __handleSubmitToListError() {
                        const e = new AbortController,
                            {
                                signal: t
                            } = e;
                        window.addEventListener(T.H, (() => {
                            this.__handlePassedCaptchaChallenge(), (0, y.M)({
                                metric: E.uf,
                                formVersionCId: this.formVersionCId,
                                formId: this.formId,
                                companyId: this.companyId,
                                submittedFields: this.composedFields,
                                logTelemetric: !0
                            }), e.abort()
                        }), {
                            signal: t
                        }), window.addEventListener(T.vT, (() => {
                            new u({
                                actionId: this.actionId,
                                formVersionCId: this.formVersionCId,
                                getState: this.getState
                            }).runAction(), e.abort()
                        }), {
                            signal: t
                        }), (0, y.M)({
                            metric: E.Wx,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: this.composedFields,
                            logTelemetric: !0
                        })
                    }
                    __handleWAFRuleViolationError() {
                        (0, y.M)({
                            metric: E.wL,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: this.composedFields,
                            logTelemetric: !0
                        });
                        new u({
                            actionId: this.actionId,
                            formVersionCId: this.formVersionCId,
                            getState: this.getState
                        }).runAction()
                    }
                    __baseSubmitToList(e) {
                        const {
                            composedFields: t,
                            formId: n,
                            companyId: o
                        } = this, i = this.getState(), r = (0, C.io)(i, this.formVersionCId), s = this.__makePOSTBody({
                            composedFields: t,
                            requestOTPCode: r,
                            phoneInputConsentTypes: (0, w.CW)(i, this.formVersionCId)
                        });
                        return (0, S.x7)(s), (0, h.W)((() => e(o, s)), 5, 1e3 + 1e3 * Math.random(), [429]).then((e => {
                            if (429 === e.status) throw new A.TT;
                            if (403 === e.status) throw new A.FR;
                            return e
                        })).then((e => {
                            if (e.status === k.Sz && this.formAction.actionType) {
                                const t = Object.fromEntries(Object.entries(this.profileEvents).filter((([, e]) => null !== e))),
                                    o = Object.keys(t);
                                if ((0, I.Z)(this.formId, o), o.length > 0) {
                                    const e = (0, re.iv)(re.yn),
                                        t = (null == e ? void 0 : e.submittedForms) || {},
                                        i = (null == e ? void 0 : e.completedForms) || {};
                                    try {
                                        (0, re.$T)(re.yn, Object.assign({}, e, {
                                            submittedForms: Object.assign({}, t, o.includes("formSubmitted") ? {
                                                [n]: (new Date).toISOString()
                                            } : {}),
                                            completedForms: Object.assign({}, i, o.includes("formCompleted") ? {
                                                [n]: (new Date).toISOString()
                                            } : {})
                                        }))
                                    } catch (e) {
                                        console.error("Error saving session storage", e)
                                    }
                                }
                                return (0, b.$k)({
                                    formId: n,
                                    successActionType: this.formAction.actionType
                                }), (0, M.n)(200, this.submitMetric({
                                    state: i,
                                    isSubscribe: !0
                                })).then((() => e)).catch((() => e))
                            }
                            return e
                        })).catch((e => {
                            if (e instanceof A.a) throw this.__handleSubmitToListError(), e;
                            if (e instanceof A.FR || (0, v.p)(e)) return this.__handleWAFRuleViolationError(), null;
                            throw e
                        }))
                    }
                    __submitToList() {
                        return this.__baseSubmitToList(f.Y)
                    }
                    __makePOSTBody({
                        composedFields: e,
                        requestOTPCode: t = !1,
                        phoneInputConsentTypes: n
                    }) {
                        const o = new Date,
                            i = "object" == typeof window.Shopify && window.Shopify.shop ? {
                                services: JSON.stringify({
                                    shopify: {
                                        source: "form"
                                    }
                                })
                            } : {},
                            r = Object.assign({}, e, i),
                            {
                                $exchange_id: s
                            } = (0, p.zy)(),
                            {
                                attributes: a,
                                properties: l,
                                customSource: d
                            } = this.buildProfileAttributes(r),
                            c = Object.values(this.profileEvents).filter((e => null !== e)),
                            {
                                listRelationships: m,
                                formRelationships: u
                            } = this,
                            f = Object.keys(m).length > 0 || Object.keys(u).length > 0;
                        return Object.assign({
                            data: Object.assign({
                                type: k.NR,
                                attributes: Object.assign({}, c.length > 0 ? {
                                    events: {
                                        data: c
                                    }
                                } : {}, {
                                    profile: {
                                        data: {
                                            type: k.cC,
                                            attributes: Object.assign({}, a, {
                                                subscriptions: Object.assign({}, a.email && "false" !== r.opt_in_promotional_email ? {
                                                    email: {
                                                        marketing: {
                                                            consent: "SUBSCRIBED"
                                                        }
                                                    }
                                                } : {}, this.calculateSmsSubscriptionsForStep({
                                                    attributes: a,
                                                    modifiedComposedFields: r,
                                                    phoneInputConsentTypes: n
                                                }), this.calculateWhatsAppSubscriptionsForStep({
                                                    attributes: a,
                                                    modifiedComposedFields: r,
                                                    phoneInputConsentTypes: n
                                                })),
                                                properties: Object.assign({}, l, {
                                                    $timezone_offset: -o.getTimezoneOffset() / 60
                                                }, s ? {
                                                    $exchange_id: s
                                                } : {})
                                            })
                                        }
                                    }
                                }, d ? {
                                    custom_source: d
                                } : {})
                            }, f ? {
                                relationships: Object.assign({}, m, u)
                            } : {})
                        }, t ? {
                            meta: {
                                send_otp_code: !0
                            }
                        } : {})
                    }
                    __createProfileEvents() {
                        const e = this.getState(),
                            t = e.onsiteState.openFormVersions[this.formVersionCId];
                        if (!t) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: n
                        } = t, o = (0, w.B0)(e, n), i = void 0 !== (0, w.CW)(e, this.formVersionCId), r = Z(this.formActionType, this.composedFields, o, i), s = (0, p.pN)();
                        if (!r && !s) return;
                        const {
                            $exchange_id: a
                        } = (0, p.zy)();
                        s ? this.saveProfileEventsToClass(a) : this.saveProfileEventsToClass()
                    }
                    saveProfileEventsToClass(e) {
                        var t;
                        const n = this.getState(),
                            o = n.onsiteState.openFormVersions[this.formVersionCId];
                        if (!o) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: i,
                            currentViewId: r
                        } = o, s = (0, x.QR)(n, i), a = s.length, l = !(null == (t = n.onsiteState.createdProfileEvents[this.formId]) || !t.formSubmitted), d = (0, O.Z)(), c = n.formsState.formVersions[i], m = (0, re.iv)(re.yn), u = (null == m ? void 0 : m.submittedForms) || {}, f = (null == m ? void 0 : m.completedForms) || {}, p = l || this.formId in u ? null : B({
                            exchangeId: e,
                            email: this.composedFields.$email,
                            phoneNumber: this.composedFields.$phone_number,
                            formId: this.formId,
                            formVersionId: i,
                            deviceType: d,
                            pageUrl: window.location.href,
                            metricName: "Form submitted by profile",
                            utmParams: (0, F.Z)()
                        }), h = (0, C.p$)({
                            state: n,
                            formVersionId: i,
                            deviceType: d
                        }), v = this.formId in f ? null : B({
                            exchangeId: e,
                            email: this.composedFields.$email,
                            phoneNumber: this.composedFields.$phone_number,
                            formId: this.formId,
                            formVersionId: i,
                            deviceType: d,
                            pageUrl: window.location.href,
                            metricName: "Form completed by profile",
                            utmParams: (0, F.Z)(),
                            successStepName: h
                        });
                        2 === a && (this.profileEvents = {
                            formSubmitted: p,
                            formCompleted: v
                        });
                        const y = (c ? (0, x.sb)(n, c.formVersionId, d, (0, C.wf)(n, this.formVersionCId)) : void 0) === this.formAction.viewId,
                            I = s.find((({
                                viewId: e
                            }) => e === r));
                        if ((0, g.x)(I)) return;
                        const b = (0, x.ad)(n, I, d);
                        a > 2 && b.length > 1 && (this.profileEvents = Object.assign({}, this.profileEvents, {
                            formSubmitted: p
                        }), y && (this.profileEvents = Object.assign({}, this.profileEvents, {
                            formSubmitted: p,
                            formCompleted: v
                        }))), a > 2 && 1 === b.length && (this.profileEvents = Object.assign({}, this.profileEvents, {
                            formSubmitted: p,
                            formCompleted: v
                        }))
                    }
                    _trackSpinToWinSubmit(e, t, n, o) {
                        var i;
                        const r = (0, x.Qe)(e, t.currentViewId);
                        if (!r) return null;
                        const s = (0, x.Tf)(e, t.formVersionId);
                        if (!s) return null;
                        const a = (0, W.L)(e, s),
                            l = null == (i = r.data.wheelLogic.slices.find((e => e.childViewId === a))) ? void 0 : i.probability;
                        return (0, y.M)({
                            metric: E.nn,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            step_name: n,
                            step_number: void 0 !== o ? o + 1 : o,
                            componentId: r.componentId,
                            overrideViewId: a,
                            outcomeProbability: l
                        })
                    }
                    buildProfileAttributes(e) {
                        let t = Object.assign({}, e);
                        const n = {};
                        let o;
                        return "email" in e && (n.email = e.email, delete t.email), "$email" in e && (n.email = e.$email, delete t.$email), "sms_consent" in e && (e.sms_consent && (n.phone_number = e.$phone_number, delete t.$phone_number), delete t.sms_consent), "opt_in_promotional_email" in e && delete t.opt_in_promotional_email, "opt_in_promotional_sms" in e && delete t.opt_in_promotional_sms, "whatsapp_consent" in e && (e.whatsapp_consent && (n.phone_number = e.$phone_number, delete t.$phone_number), delete t.whatsapp_consent), "sentIdentifiers" in e && (t = Object.assign({}, t, e.sentIdentifiers), delete t.sentIdentifiers), _.XK.forEach((n => {
                            if (e[n]) {
                                const i = e[n];
                                o = Array.isArray(i) ? 1 === i.length ? i[0] : i.join(", ") : i, delete t[n]
                            }
                        })), {
                            attributes: n,
                            properties: t,
                            customSource: o
                        }
                    }
                    calculateSmsSubscriptionsForStep({
                        attributes: e,
                        modifiedComposedFields: t,
                        phoneInputConsentTypes: n
                    }) {
                        if (!e.phone_number) return {};
                        switch (null == n ? void 0 : n.sms) {
                            case $.E3.PROMOTIONAL:
                                return "false" === t.opt_in_promotional_sms ? {} : {
                                    sms: {
                                        marketing: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            case $.E3.TRANSACTIONAL:
                                return {
                                    sms: {
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            case $.E3.SINGLE_STEP_TRANSACTIONAL_PROMOTIONAL:
                                return {
                                    sms: Object.assign({
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }, "true" === t.opt_in_promotional_sms ? {
                                        marketing: {
                                            consent: "SUBSCRIBED"
                                        }
                                    } : {})
                                };
                            case $.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL:
                                return {
                                    sms: {
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            default:
                                return {}
                        }
                    }
                    calculateWhatsAppSubscriptionsForStep({
                        attributes: e,
                        modifiedComposedFields: t,
                        phoneInputConsentTypes: n
                    }) {
                        if (!e.phone_number) return {};
                        switch (null == n ? void 0 : n.whatsApp) {
                            case $.E3.PROMOTIONAL:
                                return "false" === t.opt_in_promotional_whatsapp ? {} : {
                                    whatsapp: {
                                        marketing: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            case $.E3.TRANSACTIONAL:
                                return {
                                    whatsapp: {
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            case $.E3.SINGLE_STEP_TRANSACTIONAL_PROMOTIONAL:
                                return {
                                    whatsapp: Object.assign({
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }, "true" === t.opt_in_promotional_whatsapp ? {
                                        marketing: {
                                            consent: "SUBSCRIBED"
                                        }
                                    } : {})
                                };
                            case $.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL:
                                return {
                                    whatsapp: {
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            default:
                                return {}
                        }
                    }
                },
                ae = n(31843);
            const le = ({
                onsiteState: e
            }, t) => {
                var n;
                return !(null == (n = e.companySenderSettings) || null == (n = n.emailSettings) || !n[t])
            };
            var de = n(92887),
                ce = n(82191),
                me = n(99385),
                ue = n(62223);
            const fe = async (e, t, n, o, i, r, a) => {
                var l, c;
                const m = (0, x.QE)(e, a);
                let u = (0, x.Tf)(e, a);
                if ((0, s.Cw)("requestShopPayShow", {
                        firstViewId: m,
                        successViewId: u
                    }), !u) return !1;
                const f = (0, W.L)(e, u);
                f && (u = f, (0, s.Cw)("requestShopPayShow", {
                    overrideSuccessViewId: f
                }));
                const p = (0, x.I_)(e, u);
                var h;
                null != p && null != (l = p[0]) && l.viewId && (u = null == p || null == (h = p[0]) ? void 0 : h.viewId, (0, s.Cw)("requestShopPayShow", {
                    skippedDynamicViewCalculation: !0,
                    overrideSuccessViewId: u
                }));
                const v = (0, x.nC)(e, u).find((e => e && (0, w.J6)(e))),
                    g = (0, w.Mh)(e, a, [$.Tg.SMS]) || (0, w.K1)(e, a),
                    I = (null == v ? void 0 : v.data.couponType) === ce.$i.STATIC ? null == v || null == (c = v.data.couponData) ? void 0 : c.text : await (0, d.zS)({
                        formVersionCId: r
                    });
                if ((0, s.Cw)("requestShopPayShow", {
                        hasCouponComponent: void 0 !== v,
                        listId: g,
                        discountCode: I
                    }), v && g && "string" == typeof I) {
                    let e, a = !0;
                    const l = new Promise((t => {
                        e = t, setTimeout((() => {
                            a && t(!0)
                        }), 5e3)
                    }));
                    return (0, ue.AN)(o, i, g, t, I, (() => {
                        a = !1, (0, S.UY)({
                            showingShopLogin: me.K.SHOWING
                        })
                    }), (() => {
                        e(!0), ((e, t) => {
                            (0, d.Cm)({
                                id: e,
                                changes: {
                                    currentViewId: t
                                }
                            })
                        })(r, n)
                    }), ((t, n) => {
                        e(!n), ((e, t, n, o, i, r) => {
                            (0, s.Cw)("onShopPayComplete"), r && (0, d.Cm)({
                                id: n,
                                changes: {
                                    currentViewId: o
                                }
                            }), (0, S.UY)({
                                showingShopLogin: me.K.CLOSED
                            }), i && e && (0, y.M)({
                                metric: i,
                                formVersionCId: n,
                                formId: t,
                                companyId: e
                            })
                        })(i, o, r, u, t, n)
                    }), (() => {
                        e(!1), ((e, t) => {
                            (0, s.Cw)("onShopPayRestart"), t ? ((0, d.Cm)({
                                id: e,
                                changes: {
                                    currentViewId: t
                                }
                            }), (0, S.UY)({
                                showingShopLogin: me.K.NEVER_SHOWN
                            })) : (0, S.UY)({
                                showingShopLogin: me.K.CLOSED
                            })
                        })(r, null != m ? m : void 0)
                    })), l
                }
                return !1
            };
            class pe extends oe {
                constructor(e) {
                    super(e), this.getState = void 0, this.getState = e.getState, this.__handler = this.__handler.bind(this), this._checkAndRemoveRedirectToInboxBtns = this._checkAndRemoveRedirectToInboxBtns.bind(this)
                }
                async __handler() {
                    var e;
                    const t = this.getState(),
                        n = t.onsiteState.openFormVersions[this.formVersionCId];
                    if (!n || !this.formAction.viewId) return null;
                    if ((0, de.mn)(t, n.formVersionId) && this.formAction.viewId && (0, de.ac)(t, this.formVersionCId, this.formAction.viewId)) {
                        const e = (0, de.Bu)(t, this.formVersionCId);
                        (0, de.rm)(e, this.companyId, t, this.formVersionCId, this.formAction.viewId, d.fK)
                    }
                    let o = this.formAction.viewId;
                    if (null != (e = t.onsiteState.dynamicViewOverrides) && e[o] && (o = (0, W.L)(t, o) || this.formAction.viewId), (0, C.wf)(t, this.formVersionCId) && "string" == typeof this.composedFields[_.HD]) {
                        if (!await fe(t, this.composedFields[_.HD], o, this.formId, this.companyId, this.formVersionCId, n.formVersionId)) return
                    }
                    return this._checkAndRemoveRedirectToInboxBtns(n.formVersionId, o), (0, d.Cm)({
                        id: this.formVersionCId,
                        changes: {
                            currentViewId: o
                        }
                    })
                }
                _checkAndRemoveRedirectToInboxBtns(e, t) {
                    const n = this.getState(),
                        o = (0, x.Tf)(n, e);
                    o && o === t && ((e, t, n, o) => {
                        var i;
                        const s = H.Z.getState(),
                            a = (s.formsState.actions ? Object.values(s.formsState.actions) : []).filter((e => (null == e ? void 0 : e.actionType) === r.Cd)).map((e => null == e ? void 0 : e.actionId));
                        if (0 === a.length) return;
                        const l = (0, x.nC)(s, o).filter((e => e && "BUTTON" === e.componentType && e.actionId && a.includes(e.actionId))).map((e => null == e ? void 0 : e.componentId));
                        if (0 === l.length) return;
                        const {
                            previousFormSubmitBody: d
                        } = s.onsiteState.client, c = null == d || null == (i = d.data) || null == (i = i.relationships) || null == (i = i.list) || null == (i = i.data) ? void 0 : i.id, m = null == d ? void 0 : d.data.attributes.profile.data.attributes[_.Td], u = (0, ae.Wt)(m || ""), f = Object.entries(s.formsState.components).filter((([, e]) => !l.includes(null == e ? void 0 : e.componentId)));
                        m && c && le(s, c) && u || ((0, y.M)({
                            metric: E.kM,
                            formVersionCId: n,
                            formId: t,
                            companyId: e,
                            userEmail: m,
                            listId: c,
                            emailProvider: u
                        }), H.Z.setState((e => Object.assign({}, e, {
                            formsState: Object.assign({}, e.formsState, {
                                components: Object.fromEntries(f)
                            })
                        }))))
                    })(this.companyId, this.formId, this.formVersionCId, o)
                }
            }
            pe.formActionType = r.hL;
            var he = pe;
            class ve extends se {
                constructor(e) {
                    super(e), this.getState = void 0, this.getState = e.getState, this.__preHandler = this.__preHandler.bind(this), this.__postHandler = this.__postHandler.bind(this), this.__handlePassedCaptchaChallenge = this.__handlePassedCaptchaChallenge.bind(this)
                }
                async __postHandler(e) {
                    super.__postHandler(e);
                    if (!this.getState().onsiteState.openFormVersions[this.formVersionCId] || !this.formAction.viewId) return null;
                    e && this.__submitHandlerCheck(e.status);
                    return new he({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
                __submitToList() {
                    return this.__baseSubmitToList(f.s)
                }
                __handlePassedCaptchaChallenge() {
                    new ve({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
            }
            ve.formActionType = r.p;
            var ge = ve;
            n(26650);
            var ye = e => {
                window.location.assign(e)
            };
            const Ie = ["isSubmit"];
            class be extends l {
                constructor(e) {
                    var t, n;
                    let {
                        isSubmit: o
                    } = e, s = i()(e, Ie);
                    super(s), this.redirectUrl = void 0, this.newWindow = void 0, this.isSubmit = void 0, this.getState = void 0, this.redirectUrl = (null == (t = this.formAction.data) ? void 0 : t.redirectUrl) || "about:blank", this.newWindow = !(null == (n = this.formAction.data) || !n.newWindow) && this.formAction.actionType === r.$b, this.isSubmit = !!o, this.formActionType = r.$b, this.getState = s.getState, this.__handler = this.__handler.bind(this)
                }
                __redirectUrl() {
                    const e = this.redirectUrl.replace(/^javascript:/, "");
                    if (this.newWindow && this.formAction.actionType === r.$b) {
                        const t = window.open(e, "_blank");
                        null == t || t.focus()
                    } else ye(e)
                }
                __handler() {
                    const {
                        formId: e,
                        newWindow: t,
                        formVersionCId: n
                    } = this;
                    this.formAction.actionType === r.$b && (0, b.$k)({
                        formId: e,
                        successActionType: r.$b
                    });
                    const o = this.getState(),
                        i = o.onsiteState.openFormVersions[n];
                    if (!i) throw new Error("Open Form Version does not exist");
                    const s = i.sentSubmitMetric,
                        a = o.formsState.views[i.currentViewId],
                        l = a ? (0, x.O)(o, a) : void 0,
                        {
                            formVersionId: d
                        } = i,
                        c = o.formsState.formVersions[d],
                        m = (0, O.Z)(),
                        u = (0, x.QR)(o, d).length,
                        f = c ? (0, x.sb)(o, c.formVersionId, m, (0, C.wf)(o, this.formVersionCId)) : void 0;
                    t || 1 !== u || f !== (null == a ? void 0 : a.viewId) || this.isSubmit || s || ((0, ie.LY)({
                        formId: this.formId,
                        formVersionId: d,
                        pageUrl: window.location.href,
                        deviceType: m,
                        hasSubmittedEventBeenCreated: !1,
                        utmParams: (0, F.Z)()
                    }), (0, ie.ej)({
                        state: H.Z.getState(),
                        formId: this.formId,
                        formVersionId: d,
                        pageUrl: window.location.href,
                        deviceType: m,
                        hasCompletedEventBeenCreated: !1,
                        utmParams: (0, F.Z)()
                    }));
                    const p = Promise.allSettled([(0, y.M)({
                        metric: E.nR,
                        logTelemetric: !this.isSubmit && !s,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        action_type: "Go to URL",
                        destination_url: this.redirectUrl
                    }), (0, y.M)({
                        metric: E._5,
                        logTelemetric: !this.isSubmit,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        action_type: "Go to URL",
                        destination_url: this.redirectUrl,
                        step_number: l ? l + 1 : void 0,
                        step_name: a ? (0, x.E5)(o, a.viewId) : void 0
                    })]);
                    return t ? (this.__redirectUrl(), p) : (0, M.n)(200, p).then((() => this.__redirectUrl())).catch((() => this.__redirectUrl()))
                }
            }
            be.formActionType = r.$b;
            var Se = be,
                we = n(76166);
            class Ce extends l {
                constructor(e) {
                    super(e), this.getState = void 0, this.formActionType = r.Cd, this.getState = e.getState, this.__handler = this.__handler.bind(this)
                }
                __handler() {
                    var e;
                    const t = this.getState(),
                        {
                            previousFormSubmitBody: n
                        } = t.onsiteState.client,
                        o = null == n ? void 0 : n.data.attributes.profile.data.attributes[_.Td],
                        i = null == n || null == (e = n.data) || null == (e = e.relationships) || null == (e = e.list) || null == (e = e.data) ? void 0 : e.id;
                    if (!o || !i || !le(t, i)) throw (0, y.M)({
                        metric: E.Yu,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        userEmail: o,
                        listId: i
                    }), new Error("Cannot redirect to inbox. Email address and list ID must both be present.");
                    const {
                        senderEmail: r,
                        subject: a
                    } = (({
                        onsiteState: e
                    }, t) => {
                        var n, o;
                        return {
                            senderEmail: null == (n = e.companySenderSettings) ? void 0 : n.emailAddress,
                            subject: null == (o = e.companySenderSettings) || null == (o = o.emailSettings) || null == (o = o[t]) ? void 0 : o.subject
                        }
                    })(t, i), l = (0, O.Z)() === we.Jq, d = (0, ae.qV)({
                        userEmail: o,
                        isMobileDevice: l,
                        subject: a,
                        senderEmail: r
                    }), {
                        link: c,
                        provider: m
                    } = d || {};
                    if ((0, y.M)({
                            metric: E.t2,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            userEmail: o,
                            listId: i,
                            sniper_link: c,
                            emailProvider: m
                        }), c) {
                        const e = window.open(c, "_blank");
                        null == e || e.focus()
                    } else(0, s.qB)(`Could not generate sniper link. User email: ${o}. List ID: ${i}. isMobileDevice: ${l}. subject: ${a}. senderEmail: ${r}`)
                }
            }
            Ce.formActionType = r.Cd;
            var xe = Ce;
            class Ee extends se {
                constructor(e) {
                    super(e), this.getState = void 0, this.getState = e.getState, this.__postHandler = this.__postHandler.bind(this), this.__handlePassedCaptchaChallenge = this.__handlePassedCaptchaChallenge.bind(this)
                }
                __postHandler(e) {
                    return super.__postHandler(e), e && this.__submitHandlerCheck(e.status), new Promise((e => {
                        if (this.composedFields.$email || this.composedFields.$phone_number) {
                            let t = 5;
                            const n = setInterval((() => {
                                ((0, p.pN)() || 0 === t) && (clearInterval(n), e(!0)), t -= 1
                            }), 600)
                        }
                        e(!0)
                    })).then((() => {
                        const {
                            formVersionCId: e,
                            actionId: t
                        } = this;
                        return new Se({
                            actionId: t,
                            formVersionCId: e,
                            getState: this.getState,
                            isSubmit: !0
                        }).runAction()
                    }))
                }
                __submitToList() {
                    return this.__baseSubmitToList(f.s)
                }
                __handlePassedCaptchaChallenge() {
                    new Ee({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
            }
            Ee.formActionType = r.uo;
            var _e = Ee;
            class ke extends se {
                constructor(e) {
                    super(e), this.getState = void 0, this.getState = e.getState, this.__postHandler = this.__postHandler.bind(this), this.__handlePassedCaptchaChallenge = this.__handlePassedCaptchaChallenge.bind(this)
                }
                __postHandler(e) {
                    super.__postHandler(e), e && this.__submitHandlerCheck(e.status);
                    const {
                        formVersionCId: t,
                        actionId: n
                    } = this;
                    return new u({
                        actionId: n,
                        formVersionCId: t,
                        getState: this.getState,
                        isSubmit: !0
                    }).runAction()
                }
                __submitToList() {
                    return this.__baseSubmitToList(f.s)
                }
                __handlePassedCaptchaChallenge() {
                    new ke({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
            }
            ke.formActionType = r.Ry;
            var Ve = ke;
            const Te = (e, t) => {
                    const n = e.onsiteState.openFormVersions[t];
                    if (!n) throw new Error("Open Form Version does not exist");
                    const {
                        formVersionId: o
                    } = n;
                    return (0, w.l1)(e, o, we.Jq).find((e => e.componentType === _.Ys))
                },
                $e = new Date("1/1/1900");

            function Ze(e) {
                return e && 6 === e.length
            }
            class Fe extends l {
                constructor(e) {
                    var t, n, o;
                    super(e), this.toPhoneNumber = void 0, this.hiddenFieldsComponentId = void 0, this.optInMessage = void 0, this.optInKeyword = void 0, this.getState = void 0, this.hiddenFieldsComponentId = (0, w.cA)(e.getState(), e.actionId), this.toPhoneNumber = null == (t = this.formAction.data) ? void 0 : t.toPhoneNumber, this.optInMessage = (null == (n = this.formAction.data) ? void 0 : n.optInMessage) || "Send this text to subscribe to SMS updates!", this.optInKeyword = (null == (o = this.formAction.data) ? void 0 : o.optInKeyword) || "JOIN", this.formActionType = r.T5, this.getState = e.getState, this.__preHandler = this.__preHandler.bind(this), this.__handler = this.__handler.bind(this)
                }
                async __preHandler() {
                    const e = this.getState(),
                        t = Te(e, this.formVersionCId);
                    if (void 0 !== t) {
                        var n;
                        const e = null == (n = await (0, d.eN)({
                            formVersionCId: this.formVersionCId
                        })) ? void 0 : n.filter((e => e.componentId === t.componentId));
                        if (e && e.some((({
                                valid: e
                            }) => !e))) throw new A.mN({
                            type: "form"
                        })
                    }
                    return !0
                }
                __handler() {
                    const e = this.getState(),
                        t = ((e, t, n) => {
                            const o = Te(e, t);
                            if (o && void 0 !== (r = o).data.format && void 0 !== r.data.delimiter) {
                                var i;
                                const o = (0, C.$f)({
                                        state: e,
                                        formVersionCId: t,
                                        hiddenFieldsComponentId: n
                                    }),
                                    r = (null == (i = e.onsiteState.openFormVersions[t]) || null == (i = i.sentIdentifiers) ? void 0 : i[_.vC]) || o[_.vC];
                                if (!r || "string" != typeof r) return;
                                const s = new Date(r).getTime() - $e.getTime();
                                return Math.round(s / 864e5).toString(36)
                            }
                            var r
                        })(e, this.formVersionCId, this.hiddenFieldsComponentId),
                        n = e.onsiteState.client.smsSubscriptionUniqueId,
                        o = ((e, t, n) => Ze(t) && n ? `${e}:${t}:${n}` : n ? `${e}:$kbday:${n}` : Ze(t) ? `${e}:${t}` : `${e}`)(this.optInKeyword, n, t),
                        i = `sms:${this.toPhoneNumber}?&body=${encodeURIComponent(`${this.optInMessage} (ref:${o})`)}`;
                    (0, b.$k)({
                        formId: this.formId,
                        successActionType: r.T5
                    }), (0, d.et)({
                        formVersionCId: this.formVersionCId,
                        isSubmit: !0
                    });
                    const s = (0, ie.f8)(e, this.formVersionCId, !0),
                        a = e.onsiteState.openFormVersions[this.formVersionCId],
                        l = a ? e.formsState.views[a.currentViewId] : void 0,
                        c = [];
                    if ((0, C.Gt)(e, this.formVersionCId, s) && c.push((0, y.M)({
                            metric: E.FB,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            action_type: "Subscribe Via SMS",
                            sms_keyword: this.optInKeyword,
                            destination_url: i
                        })), l) {
                        var m;
                        const t = null != (m = (0, x.O)(e, l)) ? m : l.position;
                        c.push((0, y.M)({
                            metric: E.AH,
                            formVersionCId: this.formVersionCId,
                            logCustomEvent: !0,
                            formId: this.formId,
                            companyId: this.companyId,
                            step_number: t + 1,
                            step_name: (0, x.E5)(e, l.viewId),
                            action_type: "Subscribe Via SMS"
                        }))
                    }
                    const u = Promise.allSettled(c);
                    return (0, M.n)(200, u).then((() => ye(i))).catch((() => ye(i)))
                }
            }
            Fe.formActionType = r.T5;
            var Oe = Fe,
                Ae = n(46456);
            let Me, Be = !1;
            class De extends oe {
                constructor(e) {
                    super(e), this.isSubmit = void 0, this.getState = void 0, this.isSubmit = !1, this.formActionType = r.WP, this.getState = e.getState, Me = null, Be || (Be = !0, this.startTimer()), this.__handler = this.__handler.bind(this)
                }
                startTimer() {
                    Me = setTimeout((() => {
                        Me = null
                    }), 5e3)
                }
                __handler() {
                    var e, t;
                    if (null !== Me) return (0, s.qB)("ResendOptInCodeAction - Resend opt in code action is currently debouncing."), Promise.resolve();
                    this.startTimer();
                    const n = this.getState(),
                        {
                            previousFormSubmitBody: o
                        } = n.onsiteState.client,
                        i = null != (e = null == o ? void 0 : o.data.attributes.profile.data.attributes[_.lL]) ? e : null == o ? void 0 : o.data.attributes.profile.data.attributes[_.HO];
                    if (!i || null == o || null == (t = o.data) || null == (t = t.relationships) || null == (t = t.list) || null == (t = t.data) || !t.id) throw new Error("Cannot resend opt in code. No previous form submit with phone number and or list id found.");
                    const r = o.data.attributes.profile.data.attributes[_.Td],
                        a = (0, Ae.Z)(o.data.attributes.profile.data.attributes.properties) ? o.data.attributes.profile.data.attributes.properties : {},
                        l = "$email" in a ? a.$email : void 0,
                        d = r || l,
                        c = {
                            [_.HO]: i,
                            properties: a
                        };
                    return d && (c.properties = Object.assign({}, c.properties, {
                        [_.HD]: d
                    })), (0, y.M)({
                        metric: E.Eo,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        submittedFields: c
                    }), (0, f.Y)(this.companyId, {
                        data: {
                            type: k.NR,
                            attributes: {
                                profile: {
                                    data: {
                                        type: k.cC,
                                        attributes: c
                                    }
                                }
                            },
                            relationships: Object.assign({}, this.previousListRelationships, this.formRelationships)
                        },
                        meta: {
                            send_otp_code: !0
                        }
                    })
                }
            }
            De.formActionType = r.WP;
            var Ne = De,
                je = n(510);
            var Re = n(74192);
            const Pe = ["isSubmit"];
            class ze extends se {
                constructor(e) {
                    let t = i()(e, Pe);
                    super(t), this.isSubmit = void 0, this.getState = void 0, this.isSubmit = !0, this.formActionType = r.Kc, this.getState = t.getState, this.__handler = this.__handler.bind(this), this.__postHandler = this.__postHandler.bind(this), this.__submitSuccessMetrics = this.__submitSuccessMetrics.bind(this)
                }
                __handler() {
                    const e = this.getState();
                    if (!e.onsiteState.openFormVersions[this.formVersionCId]) throw new Error("Open Form Version does not exist");
                    const {
                        previousFormSubmitBody: t
                    } = e.onsiteState.client, n = (null == t ? void 0 : t.data.attributes.profile.data.attributes[_.lL]) || (null == t ? void 0 : t.data.attributes.profile.data.attributes[_.HO]), o = this.composedFields[_.My];
                    if (!t || !n || !o || "string" != typeof n || "string" != typeof o) throw new Error(`Cannot submit opt in code. Previously submitted phone number and token must both be present: ${JSON.stringify({phoneNumber:n,token:o})}`);
                    return (0, h.W)((() => (async ({
                        companyId: e,
                        phoneNumber: t,
                        token: n
                    }) => (await (0, U.l)(), (0, P.Z)(`https://a.klaviyo.com/client/otp-verify?company_id=${e}`, {
                        method: "POST",
                        headers: Object.assign({
                            "Access-Control-Allow-Headers": "*",
                            "Content-Type": "application/json"
                        }, (0, q.h)()),
                        body: JSON.stringify({
                            token: n,
                            channel: "sms",
                            destination: t,
                            company_id: e
                        })
                    })))({
                        companyId: this.companyId,
                        phoneNumber: n,
                        token: o
                    })), 5, 1e3 + 1e3 * Math.random(), [429]).then((e => {
                        if (429 === e.status) throw new A.TT;
                        return e
                    })).then((t => {
                        var n;
                        const {
                            formVersionCId: o
                        } = this, i = null == (n = e.onsiteState.openFormVersions[o]) ? void 0 : n.formVersionId;
                        if (t.status === k.ke && i) {
                            const t = (0, je.G)(e, i)[0],
                                n = (0, x.nC)(e, t).find((e => (null == e ? void 0 : e.componentType) === _.eC));
                            if (n) throw (0, d.hX)({
                                componentId: null == n ? void 0 : n.componentId,
                                formVersionCId: o,
                                violation: {
                                    componentId: null == n ? void 0 : n.componentId,
                                    valid: !1,
                                    validationErrorType: Re.pv
                                }
                            }), new A.mN({
                                type: Re.pv
                            })
                        }
                        return t
                    })).then((e => e.status === k.dl && this.formAction.actionType ? ((0, b.$k)({
                        formId: this.formId,
                        successActionType: this.formAction.actionType
                    }), (0, M.n)(200, this.__submitSuccessMetrics()).then((() => e)).catch((() => e))) : e))
                }
                async __postHandler(e) {
                    super.__postHandler(e);
                    if (!this.getState().onsiteState.openFormVersions[this.formVersionCId] || !this.formAction.viewId) return null;
                    if ((null == e ? void 0 : e.status) === k.ke) return null;
                    e && this.__submitHandlerCheck(e.status);
                    return new he({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
                async __submitSuccessMetrics() {
                    const e = this.getState();
                    this.submitMetric({
                        state: e,
                        isSubscribe: !0
                    });
                    return (0, y.M)({
                        metric: E.Jv,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        submittedFields: this.composedFields,
                        action_type: "Submit Form"
                    })
                }
            }
            ze.formActionType = r.Kc;
            var He = ze;
            const We = ["isSubmit"];
            class Le extends l {
                constructor(e) {
                    var t, n, o;
                    let r = i()(e, We);
                    super(r), this.formIdToOpen = void 0, this.closeSourceForm = void 0, this.isSubmit = void 0, this.getState = void 0, this.onRenderForms = void 0, this.formIdToOpen = null == (t = this.formAction.data) ? void 0 : t.formIdToOpen, this.closeSourceForm = null != (n = null == (o = this.formAction.data) ? void 0 : o.closeSourceForm) && n, this.getState = r.getState, this.onRenderForms = r.onRenderForms, this.__openFormVersion = this.__openFormVersion.bind(this), this.__handler = this.__handler.bind(this)
                }
                __openFormVersion() {
                    if (this.closeSourceForm && (0, d.et)({
                            formVersionCId: this.formVersionCId
                        }), !this.formIdToOpen) return void console.error("No form to open specified.");
                    const e = this.getState().formsState.forms[this.formIdToOpen];
                    null != e && e.liveFormVersion ? (0, d.f7)({
                        formVersionId: null == e ? void 0 : e.liveFormVersion,
                        onRenderForms: this.onRenderForms
                    }) : console.error(`Form with formId: ${this.formIdToOpen} does not have a live form version. Please check the form configuration.`)
                }
                __handler() {
                    const {
                        formId: e,
                        formVersionCId: t
                    } = this;
                    this.formAction.actionType === r.y6 && (0, b.$k)({
                        formId: e,
                        successActionType: r.y6
                    });
                    const n = this.getState().onsiteState.openFormVersions[t];
                    if (!n) throw new Error("Open Form Version does not exist");
                    const o = n.sentSubmitMetric,
                        i = Promise.allSettled([(0, y.M)({
                            metric: E.qo,
                            logTelemetric: !this.isSubmit && !o,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            action_type: "Open Form",
                            form_to_open: this.formIdToOpen
                        })]);
                    return (0, M.n)(200, i).then((() => this.__openFormVersion())).catch((() => this.__openFormVersion()))
                }
            }
            Le.formActionType = r.y6;
            var qe = Le;
            const Ue = ["$phone_number"];
            class Ke extends se {
                constructor(e) {
                    super(e), this.getState = void 0, this.__submitHandler = (e, t) => {
                        var n, o;
                        const r = this.getState(),
                            s = r.onsiteState.openFormVersions[this.formVersionCId];
                        let a = t;
                        if (void 0 === s) throw new Error("Expected open form version");
                        const l = (0, w.CW)(r, this.formVersionCId),
                            {
                                phoneNumberConsentChannels: d,
                                apiCallChannelSettings: c
                            } = this.__buildChannelSettings(l),
                            m = (0, w.Mh)(r, s.formVersionId, d);
                        if (void 0 === m) throw new Error("Expected list ID");
                        const u = null == (n = t.data.attributes.profile.data.attributes.properties) ? void 0 : n.$phone_number;
                        if (void 0 === u) throw new Error("Expected phone number for SMS promotional opt in action");
                        const p = null != (o = t.data.attributes.profile.data.attributes.properties) ? o : {},
                            h = i()(p, Ue);
                        return a = Object.assign({}, t, {
                            data: Object.assign({}, t.data, {
                                attributes: {
                                    profile: Object.assign({}, t.data.attributes.profile, {
                                        data: Object.assign({}, t.data.attributes.profile.data, {
                                            attributes: Object.assign({}, t.data.attributes.profile.data.attributes, {
                                                properties: h,
                                                phone_number: u,
                                                subscriptions: Object.assign({}, t.data.attributes.profile.data.attributes.email ? {
                                                    email: {
                                                        marketing: {
                                                            consent: "SUBSCRIBED"
                                                        }
                                                    }
                                                } : {}, c)
                                            })
                                        })
                                    })
                                },
                                relationships: Object.assign({
                                    list: {
                                        data: {
                                            type: k._,
                                            id: m
                                        }
                                    }
                                }, this.formRelationships)
                            })
                        }), (0, f.Y)(e, a)
                    }, this.formActionType = r.pt, this.getState = e.getState, this.__submitHandler = this.__submitHandler.bind(this), this.__postHandler = this.__postHandler.bind(this)
                }
                __submitToList() {
                    return this.__baseSubmitToList(this.__submitHandler)
                }
                async __postHandler(e) {
                    super.__postHandler(e);
                    if (!this.getState().onsiteState.openFormVersions[this.formVersionCId] || !this.formAction.viewId) return null;
                    e && this.__submitHandlerCheck(e.status);
                    const t = this.formAction.viewId;
                    return (0, d.Cm)({
                        id: this.formVersionCId,
                        changes: {
                            currentViewId: t
                        }
                    })
                }
                __buildChannelSettings(e) {
                    const t = [],
                        n = {},
                        o = {
                            sms: $.Tg.SMS,
                            whatsapp: $.Tg.WHATSAPP
                        };
                    return Object.entries(o).forEach((([o, i]) => {
                        const r = null == e ? void 0 : e[i];
                        if (r === $.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL) t.push(i), n[o] = {
                            marketing: {
                                consent: "SUBSCRIBED"
                            }
                        };
                        else if (r) throw new Error(`Expected consent type to be ${$.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL} but got ${JSON.stringify(e)}`)
                    })), {
                        phoneNumberConsentChannels: t,
                        apiCallChannelSettings: n
                    }
                }
            }
            Ke.formActionType = r.pt;
            var Ge = Ke;
            class Ye extends se {
                constructor(e) {
                    super(e), this.getState = void 0, this.getState = e.getState, this.__handler = this.__handler.bind(this), this.__postHandler = this.__postHandler.bind(this)
                }
                __submitToList() {
                    return this.__baseSubmitToList(f.s)
                }
                __storeCurrentStepData() {
                    const e = this.getState().onsiteState.openFormVersions[this.formVersionCId];
                    if (!e) return;
                    const t = Object.assign({}, e.accumulatedFormData, this.composedFields);
                    (0, d.fK)({
                        id: this.formVersionCId,
                        changes: {
                            accumulatedFormData: t
                        }
                    })
                }
                async __handler() {
                    const e = this.getState(),
                        t = e.onsiteState.openFormVersions[this.formVersionCId];
                    if (!t) throw new Error("Open Form Version does not exist");
                    this.__storeCurrentStepData();
                    const n = (0, de.Bu)(e, this.formVersionCId, this.composedFields),
                        o = !!n.$phone_number,
                        i = !!n.opt_in_promotional_email && "true" === n.opt_in_promotional_email;
                    (0, s.qB)("Back-in-stock submit check", {
                        hasPhoneFromAnyStep: o,
                        hasEmailOptInFromAnyStep: i,
                        opt_in_promotional_email: n.opt_in_promotional_email
                    });
                    const r = o || i;
                    let a;
                    if ((0, s.qB)("Back-in-stock debug - shouldSubmitToList:", {
                            shouldSubmitToList: r
                        }), r) {
                        const e = this.composedFields,
                            t = "true" === n.opt_in_promotional_email;
                        this.composedFields = Object.assign({}, n, {
                            opt_in_promotional_email: t ? "true" : "false",
                            [_.eQ]: o ? "true" : "false"
                        }), a = super.__handler() || Promise.resolve(null), this.composedFields = e
                    } else a = Promise.resolve(null);
                    t.sentBackInStockSubmitMetric || ((0, y.M)({
                        metric: E.x_,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        submittedFields: n,
                        logCustomEvent: !0,
                        logTelemetric: !0
                    }), (0, d.fK)({
                        id: this.formVersionCId,
                        changes: {
                            sentBackInStockSubmitMetric: !0
                        }
                    }));
                    const l = (0, x.E5)(e, t.currentViewId),
                        c = e.formsState.views[t.currentViewId],
                        m = c ? (0, x.O)(e, c) : void 0;
                    return (0, y.M)({
                        metric: E.U9,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        submittedFields: Object.assign({}, n, {
                            $step_name: l
                        }),
                        step_name: l,
                        step_number: void 0 !== m ? m + 1 : m,
                        logCustomEvent: !0,
                        logTelemetric: !0
                    }), a
                }
                async __postHandler(e) {
                    super.__postHandler(e), e && this.__submitHandlerCheck(e.status);
                    if (!this.getState().onsiteState.openFormVersions[this.formVersionCId] || !this.formAction.viewId) return null;
                    return new he({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
                __makePOSTBody({
                    composedFields: e,
                    requestOTPCode: t = !1,
                    phoneInputConsentTypes: n
                }) {
                    const o = super.__makePOSTBody({
                        composedFields: e,
                        requestOTPCode: t,
                        phoneInputConsentTypes: n
                    });
                    if (e.$phone_number) {
                        const e = o.data.attributes.profile.data.attributes.subscriptions;
                        return Object.assign({}, o, {
                            data: Object.assign({}, o.data, {
                                attributes: Object.assign({}, o.data.attributes, {
                                    profile: Object.assign({}, o.data.attributes.profile, {
                                        data: Object.assign({}, o.data.attributes.profile.data, {
                                            attributes: Object.assign({}, o.data.attributes.profile.data.attributes, {
                                                subscriptions: Object.assign({}, e, {
                                                    sms: {
                                                        marketing: {
                                                            consent: "SUBSCRIBED"
                                                        }
                                                    }
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    }
                    return o
                }
            }
            Ye.formActionType = r.r8;
            var Xe = Ye;
            class Je extends l {
                constructor(e) {
                    var t, n;
                    super(e), this.deepLinkUrl = void 0, this.deepLinkUrl = null != (t = null == (n = this.formAction.data) ? void 0 : n.deepLinkUrl) ? t : "", this.formActionType = Je.formActionType
                }
                async __handler() {
                    var e;
                    return await (0, M.n)(200, Promise.allSettled([(0, y.M)({
                        metric: E.VJ,
                        logTelemetric: !0,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        action_type: "Go to Deep Link URL",
                        destination_url: this.deepLinkUrl
                    })])).catch((() => {})), (0, b.$k)({
                        formId: this.formId,
                        successActionType: r.eZ
                    }), (0, d.fK)({
                        id: this.formVersionCId,
                        changes: {
                            logCloseMetric: !1
                        }
                    }), null == (e = this.messageBus) || e.emit("openDeepLink", {
                        ios: this.deepLinkUrl,
                        android: this.deepLinkUrl
                    }), (0, d.et)({
                        formVersionCId: this.formVersionCId,
                        isSubmit: !0
                    })
                }
            }
            Je.formActionType = r.eZ;
            var Qe = Je;
            const et = {
                    [Qe.formActionType]: Qe
                },
                tt = Object.assign({
                    [u.formActionType]: u,
                    [ge.formActionType]: ge,
                    [he.formActionType]: he,
                    [Se.formActionType]: Se,
                    [xe.formActionType]: xe,
                    [Ve.formActionType]: Ve,
                    [_e.formActionType]: _e,
                    [Oe.formActionType]: Oe,
                    [Ne.formActionType]: Ne,
                    [He.formActionType]: He,
                    [qe.formActionType]: qe,
                    [Ge.formActionType]: Ge,
                    [Xe.formActionType]: Xe
                }, et),
                nt = ({
                    actionId: e,
                    getState: t
                }) => {
                    var n;
                    const o = t(),
                        i = o.formsState.actions ? null == (n = o.formsState.actions[e]) ? void 0 : n.actionType : void 0;
                    return tt[i]
                }
        },
        74192: function(e, t, n) {
            n.d(t, {
                pv: function() {
                    return o
                }
            });
            const o = "invalidCode"
        },
        32737: function(e, t, n) {
            n.d(t, {
                M: function() {
                    return m
                },
                displayBackInStockButtonHandler: function() {
                    return f
                }
            });
            n(92461), n(70818), n(39265), n(60873), n(61099);
            var o = n(25598),
                i = n(12948),
                r = n(80101),
                s = n(40910),
                a = n(20323),
                l = n(57829),
                d = n(78446),
                c = n(74872);
            const m = "klaviyo-bis-button-container",
                u = async ({
                    formId: e,
                    formVersionId: t,
                    openForm: r,
                    foundDynamicButtonId: s,
                    normalizedFormData: d
                }) => {
                    let c, u, f;
                    try {
                        var p, h;
                        const v = await (async e => {
                            const t = (await Promise.all([n.e(2462), n.e(8760), n.e(8257)]).then(n.bind(n, 80650))).createInitializer().getPlatform();
                            if (!t) return (0, o.mm)(`Back in Stock: Platform adapter not available. Button will not be placed. formVersionId: ${e}`), null;
                            const i = t.getButtonPlacementInfo();
                            return i && i.button && i.container ? i : ((0, o.mm)(`Back in Stock: Target button or container NOT FOUND via platform adapter. Button will not be placed. formVersionId: ${e}`), null)
                        })(t);
                        if (!v) return null;
                        const {
                            button: g,
                            container: y
                        } = v;
                        f = g;
                        const I = null == (p = d.data.dynamicButtons) || null == (p = p[s]) ? void 0 : p.data,
                            b = null == I ? void 0 : I.display;
                        await (async e => {
                            if (null == e || !e.fontFamily) return;
                            const t = e.fontFamily.split(",").map((e => e.trim())).filter(Boolean);
                            if (0 === t.length) return;
                            const o = e.fontWeight,
                                r = "string" == typeof o ? parseInt(o, 10) : o,
                                s = r ? [r] : [400, 500, 600, 700];
                            try {
                                const {
                                    waitForFontFamilies: e
                                } = await Promise.resolve().then(n.bind(n, 38931));
                                await e(t, {
                                    weights: s
                                })
                            } catch (e) {
                                const t = e instanceof Error ? e : new Error(String(e));
                                (0, i.T)(t, {
                                    tags: {
                                        feature: "bis-font-loading"
                                    },
                                    extra: {
                                        message: "Failed to wait for button fonts"
                                    }
                                })
                            }
                        })(null == I ? void 0 : I.textStyles);
                        const S = document.createElement("div");
                        S.id = m, S.style.marginBottom = "10px", "fitToText" !== (null == I || null == (h = I.buttonStyles) ? void 0 : h.width) && (S.style.flex = "1"), "NEXT_TO" !== b && (c = g.style.getPropertyValue("display"), u = g.style.getPropertyPriority("display"), g.style.setProperty("display", "none", "important"));
                        const w = l.Z.getState().onsiteState.client.klaviyoCompanyId;
                        return (0, o.mm)(`Back in Stock: Button placement for formVersionId: ${t}, companyId: ${w}`), (({
                            targetSoldOutButton: e,
                            parentOfSoldOutButtonFromPlatform: t,
                            containerDiv: n,
                            displaySetting: i,
                            formVersionId: r,
                            onContainerRemoved: s
                        }) => {
                            if (!t.contains(e)) throw (0, o.mm)(`Back in Stock: targetSoldOutButton is not a child of parentOfSoldOutButton. Cannot place button. formVersionId: ${r}`), new Error("targetSoldOutButton not a child of parentOfSoldOutButton during BIS button placement"); {
                                const t = e.parentElement;
                                if (!t) throw (0, o.mm)(`Back in Stock: targetSoldOutButton for formVersionId: ${r} has no direct parent. Button cannot be placed.`), new Error(`targetSoldOutButton for formVersionId: ${r} has no direct parent.`);
                                "NEXT_TO" !== i ? t.insertBefore(n, e) : e.insertAdjacentElement("afterend", n), new MutationObserver(((e, t) => {
                                    for (const o of e)
                                        if ("childList" === o.type && Array.from(o.removedNodes).some((e => e === n))) {
                                            s(), t.disconnect();
                                            break
                                        }
                                })).observe(t, {
                                    childList: !0
                                })
                            }
                        })({
                            targetSoldOutButton: g,
                            parentOfSoldOutButtonFromPlatform: y,
                            containerDiv: S,
                            displaySetting: b,
                            formVersionId: t,
                            onContainerRemoved: () => {
                                void 0 !== c && (g.style.setProperty("display", c, u), "" === c && g.style.removeProperty("display"))
                            }
                        }), (({
                            foundDynamicButtonId: e,
                            formVersionId: t,
                            openForm: n,
                            formId: i
                        }) => {
                            if ((0, o.mm)(`Preparing to render BackInStockButtonComponent via portal for formVersionId: ${t}.`), "function" != typeof a.C) throw (0, o.mm)(`Back in Stock: setBISPortalConfig is not a function for formVersionId: ${t}.`), new Error(`setBISPortalConfig function is not available or not imported correctly for formId: ${i}, formVersionId: ${t}`);
                            (0, a.C)({
                                dynamicButtonId: e,
                                formVersionId: t,
                                onClick: n
                            }), (0, o.mm)(`Back in Stock: Requested Notify Me button for formVersionId: ${t} to be rendered via portal.`)
                        })({
                            foundDynamicButtonId: s,
                            formVersionId: t,
                            openForm: r,
                            formId: e
                        }), S
                    } catch (n) {
                        const r = n instanceof Error ? n : new Error(String(n));
                        return f && void 0 !== c && (f.style.setProperty("display", c, u), "" === c && f.style.removeProperty("display")), (0, i.T)(r, {
                            tags: {
                                handler: "createPlatformSpecificContainer"
                            },
                            extra: {
                                formId: e,
                                formVersionId: t,
                                foundDynamicButtonId: s
                            }
                        }), (0, o.mm)(`Back in Stock: Error creating platform specific container for formVersionId: ${t}. Error: ${r.message}`), null
                    }
                },
                f = async ({
                    formId: e,
                    formVersionId: t,
                    normalizedFormData: n,
                    openForm: a
                }) => {
                    if (document.getElementById(m))(0, o.mm)(`Back in Stock: Container ${m} already exists. Skipping for formVersionId: ${t}.`);
                    else try {
                        if (null == n || !n.data) return void(0, o.mm)("Back in Stock: normalizedFormData or its data is missing. Cannot place button.", {
                            formId: e,
                            formVersionId: t
                        });
                        const {
                            dynamicButtons: i
                        } = n.data;
                        if (!i) return void(0, o.mm)(`Back in Stock: No dynamicButtons in normalizedFormData for formId: ${e}, formVersionId: ${t}.`);
                        const m = Object.keys(i).find((e => {
                            const n = i[e];
                            return (null == n ? void 0 : n.formVersionId) === t && (null == n ? void 0 : n.type) === d.I
                        }));
                        if (!m) return void(0, o.mm)(`Back in Stock: No matching dynamic button for formVersionId: ${t}.`);
                        if (await u({
                                formId: e,
                                formVersionId: t,
                                openForm: a,
                                foundDynamicButtonId: m,
                                normalizedFormData: n
                            })) {
                            const n = l.Z.getState().onsiteState.client.klaviyoCompanyId;
                            if (n) {
                                const i = (0, r.Z)();
                                (0, o.mm)(`Back in Stock: Button successfully placed for formVersionId: ${t}, logging placed metric.`), (0, s.M)({
                                    metric: c.MD,
                                    formVersionCId: i,
                                    formId: e,
                                    companyId: n
                                })
                            }
                        }
                    } catch (n) {
                        const r = n instanceof Error ? n : new Error(String(n));
                        (0, i.T)(r, {
                            tags: {
                                handler: "displayBackInStockButtonHandler",
                                point: "dynamicButtonsAccess"
                            },
                            extra: {
                                formId: e,
                                formVersionId: t
                            }
                        }), (0, o.mm)(`Back in Stock: Error in displayBackInStockButtonHandler for formVersionId: ${t}. Error: ${r.message}`)
                    }
                }
        },
        20323: function(e, t, n) {
            n.d(t, {
                C: function() {
                    return i
                },
                m: function() {
                    return r
                }
            });
            var o = n(57829);
            const i = e => {
                    o.Z.setState((t => Object.assign({}, t, {
                        onsiteState: Object.assign({}, t.onsiteState, {
                            bisPortalConfig: e
                        })
                    })))
                },
                r = () => {
                    o.Z.setState((e => Object.assign({}, e, {
                        onsiteState: Object.assign({}, e.onsiteState, {
                            bisPortalConfig: void 0
                        })
                    })))
                }
        },
        510: function(e, t, n) {
            n.d(t, {
                G: function() {
                    return i
                }
            });
            n(92461), n(70818);
            var o = n(51163);
            const i = (e, t) => {
                const n = e.formsState.formVersions[t];
                return (null == n ? void 0 : n.views.filter((t => (0, o.Sz)(e, t)))) || []
            }
        },
        16639: function(e, t, n) {
            n.d(t, {
                s: function() {
                    return o
                }
            });
            const o = {
                animationTimingFunction: "ease",
                animationPlayState: "running",
                animationDelay: "0s",
                animationIterationCount: 1,
                animationFillMode: "forwards"
            }
        },
        78446: function(e, t, n) {
            n.d(t, {
                I: function() {
                    return o
                }
            });
            const o = "BACK_IN_STOCK_OPEN"
        },
        69914: function(e, t, n) {
            n.d(t, {
                B: function() {
                    return o
                }
            });
            const o = 9e4
        },
        23760: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return i
                },
                p: function() {
                    return o
                }
            });
            const o = "teaser",
                i = "component"
        },
        65916: function(e, t) {
            t.Z = (e, t) => e / (e + 1) * t
        }
    }
]);