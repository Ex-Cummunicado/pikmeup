{
    "token": "hWN1RQDRnSgxxi7Nbj0VmsOk?key=9b91542a36e543c7f4a63082e6cc83fa",
    "note": "",
    "attributes": {
        "auid": "970494816.1754380918",
        "fbp": "fb.1.1754380918829.1639229255",
        "host": "https:\/\/pickem.store",
        "sh": "900",
        "sw": "1440",
        "ttp": "hEjVtCdnc2mxvL1dIBJt23RJ1RK.tt.0"
    },
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "USD",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": [],
    "discount_codes": []
}