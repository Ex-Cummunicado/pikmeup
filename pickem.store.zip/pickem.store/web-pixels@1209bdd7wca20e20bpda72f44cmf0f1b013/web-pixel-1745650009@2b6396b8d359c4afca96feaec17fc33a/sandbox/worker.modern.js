importScripts('https://pickem.store/cdn/wpm/s1209bdd7wca20e20bpda72f44cmf0f1b013m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('1745650009', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-1745650009@2b6396b8d359c4afca96feaec17fc33a.js');