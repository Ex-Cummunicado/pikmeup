(function(shopify) {
    (() => {
        var T = "WebPixel::Render";
        var h = a => shopify.extend(T, a);
        var U = "https://connect.facebook.net/en_US/fbevents.js",
            V = ["default", "title", "default title", ""];

        function F() {
            window.fbq && typeof window.fbq == "function" || (window.fbq = function() {
                window.fbq.callMethod ? window.fbq.callMethod.apply(window.fbq, arguments) : window.fbq.queue.push(arguments)
            }, window._fbq || (window._fbq = window.fbq), window.fbq.push = window.fbq, window.fbq.loaded = !0, window.fbq.version = "2.0", window.fbq.queue = [])
        }

        function x() {
            let a = document.createElement("script");
            return a.setAttribute("async", "true"), a.setAttribute("src", U), a
        }

        function R() {
            var g;
            let a = document.getElementsByTagName("script")[0];
            a === void 0 ? document.head.appendChild(x()) : (g = a.parentNode) == null || g.insertBefore(x(), a)
        }
        F();
        R();
        h(({
            analytics: a,
            browser: g,
            settings: E,
            init: N,
            customerPrivacy: O
        }) => {
            let v = E.pixel_id;

            function b(n, t, e = {}, o = {}) {
                window.fbq("trackShopify", v, n, e, {
                    eventID: t
                }, o)
            }

            function C(n) {
                var o, i, c;
                let t = [],
                    e = n.lineItems;
                if (e != null)
                    for (let r of e) {
                        let s = ((o = r.variant) == null ? void 0 : o.product.id) || ((i = r.variant) == null ? void 0 : i.id) || ((c = r.variant) == null ? void 0 : c.sku);
                        s != null && t.push(parseInt(s))
                    }
                return t
            }

            function q(n) {
                var e;
                let t = n.lineItems;
                if (t != null) {
                    for (let o of t)
                        if ((e = o.variant) != null && e.product.id) return "product_group"
                }
                return "product"
            }

            function I(n) {
                var o, i, c;
                let t = [],
                    e = n.lineItems;
                if (e != null)
                    for (let r of e) {
                        let s = ((o = r.variant) == null ? void 0 : o.id) || ((i = r.variant) == null ? void 0 : i.sku) || ((c = r.variant) == null ? void 0 : c.product.id);
                        s != null && t.push(parseInt(s))
                    }
                return t
            }

            function k(n) {
                var e, o;
                let t = n.lineItems;
                if (t != null) {
                    for (let i of t)
                        if ((e = i.variant) != null && e.id || (o = i.variant) != null && o.sku) return "product"
                }
                return "product_group"
            }

            function A(n) {
                let t = 0,
                    e = n.lineItems;
                if (e != null)
                    for (let o of e) t += o.quantity || 1;
                return t
            }

            function D(n) {
                var o, i, c, r, s, f, p, l;
                let t = [],
                    e = n.lineItems;
                if (e != null)
                    for (let d of e) {
                        let u = ((o = d.variant) == null ? void 0 : o.product.id) || ((i = d.variant) == null ? void 0 : i.id) || ((c = d.variant) == null ? void 0 : c.sku),
                            m = ((r = d.variant) == null ? void 0 : r.id) || ((s = d.variant) == null ? void 0 : s.sku) || ((f = d.variant) == null ? void 0 : f.product.id);
                        if (u != null && m != null) {
                            let _ = {};
                            _.id = u ? parseInt(u) : null, _.sku = m ? parseInt(m) : null, _.item_price = ((l = (p = d.variant) == null ? void 0 : p.price) == null ? void 0 : l.amount) || null, _.quantity = d.quantity || 1, _.currency = n.currencyCode || "USD", t.push(_)
                        }
                    }
                return t
            }

            function P(n, t) {
                return t == null || V.includes(t.toLowerCase()) ? n || "" : n + " - " + t
            }

            function y(n) {
                var e, o, i, c, r, s, f, p, l, d, u, m;
                let t = {};
                t.ct = ((e = n.billingAddress) == null ? void 0 : e.city) || ((o = n.shippingAddress) == null ? void 0 : o.city), t.country = ((i = n.billingAddress) == null ? void 0 : i.countryCode) || ((c = n.shippingAddress) == null ? void 0 : c.countryCode), t.fn = ((r = n.billingAddress) == null ? void 0 : r.firstName) || ((s = n.shippingAddress) == null ? void 0 : s.firstName), t.ln = ((f = n.billingAddress) == null ? void 0 : f.lastName) || ((p = n.shippingAddress) == null ? void 0 : p.lastName), t.ph = n.phone, t.st = ((l = n.billingAddress) == null ? void 0 : l.provinceCode) || ((d = n.shippingAddress) == null ? void 0 : d.provinceCode), t.zp = ((u = n.billingAddress) == null ? void 0 : u.zip) || ((m = n.shippingAddress) == null ? void 0 : m.zip), t.em = n.email, window.fbq("set", "userData", t)
            }

            function S(n) {
                n ? window.fbq("dataProcessingOptions", []) : window.fbq("dataProcessingOptions", ["LDU"], 0, 0)
            }
            let w = N.customerPrivacy.saleOfDataAllowed;
            S(w), window.fbq("init", v, {}, {
                agent: "shopify_web_pixel"
            }), O.subscribe("visitorConsentCollected", n => {
                w = n.customerPrivacy.saleOfDataAllowed, S(w)
            }), a.subscribe("page_viewed", n => {
                b("PageView", n.id)
            }), a.subscribe("search_submitted", n => {
                let t = n.data.searchResult.query || "";
                b("Search", n.id, {
                    search_string: t
                })
            }), a.subscribe("product_viewed", n => {
                let {
                    productVariant: t
                } = n.data, e = t.product.id || t.id || t.sku, o = e ? [parseInt(e)] : [], i = t.product.id ? "product_group" : "product", c = P(t.product.title, t.title), r = t.product.type || "", s = t.price.currencyCode || "USD", f = t.price.amount || null, p = t.id || t.sku || t.product.id, l = p ? [parseInt(p)] : [], d = t.id || t.sku ? "product" : "product_group", u = {};
                u.id = e ? parseInt(e) : null, u.sku = p ? parseInt(p) : null, u.item_price = f, u.quantity = 1, u.currency = s;
                let m = [u];
                b("ViewContent", n.id, {
                    content_ids: o,
                    content_type: i,
                    content_name: c,
                    content_category: r,
                    currency: s,
                    value: f
                }, {
                    product_variant_ids: l,
                    content_type_favor_variant: d,
                    contents: m
                })
            }), a.subscribe("product_added_to_cart", n => {
                let {
                    cartLine: t
                } = n.data, e = (t == null ? void 0 : t.merchandise.product.id) || (t == null ? void 0 : t.merchandise.id) || (t == null ? void 0 : t.merchandise.sku), o = e ? [parseInt(e)] : [], i = t != null && t.merchandise.product.id ? "product_group" : "product", c = P(t == null ? void 0 : t.merchandise.product.title, t == null ? void 0 : t.merchandise.title), r = (t == null ? void 0 : t.merchandise.product.type) || "", s = (t == null ? void 0 : t.merchandise.price.currencyCode) || "USD", f = (t == null ? void 0 : t.merchandise.price.amount) || null, p = (t == null ? void 0 : t.quantity) || 1, l = (t == null ? void 0 : t.merchandise.id) || (t == null ? void 0 : t.merchandise.sku) || (t == null ? void 0 : t.merchandise.product.id), d = l ? [parseInt(l)] : [], u = t != null && t.merchandise.id || t != null && t.merchandise.sku ? "product" : "product_group", m = {};
                m.id = e ? parseInt(e) : null, m.sku = l ? parseInt(l) : null, m.item_price = f, m.quantity = p, m.currency = s;
                let _ = [m];
                b("AddToCart", n.id, {
                    content_ids: o,
                    content_type: i,
                    content_name: c,
                    content_category: r,
                    currency: s,
                    value: f,
                    num_items: p
                }, {
                    product_variant_ids: d,
                    content_type_favor_variant: u,
                    contents: _
                })
            }), a.subscribe("checkout_started", n => {
                var l;
                let {
                    checkout: t
                } = n.data;
                y(t);
                let e = C(t),
                    o = q(t),
                    i = t.currencyCode || "USD",
                    c = ((l = t.subtotalPrice) == null ? void 0 : l.amount) || 0,
                    r = A(t),
                    s = I(t),
                    f = k(t),
                    p = D(t);
                b("InitiateCheckout", n.id, {
                    content_ids: e,
                    content_type: o,
                    currency: i,
                    value: c,
                    num_items: r
                }, {
                    product_variant_ids: s,
                    content_type_favor_variant: f,
                    contents: p
                })
            }), a.subscribe("checkout_completed", n => {
                var d, u;
                let {
                    checkout: t
                } = n.data;
                y(t);
                let e = C(t),
                    o = q(t),
                    i = t.currencyCode || "USD",
                    c = ((d = t.totalPrice) == null ? void 0 : d.amount) || 0,
                    r = A(t),
                    s = I(t),
                    f = k(t),
                    p = D(t),
                    l = (u = t.order) == null ? void 0 : u.id;
                b("Purchase", n.id, {
                    content_ids: e,
                    content_type: o,
                    currency: i,
                    value: c,
                    num_items: r
                }, {
                    product_variant_ids: s,
                    content_type_favor_variant: f,
                    contents: p,
                    order_id: l
                })
            }), a.subscribe("payment_info_submitted", n => {
                var i;
                let {
                    checkout: t
                } = n.data;
                y(t);
                let e = t.currencyCode || "USD",
                    o = ((i = t.totalPrice) == null ? void 0 : i.amount) || 0;
                b("AddPaymentInfo", n.id, {
                    currency: e,
                    value: o
                })
            })
        });
    })();

})(self.webPixelsManager.createShopifyExtend('460947801', 'app'));