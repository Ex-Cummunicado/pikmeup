importScripts('https://pickem.store/cdn/wpm/s1209bdd7wca20e20bpda72f44cmf0f1b013m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('1342472537', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-1342472537@0b931e61cd824059de71b539db648e2d.js');