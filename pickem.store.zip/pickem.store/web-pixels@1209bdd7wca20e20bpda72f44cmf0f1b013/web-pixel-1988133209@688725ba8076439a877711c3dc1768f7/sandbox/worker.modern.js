importScripts('https://pickem.store/cdn/wpm/s1209bdd7wca20e20bpda72f44cmf0f1b013m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('1988133209', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-1988133209@688725ba8076439a877711c3dc1768f7.js');