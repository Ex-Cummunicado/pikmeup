importScripts('https://pickem.store/cdn/wpm/s1209bdd7wca20e20bpda72f44cmf0f1b013m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('shopify-app-pixel', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-shopify-app-pixel@0440.js');