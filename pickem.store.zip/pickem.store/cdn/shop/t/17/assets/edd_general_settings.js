var edd_options = {
    "is_enabled": "1",
    "cutoff_time": "12:00 AM",
    "off_day": "Array\n(\n    [0] => no_off_day\n)\n",
    "message": "Expected Delivery Date {min_lead_days,1}  and {max_lead_days,3}.  ",
    "msg_preview": {
        "font_size": "",
        "text_transfrom": "initial",
        "font_weight": "",
        "font_style": "",
        "text_align": "left",
        "border": "rgb(232 232 232)",
        "color": "",
        "highlight_clr": "not_set",
        "background_clr": "rgb(243, 243, 243)",
        "background_option": "color ",
        "background": ""
    },
    "date_format": "14",
    "is_all_products": "1",
    "display_on_other_page": "0",
    "cutofftime_enable": "0",
    "edd_for_customer_or_admin": "admin",
    "hide_default_message": "0",
    "holidays": "[]",
    "custom_date_format": "",
    "date_option": "default",
    "countdown_formate": "",
    "check_box_change_msg_position": "0",
    "check_box_order_confirmation": "0",
    "cart_msg_apperance": "message",
    "custom_cart_label": "Order Estimation",
    "detail_page_class": "",
    "additional_script": " ",
    "template_id": "not_set",
    "zipcode_widget_title": "Check Your Product Availability",
    "zipcode_input_placeholder": "Hint:350040,36925",
    "zipcode_button_text": "Check",
    "zipcode_unserviceable_msg": "Unfortunately, this product is not available in your area",
    "widget_btn_bg_color": "#000",
    "widget_btn_hvr_color": "#000",
    "widget_btn_txt_color": "#fff",
    "widget_btn_txt_hvr_color": "#fff",
    "trial_active": 1,
    "trial_end_date": "2023-08-28",
    "allow_store": 0,
    "allow_store_end_date": "not_get",
    "plan_info": {
        "plan": "premium",
        "is_active": 1
    },
    "edd_customer_option": {
        "min_day": "1",
        "max_day": "3",
        "calender_alignment": "right",
        "cart_calendar_heading": "Schedule Product Delivery",
        "cart_calendar_err_msg": "Please select delivery date before checkout",
        "order_delivery_date_label": "Delivery Date",
        "order_delivery_day_label": "Delivery Day",
        "weekday_translation": "Sun,Mon,Tue,Wen,Thu,Fri,Sat",
        "month_translation": "Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec",
        "off_day": ""
    },
    "store_id": "5914"
};
var edd_customer_option = {
    "min_day": "1",
    "max_day": "3",
    "calender_alignment": "right",
    "cart_calendar_heading": "Schedule Product Delivery",
    "cart_calendar_err_msg": "Please select delivery date before checkout",
    "order_delivery_date_label": "Delivery Date",
    "order_delivery_day_label": "Delivery Day",
    "weekday_translation": "Sun,Mon,Tue,Wen,Thu,Fri,Sat",
    "month_translation": "Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec",
    "off_day": ""
};
var edd_is_install = 1;
var edd_plan_info = {
    "plan": "premium",
    "is_active": 1
};
var edd_random_string = 'UtOXi';
var check_edd_data_from_liquid = '1';