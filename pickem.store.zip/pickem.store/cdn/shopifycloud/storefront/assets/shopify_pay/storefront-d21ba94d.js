(() => {
    var __create = Object.create;
    var __defProp = Object.defineProperty;
    var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames = Object.getOwnPropertyNames;
    var __getProtoOf = Object.getPrototypeOf;
    var __hasOwnProp = Object.prototype.hasOwnProperty;
    var __commonJS = (cb, mod) => function __require() {
        return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = {
            exports: {}
        }).exports, mod), mod.exports
    };
    var __copyProps = (to, from, except, desc) => {
        if (from && typeof from === "object" || typeof from === "function") {
            for (let key of __getOwnPropNames(from))
                if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
                    get: () => from[key],
                    enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
                })
        }
        return to
    };
    var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
        value: mod,
        enumerable: true
    }) : target, mod));
    var require_cof = __commonJS({
        "node_modules/core-js/modules/_cof.js" (exports, module) {
            var toString = {}.toString;
            module.exports = function(it) {
                return toString.call(it).slice(8, -1)
            }
        }
    });
    var require_core = __commonJS({
        "node_modules/core-js/modules/_core.js" (exports, module) {
            var core = module.exports = {
                version: "2.6.12"
            };
            if (typeof __e == "number") __e = core
        }
    });
    var require_global = __commonJS({
        "node_modules/core-js/modules/_global.js" (exports, module) {
            var global2 = module.exports = typeof window != "undefined" && window.Math == Math ? window : typeof self != "undefined" && self.Math == Math ? self : Function("return this")();
            if (typeof __g == "number") __g = global2
        }
    });
    var require_library = __commonJS({
        "node_modules/core-js/modules/_library.js" (exports, module) {
            module.exports = false
        }
    });
    var require_shared = __commonJS({
        "node_modules/core-js/modules/_shared.js" (exports, module) {
            var core = require_core();
            var global2 = require_global();
            var SHARED = "__core-js_shared__";
            var store = global2[SHARED] || (global2[SHARED] = {});
            (module.exports = function(key, value) {
                return store[key] || (store[key] = value !== void 0 ? value : {})
            })("versions", []).push({
                version: core.version,
                mode: require_library() ? "pure" : "global",
                copyright: "\xA9 2020 Denis Pushkarev (zloirock.ru)"
            })
        }
    });
    var require_uid = __commonJS({
        "node_modules/core-js/modules/_uid.js" (exports, module) {
            var id = 0;
            var px = Math.random();
            module.exports = function(key) {
                return "Symbol(".concat(key === void 0 ? "" : key, ")_", (++id + px).toString(36))
            }
        }
    });
    var require_wks = __commonJS({
        "node_modules/core-js/modules/_wks.js" (exports, module) {
            var store = require_shared()("wks");
            var uid = require_uid();
            var Symbol2 = require_global().Symbol;
            var USE_SYMBOL = typeof Symbol2 == "function";
            var $exports = module.exports = function(name) {
                return store[name] || (store[name] = USE_SYMBOL && Symbol2[name] || (USE_SYMBOL ? Symbol2 : uid)("Symbol." + name))
            };
            $exports.store = store
        }
    });
    var require_classof = __commonJS({
        "node_modules/core-js/modules/_classof.js" (exports, module) {
            var cof = require_cof();
            var TAG = require_wks()("toStringTag");
            var ARG = cof(function() {
                return arguments
            }()) == "Arguments";
            var tryGet = function(it, key) {
                try {
                    return it[key]
                } catch (e) {}
            };
            module.exports = function(it) {
                var O, T, B;
                return it === void 0 ? "Undefined" : it === null ? "Null" : typeof(T = tryGet(O = Object(it), TAG)) == "string" ? T : ARG ? cof(O) : (B = cof(O)) == "Object" && typeof O.callee == "function" ? "Arguments" : B
            }
        }
    });
    var require_is_object = __commonJS({
        "node_modules/core-js/modules/_is-object.js" (exports, module) {
            module.exports = function(it) {
                return typeof it === "object" ? it !== null : typeof it === "function"
            }
        }
    });
    var require_an_object = __commonJS({
        "node_modules/core-js/modules/_an-object.js" (exports, module) {
            var isObject = require_is_object();
            module.exports = function(it) {
                if (!isObject(it)) throw TypeError(it + " is not an object!");
                return it
            }
        }
    });
    var require_fails = __commonJS({
        "node_modules/core-js/modules/_fails.js" (exports, module) {
            module.exports = function(exec) {
                try {
                    return !!exec()
                } catch (e) {
                    return true
                }
            }
        }
    });
    var require_descriptors = __commonJS({
        "node_modules/core-js/modules/_descriptors.js" (exports, module) {
            module.exports = !require_fails()(function() {
                return Object.defineProperty({}, "a", {
                    get: function() {
                        return 7
                    }
                }).a != 7
            })
        }
    });
    var require_dom_create = __commonJS({
        "node_modules/core-js/modules/_dom-create.js" (exports, module) {
            var isObject = require_is_object();
            var document2 = require_global().document;
            var is = isObject(document2) && isObject(document2.createElement);
            module.exports = function(it) {
                return is ? document2.createElement(it) : {}
            }
        }
    });
    var require_ie8_dom_define = __commonJS({
        "node_modules/core-js/modules/_ie8-dom-define.js" (exports, module) {
            module.exports = !require_descriptors() && !require_fails()(function() {
                return Object.defineProperty(require_dom_create()("div"), "a", {
                    get: function() {
                        return 7
                    }
                }).a != 7
            })
        }
    });
    var require_to_primitive = __commonJS({
        "node_modules/core-js/modules/_to-primitive.js" (exports, module) {
            var isObject = require_is_object();
            module.exports = function(it, S) {
                if (!isObject(it)) return it;
                var fn, val;
                if (S && typeof(fn = it.toString) == "function" && !isObject(val = fn.call(it))) return val;
                if (typeof(fn = it.valueOf) == "function" && !isObject(val = fn.call(it))) return val;
                if (!S && typeof(fn = it.toString) == "function" && !isObject(val = fn.call(it))) return val;
                throw TypeError("Can't convert object to primitive value")
            }
        }
    });
    var require_object_dp = __commonJS({
        "node_modules/core-js/modules/_object-dp.js" (exports) {
            var anObject = require_an_object();
            var IE8_DOM_DEFINE = require_ie8_dom_define();
            var toPrimitive = require_to_primitive();
            var dP = Object.defineProperty;
            exports.f = require_descriptors() ? Object.defineProperty : function defineProperty(O, P, Attributes) {
                anObject(O);
                P = toPrimitive(P, true);
                anObject(Attributes);
                if (IE8_DOM_DEFINE) try {
                    return dP(O, P, Attributes)
                } catch (e) {}
                if ("get" in Attributes || "set" in Attributes) throw TypeError("Accessors not supported!");
                if ("value" in Attributes) O[P] = Attributes.value;
                return O
            }
        }
    });
    var require_property_desc = __commonJS({
        "node_modules/core-js/modules/_property-desc.js" (exports, module) {
            module.exports = function(bitmap, value) {
                return {
                    enumerable: !(bitmap & 1),
                    configurable: !(bitmap & 2),
                    writable: !(bitmap & 4),
                    value
                }
            }
        }
    });
    var require_hide = __commonJS({
        "node_modules/core-js/modules/_hide.js" (exports, module) {
            var dP = require_object_dp();
            var createDesc = require_property_desc();
            module.exports = require_descriptors() ? function(object, key, value) {
                return dP.f(object, key, createDesc(1, value))
            } : function(object, key, value) {
                object[key] = value;
                return object
            }
        }
    });
    var require_has = __commonJS({
        "node_modules/core-js/modules/_has.js" (exports, module) {
            var hasOwnProperty = {}.hasOwnProperty;
            module.exports = function(it, key) {
                return hasOwnProperty.call(it, key)
            }
        }
    });
    var require_function_to_string = __commonJS({
        "node_modules/core-js/modules/_function-to-string.js" (exports, module) {
            module.exports = require_shared()("native-function-to-string", Function.toString)
        }
    });
    var require_redefine = __commonJS({
        "node_modules/core-js/modules/_redefine.js" (exports, module) {
            var global2 = require_global();
            var hide = require_hide();
            var has = require_has();
            var SRC = require_uid()("src");
            var $toString = require_function_to_string();
            var TO_STRING = "toString";
            var TPL = ("" + $toString).split(TO_STRING);
            require_core().inspectSource = function(it) {
                return $toString.call(it)
            };
            (module.exports = function(O, key, val, safe) {
                var isFunction = typeof val == "function";
                if (isFunction) has(val, "name") || hide(val, "name", key);
                if (O[key] === val) return;
                if (isFunction) has(val, SRC) || hide(val, SRC, O[key] ? "" + O[key] : TPL.join(String(key)));
                if (O === global2) {
                    O[key] = val
                } else if (!safe) {
                    delete O[key];
                    hide(O, key, val)
                } else if (O[key]) {
                    O[key] = val
                } else {
                    hide(O, key, val)
                }
            })(Function.prototype, TO_STRING, function toString() {
                return typeof this == "function" && this[SRC] || $toString.call(this)
            })
        }
    });
    var require_es6_object_to_string = __commonJS({
        "node_modules/core-js/modules/es6.object.to-string.js" () {
            "use strict";
            var classof = require_classof();
            var test = {};
            test[require_wks()("toStringTag")] = "z";
            if (test + "" != "[object z]") {
                require_redefine()(Object.prototype, "toString", function toString() {
                    return "[object " + classof(this) + "]"
                }, true)
            }
        }
    });
    var require_to_integer = __commonJS({
        "node_modules/core-js/modules/_to-integer.js" (exports, module) {
            var ceil = Math.ceil;
            var floor = Math.floor;
            module.exports = function(it) {
                return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it)
            }
        }
    });
    var require_defined = __commonJS({
        "node_modules/core-js/modules/_defined.js" (exports, module) {
            module.exports = function(it) {
                if (it == void 0) throw TypeError("Can't call method on  " + it);
                return it
            }
        }
    });
    var require_string_at = __commonJS({
        "node_modules/core-js/modules/_string-at.js" (exports, module) {
            var toInteger = require_to_integer();
            var defined = require_defined();
            module.exports = function(TO_STRING) {
                return function(that, pos) {
                    var s = String(defined(that));
                    var i = toInteger(pos);
                    var l = s.length;
                    var a, b;
                    if (i < 0 || i >= l) return TO_STRING ? "" : void 0;
                    a = s.charCodeAt(i);
                    return a < 55296 || a > 56319 || i + 1 === l || (b = s.charCodeAt(i + 1)) < 56320 || b > 57343 ? TO_STRING ? s.charAt(i) : a : TO_STRING ? s.slice(i, i + 2) : (a - 55296 << 10) + (b - 56320) + 65536
                }
            }
        }
    });
    var require_a_function = __commonJS({
        "node_modules/core-js/modules/_a-function.js" (exports, module) {
            module.exports = function(it) {
                if (typeof it != "function") throw TypeError(it + " is not a function!");
                return it
            }
        }
    });
    var require_ctx = __commonJS({
        "node_modules/core-js/modules/_ctx.js" (exports, module) {
            var aFunction = require_a_function();
            module.exports = function(fn, that, length) {
                aFunction(fn);
                if (that === void 0) return fn;
                switch (length) {
                    case 1:
                        return function(a) {
                            return fn.call(that, a)
                        };
                    case 2:
                        return function(a, b) {
                            return fn.call(that, a, b)
                        };
                    case 3:
                        return function(a, b, c) {
                            return fn.call(that, a, b, c)
                        }
                }
                return function() {
                    return fn.apply(that, arguments)
                }
            }
        }
    });
    var require_export = __commonJS({
        "node_modules/core-js/modules/_export.js" (exports, module) {
            var global2 = require_global();
            var core = require_core();
            var hide = require_hide();
            var redefine = require_redefine();
            var ctx = require_ctx();
            var PROTOTYPE = "prototype";
            var $export = function(type, name, source) {
                var IS_FORCED = type & $export.F;
                var IS_GLOBAL = type & $export.G;
                var IS_STATIC = type & $export.S;
                var IS_PROTO = type & $export.P;
                var IS_BIND = type & $export.B;
                var target = IS_GLOBAL ? global2 : IS_STATIC ? global2[name] || (global2[name] = {}) : (global2[name] || {})[PROTOTYPE];
                var exports2 = IS_GLOBAL ? core : core[name] || (core[name] = {});
                var expProto = exports2[PROTOTYPE] || (exports2[PROTOTYPE] = {});
                var key, own, out, exp;
                if (IS_GLOBAL) source = name;
                for (key in source) {
                    own = !IS_FORCED && target && target[key] !== void 0;
                    out = (own ? target : source)[key];
                    exp = IS_BIND && own ? ctx(out, global2) : IS_PROTO && typeof out == "function" ? ctx(Function.call, out) : out;
                    if (target) redefine(target, key, out, type & $export.U);
                    if (exports2[key] != out) hide(exports2, key, exp);
                    if (IS_PROTO && expProto[key] != out) expProto[key] = out
                }
            };
            global2.core = core;
            $export.F = 1;
            $export.G = 2;
            $export.S = 4;
            $export.P = 8;
            $export.B = 16;
            $export.W = 32;
            $export.U = 64;
            $export.R = 128;
            module.exports = $export
        }
    });
    var require_iterators = __commonJS({
        "node_modules/core-js/modules/_iterators.js" (exports, module) {
            module.exports = {}
        }
    });
    var require_iobject = __commonJS({
        "node_modules/core-js/modules/_iobject.js" (exports, module) {
            var cof = require_cof();
            module.exports = Object("z").propertyIsEnumerable(0) ? Object : function(it) {
                return cof(it) == "String" ? it.split("") : Object(it)
            }
        }
    });
    var require_to_iobject = __commonJS({
        "node_modules/core-js/modules/_to-iobject.js" (exports, module) {
            var IObject = require_iobject();
            var defined = require_defined();
            module.exports = function(it) {
                return IObject(defined(it))
            }
        }
    });
    var require_to_length = __commonJS({
        "node_modules/core-js/modules/_to-length.js" (exports, module) {
            var toInteger = require_to_integer();
            var min = Math.min;
            module.exports = function(it) {
                return it > 0 ? min(toInteger(it), 9007199254740991) : 0
            }
        }
    });
    var require_to_absolute_index = __commonJS({
        "node_modules/core-js/modules/_to-absolute-index.js" (exports, module) {
            var toInteger = require_to_integer();
            var max = Math.max;
            var min = Math.min;
            module.exports = function(index, length) {
                index = toInteger(index);
                return index < 0 ? max(index + length, 0) : min(index, length)
            }
        }
    });
    var require_array_includes = __commonJS({
        "node_modules/core-js/modules/_array-includes.js" (exports, module) {
            var toIObject = require_to_iobject();
            var toLength = require_to_length();
            var toAbsoluteIndex = require_to_absolute_index();
            module.exports = function(IS_INCLUDES) {
                return function($this, el, fromIndex) {
                    var O = toIObject($this);
                    var length = toLength(O.length);
                    var index = toAbsoluteIndex(fromIndex, length);
                    var value;
                    if (IS_INCLUDES && el != el)
                        while (length > index) {
                            value = O[index++];
                            if (value != value) return true
                        } else
                            for (; length > index; index++)
                                if (IS_INCLUDES || index in O) {
                                    if (O[index] === el) return IS_INCLUDES || index || 0
                                }
                    return !IS_INCLUDES && -1
                }
            }
        }
    });
    var require_shared_key = __commonJS({
        "node_modules/core-js/modules/_shared-key.js" (exports, module) {
            var shared = require_shared()("keys");
            var uid = require_uid();
            module.exports = function(key) {
                return shared[key] || (shared[key] = uid(key))
            }
        }
    });
    var require_object_keys_internal = __commonJS({
        "node_modules/core-js/modules/_object-keys-internal.js" (exports, module) {
            var has = require_has();
            var toIObject = require_to_iobject();
            var arrayIndexOf = require_array_includes()(false);
            var IE_PROTO = require_shared_key()("IE_PROTO");
            module.exports = function(object, names) {
                var O = toIObject(object);
                var i = 0;
                var result = [];
                var key;
                for (key in O)
                    if (key != IE_PROTO) has(O, key) && result.push(key);
                while (names.length > i)
                    if (has(O, key = names[i++])) {
                        ~arrayIndexOf(result, key) || result.push(key)
                    }
                return result
            }
        }
    });
    var require_enum_bug_keys = __commonJS({
        "node_modules/core-js/modules/_enum-bug-keys.js" (exports, module) {
            module.exports = "constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(",")
        }
    });
    var require_object_keys = __commonJS({
        "node_modules/core-js/modules/_object-keys.js" (exports, module) {
            var $keys = require_object_keys_internal();
            var enumBugKeys = require_enum_bug_keys();
            module.exports = Object.keys || function keys(O) {
                return $keys(O, enumBugKeys)
            }
        }
    });
    var require_object_dps = __commonJS({
        "node_modules/core-js/modules/_object-dps.js" (exports, module) {
            var dP = require_object_dp();
            var anObject = require_an_object();
            var getKeys = require_object_keys();
            module.exports = require_descriptors() ? Object.defineProperties : function defineProperties(O, Properties) {
                anObject(O);
                var keys = getKeys(Properties);
                var length = keys.length;
                var i = 0;
                var P;
                while (length > i) dP.f(O, P = keys[i++], Properties[P]);
                return O
            }
        }
    });
    var require_html = __commonJS({
        "node_modules/core-js/modules/_html.js" (exports, module) {
            var document2 = require_global().document;
            module.exports = document2 && document2.documentElement
        }
    });
    var require_object_create = __commonJS({
        "node_modules/core-js/modules/_object-create.js" (exports, module) {
            var anObject = require_an_object();
            var dPs = require_object_dps();
            var enumBugKeys = require_enum_bug_keys();
            var IE_PROTO = require_shared_key()("IE_PROTO");
            var Empty = function() {};
            var PROTOTYPE = "prototype";
            var createDict = function() {
                var iframe = require_dom_create()("iframe");
                var i = enumBugKeys.length;
                var lt = "<";
                var gt = ">";
                var iframeDocument;
                iframe.style.display = "none";
                require_html().appendChild(iframe);
                iframe.src = "javascript:";
                iframeDocument = iframe.contentWindow.document;
                iframeDocument.open();
                iframeDocument.write(lt + "script" + gt + "document.F=Object" + lt + "/script" + gt);
                iframeDocument.close();
                createDict = iframeDocument.F;
                while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
                return createDict()
            };
            module.exports = Object.create || function create(O, Properties) {
                var result;
                if (O !== null) {
                    Empty[PROTOTYPE] = anObject(O);
                    result = new Empty;
                    Empty[PROTOTYPE] = null;
                    result[IE_PROTO] = O
                } else result = createDict();
                return Properties === void 0 ? result : dPs(result, Properties)
            }
        }
    });
    var require_set_to_string_tag = __commonJS({
        "node_modules/core-js/modules/_set-to-string-tag.js" (exports, module) {
            var def = require_object_dp().f;
            var has = require_has();
            var TAG = require_wks()("toStringTag");
            module.exports = function(it, tag, stat) {
                if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, {
                    configurable: true,
                    value: tag
                })
            }
        }
    });
    var require_iter_create = __commonJS({
        "node_modules/core-js/modules/_iter-create.js" (exports, module) {
            "use strict";
            var create = require_object_create();
            var descriptor = require_property_desc();
            var setToStringTag = require_set_to_string_tag();
            var IteratorPrototype = {};
            require_hide()(IteratorPrototype, require_wks()("iterator"), function() {
                return this
            });
            module.exports = function(Constructor, NAME, next) {
                Constructor.prototype = create(IteratorPrototype, {
                    next: descriptor(1, next)
                });
                setToStringTag(Constructor, NAME + " Iterator")
            }
        }
    });
    var require_to_object = __commonJS({
        "node_modules/core-js/modules/_to-object.js" (exports, module) {
            var defined = require_defined();
            module.exports = function(it) {
                return Object(defined(it))
            }
        }
    });
    var require_object_gpo = __commonJS({
        "node_modules/core-js/modules/_object-gpo.js" (exports, module) {
            var has = require_has();
            var toObject = require_to_object();
            var IE_PROTO = require_shared_key()("IE_PROTO");
            var ObjectProto = Object.prototype;
            module.exports = Object.getPrototypeOf || function(O) {
                O = toObject(O);
                if (has(O, IE_PROTO)) return O[IE_PROTO];
                if (typeof O.constructor == "function" && O instanceof O.constructor) {
                    return O.constructor.prototype
                }
                return O instanceof Object ? ObjectProto : null
            }
        }
    });
    var require_iter_define = __commonJS({
        "node_modules/core-js/modules/_iter-define.js" (exports, module) {
            "use strict";
            var LIBRARY = require_library();
            var $export = require_export();
            var redefine = require_redefine();
            var hide = require_hide();
            var Iterators = require_iterators();
            var $iterCreate = require_iter_create();
            var setToStringTag = require_set_to_string_tag();
            var getPrototypeOf = require_object_gpo();
            var ITERATOR = require_wks()("iterator");
            var BUGGY = !([].keys && "next" in [].keys());
            var FF_ITERATOR = "@@iterator";
            var KEYS = "keys";
            var VALUES = "values";
            var returnThis = function() {
                return this
            };
            module.exports = function(Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
                $iterCreate(Constructor, NAME, next);
                var getMethod = function(kind) {
                    if (!BUGGY && kind in proto) return proto[kind];
                    switch (kind) {
                        case KEYS:
                            return function keys() {
                                return new Constructor(this, kind)
                            };
                        case VALUES:
                            return function values() {
                                return new Constructor(this, kind)
                            }
                    }
                    return function entries() {
                        return new Constructor(this, kind)
                    }
                };
                var TAG = NAME + " Iterator";
                var DEF_VALUES = DEFAULT == VALUES;
                var VALUES_BUG = false;
                var proto = Base.prototype;
                var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
                var $default = $native || getMethod(DEFAULT);
                var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod("entries") : void 0;
                var $anyNative = NAME == "Array" ? proto.entries || $native : $native;
                var methods2, key, IteratorPrototype;
                if ($anyNative) {
                    IteratorPrototype = getPrototypeOf($anyNative.call(new Base));
                    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
                        setToStringTag(IteratorPrototype, TAG, true);
                        if (!LIBRARY && typeof IteratorPrototype[ITERATOR] != "function") hide(IteratorPrototype, ITERATOR, returnThis)
                    }
                }
                if (DEF_VALUES && $native && $native.name !== VALUES) {
                    VALUES_BUG = true;
                    $default = function values() {
                        return $native.call(this)
                    }
                }
                if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
                    hide(proto, ITERATOR, $default)
                }
                Iterators[NAME] = $default;
                Iterators[TAG] = returnThis;
                if (DEFAULT) {
                    methods2 = {
                        values: DEF_VALUES ? $default : getMethod(VALUES),
                        keys: IS_SET ? $default : getMethod(KEYS),
                        entries: $entries
                    };
                    if (FORCED)
                        for (key in methods2) {
                            if (!(key in proto)) redefine(proto, key, methods2[key])
                        } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods2)
                }
                return methods2
            }
        }
    });
    var require_es6_string_iterator = __commonJS({
        "node_modules/core-js/modules/es6.string.iterator.js" () {
            "use strict";
            var $at = require_string_at()(true);
            require_iter_define()(String, "String", function(iterated) {
                this._t = String(iterated);
                this._i = 0
            }, function() {
                var O = this._t;
                var index = this._i;
                var point;
                if (index >= O.length) return {
                    value: void 0,
                    done: true
                };
                point = $at(O, index);
                this._i += point.length;
                return {
                    value: point,
                    done: false
                }
            })
        }
    });
    var require_add_to_unscopables = __commonJS({
        "node_modules/core-js/modules/_add-to-unscopables.js" (exports, module) {
            var UNSCOPABLES = require_wks()("unscopables");
            var ArrayProto = Array.prototype;
            if (ArrayProto[UNSCOPABLES] == void 0) require_hide()(ArrayProto, UNSCOPABLES, {});
            module.exports = function(key) {
                ArrayProto[UNSCOPABLES][key] = true
            }
        }
    });
    var require_iter_step = __commonJS({
        "node_modules/core-js/modules/_iter-step.js" (exports, module) {
            module.exports = function(done, value) {
                return {
                    value,
                    done: !!done
                }
            }
        }
    });
    var require_es6_array_iterator = __commonJS({
        "node_modules/core-js/modules/es6.array.iterator.js" (exports, module) {
            "use strict";
            var addToUnscopables = require_add_to_unscopables();
            var step = require_iter_step();
            var Iterators = require_iterators();
            var toIObject = require_to_iobject();
            module.exports = require_iter_define()(Array, "Array", function(iterated, kind) {
                this._t = toIObject(iterated);
                this._i = 0;
                this._k = kind
            }, function() {
                var O = this._t;
                var kind = this._k;
                var index = this._i++;
                if (!O || index >= O.length) {
                    this._t = void 0;
                    return step(1)
                }
                if (kind == "keys") return step(0, index);
                if (kind == "values") return step(0, O[index]);
                return step(0, [index, O[index]])
            }, "values");
            Iterators.Arguments = Iterators.Array;
            addToUnscopables("keys");
            addToUnscopables("values");
            addToUnscopables("entries")
        }
    });
    var require_web_dom_iterable = __commonJS({
        "node_modules/core-js/modules/web.dom.iterable.js" () {
            var $iterators = require_es6_array_iterator();
            var getKeys = require_object_keys();
            var redefine = require_redefine();
            var global2 = require_global();
            var hide = require_hide();
            var Iterators = require_iterators();
            var wks = require_wks();
            var ITERATOR = wks("iterator");
            var TO_STRING_TAG = wks("toStringTag");
            var ArrayValues = Iterators.Array;
            var DOMIterables = {
                CSSRuleList: true,
                CSSStyleDeclaration: false,
                CSSValueList: false,
                ClientRectList: false,
                DOMRectList: false,
                DOMStringList: false,
                DOMTokenList: true,
                DataTransferItemList: false,
                FileList: false,
                HTMLAllCollection: false,
                HTMLCollection: false,
                HTMLFormElement: false,
                HTMLSelectElement: false,
                MediaList: true,
                MimeTypeArray: false,
                NamedNodeMap: false,
                NodeList: true,
                PaintRequestList: false,
                Plugin: false,
                PluginArray: false,
                SVGLengthList: false,
                SVGNumberList: false,
                SVGPathSegList: false,
                SVGPointList: false,
                SVGStringList: false,
                SVGTransformList: false,
                SourceBufferList: false,
                StyleSheetList: true,
                TextTrackCueList: false,
                TextTrackList: false,
                TouchList: false
            };
            for (collections = getKeys(DOMIterables), i = 0; i < collections.length; i++) {
                NAME = collections[i];
                explicit = DOMIterables[NAME];
                Collection = global2[NAME];
                proto = Collection && Collection.prototype;
                if (proto) {
                    if (!proto[ITERATOR]) hide(proto, ITERATOR, ArrayValues);
                    if (!proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
                    Iterators[NAME] = ArrayValues;
                    if (explicit) {
                        for (key in $iterators)
                            if (!proto[key]) redefine(proto, key, $iterators[key], true)
                    }
                }
            }
            var NAME;
            var explicit;
            var Collection;
            var proto;
            var key;
            var collections;
            var i
        }
    });
    var require_an_instance = __commonJS({
        "node_modules/core-js/modules/_an-instance.js" (exports, module) {
            module.exports = function(it, Constructor, name, forbiddenField) {
                if (!(it instanceof Constructor) || forbiddenField !== void 0 && forbiddenField in it) {
                    throw TypeError(name + ": incorrect invocation!")
                }
                return it
            }
        }
    });
    var require_iter_call = __commonJS({
        "node_modules/core-js/modules/_iter-call.js" (exports, module) {
            var anObject = require_an_object();
            module.exports = function(iterator, fn, value, entries) {
                try {
                    return entries ? fn(anObject(value)[0], value[1]) : fn(value)
                } catch (e) {
                    var ret = iterator["return"];
                    if (ret !== void 0) anObject(ret.call(iterator));
                    throw e
                }
            }
        }
    });
    var require_is_array_iter = __commonJS({
        "node_modules/core-js/modules/_is-array-iter.js" (exports, module) {
            var Iterators = require_iterators();
            var ITERATOR = require_wks()("iterator");
            var ArrayProto = Array.prototype;
            module.exports = function(it) {
                return it !== void 0 && (Iterators.Array === it || ArrayProto[ITERATOR] === it)
            }
        }
    });
    var require_core_get_iterator_method = __commonJS({
        "node_modules/core-js/modules/core.get-iterator-method.js" (exports, module) {
            var classof = require_classof();
            var ITERATOR = require_wks()("iterator");
            var Iterators = require_iterators();
            module.exports = require_core().getIteratorMethod = function(it) {
                if (it != void 0) return it[ITERATOR] || it["@@iterator"] || Iterators[classof(it)]
            }
        }
    });
    var require_for_of = __commonJS({
        "node_modules/core-js/modules/_for-of.js" (exports, module) {
            var ctx = require_ctx();
            var call = require_iter_call();
            var isArrayIter = require_is_array_iter();
            var anObject = require_an_object();
            var toLength = require_to_length();
            var getIterFn = require_core_get_iterator_method();
            var BREAK = {};
            var RETURN = {};
            var exports = module.exports = function(iterable, entries, fn, that, ITERATOR) {
                var iterFn = ITERATOR ? function() {
                    return iterable
                } : getIterFn(iterable);
                var f = ctx(fn, that, entries ? 2 : 1);
                var index = 0;
                var length, step, iterator, result;
                if (typeof iterFn != "function") throw TypeError(iterable + " is not iterable!");
                if (isArrayIter(iterFn))
                    for (length = toLength(iterable.length); length > index; index++) {
                        result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
                        if (result === BREAK || result === RETURN) return result
                    } else
                        for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
                            result = call(iterator, f, step.value, entries);
                            if (result === BREAK || result === RETURN) return result
                        }
            };
            exports.BREAK = BREAK;
            exports.RETURN = RETURN
        }
    });
    var require_species_constructor = __commonJS({
        "node_modules/core-js/modules/_species-constructor.js" (exports, module) {
            var anObject = require_an_object();
            var aFunction = require_a_function();
            var SPECIES = require_wks()("species");
            module.exports = function(O, D) {
                var C = anObject(O).constructor;
                var S;
                return C === void 0 || (S = anObject(C)[SPECIES]) == void 0 ? D : aFunction(S)
            }
        }
    });
    var require_invoke = __commonJS({
        "node_modules/core-js/modules/_invoke.js" (exports, module) {
            module.exports = function(fn, args, that) {
                var un = that === void 0;
                switch (args.length) {
                    case 0:
                        return un ? fn() : fn.call(that);
                    case 1:
                        return un ? fn(args[0]) : fn.call(that, args[0]);
                    case 2:
                        return un ? fn(args[0], args[1]) : fn.call(that, args[0], args[1]);
                    case 3:
                        return un ? fn(args[0], args[1], args[2]) : fn.call(that, args[0], args[1], args[2]);
                    case 4:
                        return un ? fn(args[0], args[1], args[2], args[3]) : fn.call(that, args[0], args[1], args[2], args[3])
                }
                return fn.apply(that, args)
            }
        }
    });
    var require_task = __commonJS({
        "node_modules/core-js/modules/_task.js" (exports, module) {
            var ctx = require_ctx();
            var invoke = require_invoke();
            var html = require_html();
            var cel = require_dom_create();
            var global2 = require_global();
            var process = global2.process;
            var setTask = global2.setImmediate;
            var clearTask = global2.clearImmediate;
            var MessageChannel = global2.MessageChannel;
            var Dispatch = global2.Dispatch;
            var counter = 0;
            var queue = {};
            var ONREADYSTATECHANGE = "onreadystatechange";
            var defer;
            var channel;
            var port;
            var run = function() {
                var id = +this;
                if (queue.hasOwnProperty(id)) {
                    var fn = queue[id];
                    delete queue[id];
                    fn()
                }
            };
            var listener = function(event) {
                run.call(event.data)
            };
            if (!setTask || !clearTask) {
                setTask = function setImmediate(fn) {
                    var args = [];
                    var i = 1;
                    while (arguments.length > i) args.push(arguments[i++]);
                    queue[++counter] = function() {
                        invoke(typeof fn == "function" ? fn : Function(fn), args)
                    };
                    defer(counter);
                    return counter
                };
                clearTask = function clearImmediate(id) {
                    delete queue[id]
                };
                if (require_cof()(process) == "process") {
                    defer = function(id) {
                        process.nextTick(ctx(run, id, 1))
                    }
                } else if (Dispatch && Dispatch.now) {
                    defer = function(id) {
                        Dispatch.now(ctx(run, id, 1))
                    }
                } else if (MessageChannel) {
                    channel = new MessageChannel;
                    port = channel.port2;
                    channel.port1.onmessage = listener;
                    defer = ctx(port.postMessage, port, 1)
                } else if (global2.addEventListener && typeof postMessage == "function" && !global2.importScripts) {
                    defer = function(id) {
                        global2.postMessage(id + "", "*")
                    };
                    global2.addEventListener("message", listener, false)
                } else if (ONREADYSTATECHANGE in cel("script")) {
                    defer = function(id) {
                        html.appendChild(cel("script"))[ONREADYSTATECHANGE] = function() {
                            html.removeChild(this);
                            run.call(id)
                        }
                    }
                } else {
                    defer = function(id) {
                        setTimeout(ctx(run, id, 1), 0)
                    }
                }
            }
            module.exports = {
                set: setTask,
                clear: clearTask
            }
        }
    });
    var require_microtask = __commonJS({
        "node_modules/core-js/modules/_microtask.js" (exports, module) {
            var global2 = require_global();
            var macrotask = require_task().set;
            var Observer = global2.MutationObserver || global2.WebKitMutationObserver;
            var process = global2.process;
            var Promise2 = global2.Promise;
            var isNode = require_cof()(process) == "process";
            module.exports = function() {
                var head, last, notify;
                var flush = function() {
                    var parent, fn;
                    if (isNode && (parent = process.domain)) parent.exit();
                    while (head) {
                        fn = head.fn;
                        head = head.next;
                        try {
                            fn()
                        } catch (e) {
                            if (head) notify();
                            else last = void 0;
                            throw e
                        }
                    }
                    last = void 0;
                    if (parent) parent.enter()
                };
                if (isNode) {
                    notify = function() {
                        process.nextTick(flush)
                    }
                } else if (Observer && !(global2.navigator && global2.navigator.standalone)) {
                    var toggle = true;
                    var node = document.createTextNode("");
                    new Observer(flush).observe(node, {
                        characterData: true
                    });
                    notify = function() {
                        node.data = toggle = !toggle
                    }
                } else if (Promise2 && Promise2.resolve) {
                    var promise = Promise2.resolve(void 0);
                    notify = function() {
                        promise.then(flush)
                    }
                } else {
                    notify = function() {
                        macrotask.call(global2, flush)
                    }
                }
                return function(fn) {
                    var task = {
                        fn,
                        next: void 0
                    };
                    if (last) last.next = task;
                    if (!head) {
                        head = task;
                        notify()
                    }
                    last = task
                }
            }
        }
    });
    var require_new_promise_capability = __commonJS({
        "node_modules/core-js/modules/_new-promise-capability.js" (exports, module) {
            "use strict";
            var aFunction = require_a_function();

            function PromiseCapability(C) {
                var resolve, reject;
                this.promise = new C(function($$resolve, $$reject) {
                    if (resolve !== void 0 || reject !== void 0) throw TypeError("Bad Promise constructor");
                    resolve = $$resolve;
                    reject = $$reject
                });
                this.resolve = aFunction(resolve);
                this.reject = aFunction(reject)
            }
            module.exports.f = function(C) {
                return new PromiseCapability(C)
            }
        }
    });
    var require_perform = __commonJS({
        "node_modules/core-js/modules/_perform.js" (exports, module) {
            module.exports = function(exec) {
                try {
                    return {
                        e: false,
                        v: exec()
                    }
                } catch (e) {
                    return {
                        e: true,
                        v: e
                    }
                }
            }
        }
    });
    var require_user_agent = __commonJS({
        "node_modules/core-js/modules/_user-agent.js" (exports, module) {
            var global2 = require_global();
            var navigator2 = global2.navigator;
            module.exports = navigator2 && navigator2.userAgent || ""
        }
    });
    var require_promise_resolve = __commonJS({
        "node_modules/core-js/modules/_promise-resolve.js" (exports, module) {
            var anObject = require_an_object();
            var isObject = require_is_object();
            var newPromiseCapability = require_new_promise_capability();
            module.exports = function(C, x) {
                anObject(C);
                if (isObject(x) && x.constructor === C) return x;
                var promiseCapability = newPromiseCapability.f(C);
                var resolve = promiseCapability.resolve;
                resolve(x);
                return promiseCapability.promise
            }
        }
    });
    var require_redefine_all = __commonJS({
        "node_modules/core-js/modules/_redefine-all.js" (exports, module) {
            var redefine = require_redefine();
            module.exports = function(target, src, safe) {
                for (var key in src) redefine(target, key, src[key], safe);
                return target
            }
        }
    });
    var require_set_species = __commonJS({
        "node_modules/core-js/modules/_set-species.js" (exports, module) {
            "use strict";
            var global2 = require_global();
            var dP = require_object_dp();
            var DESCRIPTORS = require_descriptors();
            var SPECIES = require_wks()("species");
            module.exports = function(KEY) {
                var C = global2[KEY];
                if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
                    configurable: true,
                    get: function() {
                        return this
                    }
                })
            }
        }
    });
    var require_iter_detect = __commonJS({
        "node_modules/core-js/modules/_iter-detect.js" (exports, module) {
            var ITERATOR = require_wks()("iterator");
            var SAFE_CLOSING = false;
            try {
                riter = [7][ITERATOR]();
                riter["return"] = function() {
                    SAFE_CLOSING = true
                };
                Array.from(riter, function() {
                    throw 2
                })
            } catch (e) {}
            var riter;
            module.exports = function(exec, skipClosing) {
                if (!skipClosing && !SAFE_CLOSING) return false;
                var safe = false;
                try {
                    var arr = [7];
                    var iter = arr[ITERATOR]();
                    iter.next = function() {
                        return {
                            done: safe = true
                        }
                    };
                    arr[ITERATOR] = function() {
                        return iter
                    };
                    exec(arr)
                } catch (e) {}
                return safe
            }
        }
    });
    var require_es6_promise = __commonJS({
        "node_modules/core-js/modules/es6.promise.js" () {
            "use strict";
            var LIBRARY = require_library();
            var global2 = require_global();
            var ctx = require_ctx();
            var classof = require_classof();
            var $export = require_export();
            var isObject = require_is_object();
            var aFunction = require_a_function();
            var anInstance = require_an_instance();
            var forOf = require_for_of();
            var speciesConstructor = require_species_constructor();
            var task = require_task().set;
            var microtask = require_microtask()();
            var newPromiseCapabilityModule = require_new_promise_capability();
            var perform = require_perform();
            var userAgent = require_user_agent();
            var promiseResolve = require_promise_resolve();
            var PROMISE = "Promise";
            var TypeError2 = global2.TypeError;
            var process = global2.process;
            var versions = process && process.versions;
            var v8 = versions && versions.v8 || "";
            var $Promise = global2[PROMISE];
            var isNode = classof(process) == "process";
            var empty = function() {};
            var Internal;
            var newGenericPromiseCapability;
            var OwnPromiseCapability;
            var Wrapper;
            var newPromiseCapability = newGenericPromiseCapability = newPromiseCapabilityModule.f;
            var USE_NATIVE = !! function() {
                try {
                    var promise = $Promise.resolve(1);
                    var FakePromise = (promise.constructor = {})[require_wks()("species")] = function(exec) {
                        exec(empty, empty)
                    };
                    return (isNode || typeof PromiseRejectionEvent == "function") && promise.then(empty) instanceof FakePromise && v8.indexOf("6.6") !== 0 && userAgent.indexOf("Chrome/66") === -1
                } catch (e) {}
            }();
            var isThenable = function(it) {
                var then;
                return isObject(it) && typeof(then = it.then) == "function" ? then : false
            };
            var notify = function(promise, isReject) {
                if (promise._n) return;
                promise._n = true;
                var chain = promise._c;
                microtask(function() {
                    var value = promise._v;
                    var ok = promise._s == 1;
                    var i = 0;
                    var run = function(reaction) {
                        var handler = ok ? reaction.ok : reaction.fail;
                        var resolve = reaction.resolve;
                        var reject = reaction.reject;
                        var domain = reaction.domain;
                        var result, then, exited;
                        try {
                            if (handler) {
                                if (!ok) {
                                    if (promise._h == 2) onHandleUnhandled(promise);
                                    promise._h = 1
                                }
                                if (handler === true) result = value;
                                else {
                                    if (domain) domain.enter();
                                    result = handler(value);
                                    if (domain) {
                                        domain.exit();
                                        exited = true
                                    }
                                }
                                if (result === reaction.promise) {
                                    reject(TypeError2("Promise-chain cycle"))
                                } else if (then = isThenable(result)) {
                                    then.call(result, resolve, reject)
                                } else resolve(result)
                            } else reject(value)
                        } catch (e) {
                            if (domain && !exited) domain.exit();
                            reject(e)
                        }
                    };
                    while (chain.length > i) run(chain[i++]);
                    promise._c = [];
                    promise._n = false;
                    if (isReject && !promise._h) onUnhandled(promise)
                })
            };
            var onUnhandled = function(promise) {
                task.call(global2, function() {
                    var value = promise._v;
                    var unhandled = isUnhandled(promise);
                    var result, handler, console2;
                    if (unhandled) {
                        result = perform(function() {
                            if (isNode) {
                                process.emit("unhandledRejection", value, promise)
                            } else if (handler = global2.onunhandledrejection) {
                                handler({
                                    promise,
                                    reason: value
                                })
                            } else if ((console2 = global2.console) && console2.error) {
                                console2.error("Unhandled promise rejection", value)
                            }
                        });
                        promise._h = isNode || isUnhandled(promise) ? 2 : 1
                    }
                    promise._a = void 0;
                    if (unhandled && result.e) throw result.v
                })
            };
            var isUnhandled = function(promise) {
                return promise._h !== 1 && (promise._a || promise._c).length === 0
            };
            var onHandleUnhandled = function(promise) {
                task.call(global2, function() {
                    var handler;
                    if (isNode) {
                        process.emit("rejectionHandled", promise)
                    } else if (handler = global2.onrejectionhandled) {
                        handler({
                            promise,
                            reason: promise._v
                        })
                    }
                })
            };
            var $reject = function(value) {
                var promise = this;
                if (promise._d) return;
                promise._d = true;
                promise = promise._w || promise;
                promise._v = value;
                promise._s = 2;
                if (!promise._a) promise._a = promise._c.slice();
                notify(promise, true)
            };
            var $resolve = function(value) {
                var promise = this;
                var then;
                if (promise._d) return;
                promise._d = true;
                promise = promise._w || promise;
                try {
                    if (promise === value) throw TypeError2("Promise can't be resolved itself");
                    if (then = isThenable(value)) {
                        microtask(function() {
                            var wrapper = {
                                _w: promise,
                                _d: false
                            };
                            try {
                                then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1))
                            } catch (e) {
                                $reject.call(wrapper, e)
                            }
                        })
                    } else {
                        promise._v = value;
                        promise._s = 1;
                        notify(promise, false)
                    }
                } catch (e) {
                    $reject.call({
                        _w: promise,
                        _d: false
                    }, e)
                }
            };
            if (!USE_NATIVE) {
                $Promise = function Promise2(executor) {
                    anInstance(this, $Promise, PROMISE, "_h");
                    aFunction(executor);
                    Internal.call(this);
                    try {
                        executor(ctx($resolve, this, 1), ctx($reject, this, 1))
                    } catch (err) {
                        $reject.call(this, err)
                    }
                };
                Internal = function Promise2(executor) {
                    this._c = [];
                    this._a = void 0;
                    this._s = 0;
                    this._d = false;
                    this._v = void 0;
                    this._h = 0;
                    this._n = false
                };
                Internal.prototype = require_redefine_all()($Promise.prototype, {
                    then: function then(onFulfilled, onRejected) {
                        var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
                        reaction.ok = typeof onFulfilled == "function" ? onFulfilled : true;
                        reaction.fail = typeof onRejected == "function" && onRejected;
                        reaction.domain = isNode ? process.domain : void 0;
                        this._c.push(reaction);
                        if (this._a) this._a.push(reaction);
                        if (this._s) notify(this, false);
                        return reaction.promise
                    },
                    "catch": function(onRejected) {
                        return this.then(void 0, onRejected)
                    }
                });
                OwnPromiseCapability = function() {
                    var promise = new Internal;
                    this.promise = promise;
                    this.resolve = ctx($resolve, promise, 1);
                    this.reject = ctx($reject, promise, 1)
                };
                newPromiseCapabilityModule.f = newPromiseCapability = function(C) {
                    return C === $Promise || C === Wrapper ? new OwnPromiseCapability(C) : newGenericPromiseCapability(C)
                }
            }
            $export($export.G + $export.W + $export.F * !USE_NATIVE, {
                Promise: $Promise
            });
            require_set_to_string_tag()($Promise, PROMISE);
            require_set_species()(PROMISE);
            Wrapper = require_core()[PROMISE];
            $export($export.S + $export.F * !USE_NATIVE, PROMISE, {
                reject: function reject(r) {
                    var capability = newPromiseCapability(this);
                    var $$reject = capability.reject;
                    $$reject(r);
                    return capability.promise
                }
            });
            $export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
                resolve: function resolve(x) {
                    return promiseResolve(LIBRARY && this === Wrapper ? $Promise : this, x)
                }
            });
            $export($export.S + $export.F * !(USE_NATIVE && require_iter_detect()(function(iter) {
                $Promise.all(iter)["catch"](empty)
            })), PROMISE, {
                all: function all(iterable) {
                    var C = this;
                    var capability = newPromiseCapability(C);
                    var resolve = capability.resolve;
                    var reject = capability.reject;
                    var result = perform(function() {
                        var values = [];
                        var index = 0;
                        var remaining = 1;
                        forOf(iterable, false, function(promise) {
                            var $index = index++;
                            var alreadyCalled = false;
                            values.push(void 0);
                            remaining++;
                            C.resolve(promise).then(function(value) {
                                if (alreadyCalled) return;
                                alreadyCalled = true;
                                values[$index] = value;
                                --remaining || resolve(values)
                            }, reject)
                        });
                        --remaining || resolve(values)
                    });
                    if (result.e) reject(result.v);
                    return capability.promise
                },
                race: function race(iterable) {
                    var C = this;
                    var capability = newPromiseCapability(C);
                    var reject = capability.reject;
                    var result = perform(function() {
                        forOf(iterable, false, function(promise) {
                            C.resolve(promise).then(capability.resolve, reject)
                        })
                    });
                    if (result.e) reject(result.v);
                    return capability.promise
                }
            })
        }
    });
    var require_promise = __commonJS({
        "node_modules/core-js/es6/promise.js" (exports, module) {
            require_es6_object_to_string();
            require_es6_string_iterator();
            require_web_dom_iterable();
            require_es6_promise();
            module.exports = require_core().Promise
        }
    });
    var require_ua_parser = __commonJS({
        "node_modules/ua-parser-js/src/ua-parser.js" (exports, module) {
            (function(window2, undefined2) {
                "use strict";
                var LIBVERSION = "0.7.40",
                    EMPTY = "",
                    UNKNOWN = "?",
                    FUNC_TYPE = "function",
                    UNDEF_TYPE = "undefined",
                    OBJ_TYPE = "object",
                    STR_TYPE = "string",
                    MAJOR = "major",
                    MODEL = "model",
                    NAME = "name",
                    TYPE = "type",
                    VENDOR = "vendor",
                    VERSION = "version",
                    ARCHITECTURE = "architecture",
                    CONSOLE = "console",
                    MOBILE = "mobile",
                    TABLET = "tablet",
                    SMARTTV = "smarttv",
                    WEARABLE = "wearable",
                    EMBEDDED = "embedded",
                    UA_MAX_LENGTH = 500;
                var AMAZON = "Amazon",
                    APPLE = "Apple",
                    ASUS = "ASUS",
                    BLACKBERRY = "BlackBerry",
                    BROWSER = "Browser",
                    CHROME = "Chrome",
                    EDGE = "Edge",
                    FIREFOX = "Firefox",
                    GOOGLE = "Google",
                    HUAWEI = "Huawei",
                    LG = "LG",
                    MICROSOFT = "Microsoft",
                    MOTOROLA = "Motorola",
                    OPERA = "Opera",
                    SAMSUNG = "Samsung",
                    SHARP = "Sharp",
                    SONY = "Sony",
                    XIAOMI = "Xiaomi",
                    ZEBRA = "Zebra",
                    FACEBOOK = "Facebook",
                    CHROMIUM_OS = "Chromium OS",
                    MAC_OS = "Mac OS",
                    SUFFIX_BROWSER = " Browser";
                var extend = function(regexes2, extensions) {
                        var mergedRegexes = {};
                        for (var i in regexes2) {
                            if (extensions[i] && extensions[i].length % 2 === 0) {
                                mergedRegexes[i] = extensions[i].concat(regexes2[i])
                            } else {
                                mergedRegexes[i] = regexes2[i]
                            }
                        }
                        return mergedRegexes
                    },
                    enumerize = function(arr) {
                        var enums = {};
                        for (var i = 0; i < arr.length; i++) {
                            enums[arr[i].toUpperCase()] = arr[i]
                        }
                        return enums
                    },
                    has = function(str1, str2) {
                        return typeof str1 === STR_TYPE ? lowerize(str2).indexOf(lowerize(str1)) !== -1 : false
                    },
                    lowerize = function(str) {
                        return str.toLowerCase()
                    },
                    majorize = function(version) {
                        return typeof version === STR_TYPE ? version.replace(/[^\d\.]/g, EMPTY).split(".")[0] : undefined2
                    },
                    trim = function(str, len) {
                        if (typeof str === STR_TYPE) {
                            str = str.replace(/^\s\s*/, EMPTY);
                            return typeof len === UNDEF_TYPE ? str : str.substring(0, UA_MAX_LENGTH)
                        }
                    };
                var rgxMapper = function(ua, arrays) {
                        var i = 0,
                            j, k, p, q, matches, match;
                        while (i < arrays.length && !matches) {
                            var regex = arrays[i],
                                props = arrays[i + 1];
                            j = k = 0;
                            while (j < regex.length && !matches) {
                                if (!regex[j]) {
                                    break
                                }
                                matches = regex[j++].exec(ua);
                                if (!!matches) {
                                    for (p = 0; p < props.length; p++) {
                                        match = matches[++k];
                                        q = props[p];
                                        if (typeof q === OBJ_TYPE && q.length > 0) {
                                            if (q.length === 2) {
                                                if (typeof q[1] == FUNC_TYPE) {
                                                    this[q[0]] = q[1].call(this, match)
                                                } else {
                                                    this[q[0]] = q[1]
                                                }
                                            } else if (q.length === 3) {
                                                if (typeof q[1] === FUNC_TYPE && !(q[1].exec && q[1].test)) {
                                                    this[q[0]] = match ? q[1].call(this, match, q[2]) : undefined2
                                                } else {
                                                    this[q[0]] = match ? match.replace(q[1], q[2]) : undefined2
                                                }
                                            } else if (q.length === 4) {
                                                this[q[0]] = match ? q[3].call(this, match.replace(q[1], q[2])) : undefined2
                                            }
                                        } else {
                                            this[q] = match ? match : undefined2
                                        }
                                    }
                                }
                            }
                            i += 2
                        }
                    },
                    strMapper = function(str, map) {
                        for (var i in map) {
                            if (typeof map[i] === OBJ_TYPE && map[i].length > 0) {
                                for (var j = 0; j < map[i].length; j++) {
                                    if (has(map[i][j], str)) {
                                        return i === UNKNOWN ? undefined2 : i
                                    }
                                }
                            } else if (has(map[i], str)) {
                                return i === UNKNOWN ? undefined2 : i
                            }
                        }
                        return map.hasOwnProperty("*") ? map["*"] : str
                    };
                var oldSafariMap = {
                        "1.0": "/8",
                        "1.2": "/1",
                        "1.3": "/3",
                        "2.0": "/412",
                        "2.0.2": "/416",
                        "2.0.3": "/417",
                        "2.0.4": "/419",
                        "?": "/"
                    },
                    windowsVersionMap = {
                        "ME": "4.90",
                        "NT 3.11": "NT3.51",
                        "NT 4.0": "NT4.0",
                        "2000": "NT 5.0",
                        "XP": ["NT 5.1", "NT 5.2"],
                        "Vista": "NT 6.0",
                        "7": "NT 6.1",
                        "8": "NT 6.2",
                        "8.1": "NT 6.3",
                        "10": ["NT 6.4", "NT 10.0"],
                        "RT": "ARM"
                    };
                var regexes = {
                    browser: [
                        [/\b(?:crmo|crios)\/([\w\.]+)/i],
                        [VERSION, [NAME, "Chrome"]],
                        [/edg(?:e|ios|a)?\/([\w\.]+)/i],
                        [VERSION, [NAME, "Edge"]],
                        [/(opera mini)\/([-\w\.]+)/i, /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i, /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i],
                        [NAME, VERSION],
                        [/opios[\/ ]+([\w\.]+)/i],
                        [VERSION, [NAME, OPERA + " Mini"]],
                        [/\bop(?:rg)?x\/([\w\.]+)/i],
                        [VERSION, [NAME, OPERA + " GX"]],
                        [/\bopr\/([\w\.]+)/i],
                        [VERSION, [NAME, OPERA]],
                        [/\bb[ai]*d(?:uhd|[ub]*[aekoprswx]{5,6})[\/ ]?([\w\.]+)/i],
                        [VERSION, [NAME, "Baidu"]],
                        [/\b(?:mxbrowser|mxios|myie2)\/?([-\w\.]*)\b/i],
                        [VERSION, [NAME, "Maxthon"]],
                        [/(kindle)\/([\w\.]+)/i, /(lunascape|maxthon|netfront|jasmine|blazer|sleipnir)[\/ ]?([\w\.]*)/i, /(avant|iemobile|slim(?:browser|boat|jet))[\/ ]?([\d\.]*)/i, /(?:ms|\()(ie) ([\w\.]+)/i, /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|duckduckgo|klar|helio|(?=comodo_)?dragon)\/([-\w\.]+)/i, /(heytap|ovi|115)browser\/([\d\.]+)/i, /(weibo)__([\d\.]+)/i],
                        [NAME, VERSION],
                        [/quark(?:pc)?\/([-\w\.]+)/i],
                        [VERSION, [NAME, "Quark"]],
                        [/\bddg\/([\w\.]+)/i],
                        [VERSION, [NAME, "DuckDuckGo"]],
                        [/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],
                        [VERSION, [NAME, "UC" + BROWSER]],
                        [/microm.+\bqbcore\/([\w\.]+)/i, /\bqbcore\/([\w\.]+).+microm/i, /micromessenger\/([\w\.]+)/i],
                        [VERSION, [NAME, "WeChat"]],
                        [/konqueror\/([\w\.]+)/i],
                        [VERSION, [NAME, "Konqueror"]],
                        [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],
                        [VERSION, [NAME, "IE"]],
                        [/ya(?:search)?browser\/([\w\.]+)/i],
                        [VERSION, [NAME, "Yandex"]],
                        [/slbrowser\/([\w\.]+)/i],
                        [VERSION, [NAME, "Smart Lenovo " + BROWSER]],
                        [/(avast|avg)\/([\w\.]+)/i],
                        [
                            [NAME, /(.+)/, "$1 Secure " + BROWSER], VERSION
                        ],
                        [/\bfocus\/([\w\.]+)/i],
                        [VERSION, [NAME, FIREFOX + " Focus"]],
                        [/\bopt\/([\w\.]+)/i],
                        [VERSION, [NAME, OPERA + " Touch"]],
                        [/coc_coc\w+\/([\w\.]+)/i],
                        [VERSION, [NAME, "Coc Coc"]],
                        [/dolfin\/([\w\.]+)/i],
                        [VERSION, [NAME, "Dolphin"]],
                        [/coast\/([\w\.]+)/i],
                        [VERSION, [NAME, OPERA + " Coast"]],
                        [/miuibrowser\/([\w\.]+)/i],
                        [VERSION, [NAME, "MIUI" + SUFFIX_BROWSER]],
                        [/fxios\/([\w\.-]+)/i],
                        [VERSION, [NAME, FIREFOX]],
                        [/\bqihoobrowser\/?([\w\.]*)/i],
                        [VERSION, [NAME, "360"]],
                        [/\b(qq)\/([\w\.]+)/i],
                        [
                            [NAME, /(.+)/, "$1Browser"], VERSION
                        ],
                        [/(oculus|sailfish|huawei|vivo|pico)browser\/([\w\.]+)/i],
                        [
                            [NAME, /(.+)/, "$1" + SUFFIX_BROWSER], VERSION
                        ],
                        [/samsungbrowser\/([\w\.]+)/i],
                        [VERSION, [NAME, SAMSUNG + " Internet"]],
                        [/metasr[\/ ]?([\d\.]+)/i],
                        [VERSION, [NAME, "Sogou Explorer"]],
                        [/(sogou)mo\w+\/([\d\.]+)/i],
                        [
                            [NAME, "Sogou Mobile"], VERSION
                        ],
                        [/(electron)\/([\w\.]+) safari/i, /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i, /m?(qqbrowser|2345(?=browser|chrome|explorer))\w*[\/ ]?v?([\w\.]+)/i],
                        [NAME, VERSION],
                        [/(lbbrowser|rekonq)/i, /\[(linkedin)app\]/i],
                        [NAME],
                        [/ome\/([\w\.]+) \w* ?(iron) saf/i, /ome\/([\w\.]+).+qihu (360)[es]e/i],
                        [VERSION, NAME],
                        [/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i],
                        [
                            [NAME, FACEBOOK], VERSION
                        ],
                        [/(Klarna)\/([\w\.]+)/i, /(kakao(?:talk|story))[\/ ]([\w\.]+)/i, /(naver)\(.*?(\d+\.[\w\.]+).*\)/i, /safari (line)\/([\w\.]+)/i, /\b(line)\/([\w\.]+)\/iab/i, /(alipay)client\/([\w\.]+)/i, /(twitter)(?:and| f.+e\/([\w\.]+))/i, /(chromium|instagram|snapchat)[\/ ]([-\w\.]+)/i],
                        [NAME, VERSION],
                        [/\bgsa\/([\w\.]+) .*safari\//i],
                        [VERSION, [NAME, "GSA"]],
                        [/musical_ly(?:.+app_?version\/|_)([\w\.]+)/i],
                        [VERSION, [NAME, "TikTok"]],
                        [/headlesschrome(?:\/([\w\.]+)| )/i],
                        [VERSION, [NAME, CHROME + " Headless"]],
                        [/ wv\).+(chrome)\/([\w\.]+)/i],
                        [
                            [NAME, CHROME + " WebView"], VERSION
                        ],
                        [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],
                        [VERSION, [NAME, "Android " + BROWSER]],
                        [/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i],
                        [NAME, VERSION],
                        [/version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i],
                        [VERSION, [NAME, "Mobile Safari"]],
                        [/version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i],
                        [VERSION, NAME],
                        [/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],
                        [NAME, [VERSION, strMapper, oldSafariMap]],
                        [/(webkit|khtml)\/([\w\.]+)/i],
                        [NAME, VERSION],
                        [/(navigator|netscape\d?)\/([-\w\.]+)/i],
                        [
                            [NAME, "Netscape"], VERSION
                        ],
                        [/(wolvic|librewolf)\/([\w\.]+)/i],
                        [NAME, VERSION],
                        [/mobile vr; rv:([\w\.]+)\).+firefox/i],
                        [VERSION, [NAME, FIREFOX + " Reality"]],
                        [/ekiohf.+(flow)\/([\w\.]+)/i, /(swiftfox)/i, /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror)[\/ ]?([\w\.\+]+)/i, /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i, /(firefox)\/([\w\.]+)/i, /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i, /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i, /(links) \(([\w\.]+)/i],
                        [NAME, [VERSION, /_/g, "."]],
                        [/(cobalt)\/([\w\.]+)/i],
                        [NAME, [VERSION, /master.|lts./, ""]]
                    ],
                    cpu: [
                        [/(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i],
                        [
                            [ARCHITECTURE, "amd64"]
                        ],
                        [/(ia32(?=;))/i],
                        [
                            [ARCHITECTURE, lowerize]
                        ],
                        [/((?:i[346]|x)86)[;\)]/i],
                        [
                            [ARCHITECTURE, "ia32"]
                        ],
                        [/\b(aarch64|arm(v?8e?l?|_?64))\b/i],
                        [
                            [ARCHITECTURE, "arm64"]
                        ],
                        [/\b(arm(?:v[67])?ht?n?[fl]p?)\b/i],
                        [
                            [ARCHITECTURE, "armhf"]
                        ],
                        [/windows (ce|mobile); ppc;/i],
                        [
                            [ARCHITECTURE, "arm"]
                        ],
                        [/((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i],
                        [
                            [ARCHITECTURE, /ower/, EMPTY, lowerize]
                        ],
                        [/(sun4\w)[;\)]/i],
                        [
                            [ARCHITECTURE, "sparc"]
                        ],
                        [/((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i],
                        [
                            [ARCHITECTURE, lowerize]
                        ]
                    ],
                    device: [
                        [/\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i],
                        [MODEL, [VENDOR, SAMSUNG],
                            [TYPE, TABLET]
                        ],
                        [/\b((?:s[cgp]h|gt|sm)-(?![lr])\w+|sc[g-]?[\d]+a?|galaxy nexus)/i, /samsung[- ]((?!sm-[lr])[-\w]+)/i, /sec-(sgh\w+)/i],
                        [MODEL, [VENDOR, SAMSUNG],
                            [TYPE, MOBILE]
                        ],
                        [/(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i],
                        [MODEL, [VENDOR, APPLE],
                            [TYPE, MOBILE]
                        ],
                        [/\((ipad);[-\w\),; ]+apple/i, /applecoremedia\/[\w\.]+ \((ipad)/i, /\b(ipad)\d\d?,\d\d?[;\]].+ios/i],
                        [MODEL, [VENDOR, APPLE],
                            [TYPE, TABLET]
                        ],
                        [/(macintosh);/i],
                        [MODEL, [VENDOR, APPLE]],
                        [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],
                        [MODEL, [VENDOR, SHARP],
                            [TYPE, MOBILE]
                        ],
                        [/(?:honor)([-\w ]+)[;\)]/i],
                        [MODEL, [VENDOR, "Honor"],
                            [TYPE, MOBILE]
                        ],
                        [/\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i],
                        [MODEL, [VENDOR, HUAWEI],
                            [TYPE, TABLET]
                        ],
                        [/(?:huawei)([-\w ]+)[;\)]/i, /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i],
                        [MODEL, [VENDOR, HUAWEI],
                            [TYPE, MOBILE]
                        ],
                        [/\b(poco[\w ]+|m2\d{3}j\d\d[a-z]{2})(?: bui|\))/i, /\b; (\w+) build\/hm\1/i, /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i, /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i, /oid[^\)]+; (m?[12][0-389][01]\w{3,6}[c-y])( bui|; wv|\))/i, /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite|pro)?)(?: bui|\))/i],
                        [
                            [MODEL, /_/g, " "],
                            [VENDOR, XIAOMI],
                            [TYPE, MOBILE]
                        ],
                        [/oid[^\)]+; (2\d{4}(283|rpbf)[cgl])( bui|\))/i, /\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i],
                        [
                            [MODEL, /_/g, " "],
                            [VENDOR, XIAOMI],
                            [TYPE, TABLET]
                        ],
                        [/; (\w+) bui.+ oppo/i, /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i],
                        [MODEL, [VENDOR, "OPPO"],
                            [TYPE, MOBILE]
                        ],
                        [/\b(opd2\d{3}a?) bui/i],
                        [MODEL, [VENDOR, "OPPO"],
                            [TYPE, TABLET]
                        ],
                        [/vivo (\w+)(?: bui|\))/i, /\b(v[12]\d{3}\w?[at])(?: bui|;)/i],
                        [MODEL, [VENDOR, "Vivo"],
                            [TYPE, MOBILE]
                        ],
                        [/\b(rmx[1-3]\d{3})(?: bui|;|\))/i],
                        [MODEL, [VENDOR, "Realme"],
                            [TYPE, MOBILE]
                        ],
                        [/\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i, /\bmot(?:orola)?[- ](\w*)/i, /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i],
                        [MODEL, [VENDOR, MOTOROLA],
                            [TYPE, MOBILE]
                        ],
                        [/\b(mz60\d|xoom[2 ]{0,2}) build\//i],
                        [MODEL, [VENDOR, MOTOROLA],
                            [TYPE, TABLET]
                        ],
                        [/((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i],
                        [MODEL, [VENDOR, LG],
                            [TYPE, TABLET]
                        ],
                        [/(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i, /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i, /\blg-?([\d\w]+) bui/i],
                        [MODEL, [VENDOR, LG],
                            [TYPE, MOBILE]
                        ],
                        [/(ideatab[-\w ]+)/i, /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i],
                        [MODEL, [VENDOR, "Lenovo"],
                            [TYPE, TABLET]
                        ],
                        [/(?:maemo|nokia).*(n900|lumia \d+)/i, /nokia[-_ ]?([-\w\.]*)/i],
                        [
                            [MODEL, /_/g, " "],
                            [VENDOR, "Nokia"],
                            [TYPE, MOBILE]
                        ],
                        [/(pixel c)\b/i],
                        [MODEL, [VENDOR, GOOGLE],
                            [TYPE, TABLET]
                        ],
                        [/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],
                        [MODEL, [VENDOR, GOOGLE],
                            [TYPE, MOBILE]
                        ],
                        [/droid.+; (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i],
                        [MODEL, [VENDOR, SONY],
                            [TYPE, MOBILE]
                        ],
                        [/sony tablet [ps]/i, /\b(?:sony)?sgp\w+(?: bui|\))/i],
                        [
                            [MODEL, "Xperia Tablet"],
                            [VENDOR, SONY],
                            [TYPE, TABLET]
                        ],
                        [/ (kb2005|in20[12]5|be20[12][59])\b/i, /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i],
                        [MODEL, [VENDOR, "OnePlus"],
                            [TYPE, MOBILE]
                        ],
                        [/(alexa)webm/i, /(kf[a-z]{2}wi|aeo(?!bc)\w\w)( bui|\))/i, /(kf[a-z]+)( bui|\)).+silk\//i],
                        [MODEL, [VENDOR, AMAZON],
                            [TYPE, TABLET]
                        ],
                        [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],
                        [
                            [MODEL, /(.+)/g, "Fire Phone $1"],
                            [VENDOR, AMAZON],
                            [TYPE, MOBILE]
                        ],
                        [/(playbook);[-\w\),; ]+(rim)/i],
                        [MODEL, VENDOR, [TYPE, TABLET]],
                        [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i],
                        [MODEL, [VENDOR, BLACKBERRY],
                            [TYPE, MOBILE]
                        ],
                        [/(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i],
                        [MODEL, [VENDOR, ASUS],
                            [TYPE, TABLET]
                        ],
                        [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],
                        [MODEL, [VENDOR, ASUS],
                            [TYPE, MOBILE]
                        ],
                        [/(nexus 9)/i],
                        [MODEL, [VENDOR, "HTC"],
                            [TYPE, TABLET]
                        ],
                        [/(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i, /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i, /(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i],
                        [VENDOR, [MODEL, /_/g, " "],
                            [TYPE, MOBILE]
                        ],
                        [/droid [\w\.]+; ((?:8[14]9[16]|9(?:0(?:48|60|8[01])|1(?:3[27]|66)|2(?:6[69]|9[56])|466))[gqswx])\w*(\)| bui)/i],
                        [MODEL, [VENDOR, "TCL"],
                            [TYPE, TABLET]
                        ],
                        [/(itel) ((\w+))/i],
                        [
                            [VENDOR, lowerize], MODEL, [TYPE, strMapper, {
                                "tablet": ["p10001l", "w7001"],
                                "*": "mobile"
                            }]
                        ],
                        [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],
                        [MODEL, [VENDOR, "Acer"],
                            [TYPE, TABLET]
                        ],
                        [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i],
                        [MODEL, [VENDOR, "Meizu"],
                            [TYPE, MOBILE]
                        ],
                        [/; ((?:power )?armor(?:[\w ]{0,8}))(?: bui|\))/i],
                        [MODEL, [VENDOR, "Ulefone"],
                            [TYPE, MOBILE]
                        ],
                        [/; (energy ?\w+)(?: bui|\))/i, /; energizer ([\w ]+)(?: bui|\))/i],
                        [MODEL, [VENDOR, "Energizer"],
                            [TYPE, MOBILE]
                        ],
                        [/; cat (b35);/i, /; (b15q?|s22 flip|s48c|s62 pro)(?: bui|\))/i],
                        [MODEL, [VENDOR, "Cat"],
                            [TYPE, MOBILE]
                        ],
                        [/((?:new )?andromax[\w- ]+)(?: bui|\))/i],
                        [MODEL, [VENDOR, "Smartfren"],
                            [TYPE, MOBILE]
                        ],
                        [/droid.+; (a(?:015|06[35]|142p?))/i],
                        [MODEL, [VENDOR, "Nothing"],
                            [TYPE, MOBILE]
                        ],
                        [/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron|infinix|tecno|micromax|advan)[-_ ]?([-\w]*)/i, /; (imo) ((?!tab)[\w ]+?)(?: bui|\))/i, /(hp) ([\w ]+\w)/i, /(asus)-?(\w+)/i, /(microsoft); (lumia[\w ]+)/i, /(lenovo)[-_ ]?([-\w]+)/i, /(jolla)/i, /(oppo) ?([\w ]+) bui/i],
                        [VENDOR, MODEL, [TYPE, MOBILE]],
                        [/(imo) (tab \w+)/i, /(kobo)\s(ereader|touch)/i, /(archos) (gamepad2?)/i, /(hp).+(touchpad(?!.+tablet)|tablet)/i, /(kindle)\/([\w\.]+)/i, /(nook)[\w ]+build\/(\w+)/i, /(dell) (strea[kpr\d ]*[\dko])/i, /(le[- ]+pan)[- ]+(\w{1,9}) bui/i, /(trinity)[- ]*(t\d{3}) bui/i, /(gigaset)[- ]+(q\w{1,9}) bui/i, /(vodafone) ([\w ]+)(?:\)| bui)/i],
                        [VENDOR, MODEL, [TYPE, TABLET]],
                        [/(surface duo)/i],
                        [MODEL, [VENDOR, MICROSOFT],
                            [TYPE, TABLET]
                        ],
                        [/droid [\d\.]+; (fp\du?)(?: b|\))/i],
                        [MODEL, [VENDOR, "Fairphone"],
                            [TYPE, MOBILE]
                        ],
                        [/(u304aa)/i],
                        [MODEL, [VENDOR, "AT&T"],
                            [TYPE, MOBILE]
                        ],
                        [/\bsie-(\w*)/i],
                        [MODEL, [VENDOR, "Siemens"],
                            [TYPE, MOBILE]
                        ],
                        [/\b(rct\w+) b/i],
                        [MODEL, [VENDOR, "RCA"],
                            [TYPE, TABLET]
                        ],
                        [/\b(venue[\d ]{2,7}) b/i],
                        [MODEL, [VENDOR, "Dell"],
                            [TYPE, TABLET]
                        ],
                        [/\b(q(?:mv|ta)\w+) b/i],
                        [MODEL, [VENDOR, "Verizon"],
                            [TYPE, TABLET]
                        ],
                        [/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],
                        [MODEL, [VENDOR, "Barnes & Noble"],
                            [TYPE, TABLET]
                        ],
                        [/\b(tm\d{3}\w+) b/i],
                        [MODEL, [VENDOR, "NuVision"],
                            [TYPE, TABLET]
                        ],
                        [/\b(k88) b/i],
                        [MODEL, [VENDOR, "ZTE"],
                            [TYPE, TABLET]
                        ],
                        [/\b(nx\d{3}j) b/i],
                        [MODEL, [VENDOR, "ZTE"],
                            [TYPE, MOBILE]
                        ],
                        [/\b(gen\d{3}) b.+49h/i],
                        [MODEL, [VENDOR, "Swiss"],
                            [TYPE, MOBILE]
                        ],
                        [/\b(zur\d{3}) b/i],
                        [MODEL, [VENDOR, "Swiss"],
                            [TYPE, TABLET]
                        ],
                        [/\b((zeki)?tb.*\b) b/i],
                        [MODEL, [VENDOR, "Zeki"],
                            [TYPE, TABLET]
                        ],
                        [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i],
                        [
                            [VENDOR, "Dragon Touch"], MODEL, [TYPE, TABLET]
                        ],
                        [/\b(ns-?\w{0,9}) b/i],
                        [MODEL, [VENDOR, "Insignia"],
                            [TYPE, TABLET]
                        ],
                        [/\b((nxa|next)-?\w{0,9}) b/i],
                        [MODEL, [VENDOR, "NextBook"],
                            [TYPE, TABLET]
                        ],
                        [/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],
                        [
                            [VENDOR, "Voice"], MODEL, [TYPE, MOBILE]
                        ],
                        [/\b(lvtel\-)?(v1[12]) b/i],
                        [
                            [VENDOR, "LvTel"], MODEL, [TYPE, MOBILE]
                        ],
                        [/\b(ph-1) /i],
                        [MODEL, [VENDOR, "Essential"],
                            [TYPE, MOBILE]
                        ],
                        [/\b(v(100md|700na|7011|917g).*\b) b/i],
                        [MODEL, [VENDOR, "Envizen"],
                            [TYPE, TABLET]
                        ],
                        [/\b(trio[-\w\. ]+) b/i],
                        [MODEL, [VENDOR, "MachSpeed"],
                            [TYPE, TABLET]
                        ],
                        [/\btu_(1491) b/i],
                        [MODEL, [VENDOR, "Rotor"],
                            [TYPE, TABLET]
                        ],
                        [/(shield[\w ]+) b/i],
                        [MODEL, [VENDOR, "Nvidia"],
                            [TYPE, TABLET]
                        ],
                        [/(sprint) (\w+)/i],
                        [VENDOR, MODEL, [TYPE, MOBILE]],
                        [/(kin\.[onetw]{3})/i],
                        [
                            [MODEL, /\./g, " "],
                            [VENDOR, MICROSOFT],
                            [TYPE, MOBILE]
                        ],
                        [/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
                        [MODEL, [VENDOR, ZEBRA],
                            [TYPE, TABLET]
                        ],
                        [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],
                        [MODEL, [VENDOR, ZEBRA],
                            [TYPE, MOBILE]
                        ],
                        [/smart-tv.+(samsung)/i],
                        [VENDOR, [TYPE, SMARTTV]],
                        [/hbbtv.+maple;(\d+)/i],
                        [
                            [MODEL, /^/, "SmartTV"],
                            [VENDOR, SAMSUNG],
                            [TYPE, SMARTTV]
                        ],
                        [/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i],
                        [
                            [VENDOR, LG],
                            [TYPE, SMARTTV]
                        ],
                        [/(apple) ?tv/i],
                        [VENDOR, [MODEL, APPLE + " TV"],
                            [TYPE, SMARTTV]
                        ],
                        [/crkey/i],
                        [
                            [MODEL, CHROME + "cast"],
                            [VENDOR, GOOGLE],
                            [TYPE, SMARTTV]
                        ],
                        [/droid.+aft(\w+)( bui|\))/i],
                        [MODEL, [VENDOR, AMAZON],
                            [TYPE, SMARTTV]
                        ],
                        [/\(dtv[\);].+(aquos)/i, /(aquos-tv[\w ]+)\)/i],
                        [MODEL, [VENDOR, SHARP],
                            [TYPE, SMARTTV]
                        ],
                        [/(bravia[\w ]+)( bui|\))/i],
                        [MODEL, [VENDOR, SONY],
                            [TYPE, SMARTTV]
                        ],
                        [/(mitv-\w{5}) bui/i],
                        [MODEL, [VENDOR, XIAOMI],
                            [TYPE, SMARTTV]
                        ],
                        [/Hbbtv.*(technisat) (.*);/i],
                        [VENDOR, MODEL, [TYPE, SMARTTV]],
                        [/\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i, /hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i],
                        [
                            [VENDOR, trim],
                            [MODEL, trim],
                            [TYPE, SMARTTV]
                        ],
                        [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],
                        [
                            [TYPE, SMARTTV]
                        ],
                        [/(ouya)/i, /(nintendo) ([wids3utch]+)/i],
                        [VENDOR, MODEL, [TYPE, CONSOLE]],
                        [/droid.+; (shield) bui/i],
                        [MODEL, [VENDOR, "Nvidia"],
                            [TYPE, CONSOLE]
                        ],
                        [/(playstation [345portablevi]+)/i],
                        [MODEL, [VENDOR, SONY],
                            [TYPE, CONSOLE]
                        ],
                        [/\b(xbox(?: one)?(?!; xbox))[\); ]/i],
                        [MODEL, [VENDOR, MICROSOFT],
                            [TYPE, CONSOLE]
                        ],
                        [/\b(sm-[lr]\d\d[05][fnuw]?s?)\b/i],
                        [MODEL, [VENDOR, SAMSUNG],
                            [TYPE, WEARABLE]
                        ],
                        [/((pebble))app/i],
                        [VENDOR, MODEL, [TYPE, WEARABLE]],
                        [/(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i],
                        [MODEL, [VENDOR, APPLE],
                            [TYPE, WEARABLE]
                        ],
                        [/droid.+; (glass) \d/i],
                        [MODEL, [VENDOR, GOOGLE],
                            [TYPE, WEARABLE]
                        ],
                        [/droid.+; (wt63?0{2,3})\)/i],
                        [MODEL, [VENDOR, ZEBRA],
                            [TYPE, WEARABLE]
                        ],
                        [/droid.+; (glass) \d/i],
                        [MODEL, [VENDOR, GOOGLE],
                            [TYPE, WEARABLE]
                        ],
                        [/(pico) (4|neo3(?: link|pro)?)/i],
                        [VENDOR, MODEL, [TYPE, WEARABLE]],
                        [/; (quest( \d| pro)?)/i],
                        [MODEL, [VENDOR, FACEBOOK],
                            [TYPE, WEARABLE]
                        ],
                        [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],
                        [VENDOR, [TYPE, EMBEDDED]],
                        [/(aeobc)\b/i],
                        [MODEL, [VENDOR, AMAZON],
                            [TYPE, EMBEDDED]
                        ],
                        [/droid .+?; ([^;]+?)(?: bui|; wv\)|\) applew).+? mobile safari/i],
                        [MODEL, [TYPE, MOBILE]],
                        [/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i],
                        [MODEL, [TYPE, TABLET]],
                        [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],
                        [
                            [TYPE, TABLET]
                        ],
                        [/(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i],
                        [
                            [TYPE, MOBILE]
                        ],
                        [/(android[-\w\. ]{0,9});.+buil/i],
                        [MODEL, [VENDOR, "Generic"]]
                    ],
                    engine: [
                        [/windows.+ edge\/([\w\.]+)/i],
                        [VERSION, [NAME, EDGE + "HTML"]],
                        [/(arkweb)\/([\w\.]+)/i],
                        [NAME, VERSION],
                        [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
                        [VERSION, [NAME, "Blink"]],
                        [/(presto)\/([\w\.]+)/i, /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna|servo)\/([\w\.]+)/i, /ekioh(flow)\/([\w\.]+)/i, /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i, /(icab)[\/ ]([23]\.[\d\.]+)/i, /\b(libweb)/i],
                        [NAME, VERSION],
                        [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                        [VERSION, NAME]
                    ],
                    os: [
                        [/microsoft (windows) (vista|xp)/i],
                        [NAME, VERSION],
                        [/(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i],
                        [NAME, [VERSION, strMapper, windowsVersionMap]],
                        [/windows nt 6\.2; (arm)/i, /windows[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i, /(?:win(?=3|9|n)|win 9x )([nt\d\.]+)/i],
                        [
                            [VERSION, strMapper, windowsVersionMap],
                            [NAME, "Windows"]
                        ],
                        [/ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i, /(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i, /cfnetwork\/.+darwin/i],
                        [
                            [VERSION, /_/g, "."],
                            [NAME, "iOS"]
                        ],
                        [/(mac os x) ?([\w\. ]*)/i, /(macintosh|mac_powerpc\b)(?!.+haiku)/i],
                        [
                            [NAME, MAC_OS],
                            [VERSION, /_/g, "."]
                        ],
                        [/droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i],
                        [VERSION, NAME],
                        [/(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish|openharmony)[-\/ ]?([\w\.]*)/i, /(blackberry)\w*\/([\w\.]*)/i, /(tizen|kaios)[\/ ]([\w\.]+)/i, /\((series40);/i],
                        [NAME, VERSION],
                        [/\(bb(10);/i],
                        [VERSION, [NAME, BLACKBERRY]],
                        [/(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i],
                        [VERSION, [NAME, "Symbian"]],
                        [/mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i],
                        [VERSION, [NAME, FIREFOX + " OS"]],
                        [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
                        [VERSION, [NAME, "webOS"]],
                        [/watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i],
                        [VERSION, [NAME, "watchOS"]],
                        [/crkey\/([\d\.]+)/i],
                        [VERSION, [NAME, CHROME + "cast"]],
                        [/(cros) [\w]+(?:\)| ([\w\.]+)\b)/i],
                        [
                            [NAME, CHROMIUM_OS], VERSION
                        ],
                        [/panasonic;(viera)/i, /(netrange)mmh/i, /(nettv)\/(\d+\.[\w\.]+)/i, /(nintendo|playstation) ([wids345portablevuch]+)/i, /(xbox); +xbox ([^\);]+)/i, /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i, /(mint)[\/\(\) ]?(\w*)/i, /(mageia|vectorlinux)[; ]/i, /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i, /(hurd|linux) ?([\w\.]*)/i, /(gnu) ?([\w\.]*)/i, /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, /(haiku) (\w+)/i],
                        [NAME, VERSION],
                        [/(sunos) ?([\w\.\d]*)/i],
                        [
                            [NAME, "Solaris"], VERSION
                        ],
                        [/((?:open)?solaris)[-\/ ]?([\w\.]*)/i, /(aix) ((\d)(?=\.|\)| )[\w\.])*/i, /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i, /(unix) ?([\w\.]*)/i],
                        [NAME, VERSION]
                    ]
                };
                var UAParser2 = function(ua, extensions) {
                    if (typeof ua === OBJ_TYPE) {
                        extensions = ua;
                        ua = undefined2
                    }
                    if (!(this instanceof UAParser2)) {
                        return new UAParser2(ua, extensions).getResult()
                    }
                    var _navigator = typeof window2 !== UNDEF_TYPE && window2.navigator ? window2.navigator : undefined2;
                    var _ua = ua || (_navigator && _navigator.userAgent ? _navigator.userAgent : EMPTY);
                    var _uach = _navigator && _navigator.userAgentData ? _navigator.userAgentData : undefined2;
                    var _rgxmap = extensions ? extend(regexes, extensions) : regexes;
                    var _isSelfNav = _navigator && _navigator.userAgent == _ua;
                    this.getBrowser = function() {
                        var _browser = {};
                        _browser[NAME] = undefined2;
                        _browser[VERSION] = undefined2;
                        rgxMapper.call(_browser, _ua, _rgxmap.browser);
                        _browser[MAJOR] = majorize(_browser[VERSION]);
                        if (_isSelfNav && _navigator && _navigator.brave && typeof _navigator.brave.isBrave == FUNC_TYPE) {
                            _browser[NAME] = "Brave"
                        }
                        return _browser
                    };
                    this.getCPU = function() {
                        var _cpu = {};
                        _cpu[ARCHITECTURE] = undefined2;
                        rgxMapper.call(_cpu, _ua, _rgxmap.cpu);
                        return _cpu
                    };
                    this.getDevice = function() {
                        var _device = {};
                        _device[VENDOR] = undefined2;
                        _device[MODEL] = undefined2;
                        _device[TYPE] = undefined2;
                        rgxMapper.call(_device, _ua, _rgxmap.device);
                        if (_isSelfNav && !_device[TYPE] && _uach && _uach.mobile) {
                            _device[TYPE] = MOBILE
                        }
                        if (_isSelfNav && _device[MODEL] == "Macintosh" && _navigator && typeof _navigator.standalone !== UNDEF_TYPE && _navigator.maxTouchPoints && _navigator.maxTouchPoints > 2) {
                            _device[MODEL] = "iPad";
                            _device[TYPE] = TABLET
                        }
                        return _device
                    };
                    this.getEngine = function() {
                        var _engine = {};
                        _engine[NAME] = undefined2;
                        _engine[VERSION] = undefined2;
                        rgxMapper.call(_engine, _ua, _rgxmap.engine);
                        return _engine
                    };
                    this.getOS = function() {
                        var _os = {};
                        _os[NAME] = undefined2;
                        _os[VERSION] = undefined2;
                        rgxMapper.call(_os, _ua, _rgxmap.os);
                        if (_isSelfNav && !_os[NAME] && _uach && _uach.platform && _uach.platform != "Unknown") {
                            _os[NAME] = _uach.platform.replace(/chrome os/i, CHROMIUM_OS).replace(/macos/i, MAC_OS)
                        }
                        return _os
                    };
                    this.getResult = function() {
                        return {
                            ua: this.getUA(),
                            browser: this.getBrowser(),
                            engine: this.getEngine(),
                            os: this.getOS(),
                            device: this.getDevice(),
                            cpu: this.getCPU()
                        }
                    };
                    this.getUA = function() {
                        return _ua
                    };
                    this.setUA = function(ua2) {
                        _ua = typeof ua2 === STR_TYPE && ua2.length > UA_MAX_LENGTH ? trim(ua2, UA_MAX_LENGTH) : ua2;
                        return this
                    };
                    this.setUA(_ua);
                    return this
                };
                UAParser2.VERSION = LIBVERSION;
                UAParser2.BROWSER = enumerize([NAME, VERSION, MAJOR]);
                UAParser2.CPU = enumerize([ARCHITECTURE]);
                UAParser2.DEVICE = enumerize([MODEL, VENDOR, TYPE, CONSOLE, MOBILE, SMARTTV, TABLET, WEARABLE, EMBEDDED]);
                UAParser2.ENGINE = UAParser2.OS = enumerize([NAME, VERSION]);
                if (typeof exports !== UNDEF_TYPE) {
                    if (typeof module !== UNDEF_TYPE && module.exports) {
                        exports = module.exports = UAParser2
                    }
                    exports.UAParser = UAParser2
                } else {
                    if (typeof define === FUNC_TYPE && define.amd) {
                        define(function() {
                            return UAParser2
                        })
                    } else if (typeof window2 !== UNDEF_TYPE) {
                        window2.UAParser = UAParser2
                    }
                }
                var $ = typeof window2 !== UNDEF_TYPE && (window2.jQuery || window2.Zepto);
                if ($ && !$.ua) {
                    var parser = new UAParser2;
                    $.ua = parser.getResult();
                    $.ua.get = function() {
                        return parser.getUA()
                    };
                    $.ua.set = function(ua) {
                        parser.setUA(ua);
                        var result = parser.getResult();
                        for (var prop in result) {
                            $.ua[prop] = result[prop]
                        }
                    }
                }
            })(typeof window === "object" ? window : exports)
        }
    });
    var import_promise = __toESM(require_promise());
    var g = typeof globalThis !== "undefined" && globalThis || typeof self !== "undefined" && self || typeof global !== "undefined" && global || {};
    var support = {
        searchParams: "URLSearchParams" in g,
        iterable: "Symbol" in g && "iterator" in Symbol,
        blob: "FileReader" in g && "Blob" in g && function() {
            try {
                new Blob;
                return true
            } catch (e) {
                return false
            }
        }(),
        formData: "FormData" in g,
        arrayBuffer: "ArrayBuffer" in g
    };

    function isDataView(obj) {
        return obj && DataView.prototype.isPrototypeOf(obj)
    }
    if (support.arrayBuffer) {
        viewClasses = ["[object Int8Array]", "[object Uint8Array]", "[object Uint8ClampedArray]", "[object Int16Array]", "[object Uint16Array]", "[object Int32Array]", "[object Uint32Array]", "[object Float32Array]", "[object Float64Array]"];
        isArrayBufferView = ArrayBuffer.isView || function(obj) {
            return obj && viewClasses.indexOf(Object.prototype.toString.call(obj)) > -1
        }
    }
    var viewClasses;
    var isArrayBufferView;

    function normalizeName(name) {
        if (typeof name !== "string") {
            name = String(name)
        }
        if (/[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(name) || name === "") {
            throw new TypeError('Invalid character in header field name: "' + name + '"')
        }
        return name.toLowerCase()
    }

    function normalizeValue(value) {
        if (typeof value !== "string") {
            value = String(value)
        }
        return value
    }

    function iteratorFor(items) {
        var iterator = {
            next: function() {
                var value = items.shift();
                return {
                    done: value === void 0,
                    value
                }
            }
        };
        if (support.iterable) {
            iterator[Symbol.iterator] = function() {
                return iterator
            }
        }
        return iterator
    }

    function Headers(headers) {
        this.map = {};
        if (headers instanceof Headers) {
            headers.forEach(function(value, name) {
                this.append(name, value)
            }, this)
        } else if (Array.isArray(headers)) {
            headers.forEach(function(header) {
                if (header.length != 2) {
                    throw new TypeError("Headers constructor: expected name/value pair to be length 2, found" + header.length)
                }
                this.append(header[0], header[1])
            }, this)
        } else if (headers) {
            Object.getOwnPropertyNames(headers).forEach(function(name) {
                this.append(name, headers[name])
            }, this)
        }
    }
    Headers.prototype.append = function(name, value) {
        name = normalizeName(name);
        value = normalizeValue(value);
        var oldValue = this.map[name];
        this.map[name] = oldValue ? oldValue + ", " + value : value
    };
    Headers.prototype["delete"] = function(name) {
        delete this.map[normalizeName(name)]
    };
    Headers.prototype.get = function(name) {
        name = normalizeName(name);
        return this.has(name) ? this.map[name] : null
    };
    Headers.prototype.has = function(name) {
        return this.map.hasOwnProperty(normalizeName(name))
    };
    Headers.prototype.set = function(name, value) {
        this.map[normalizeName(name)] = normalizeValue(value)
    };
    Headers.prototype.forEach = function(callback, thisArg) {
        for (var name in this.map) {
            if (this.map.hasOwnProperty(name)) {
                callback.call(thisArg, this.map[name], name, this)
            }
        }
    };
    Headers.prototype.keys = function() {
        var items = [];
        this.forEach(function(value, name) {
            items.push(name)
        });
        return iteratorFor(items)
    };
    Headers.prototype.values = function() {
        var items = [];
        this.forEach(function(value) {
            items.push(value)
        });
        return iteratorFor(items)
    };
    Headers.prototype.entries = function() {
        var items = [];
        this.forEach(function(value, name) {
            items.push([name, value])
        });
        return iteratorFor(items)
    };
    if (support.iterable) {
        Headers.prototype[Symbol.iterator] = Headers.prototype.entries
    }

    function consumed(body) {
        if (body._noBody) return;
        if (body.bodyUsed) {
            return Promise.reject(new TypeError("Already read"))
        }
        body.bodyUsed = true
    }

    function fileReaderReady(reader) {
        return new Promise(function(resolve, reject) {
            reader.onload = function() {
                resolve(reader.result)
            };
            reader.onerror = function() {
                reject(reader.error)
            }
        })
    }

    function readBlobAsArrayBuffer(blob) {
        var reader = new FileReader;
        var promise = fileReaderReady(reader);
        reader.readAsArrayBuffer(blob);
        return promise
    }

    function readBlobAsText(blob) {
        var reader = new FileReader;
        var promise = fileReaderReady(reader);
        var match = /charset=([A-Za-z0-9_-]+)/.exec(blob.type);
        var encoding = match ? match[1] : "utf-8";
        reader.readAsText(blob, encoding);
        return promise
    }

    function readArrayBufferAsText(buf) {
        var view = new Uint8Array(buf);
        var chars = new Array(view.length);
        for (var i = 0; i < view.length; i++) {
            chars[i] = String.fromCharCode(view[i])
        }
        return chars.join("")
    }

    function bufferClone(buf) {
        if (buf.slice) {
            return buf.slice(0)
        } else {
            var view = new Uint8Array(buf.byteLength);
            view.set(new Uint8Array(buf));
            return view.buffer
        }
    }

    function Body() {
        this.bodyUsed = false;
        this._initBody = function(body) {
            this.bodyUsed = this.bodyUsed;
            this._bodyInit = body;
            if (!body) {
                this._noBody = true;
                this._bodyText = ""
            } else if (typeof body === "string") {
                this._bodyText = body
            } else if (support.blob && Blob.prototype.isPrototypeOf(body)) {
                this._bodyBlob = body
            } else if (support.formData && FormData.prototype.isPrototypeOf(body)) {
                this._bodyFormData = body
            } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
                this._bodyText = body.toString()
            } else if (support.arrayBuffer && support.blob && isDataView(body)) {
                this._bodyArrayBuffer = bufferClone(body.buffer);
                this._bodyInit = new Blob([this._bodyArrayBuffer])
            } else if (support.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(body) || isArrayBufferView(body))) {
                this._bodyArrayBuffer = bufferClone(body)
            } else {
                this._bodyText = body = Object.prototype.toString.call(body)
            }
            if (!this.headers.get("content-type")) {
                if (typeof body === "string") {
                    this.headers.set("content-type", "text/plain;charset=UTF-8")
                } else if (this._bodyBlob && this._bodyBlob.type) {
                    this.headers.set("content-type", this._bodyBlob.type)
                } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
                    this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8")
                }
            }
        };
        if (support.blob) {
            this.blob = function() {
                var rejected = consumed(this);
                if (rejected) {
                    return rejected
                }
                if (this._bodyBlob) {
                    return Promise.resolve(this._bodyBlob)
                } else if (this._bodyArrayBuffer) {
                    return Promise.resolve(new Blob([this._bodyArrayBuffer]))
                } else if (this._bodyFormData) {
                    throw new Error("could not read FormData body as blob")
                } else {
                    return Promise.resolve(new Blob([this._bodyText]))
                }
            }
        }
        this.arrayBuffer = function() {
            if (this._bodyArrayBuffer) {
                var isConsumed = consumed(this);
                if (isConsumed) {
                    return isConsumed
                } else if (ArrayBuffer.isView(this._bodyArrayBuffer)) {
                    return Promise.resolve(this._bodyArrayBuffer.buffer.slice(this._bodyArrayBuffer.byteOffset, this._bodyArrayBuffer.byteOffset + this._bodyArrayBuffer.byteLength))
                } else {
                    return Promise.resolve(this._bodyArrayBuffer)
                }
            } else if (support.blob) {
                return this.blob().then(readBlobAsArrayBuffer)
            } else {
                throw new Error("could not read as ArrayBuffer")
            }
        };
        this.text = function() {
            var rejected = consumed(this);
            if (rejected) {
                return rejected
            }
            if (this._bodyBlob) {
                return readBlobAsText(this._bodyBlob)
            } else if (this._bodyArrayBuffer) {
                return Promise.resolve(readArrayBufferAsText(this._bodyArrayBuffer))
            } else if (this._bodyFormData) {
                throw new Error("could not read FormData body as text")
            } else {
                return Promise.resolve(this._bodyText)
            }
        };
        if (support.formData) {
            this.formData = function() {
                return this.text().then(decode)
            }
        }
        this.json = function() {
            return this.text().then(JSON.parse)
        };
        return this
    }
    var methods = ["CONNECT", "DELETE", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT", "TRACE"];

    function normalizeMethod(method) {
        var upcased = method.toUpperCase();
        return methods.indexOf(upcased) > -1 ? upcased : method
    }

    function Request(input, options) {
        if (!(this instanceof Request)) {
            throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.')
        }
        options = options || {};
        var body = options.body;
        if (input instanceof Request) {
            if (input.bodyUsed) {
                throw new TypeError("Already read")
            }
            this.url = input.url;
            this.credentials = input.credentials;
            if (!options.headers) {
                this.headers = new Headers(input.headers)
            }
            this.method = input.method;
            this.mode = input.mode;
            this.signal = input.signal;
            if (!body && input._bodyInit != null) {
                body = input._bodyInit;
                input.bodyUsed = true
            }
        } else {
            this.url = String(input)
        }
        this.credentials = options.credentials || this.credentials || "same-origin";
        if (options.headers || !this.headers) {
            this.headers = new Headers(options.headers)
        }
        this.method = normalizeMethod(options.method || this.method || "GET");
        this.mode = options.mode || this.mode || null;
        this.signal = options.signal || this.signal || function() {
            if ("AbortController" in g) {
                var ctrl = new AbortController;
                return ctrl.signal
            }
        }();
        this.referrer = null;
        if ((this.method === "GET" || this.method === "HEAD") && body) {
            throw new TypeError("Body not allowed for GET or HEAD requests")
        }
        this._initBody(body);
        if (this.method === "GET" || this.method === "HEAD") {
            if (options.cache === "no-store" || options.cache === "no-cache") {
                var reParamSearch = /([?&])_=[^&]*/;
                if (reParamSearch.test(this.url)) {
                    this.url = this.url.replace(reParamSearch, "$1_=" + new Date().getTime())
                } else {
                    var reQueryString = /\?/;
                    this.url += (reQueryString.test(this.url) ? "&" : "?") + "_=" + new Date().getTime()
                }
            }
        }
    }
    Request.prototype.clone = function() {
        return new Request(this, {
            body: this._bodyInit
        })
    };

    function decode(body) {
        var form = new FormData;
        body.trim().split("&").forEach(function(bytes) {
            if (bytes) {
                var split = bytes.split("=");
                var name = split.shift().replace(/\+/g, " ");
                var value = split.join("=").replace(/\+/g, " ");
                form.append(decodeURIComponent(name), decodeURIComponent(value))
            }
        });
        return form
    }

    function parseHeaders(rawHeaders) {
        var headers = new Headers;
        var preProcessedHeaders = rawHeaders.replace(/\r?\n[\t ]+/g, " ");
        preProcessedHeaders.split("\r").map(function(header) {
            return header.indexOf("\n") === 0 ? header.substr(1, header.length) : header
        }).forEach(function(line) {
            var parts = line.split(":");
            var key = parts.shift().trim();
            if (key) {
                var value = parts.join(":").trim();
                try {
                    headers.append(key, value)
                } catch (error) {
                    console.warn("Response " + error.message)
                }
            }
        });
        return headers
    }
    Body.call(Request.prototype);

    function Response(bodyInit, options) {
        if (!(this instanceof Response)) {
            throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.')
        }
        if (!options) {
            options = {}
        }
        this.type = "default";
        this.status = options.status === void 0 ? 200 : options.status;
        if (this.status < 200 || this.status > 599) {
            throw new RangeError("Failed to construct 'Response': The status provided (0) is outside the range [200, 599].")
        }
        this.ok = this.status >= 200 && this.status < 300;
        this.statusText = options.statusText === void 0 ? "" : "" + options.statusText;
        this.headers = new Headers(options.headers);
        this.url = options.url || "";
        this._initBody(bodyInit)
    }
    Body.call(Response.prototype);
    Response.prototype.clone = function() {
        return new Response(this._bodyInit, {
            status: this.status,
            statusText: this.statusText,
            headers: new Headers(this.headers),
            url: this.url
        })
    };
    Response.error = function() {
        var response = new Response(null, {
            status: 200,
            statusText: ""
        });
        response.ok = false;
        response.status = 0;
        response.type = "error";
        return response
    };
    var redirectStatuses = [301, 302, 303, 307, 308];
    Response.redirect = function(url, status) {
        if (redirectStatuses.indexOf(status) === -1) {
            throw new RangeError("Invalid status code")
        }
        return new Response(null, {
            status,
            headers: {
                location: url
            }
        })
    };
    var DOMException = g.DOMException;
    try {
        new DOMException
    } catch (err) {
        DOMException = function(message, name) {
            this.message = message;
            this.name = name;
            var error = Error(message);
            this.stack = error.stack
        };
        DOMException.prototype = Object.create(Error.prototype);
        DOMException.prototype.constructor = DOMException
    }

    function fetch2(input, init) {
        return new Promise(function(resolve, reject) {
            var request = new Request(input, init);
            if (request.signal && request.signal.aborted) {
                return reject(new DOMException("Aborted", "AbortError"))
            }
            var xhr = new XMLHttpRequest;

            function abortXhr() {
                xhr.abort()
            }
            xhr.onload = function() {
                var options = {
                    statusText: xhr.statusText,
                    headers: parseHeaders(xhr.getAllResponseHeaders() || "")
                };
                if (request.url.indexOf("file://") === 0 && (xhr.status < 200 || xhr.status > 599)) {
                    options.status = 200
                } else {
                    options.status = xhr.status
                }
                options.url = "responseURL" in xhr ? xhr.responseURL : options.headers.get("X-Request-URL");
                var body = "response" in xhr ? xhr.response : xhr.responseText;
                setTimeout(function() {
                    resolve(new Response(body, options))
                }, 0)
            };
            xhr.onerror = function() {
                setTimeout(function() {
                    reject(new TypeError("Network request failed"))
                }, 0)
            };
            xhr.ontimeout = function() {
                setTimeout(function() {
                    reject(new TypeError("Network request timed out"))
                }, 0)
            };
            xhr.onabort = function() {
                setTimeout(function() {
                    reject(new DOMException("Aborted", "AbortError"))
                }, 0)
            };

            function fixUrl(url) {
                try {
                    return url === "" && g.location.href ? g.location.href : url
                } catch (e) {
                    return url
                }
            }
            xhr.open(request.method, fixUrl(request.url), true);
            if (request.credentials === "include") {
                xhr.withCredentials = true
            } else if (request.credentials === "omit") {
                xhr.withCredentials = false
            }
            if ("responseType" in xhr) {
                if (support.blob) {
                    xhr.responseType = "blob"
                } else if (support.arrayBuffer) {
                    xhr.responseType = "arraybuffer"
                }
            }
            if (init && typeof init.headers === "object" && !(init.headers instanceof Headers || g.Headers && init.headers instanceof g.Headers)) {
                var names = [];
                Object.getOwnPropertyNames(init.headers).forEach(function(name) {
                    names.push(normalizeName(name));
                    xhr.setRequestHeader(name, normalizeValue(init.headers[name]))
                });
                request.headers.forEach(function(value, name) {
                    if (names.indexOf(name) === -1) {
                        xhr.setRequestHeader(name, value)
                    }
                })
            } else {
                request.headers.forEach(function(value, name) {
                    xhr.setRequestHeader(name, value)
                })
            }
            if (request.signal) {
                request.signal.addEventListener("abort", abortXhr);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4) {
                        request.signal.removeEventListener("abort", abortXhr)
                    }
                }
            }
            xhr.send(typeof request._bodyInit === "undefined" ? null : request._bodyInit)
        })
    }
    fetch2.polyfill = true;
    if (!g.fetch) {
        g.fetch = fetch2;
        g.Headers = Headers;
        g.Request = Request;
        g.Response = Response
    }
    var import_ua_parser_js = __toESM(require_ua_parser(), 1);

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function")
        }
    }

    function _defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor)
        }
    }

    function _createClass(Constructor, protoProps, staticProps) {
        if (protoProps) _defineProperties(Constructor.prototype, protoProps);
        if (staticProps) _defineProperties(Constructor, staticProps);
        return Constructor
    }
    var MOBILE_DEVICE_TYPES = ["mobile", "tablet"];
    var Browser = function() {
        _createClass(Browser2, [{
            key: "name",
            get: function get() {
                return this.ua.getBrowser().name || ""
            }
        }, {
            key: "version",
            get: function get() {
                return this.ua.getBrowser().version || ""
            }
        }, {
            key: "majorVersion",
            get: function get() {
                var version = this.version;
                if (version === "") {
                    return void 0
                }
                var majorVersion = parseInt(version.split(".")[0], 10);
                return Number.isNaN(majorVersion) ? void 0 : majorVersion
            }
        }, {
            key: "unknown",
            get: function get() {
                return this.name === ""
            }
        }, {
            key: "isMobile",
            get: function get() {
                return MOBILE_DEVICE_TYPES.includes(this.ua.getDevice().type)
            }
        }, {
            key: "isDesktop",
            get: function get() {
                return !this.isMobile
            }
        }, {
            key: "isNativeApp",
            get: function get() {
                return this.ua.getUA().includes("Shopify Mobile/", 0)
            }
        }, {
            key: "os",
            get: function get() {
                return this.ua.getOS().name || ""
            }
        }, {
            key: "isWindows",
            get: function get() {
                return this.os.includes("Windows")
            }
        }, {
            key: "isMac",
            get: function get() {
                return this.os.includes("Mac OS")
            }
        }, {
            key: "isSafari",
            get: function get() {
                return this.name.includes("Safari")
            }
        }, {
            key: "isChrome",
            get: function get() {
                return this.name.includes("Chrome")
            }
        }, {
            key: "isAndroidChrome",
            get: function get() {
                return this.ua.getUA().includes("Android") && this.name.includes("Chrome")
            }
        }, {
            key: "isFirefox",
            get: function get() {
                return this.name === "Firefox"
            }
        }, {
            key: "isIE",
            get: function get() {
                return this.name.includes("IE")
            }
        }, {
            key: "isEdge",
            get: function get() {
                return this.name === "Edge"
            }
        }, {
            key: "isIOS",
            get: function get() {
                var os = this.ua.getOS();
                var isStandardiOS = os.name && os.name.includes("iOS");
                var isShopifyiOS = /Shopify Mobile|Shopify POS|Shopify Ping/.test(this.userAgent) && this.userAgent.includes("iOS");
                return isStandardiOS || isShopifyiOS
            }
        }]);

        function Browser2(_ref) {
            var userAgent = _ref.userAgent,
                _ref$supported = _ref.supported,
                supported = _ref$supported === void 0 ? true : _ref$supported;
            _classCallCheck(this, Browser2);
            this.userAgent = void 0;
            this.supported = void 0;
            this.ua = void 0;
            this.userAgent = userAgent;
            this.supported = supported;
            this.ua = new import_ua_parser_js.UAParser(userAgent)
        }
        return Browser2
    }();
    var REDIRECT_COOKIE_KEY = "shopify_pay_redirect";
    var SHOPIFY_Y_COOKIE_KEY = "_shopify_y";
    async function performEligibilityCheck() {
        const browser = new Browser({
            userAgent: navigator.userAgent
        });
        if (browser.isSafari === true) {
            return
        }
        const state = getRedirectState();
        if (state !== null) {
            return
        }
        const sessionExists = await hasShopifyPaySession();
        if (sessionExists === true) {
            setRedirectState("true")
        } else {
            setRedirectState("pending", 1)
        }
    }
    async function hasShopifyPaySession() {
        try {
            let uri = `https://${window.ShopifyPay.apiHost}/session?v=1`;
            const shopifyYCookie = getShopifyYCookie();
            const shopId = getShopId();
            if (shopifyYCookie !== null && shopId !== null) {
                uri += `&token=${shopifyYCookie}&shop_id=${shopId}`
            }
            const response = await fetch(uri, {
                credentials: "include"
            });
            const {
                eligible
            } = await response.json();
            return eligible
        } catch (_err) {
            return false
        }
    }

    function getRedirectState() {
        const value = new RegExp(`${REDIRECT_COOKIE_KEY}=([^;]+)`).exec(document.cookie);
        if (value) {
            return decodeURIComponent(value[1]).toLowerCase()
        }
        return null
    }

    function getShopifyYCookie() {
        const value = new RegExp(`${SHOPIFY_Y_COOKIE_KEY}=([^;]+)`).exec(document.cookie);
        if (value) {
            return value[1]
        }
        return null
    }

    function getShopId() {
        if (window.ShopifyAnalytics && window.ShopifyAnalytics.lib && window.ShopifyAnalytics.lib.config && window.ShopifyAnalytics.lib.config.Trekkie && window.ShopifyAnalytics.lib.config.Trekkie.defaultAttributes && window.ShopifyAnalytics.lib.config.Trekkie.defaultAttributes.shopId) {
            return ShopifyAnalytics.lib.config.Trekkie.defaultAttributes.shopId
        }
        return null
    }

    function setRedirectState(value, hours = 365 * 24) {
        const now = new Date().getTime();
        const expireTime = new Date(now + hours * 60 * 60 * 1e3);
        document.cookie = `${REDIRECT_COOKIE_KEY}=${value}; expires=${expireTime.toGMTString()}; path=/`
    }
    var eligibility_check_default = performEligibilityCheck;
    eligibility_check_default();
})();