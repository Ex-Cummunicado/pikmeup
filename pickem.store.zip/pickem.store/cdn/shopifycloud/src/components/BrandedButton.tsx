import {forwardRef} from 'preact/compat';

import {classNames} from '~/utils/css';

import {Button} from './Button';
import type {ButtonProps} from './Button';

interface BrandedButtonProps extends ButtonProps {
  bordered?: boolean;
  fullWidth?: boolean;
}

export const BrandedButton = forwardRef<HTMLButtonElement, BrandedButtonProps>(
  ({children, bordered, fullWidth, ...props}, ref) => {
    return (
      <Button
        {...props}
        className={classNames(
          'm-auto',
          bordered ? 'border border-solid border-white/20' : 'border-none',
          fullWidth ? 'w-full justify-center' : undefined,
        )}
        ref={ref}
      >
        <span className="mx-auto flex cursor-pointer items-center justify-center gap-text-icon whitespace-nowrap p-shop-button font-sans text-branded-button text-white">
          {children}
        </span>
      </Button>
    );
  },
);

BrandedButton.displayName = 'BrandedButton';
