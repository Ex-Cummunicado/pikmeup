import type {ComponentChildren} from 'preact';
import {forwardRef, type ButtonHTMLAttributes} from 'preact/compat';

import {classNames} from '~/utils/css';

export interface ButtonProps extends ButtonHTMLAttributes {
  children: ComponentChildren;
  disableTransition?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      children,
      className: classNameProp,
      disabled,
      disableTransition = false,
      onClick,
    },
    ref,
  ) => {
    const className = classNames(
      'relative m-0 flex w-auto items-center overflow-visible rounded-login-button bg-purple-primary p-0 hover_enabled_bg-purple-d0 focus-visible_enabled_outline-none focus-visible_enabled_ring focus-visible_enabled_ring-purple-primary-light disabled_opacity-50',
      !disableTransition && 'transition-all',
      typeof classNameProp === 'string' || typeof classNameProp === 'undefined'
        ? classNameProp
        : classNameProp.value,
    );

    return (
      <button
        className={className}
        disabled={disabled}
        ref={ref}
        type="button"
        onClick={onClick}
      >
        {children}
      </button>
    );
  },
);

Button.displayName = 'Button';
