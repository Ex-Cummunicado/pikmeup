import type {RefObject} from 'preact';
import {useCallback} from 'preact/hooks';

import {useAuthorizeState} from '~/foundation/AuthorizeState/hooks';
import type {
  AuthorizeErrorEvent,
  CompletedEvent,
  MessageEventData,
} from '~/types/event';

import {useDispatchEvent} from './useDispatchEvent';

interface UseWindoidMessageHandlerProps {
  handleClose?: () => void;
  handleComplete: (event: CompletedEvent) => void;
  handleError?: (event: AuthorizeErrorEvent) => void;
  handleOpen?: () => void;
  windoidRef: RefObject<Window>;
}

export const useWindoidMessageHandler = ({
  handleClose,
  handleComplete,
  handleError,
  handleOpen,
  windoidRef,
}: UseWindoidMessageHandlerProps) => {
  const dispatchEvent = useDispatchEvent();
  const {dispatch} = useAuthorizeState();

  const handleWindoidMessage = useCallback(
    async (payload: MessageEvent<MessageEventData>) => {
      switch (payload.data.type) {
        case 'completed':
          handleComplete(payload.data as any);
          dispatchEvent('completed', payload.data, true);
          windoidRef.current?.close();
          break;
        case 'error':
          handleError?.(payload.data as any);
          dispatchEvent('error', payload.data);
          windoidRef.current?.close();
          break;
        case 'windoidopened':
          dispatch({type: 'windoidOpened'});
          dispatchEvent('windoidopened');
          handleOpen?.();
          break;
        case 'windoidclosed':
          dispatch({type: 'windoidClosed'});
          handleClose?.();
          break;
      }
    },
    [
      handleComplete,
      dispatchEvent,
      windoidRef,
      handleError,
      dispatch,
      handleOpen,
      handleClose,
    ],
  );

  return handleWindoidMessage;
};
