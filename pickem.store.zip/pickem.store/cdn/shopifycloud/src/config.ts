// eslint-disable-next-line import-x/no-anonymous-default-export
export default {
  bugsnagApiKey: 'e35d7136cee78d344ccffdbd5ca710fa',
};
