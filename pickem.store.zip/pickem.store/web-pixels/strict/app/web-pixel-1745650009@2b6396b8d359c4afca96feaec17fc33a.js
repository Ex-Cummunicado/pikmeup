(() => {
    var Ys = Object.create;
    var In = Object.defineProperty,
        zs = Object.defineProperties,
        Ks = Object.getOwnPropertyDescriptor,
        Js = Object.getOwnPropertyDescriptors,
        Vs = Object.getOwnPropertyNames,
        Et = Object.getOwnPropertySymbols,
        qs = Object.getPrototypeOf,
        xn = Object.prototype.hasOwnProperty,
        Jr = Object.prototype.propertyIsEnumerable;
    var Kr = (e, t, n) => t in e ? In(e, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: n
        }) : e[t] = n,
        p = (e, t) => {
            for (var n in t || (t = {})) xn.call(t, n) && Kr(e, n, t[n]);
            if (Et)
                for (var n of Et(t)) Jr.call(t, n) && Kr(e, n, t[n]);
            return e
        },
        E = (e, t) => zs(e, Js(t));
    var Ze = (e, t) => {
        var n = {};
        for (var r in e) xn.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
        if (e != null && Et)
            for (var r of Et(e)) t.indexOf(r) < 0 && Jr.call(e, r) && (n[r] = e[r]);
        return n
    };
    var d = (e, t) => () => (e && (t = e(e = 0)), t);
    var Xs = (e, t) => () => (t || e((t = {
        exports: {}
    }).exports, t), t.exports);
    var Zs = (e, t, n, r) => {
        if (t && typeof t == "object" || typeof t == "function")
            for (let o of Vs(t)) !xn.call(e, o) && o !== n && In(e, o, {
                get: () => t[o],
                enumerable: !(r = Ks(t, o)) || r.enumerable
            });
        return e
    };
    var Qs = (e, t, n) => (n = e != null ? Ys(qs(e)) : {}, Zs(t || !e || !e.__esModule ? In(n, "default", {
        value: e,
        enumerable: !0
    }) : n, e));
    var C = (e, t, n) => new Promise((r, o) => {
        var i = c => {
                try {
                    a(n.next(c))
                } catch (u) {
                    o(u)
                }
            },
            s = c => {
                try {
                    a(n.throw(c))
                } catch (u) {
                    o(u)
                }
            },
            a = c => c.done ? r(c.value) : Promise.resolve(c.value).then(i, s);
        a((n = n.apply(e, t)).next())
    });
    var Vr, qr = d(() => {
        Vr = "WebPixel::Render"
    });
    var bn, Xr = d(() => {
        qr();
        bn = e => shopify.extend(Vr, e)
    });
    var Zr = d(() => {
        Xr()
    });
    var Qr = d(() => {
        Zr()
    });

    function eo(e) {
        let t = e.settings,
            r = new URLSearchParams(e.init.context.window.location.search).get(ea);
        (t.environment === "stage" || r != null && r !== "false" && r !== "0") && ta(!0)
    }

    function ta(e) {
        vn = e
    }

    function N(e, ...t) {
        vn && console.error(`[Recharge Analytics] ${e}`, ...t)
    }

    function x(e, ...t) {
        vn && console.info(`%c[Recharge Analytics Debug] ${e}${t.length?":":""}`, "color: #fffbf6; background: #3901f1;", ...t)
    }
    var vn, ea, be = d(() => {
        vn = !1, ea = "recharge_analytics_debug"
    });
    var y, ye = d(() => {
        y = typeof __SENTRY_DEBUG__ == "undefined" || __SENTRY_DEBUG__
    });
    var h, U = d(() => {
        h = globalThis
    });
    var J, Fe = d(() => {
        J = typeof __SENTRY_DEBUG__ == "undefined" || __SENTRY_DEBUG__
    });
    var ie, Cn = d(() => {
        ie = "9.0.1"
    });

    function ve() {
        return Ce(h), h
    }

    function Ce(e) {
        let t = e.__SENTRY__ = e.__SENTRY__ || {};
        return t.version = t.version || ie, t[ie] = t[ie] || {}
    }

    function Re(e, t, n = h) {
        let r = n.__SENTRY__ = n.__SENTRY__ || {},
            o = r[ie] = r[ie] || {};
        return o[e] || (o[e] = t())
    }
    var Ne = d(() => {
        Cn();
        U()
    });

    function V(e) {
        if (!("console" in h)) return e();
        let t = h.console,
            n = {},
            r = Object.keys(Ue);
        r.forEach(o => {
            let i = Ue[o];
            n[o] = t[o], t[o] = i
        });
        try {
            return e()
        } finally {
            r.forEach(o => {
                t[o] = n[o]
            })
        }
    }

    function ra() {
        let e = !1,
            t = {
                enable: () => {
                    e = !0
                },
                disable: () => {
                    e = !1
                },
                isEnabled: () => e
            };
        return J ? Qe.forEach(n => {
            t[n] = (...r) => {
                e && V(() => {
                    h.console[n](`${na}[${n}]:`, ...r)
                })
            }
        }) : Qe.forEach(n => {
            t[n] = () => {}
        }), t
    }
    var na, Qe, Ue, _, M = d(() => {
        Ne();
        Fe();
        U();
        na = "Sentry Logger ", Qe = ["debug", "info", "warn", "error", "log", "assert", "trace"], Ue = {};
        _ = Re("logger", ra)
    });

    function St(...e) {
        let t = e.sort((n, r) => n[0] - r[0]).map(n => n[1]);
        return (n, r = 0, o = 0) => {
            let i = [],
                s = n.split(`
`);
            for (let a = r; a < s.length; a++) {
                let c = s[a];
                if (c.length > 1024) continue;
                let u = to.test(c) ? c.replace(to, "$1") : c;
                if (!u.match(/\S*Error: /)) {
                    for (let l of t) {
                        let f = l(u);
                        if (f) {
                            i.push(f);
                            break
                        }
                    }
                    if (i.length >= 50 + o) break
                }
            }
            return ro(i.slice(o))
        }
    }

    function Nn(e) {
        return Array.isArray(e) ? St(...e) : e
    }

    function ro(e) {
        if (!e.length) return [];
        let t = Array.from(e);
        return /sentryWrapped/.test(yt(t).function || "") && t.pop(), t.reverse(), no.test(yt(t).function || "") && (t.pop(), no.test(yt(t).function || "") && t.pop()), t.slice(0, 50).map(n => E(p({}, n), {
            filename: n.filename || yt(t).filename,
            function: n.function || se
        }))
    }

    function yt(e) {
        return e[e.length - 1] || {}
    }

    function q(e) {
        try {
            return !e || typeof e != "function" ? Rn : e.name || Rn
        } catch (t) {
            return Rn
        }
    }

    function Tt(e) {
        let t = e.exception;
        if (t) {
            let n = [];
            try {
                return t.values.forEach(r => {
                    r.stacktrace.frames && n.push(...r.stacktrace.frames)
                }), n
            } catch (r) {
                return
            }
        }
    }
    var se, to, no, Rn, et = d(() => {
        se = "?", to = /\(error: (.*)\)/, no = /captureMessage|captureException/;
        Rn = "<anonymous>"
    });

    function B(e, t) {
        It[e] = It[e] || [], It[e].push(t)
    }

    function H(e, t) {
        if (!oo[e]) {
            oo[e] = !0;
            try {
                t()
            } catch (n) {
                J && _.error(`Error while instrumenting ${e}`, n)
            }
        }
    }

    function k(e, t) {
        let n = e && It[e];
        if (n)
            for (let r of n) try {
                r(t)
            } catch (o) {
                J && _.error(`Error while triggering instrumentation handler.
Type: ${e}
Name: ${q(r)}
Error:`, o)
            }
    }
    var It, oo, Be = d(() => {
        Fe();
        M();
        et();
        It = {}, oo = {}
    });

    function An(e) {
        let t = "error";
        B(t, e), H(t, oa)
    }

    function oa() {
        kn = h.onerror, h.onerror = function(e, t, n, r, o) {
            return k("error", {
                column: r,
                error: o,
                line: n,
                msg: e,
                url: t
            }), kn ? kn.apply(this, arguments) : !1
        }, h.onerror.__SENTRY_INSTRUMENTED__ = !0
    }
    var kn, io = d(() => {
        U();
        Be();
        kn = null
    });

    function Dn(e) {
        let t = "unhandledrejection";
        B(t, e), H(t, ia)
    }

    function ia() {
        wn = h.onunhandledrejection, h.onunhandledrejection = function(e) {
            return k("unhandledrejection", e), wn ? wn.apply(this, arguments) : !0
        }, h.onunhandledrejection.__SENTRY_INSTRUMENTED__ = !0
    }
    var wn, so = d(() => {
        U();
        Be();
        wn = null
    });

    function ke(e) {
        switch (ao.call(e)) {
            case "[object Error]":
            case "[object Exception]":
            case "[object DOMException]":
            case "[object WebAssembly.Exception]":
                return !0;
            default:
                return ae(e, Error)
        }
    }

    function He(e, t) {
        return ao.call(e) === `[object ${t}]`
    }

    function xt(e) {
        return He(e, "ErrorEvent")
    }

    function bt(e) {
        return He(e, "DOMError")
    }

    function On(e) {
        return He(e, "DOMException")
    }

    function $(e) {
        return He(e, "String")
    }

    function $e(e) {
        return typeof e == "object" && e !== null && "__sentry_template_string__" in e && "__sentry_template_values__" in e
    }

    function Ae(e) {
        return e === null || $e(e) || typeof e != "object" && typeof e != "function"
    }

    function ee(e) {
        return He(e, "Object")
    }

    function we(e) {
        return typeof Event != "undefined" && ae(e, Event)
    }

    function Pn(e) {
        return typeof Element != "undefined" && ae(e, Element)
    }

    function Ln(e) {
        return He(e, "RegExp")
    }

    function fe(e) {
        return !!(e != null && e.then && typeof e.then == "function")
    }

    function Mn(e) {
        return ee(e) && "nativeEvent" in e && "preventDefault" in e && "stopPropagation" in e
    }

    function ae(e, t) {
        try {
            return e instanceof t
        } catch (n) {
            return !1
        }
    }

    function tt(e) {
        return !!(typeof e == "object" && e !== null && (e.__isVue || e._isVue))
    }
    var ao, Y = d(() => {
        ao = Object.prototype.toString
    });

    function nt(e, t = {}) {
        if (!e) return "<unknown>";
        try {
            let n = e,
                r = 5,
                o = [],
                i = 0,
                s = 0,
                a = " > ",
                c = a.length,
                u, l = Array.isArray(t) ? t : t.keyAttrs,
                f = !Array.isArray(t) && t.maxStringLength || sa;
            for (; n && i++ < r && (u = aa(n, l), !(u === "html" || i > 1 && s + o.length * c + u.length >= f));) o.push(u), s += u.length, n = n.parentNode;
            return o.reverse().join(a)
        } catch (n) {
            return "<unknown>"
        }
    }

    function aa(e, t) {
        let n = e,
            r = [];
        if (!(n != null && n.tagName)) return "";
        if (Fn.HTMLElement && n instanceof HTMLElement && n.dataset) {
            if (n.dataset.sentryComponent) return n.dataset.sentryComponent;
            if (n.dataset.sentryElement) return n.dataset.sentryElement
        }
        r.push(n.tagName.toLowerCase());
        let o = t != null && t.length ? t.filter(s => n.getAttribute(s)).map(s => [s, n.getAttribute(s)]) : null;
        if (o != null && o.length) o.forEach(s => {
            r.push(`[${s[0]}="${s[1]}"]`)
        });
        else {
            n.id && r.push(`#${n.id}`);
            let s = n.className;
            if (s && $(s)) {
                let a = s.split(/\s+/);
                for (let c of a) r.push(`.${c}`)
            }
        }
        let i = ["aria-label", "type", "name", "title", "alt"];
        for (let s of i) {
            let a = n.getAttribute(s);
            a && r.push(`[${s}="${a}"]`)
        }
        return r.join("")
    }

    function De() {
        try {
            return Fn.document.location.href
        } catch (e) {
            return ""
        }
    }

    function Un(e) {
        if (!Fn.HTMLElement) return null;
        let t = e,
            n = 5;
        for (let r = 0; r < n; r++) {
            if (!t) return null;
            if (t instanceof HTMLElement) {
                if (t.dataset.sentryComponent) return t.dataset.sentryComponent;
                if (t.dataset.sentryElement) return t.dataset.sentryElement
            }
            t = t.parentNode
        }
        return null
    }
    var Fn, sa, Bn = d(() => {
        Y();
        U();
        Fn = h, sa = 80
    });

    function ce(e, t = 0) {
        return typeof e != "string" || t === 0 || e.length <= t ? e : `${e.slice(0,t)}...`
    }

    function vt(e, t) {
        if (!Array.isArray(e)) return "";
        let n = [];
        for (let r = 0; r < e.length; r++) {
            let o = e[r];
            try {
                tt(o) ? n.push("[VueViewModel]") : n.push(String(o))
            } catch (i) {
                n.push("[value cannot be serialized]")
            }
        }
        return n.join(t)
    }

    function co(e, t, n = !1) {
        return $(e) ? Ln(t) ? t.test(e) : $(t) ? n ? e === t : e.includes(t) : !1 : !1
    }

    function Ge(e, t = [], n = !1) {
        return t.some(r => co(e, r, n))
    }
    var je = d(() => {
        Y()
    });

    function A(e, t, n) {
        if (!(t in e)) return;
        let r = e[t],
            o = n(r);
        typeof o == "function" && Ct(o, r);
        try {
            e[t] = o
        } catch (i) {
            J && _.log(`Failed to replace method "${t}" in object`, e)
        }
    }

    function G(e, t, n) {
        try {
            Object.defineProperty(e, t, {
                value: n,
                writable: !0,
                configurable: !0
            })
        } catch (r) {
            J && _.log(`Failed to add non-enumerable property "${t}" to object`, e)
        }
    }

    function Ct(e, t) {
        try {
            let n = t.prototype || {};
            e.prototype = t.prototype = n, G(e, "__sentry_original__", t)
        } catch (n) {}
    }

    function Oe(e) {
        return e.__sentry_original__
    }

    function Rt(e) {
        if (ke(e)) return p({
            message: e.message,
            name: e.name,
            stack: e.stack
        }, po(e));
        if (we(e)) {
            let t = p({
                type: e.type,
                target: uo(e.target),
                currentTarget: uo(e.currentTarget)
            }, po(e));
            return typeof CustomEvent != "undefined" && ae(e, CustomEvent) && (t.detail = e.detail), t
        } else return e
    }

    function uo(e) {
        try {
            return Pn(e) ? nt(e) : Object.prototype.toString.call(e)
        } catch (t) {
            return "<unknown>"
        }
    }

    function po(e) {
        if (typeof e == "object" && e !== null) {
            let t = {};
            for (let n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t
        } else return {}
    }

    function $n(e, t = 40) {
        let n = Object.keys(Rt(e));
        n.sort();
        let r = n[0];
        if (!r) return "[object has no keys]";
        if (r.length >= t) return ce(r, t);
        for (let o = n.length; o > 0; o--) {
            let i = n.slice(0, o).join(", ");
            if (!(i.length > t)) return o === n.length ? i : ce(i, t)
        }
        return ""
    }

    function R(e) {
        return Hn(e, new Map)
    }

    function Hn(e, t) {
        if (ca(e)) {
            let n = t.get(e);
            if (n !== void 0) return n;
            let r = {};
            t.set(e, r);
            for (let o of Object.getOwnPropertyNames(e)) typeof e[o] != "undefined" && (r[o] = Hn(e[o], t));
            return r
        }
        if (Array.isArray(e)) {
            let n = t.get(e);
            if (n !== void 0) return n;
            let r = [];
            return t.set(e, r), e.forEach(o => {
                r.push(Hn(o, t))
            }), r
        }
        return e
    }

    function ca(e) {
        if (!ee(e)) return !1;
        try {
            let t = Object.getPrototypeOf(e).constructor.name;
            return !t || t === "Object"
        } catch (t) {
            return !0
        }
    }
    var j = d(() => {
        Bn();
        Fe();
        Y();
        M();
        je()
    });

    function ue() {
        return Date.now() / lo
    }

    function ua() {
        let {
            performance: e
        } = h;
        if (!(e != null && e.now)) return ue;
        let t = Date.now() - e.now(),
            n = e.timeOrigin == null ? t : e.timeOrigin;
        return () => (n + e.now()) / lo
    }
    var lo, z, me = d(() => {
        U();
        lo = 1e3;
        z = ua()
    });

    function w() {
        let e = h,
            t = e.crypto || e.msCrypto,
            n = () => Math.random() * 16;
        try {
            if (t != null && t.randomUUID) return t.randomUUID().replace(/-/g, "");
            t != null && t.getRandomValues && (n = () => {
                let r = new Uint8Array(1);
                return t.getRandomValues(r), r[0]
            })
        } catch (r) {}
        return ("10000000100040008000" + 1e11).replace(/[018]/g, r => (r ^ (n() & 15) >> r / 4).toString(16))
    }

    function fo(e) {
        var t, n;
        return (n = (t = e.exception) == null ? void 0 : t.values) == null ? void 0 : n[0]
    }

    function te(e) {
        let {
            message: t,
            event_id: n
        } = e;
        if (t) return t;
        let r = fo(e);
        return r ? r.type && r.value ? `${r.type}: ${r.value}` : r.type || r.value || n || "<unknown>" : n || "<unknown>"
    }

    function We(e, t, n) {
        let r = e.exception = e.exception || {},
            o = r.values = r.values || [],
            i = o[0] = o[0] || {};
        i.value || (i.value = t || ""), i.type || (i.type = n || "Error")
    }

    function pe(e, t) {
        let n = fo(e);
        if (!n) return;
        let r = {
                type: "generic",
                handled: !0
            },
            o = n.mechanism;
        if (n.mechanism = p(p(p({}, r), o), t), t && "data" in t) {
            let i = p(p({}, o == null ? void 0 : o.data), t.data);
            n.mechanism.data = i
        }
    }

    function Nt(e) {
        if (pa(e)) return !0;
        try {
            G(e, "__sentry_captured__", !0)
        } catch (t) {}
        return !1
    }

    function pa(e) {
        try {
            return e.__sentry_captured__
        } catch (t) {}
    }
    var Se = d(() => {
        j();
        U()
    });

    function X(e) {
        return new ne(t => {
            t(e)
        })
    }

    function Te(e) {
        return new ne((t, n) => {
            n(e)
        })
    }
    var ge, ne, Ye = d(() => {
        Y();
        (function(e) {
            e[e.PENDING = 0] = "PENDING";
            let n = 1;
            e[e.RESOLVED = n] = "RESOLVED";
            let r = 2;
            e[e.REJECTED = r] = "REJECTED"
        })(ge || (ge = {}));
        ne = class e {
            constructor(t) {
                this._state = ge.PENDING, this._handlers = [], this._runExecutor(t)
            }
            then(t, n) {
                return new e((r, o) => {
                    this._handlers.push([!1, i => {
                        if (!t) r(i);
                        else try {
                            r(t(i))
                        } catch (s) {
                            o(s)
                        }
                    }, i => {
                        if (!n) o(i);
                        else try {
                            r(n(i))
                        } catch (s) {
                            o(s)
                        }
                    }]), this._executeHandlers()
                })
            } catch (t) {
                return this.then(n => n, t)
            } finally(t) {
                return new e((n, r) => {
                    let o, i;
                    return this.then(s => {
                        i = !1, o = s, t && t()
                    }, s => {
                        i = !0, o = s, t && t()
                    }).then(() => {
                        if (i) {
                            r(o);
                            return
                        }
                        n(o)
                    })
                })
            }
            _executeHandlers() {
                if (this._state === ge.PENDING) return;
                let t = this._handlers.slice();
                this._handlers = [], t.forEach(n => {
                    n[0] || (this._state === ge.RESOLVED && n[1](this._value), this._state === ge.REJECTED && n[2](this._value), n[0] = !0)
                })
            }
            _runExecutor(t) {
                let n = (i, s) => {
                        if (this._state === ge.PENDING) {
                            if (fe(s)) {
                                s.then(r, o);
                                return
                            }
                            this._state = i, this._value = s, this._executeHandlers()
                        }
                    },
                    r = i => {
                        n(ge.RESOLVED, i)
                    },
                    o = i => {
                        n(ge.REJECTED, i)
                    };
                try {
                    t(r, o)
                } catch (i) {
                    o(i)
                }
            }
        }
    });

    function mo(e) {
        let t = z(),
            n = {
                sid: w(),
                init: !0,
                timestamp: t,
                started: t,
                duration: 0,
                status: "ok",
                errors: 0,
                ignoreDuration: !1,
                toJSON: () => da(n)
            };
        return e && _e(n, e), n
    }

    function _e(e, t = {}) {
        if (t.user && (!e.ipAddress && t.user.ip_address && (e.ipAddress = t.user.ip_address), !e.did && !t.did && (e.did = t.user.id || t.user.email || t.user.username)), e.timestamp = t.timestamp || z(), t.abnormal_mechanism && (e.abnormal_mechanism = t.abnormal_mechanism), t.ignoreDuration && (e.ignoreDuration = t.ignoreDuration), t.sid && (e.sid = t.sid.length === 32 ? t.sid : w()), t.init !== void 0 && (e.init = t.init), !e.did && t.did && (e.did = `${t.did}`), typeof t.started == "number" && (e.started = t.started), e.ignoreDuration) e.duration = void 0;
        else if (typeof t.duration == "number") e.duration = t.duration;
        else {
            let n = e.timestamp - e.started;
            e.duration = n >= 0 ? n : 0
        }
        t.release && (e.release = t.release), t.environment && (e.environment = t.environment), !e.ipAddress && t.ipAddress && (e.ipAddress = t.ipAddress), !e.userAgent && t.userAgent && (e.userAgent = t.userAgent), typeof t.errors == "number" && (e.errors = t.errors), t.status && (e.status = t.status)
    }

    function go(e, t) {
        let n = {};
        t ? n = {
            status: t
        } : e.status === "ok" && (n = {
            status: "exited"
        }), _e(e, n)
    }

    function da(e) {
        return R({
            sid: `${e.sid}`,
            init: e.init,
            started: new Date(e.started * 1e3).toISOString(),
            timestamp: new Date(e.timestamp * 1e3).toISOString(),
            status: e.status,
            errors: e.errors,
            did: typeof e.did == "number" || typeof e.did == "string" ? `${e.did}` : void 0,
            duration: e.duration,
            abnormal_mechanism: e.abnormal_mechanism,
            attrs: {
                release: e.release,
                environment: e.environment,
                ip_address: e.ipAddress,
                user_agent: e.userAgent
            }
        })
    }
    var kt = d(() => {
        j();
        me();
        Se()
    });

    function Gn() {
        return w()
    }

    function At() {
        return w().substring(16)
    }
    var wt = d(() => {
        Se()
    });

    function Ie(e, t, n = 2) {
        if (!t || typeof t != "object" || n <= 0) return t;
        if (e && Object.keys(t).length === 0) return e;
        let r = p({}, e);
        for (let o in t) Object.prototype.hasOwnProperty.call(t, o) && (r[o] = Ie(r[o], t[o], n - 1));
        return r
    }
    var Dt = d(() => {});

    function Wn(e, t) {
        t ? G(e, jn, t) : delete e[jn]
    }

    function Yn(e) {
        return e[jn]
    }
    var jn, _o = d(() => {
        j();
        jn = "_sentrySpan"
    });
    var la, K, rt = d(() => {
        kt();
        Y();
        M();
        Se();
        wt();
        me();
        Dt();
        _o();
        la = 100, K = class e {
            constructor() {
                this._notifyingListeners = !1, this._scopeListeners = [], this._eventProcessors = [], this._breadcrumbs = [], this._attachments = [], this._user = {}, this._tags = {}, this._extra = {}, this._contexts = {}, this._sdkProcessingMetadata = {}, this._propagationContext = {
                    traceId: Gn(),
                    sampleRand: Math.random()
                }
            }
            clone() {
                let t = new e;
                return t._breadcrumbs = [...this._breadcrumbs], t._tags = p({}, this._tags), t._extra = p({}, this._extra), t._contexts = p({}, this._contexts), this._contexts.flags && (t._contexts.flags = {
                    values: [...this._contexts.flags.values]
                }), t._user = this._user, t._level = this._level, t._session = this._session, t._transactionName = this._transactionName, t._fingerprint = this._fingerprint, t._eventProcessors = [...this._eventProcessors], t._attachments = [...this._attachments], t._sdkProcessingMetadata = p({}, this._sdkProcessingMetadata), t._propagationContext = p({}, this._propagationContext), t._client = this._client, t._lastEventId = this._lastEventId, Wn(t, Yn(this)), t
            }
            setClient(t) {
                this._client = t
            }
            setLastEventId(t) {
                this._lastEventId = t
            }
            getClient() {
                return this._client
            }
            lastEventId() {
                return this._lastEventId
            }
            addScopeListener(t) {
                this._scopeListeners.push(t)
            }
            addEventProcessor(t) {
                return this._eventProcessors.push(t), this
            }
            setUser(t) {
                return this._user = t || {
                    email: void 0,
                    id: void 0,
                    ip_address: void 0,
                    username: void 0
                }, this._session && _e(this._session, {
                    user: t
                }), this._notifyScopeListeners(), this
            }
            getUser() {
                return this._user
            }
            setTags(t) {
                return this._tags = p(p({}, this._tags), t), this._notifyScopeListeners(), this
            }
            setTag(t, n) {
                return this._tags = E(p({}, this._tags), {
                    [t]: n
                }), this._notifyScopeListeners(), this
            }
            setExtras(t) {
                return this._extra = p(p({}, this._extra), t), this._notifyScopeListeners(), this
            }
            setExtra(t, n) {
                return this._extra = E(p({}, this._extra), {
                    [t]: n
                }), this._notifyScopeListeners(), this
            }
            setFingerprint(t) {
                return this._fingerprint = t, this._notifyScopeListeners(), this
            }
            setLevel(t) {
                return this._level = t, this._notifyScopeListeners(), this
            }
            setTransactionName(t) {
                return this._transactionName = t, this._notifyScopeListeners(), this
            }
            setContext(t, n) {
                return n === null ? delete this._contexts[t] : this._contexts[t] = n, this._notifyScopeListeners(), this
            }
            setSession(t) {
                return t ? this._session = t : delete this._session, this._notifyScopeListeners(), this
            }
            getSession() {
                return this._session
            }
            update(t) {
                if (!t) return this;
                let n = typeof t == "function" ? t(this) : t,
                    r = n instanceof e ? n.getScopeData() : ee(n) ? t : void 0,
                    {
                        tags: o,
                        extra: i,
                        user: s,
                        contexts: a,
                        level: c,
                        fingerprint: u = [],
                        propagationContext: l
                    } = r || {};
                return this._tags = p(p({}, this._tags), o), this._extra = p(p({}, this._extra), i), this._contexts = p(p({}, this._contexts), a), s && Object.keys(s).length && (this._user = s), c && (this._level = c), u.length && (this._fingerprint = u), l && (this._propagationContext = l), this
            }
            clear() {
                return this._breadcrumbs = [], this._tags = {}, this._extra = {}, this._user = {}, this._contexts = {}, this._level = void 0, this._transactionName = void 0, this._fingerprint = void 0, this._session = void 0, Wn(this, void 0), this._attachments = [], this.setPropagationContext({
                    traceId: Gn(),
                    sampleRand: Math.random()
                }), this._notifyScopeListeners(), this
            }
            addBreadcrumb(t, n) {
                var i;
                let r = typeof n == "number" ? n : la;
                if (r <= 0) return this;
                let o = p({
                    timestamp: ue()
                }, t);
                return this._breadcrumbs.push(o), this._breadcrumbs.length > r && (this._breadcrumbs = this._breadcrumbs.slice(-r), (i = this._client) == null || i.recordDroppedEvent("buffer_overflow", "log_item")), this._notifyScopeListeners(), this
            }
            getLastBreadcrumb() {
                return this._breadcrumbs[this._breadcrumbs.length - 1]
            }
            clearBreadcrumbs() {
                return this._breadcrumbs = [], this._notifyScopeListeners(), this
            }
            addAttachment(t) {
                return this._attachments.push(t), this
            }
            clearAttachments() {
                return this._attachments = [], this
            }
            getScopeData() {
                return {
                    breadcrumbs: this._breadcrumbs,
                    attachments: this._attachments,
                    contexts: this._contexts,
                    tags: this._tags,
                    extra: this._extra,
                    user: this._user,
                    level: this._level,
                    fingerprint: this._fingerprint || [],
                    eventProcessors: this._eventProcessors,
                    propagationContext: this._propagationContext,
                    sdkProcessingMetadata: this._sdkProcessingMetadata,
                    transactionName: this._transactionName,
                    span: Yn(this)
                }
            }
            setSDKProcessingMetadata(t) {
                return this._sdkProcessingMetadata = Ie(this._sdkProcessingMetadata, t, 2), this
            }
            setPropagationContext(t) {
                return this._propagationContext = t, this
            }
            getPropagationContext() {
                return this._propagationContext
            }
            captureException(t, n) {
                let r = (n == null ? void 0 : n.event_id) || w();
                if (!this._client) return _.warn("No client configured on scope - will not capture exception!"), r;
                let o = new Error("Sentry syntheticException");
                return this._client.captureException(t, E(p({
                    originalException: t,
                    syntheticException: o
                }, n), {
                    event_id: r
                }), this), r
            }
            captureMessage(t, n, r) {
                let o = (r == null ? void 0 : r.event_id) || w();
                if (!this._client) return _.warn("No client configured on scope - will not capture message!"), o;
                let i = new Error(t);
                return this._client.captureMessage(t, n, E(p({
                    originalException: t,
                    syntheticException: i
                }, r), {
                    event_id: o
                }), this), o
            }
            captureEvent(t, n) {
                let r = (n == null ? void 0 : n.event_id) || w();
                return this._client ? (this._client.captureEvent(t, E(p({}, n), {
                    event_id: r
                }), this), r) : (_.warn("No client configured on scope - will not capture event!"), r)
            }
            _notifyScopeListeners() {
                this._notifyingListeners || (this._notifyingListeners = !0, this._scopeListeners.forEach(t => {
                    t(this)
                }), this._notifyingListeners = !1)
            }
        }
    });

    function ho() {
        return Re("defaultCurrentScope", () => new K)
    }

    function Eo() {
        return Re("defaultIsolationScope", () => new K)
    }
    var yo = d(() => {
        Ne();
        rt()
    });

    function ze() {
        let e = ve(),
            t = Ce(e);
        return t.stack = t.stack || new zn(ho(), Eo())
    }

    function fa(e) {
        return ze().withScope(e)
    }

    function ma(e, t) {
        let n = ze();
        return n.withScope(() => (n.getStackTop().scope = e, t(e)))
    }

    function So(e) {
        return ze().withScope(() => e(ze().getIsolationScope()))
    }

    function To() {
        return {
            withIsolationScope: So,
            withScope: fa,
            withSetScope: ma,
            withSetIsolationScope: (e, t) => So(t),
            getCurrentScope: () => ze().getScope(),
            getIsolationScope: () => ze().getIsolationScope()
        }
    }
    var zn, Io = d(() => {
        yo();
        rt();
        Y();
        Ne();
        zn = class {
            constructor(t, n) {
                let r;
                t ? r = t : r = new K;
                let o;
                n ? o = n : o = new K, this._stack = [{
                    scope: r
                }], this._isolationScope = o
            }
            withScope(t) {
                let n = this._pushScope(),
                    r;
                try {
                    r = t(n)
                } catch (o) {
                    throw this._popScope(), o
                }
                return fe(r) ? r.then(o => (this._popScope(), o), o => {
                    throw this._popScope(), o
                }) : (this._popScope(), r)
            }
            getClient() {
                return this.getStackTop().client
            }
            getScope() {
                return this.getStackTop().scope
            }
            getIsolationScope() {
                return this._isolationScope
            }
            getStackTop() {
                return this._stack[this._stack.length - 1]
            }
            _pushScope() {
                let t = this.getScope().clone();
                return this._stack.push({
                    client: this.getClient(),
                    scope: t
                }), t
            }
            _popScope() {
                return this._stack.length <= 1 ? !1 : !!this._stack.pop()
            }
        }
    });

    function Ot(e) {
        let t = Ce(e);
        return t.acs ? t.acs : To()
    }
    var xo = d(() => {
        Ne();
        Io()
    });

    function W() {
        let e = ve();
        return Ot(e).getCurrentScope()
    }

    function Z() {
        let e = ve();
        return Ot(e).getIsolationScope()
    }

    function Pt() {
        return Re("globalScope", () => new K)
    }

    function Lt(...e) {
        let t = ve(),
            n = Ot(t);
        if (e.length === 2) {
            let [r, o] = e;
            return r ? n.withSetScope(r, o) : n.withScope(o)
        }
        return n.withScope(e[0])
    }

    function v() {
        return W().getClient()
    }

    function Kn(e) {
        let t = e.getPropagationContext(),
            {
                traceId: n,
                parentSpanId: r,
                propagationSpanId: o
            } = t;
        return R({
            trace_id: n,
            span_id: o || At(),
            parent_span_id: r
        })
    }
    var de = d(() => {
        xo();
        Ne();
        rt();
        j();
        wt()
    });
    var Mt, Jn, Vn, qn, Xn, Zn, Ft = d(() => {
        Mt = "sentry.source", Jn = "sentry.sample_rate", Vn = "sentry.op", qn = "sentry.origin", Xn = "sentry.profile_id", Zn = "sentry.exclusive_time"
    });

    function Ut(e) {
        return {
            scope: e[ga],
            isolationScope: e[_a]
        }
    }
    var ga, _a, Qn = d(() => {
        ga = "_sentryScope", _a = "_sentryIsolationScope"
    });

    function bo(e) {
        if (typeof e == "boolean") return Number(e);
        let t = typeof e == "string" ? parseFloat(e) : e;
        if (!(typeof t != "number" || isNaN(t) || t < 0 || t > 1)) return t
    }
    var vo = d(() => {});

    function Ro(e) {
        let t = ya(e);
        if (!t) return;
        let n = Object.entries(t).reduce((r, [o, i]) => {
            if (o.match(Ea)) {
                let s = o.slice(ha.length);
                r[s] = i
            }
            return r
        }, {});
        if (Object.keys(n).length > 0) return n
    }

    function ya(e) {
        if (!(!e || !$(e) && !Array.isArray(e))) return Array.isArray(e) ? e.reduce((t, n) => {
            let r = Co(n);
            return Object.entries(r).forEach(([o, i]) => {
                t[o] = i
            }), t
        }, {}) : Co(e)
    }

    function Co(e) {
        return e.split(",").map(t => t.split("=").map(n => decodeURIComponent(n.trim()))).reduce((t, [n, r]) => (n && r && (t[n] = r), t), {})
    }
    var ha, Ea, No = d(() => {
        Y();
        ha = "sentry-", Ea = /^sentry-/
    });

    function Do(e) {
        let {
            spanId: t,
            traceId: n,
            isRemote: r
        } = e.spanContext(), o = r ? t : Ke(e).parent_span_id, i = Ut(e).scope, s = r ? (i == null ? void 0 : i.getPropagationContext().propagationSpanId) || At() : t;
        return R({
            parent_span_id: o,
            span_id: s,
            trace_id: n
        })
    }

    function Ao(e) {
        return typeof e == "number" ? wo(e) : Array.isArray(e) ? e[0] + e[1] / 1e9 : e instanceof Date ? wo(e.getTime()) : z()
    }

    function wo(e) {
        return e > 9999999999 ? e / 1e3 : e
    }

    function Ke(e) {
        if (Ia(e)) return e.getSpanJSON();
        let {
            spanId: t,
            traceId: n
        } = e.spanContext();
        if (Ta(e)) {
            let {
                attributes: r,
                startTime: o,
                name: i,
                endTime: s,
                parentSpanId: a,
                status: c
            } = e;
            return R({
                span_id: t,
                trace_id: n,
                data: r,
                description: i,
                parent_span_id: a,
                start_timestamp: Ao(o),
                timestamp: Ao(s) || void 0,
                status: xa(c),
                op: r[Vn],
                origin: r[qn]
            })
        }
        return {
            span_id: t,
            trace_id: n,
            start_timestamp: 0,
            data: {}
        }
    }

    function Ta(e) {
        let t = e;
        return !!t.attributes && !!t.startTime && !!t.name && !!t.endTime && !!t.status
    }

    function Ia(e) {
        return typeof e.getSpanJSON == "function"
    }

    function Oo(e) {
        let {
            traceFlags: t
        } = e.spanContext();
        return t === Sa
    }

    function xa(e) {
        if (!(!e || e.code === 0)) return e.code === 1 ? "ok" : e.message || "unknown_error"
    }

    function ot(e) {
        return e[ba] || e
    }

    function er() {
        ko || (V(() => {
            console.warn("[Sentry] Returning null from `beforeSendSpan` is disallowed. To drop certain spans, configure the respective integrations directly.")
        }), ko = !0)
    }
    var Sa, ko, ba, Bt = d(() => {
        Ft();
        Qn();
        M();
        j();
        wt();
        me();
        Sa = 1, ko = !1;
        ba = "_sentryRootSpan"
    });

    function Po(e) {
        var n;
        if (typeof __SENTRY_TRACING__ == "boolean" && !__SENTRY_TRACING__) return !1;
        let t = e || ((n = v()) == null ? void 0 : n.getOptions());
        return !!t && (t.tracesSampleRate != null || !!t.tracesSampler)
    }
    var Lo = d(() => {
        de()
    });
    var Je, Ht = d(() => {
        Je = "production"
    });

    function Mo(e, t) {
        let n = t.getOptions(),
            {
                publicKey: r
            } = t.getDsn() || {},
            o = R({
                environment: n.environment || Je,
                release: n.release,
                public_key: r,
                trace_id: e
            });
        return t.emit("createDsc", o), o
    }

    function Fo(e, t) {
        let n = t.getPropagationContext();
        return n.dsc || Mo(n.traceId, e)
    }

    function Uo(e) {
        var S, T, I;
        let t = v();
        if (!t) return {};
        let n = ot(e),
            r = Ke(n),
            o = r.data,
            i = n.spanContext().traceState,
            s = (S = i == null ? void 0 : i.get("sentry.sample_rate")) != null ? S : o[Jn];

        function a(O) {
            return (typeof s == "number" || typeof s == "string") && (O.sample_rate = `${s}`), O
        }
        let c = n[va];
        if (c) return a(c);
        let u = i == null ? void 0 : i.get("sentry.dsc"),
            l = u && Ro(u);
        if (l) return a(l);
        let f = Mo(e.spanContext().traceId, t),
            g = o[Mt],
            m = r.description;
        return g !== "url" && m && (f.transaction = m), Po() && (f.sampled = String(Oo(n)), f.sample_rand = (I = i == null ? void 0 : i.get("sentry.sample_rand")) != null ? I : (T = Ut(n).scope) == null ? void 0 : T.getPropagationContext().sampleRand.toString()), a(f), t.emit("createDsc", f, n), f
    }
    var va, tr = d(() => {
        Ht();
        de();
        Ft();
        No();
        j();
        Lo();
        Bt();
        Qn();
        va = "_frozenDsc"
    });

    function Ra(e) {
        return e === "http" || e === "https"
    }

    function Ve(e, t = !1) {
        let {
            host: n,
            path: r,
            pass: o,
            port: i,
            projectId: s,
            protocol: a,
            publicKey: c
        } = e;
        return `${a}://${c}${t&&o?`:${o}`:""}@${n}${i?`:${i}`:""}/${r&&`${r}/`}${s}`
    }

    function Na(e) {
        let t = Ca.exec(e);
        if (!t) {
            V(() => {
                console.error(`Invalid Sentry Dsn: ${e}`)
            });
            return
        }
        let [n, r, o = "", i = "", s = "", a = ""] = t.slice(1), c = "", u = a, l = u.split("/");
        if (l.length > 1 && (c = l.slice(0, -1).join("/"), u = l.pop()), u) {
            let f = u.match(/^\d+/);
            f && (u = f[0])
        }
        return Bo({
            host: i,
            pass: o,
            path: c,
            projectId: u,
            port: s,
            protocol: n,
            publicKey: r
        })
    }

    function Bo(e) {
        return {
            protocol: e.protocol,
            publicKey: e.publicKey || "",
            pass: e.pass || "",
            host: e.host,
            port: e.port || "",
            path: e.path || "",
            projectId: e.projectId
        }
    }

    function ka(e) {
        if (!J) return !0;
        let {
            port: t,
            projectId: n,
            protocol: r
        } = e;
        return ["protocol", "publicKey", "host", "projectId"].find(s => e[s] ? !1 : (_.error(`Invalid Sentry Dsn: ${s} missing`), !0)) ? !1 : n.match(/^\d+$/) ? Ra(r) ? t && isNaN(parseInt(t, 10)) ? (_.error(`Invalid Sentry Dsn: Invalid port ${t}`), !1) : !0 : (_.error(`Invalid Sentry Dsn: Invalid protocol ${r}`), !1) : (_.error(`Invalid Sentry Dsn: Invalid projectId ${n}`), !1)
    }

    function Ho(e) {
        let t = typeof e == "string" ? Na(e) : Bo(e);
        if (!(!t || !ka(t))) return t
    }
    var Ca, $t = d(() => {
        Fe();
        M();
        Ca = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+)?)?@)([\w.-]+)(?::(\d+))?\/(.+)/
    });

    function Q(e, t = 100, n = 1 / 0) {
        try {
            return nr("", e, t, n)
        } catch (r) {
            return {
                ERROR: `**non-serializable** (${r})`
            }
        }
    }

    function Gt(e, t = 3, n = 100 * 1024) {
        let r = Q(e, t);
        return Oa(r) > n ? Gt(e, t - 1, n) : r
    }

    function nr(e, t, n = 1 / 0, r = 1 / 0, o = Pa()) {
        let [i, s] = o;
        if (t == null || ["boolean", "string"].includes(typeof t) || typeof t == "number" && Number.isFinite(t)) return t;
        let a = Aa(e, t);
        if (!a.startsWith("[object ")) return a;
        if (t.__sentry_skip_normalization__) return t;
        let c = typeof t.__sentry_override_normalization_depth__ == "number" ? t.__sentry_override_normalization_depth__ : n;
        if (c === 0) return a.replace("object ", "");
        if (i(t)) return "[Circular ~]";
        let u = t;
        if (u && typeof u.toJSON == "function") try {
            let m = u.toJSON();
            return nr("", m, c - 1, r, o)
        } catch (m) {}
        let l = Array.isArray(t) ? [] : {},
            f = 0,
            g = Rt(t);
        for (let m in g) {
            if (!Object.prototype.hasOwnProperty.call(g, m)) continue;
            if (f >= r) {
                l[m] = "[MaxProperties ~]";
                break
            }
            let S = g[m];
            l[m] = nr(m, S, c - 1, r, o), f++
        }
        return s(t), l
    }

    function Aa(e, t) {
        try {
            if (e === "domain" && t && typeof t == "object" && t._events) return "[Domain]";
            if (e === "domainEmitter") return "[DomainEmitter]";
            if (typeof global != "undefined" && t === global) return "[Global]";
            if (typeof window != "undefined" && t === window) return "[Window]";
            if (typeof document != "undefined" && t === document) return "[Document]";
            if (tt(t)) return "[VueViewModel]";
            if (Mn(t)) return "[SyntheticEvent]";
            if (typeof t == "number" && !Number.isFinite(t)) return `[${t}]`;
            if (typeof t == "function") return `[Function: ${q(t)}]`;
            if (typeof t == "symbol") return `[${String(t)}]`;
            if (typeof t == "bigint") return `[BigInt: ${String(t)}]`;
            let n = wa(t);
            return /^HTML(\w*)Element$/.test(n) ? `[HTMLElement: ${n}]` : `[object ${n}]`
        } catch (n) {
            return `**non-serializable** (${n})`
        }
    }

    function wa(e) {
        let t = Object.getPrototypeOf(e);
        return t ? t.constructor.name : "null prototype"
    }

    function Da(e) {
        return ~-encodeURI(e).split(/%..|./).length
    }

    function Oa(e) {
        return Da(JSON.stringify(e))
    }

    function Pa() {
        let e = new WeakSet;

        function t(r) {
            return e.has(r) ? !0 : (e.add(r), !1)
        }

        function n(r) {
            e.delete(r)
        }
        return [t, n]
    }
    var jt = d(() => {
        Y();
        j();
        et()
    });

    function Pe(e, t = []) {
        return [e, t]
    }

    function $o(e, t) {
        let [n, r] = e;
        return [n, [...r, t]]
    }

    function or(e, t) {
        let n = e[1];
        for (let r of n) {
            let o = r[0].type;
            if (t(r, o)) return !0
        }
        return !1
    }

    function rr(e) {
        let t = Ce(h);
        return t.encodePolyfill ? t.encodePolyfill(e) : new TextEncoder().encode(e)
    }

    function Go(e) {
        let [t, n] = e, r = JSON.stringify(t);

        function o(i) {
            typeof r == "string" ? r = typeof i == "string" ? r + i : [rr(r), i] : r.push(typeof i == "string" ? rr(i) : i)
        }
        for (let i of n) {
            let [s, a] = i;
            if (o(`
${JSON.stringify(s)}
`), typeof a == "string" || a instanceof Uint8Array) o(a);
            else {
                let c;
                try {
                    c = JSON.stringify(a)
                } catch (u) {
                    c = JSON.stringify(Q(a))
                }
                o(c)
            }
        }
        return typeof r == "string" ? r : La(r)
    }

    function La(e) {
        let t = e.reduce((o, i) => o + i.length, 0),
            n = new Uint8Array(t),
            r = 0;
        for (let o of e) n.set(o, r), r += o.length;
        return n
    }

    function jo(e) {
        let t = typeof e.data == "string" ? rr(e.data) : e.data;
        return [R({
            type: "attachment",
            length: t.length,
            filename: e.filename,
            content_type: e.contentType,
            attachment_type: e.attachmentType
        }), t]
    }

    function ir(e) {
        return Ma[e]
    }

    function sr(e) {
        if (!(e != null && e.sdk)) return;
        let {
            name: t,
            version: n
        } = e.sdk;
        return {
            name: t,
            version: n
        }
    }

    function Wo(e, t, n, r) {
        var i;
        let o = (i = e.sdkProcessingMetadata) == null ? void 0 : i.dynamicSamplingContext;
        return p(p(p({
            event_id: e.event_id,
            sent_at: new Date().toISOString()
        }, t && {
            sdk: t
        }), !!n && r && {
            dsn: Ve(r)
        }), o && {
            trace: R(p({}, o))
        })
    }
    var Ma, it = d(() => {
        Ne();
        $t();
        jt();
        j();
        U();
        Ma = {
            session: "session",
            sessions: "session",
            attachment: "attachment",
            transaction: "transaction",
            event: "error",
            client_report: "internal",
            user_report: "default",
            profile: "profile",
            profile_chunk: "profile",
            replay_event: "replay",
            replay_recording: "replay",
            check_in: "monitor",
            feedback: "feedback",
            span: "span",
            raw_security: "security"
        }
    });

    function Fa(e, t) {
        return t && (e.sdk = e.sdk || {}, e.sdk.name = e.sdk.name || t.name, e.sdk.version = e.sdk.version || t.version, e.sdk.integrations = [...e.sdk.integrations || [], ...t.integrations || []], e.sdk.packages = [...e.sdk.packages || [], ...t.packages || []]), e
    }

    function Yo(e, t, n, r) {
        let o = sr(n),
            i = p(p({
                sent_at: new Date().toISOString()
            }, o && {
                sdk: o
            }), !!r && t && {
                dsn: Ve(t)
            }),
            s = "aggregates" in e ? [{
                type: "sessions"
            }, e] : [{
                type: "session"
            }, e.toJSON()];
        return Pe(i, [s])
    }

    function zo(e, t, n, r) {
        let o = sr(n),
            i = e.type && e.type !== "replay_event" ? e.type : "event";
        Fa(e, n == null ? void 0 : n.sdk);
        let s = Wo(e, o, r, t);
        return delete e.sdkProcessingMetadata, Pe(s, [
            [{
                type: i
            }, e]
        ])
    }
    var Ko = d(() => {
        $t();
        it()
    });

    function Wt(e, t, n, r = 0) {
        return new ne((o, i) => {
            let s = e[r];
            if (t === null || typeof s != "function") o(t);
            else {
                let a = s(p({}, t), n);
                y && s.id && a === null && _.log(`Event processor "${s.id}" dropped event`), fe(a) ? a.then(c => Wt(e, c, n, r + 1).then(o)).then(null, i) : Wt(e, a, n, r + 1).then(o).then(null, i)
            }
        })
    }
    var Jo = d(() => {
        ye();
        Y();
        M();
        Ye()
    });

    function qo(e) {
        let t = h._sentryDebugIds;
        if (!t) return {};
        let n = Object.keys(t);
        return zt && n.length === Vo || (Vo = n.length, zt = n.reduce((r, o) => {
            Yt || (Yt = {});
            let i = Yt[o];
            if (i) r[i[0]] = i[1];
            else {
                let s = e(o);
                for (let a = s.length - 1; a >= 0; a--) {
                    let c = s[a],
                        u = c == null ? void 0 : c.filename,
                        l = t[o];
                    if (u && l) {
                        r[u] = l, Yt[o] = [u, l];
                        break
                    }
                }
            }
            return r
        }, {})), zt
    }
    var Yt, Vo, zt, Xo = d(() => {
        U()
    });

    function Zo(e, t) {
        let {
            fingerprint: n,
            span: r,
            breadcrumbs: o,
            sdkProcessingMetadata: i
        } = t;
        Ua(e, t), r && $a(e, r), Ga(e, n), Ba(e, o), Ha(e, i)
    }

    function ar(e, t) {
        let {
            extra: n,
            tags: r,
            user: o,
            contexts: i,
            level: s,
            sdkProcessingMetadata: a,
            breadcrumbs: c,
            fingerprint: u,
            eventProcessors: l,
            attachments: f,
            propagationContext: g,
            transactionName: m,
            span: S
        } = t;
        Kt(e, "extra", n), Kt(e, "tags", r), Kt(e, "user", o), Kt(e, "contexts", i), e.sdkProcessingMetadata = Ie(e.sdkProcessingMetadata, a, 2), s && (e.level = s), m && (e.transactionName = m), S && (e.span = S), c.length && (e.breadcrumbs = [...e.breadcrumbs, ...c]), u.length && (e.fingerprint = [...e.fingerprint, ...u]), l.length && (e.eventProcessors = [...e.eventProcessors, ...l]), f.length && (e.attachments = [...e.attachments, ...f]), e.propagationContext = p(p({}, e.propagationContext), g)
    }

    function Kt(e, t, n) {
        e[t] = Ie(e[t], n, 1)
    }

    function Ua(e, t) {
        let {
            extra: n,
            tags: r,
            user: o,
            contexts: i,
            level: s,
            transactionName: a
        } = t, c = R(n);
        Object.keys(c).length && (e.extra = p(p({}, c), e.extra));
        let u = R(r);
        Object.keys(u).length && (e.tags = p(p({}, u), e.tags));
        let l = R(o);
        Object.keys(l).length && (e.user = p(p({}, l), e.user));
        let f = R(i);
        Object.keys(f).length && (e.contexts = p(p({}, f), e.contexts)), s && (e.level = s), a && e.type !== "transaction" && (e.transaction = a)
    }

    function Ba(e, t) {
        let n = [...e.breadcrumbs || [], ...t];
        e.breadcrumbs = n.length ? n : void 0
    }

    function Ha(e, t) {
        e.sdkProcessingMetadata = p(p({}, e.sdkProcessingMetadata), t)
    }

    function $a(e, t) {
        e.contexts = p({
            trace: Do(t)
        }, e.contexts), e.sdkProcessingMetadata = p({
            dynamicSamplingContext: Uo(t)
        }, e.sdkProcessingMetadata);
        let n = ot(t),
            r = Ke(n).description;
        r && !e.transaction && e.type === "transaction" && (e.transaction = r)
    }

    function Ga(e, t) {
        e.fingerprint = e.fingerprint ? Array.isArray(e.fingerprint) ? e.fingerprint : [e.fingerprint] : [], t && (e.fingerprint = e.fingerprint.concat(t)), e.fingerprint.length || delete e.fingerprint
    }
    var Qo = d(() => {
        tr();
        j();
        Dt();
        Bt()
    });

    function ei(e, t, n, r, o, i) {
        let {
            normalizeDepth: s = 3,
            normalizeMaxBreadth: a = 1e3
        } = e, c = E(p({}, t), {
            event_id: t.event_id || n.event_id || w(),
            timestamp: t.timestamp || ue()
        }), u = n.integrations || e.integrations.map(I => I.name);
        ja(c, e), za(c, u), o && o.emit("applyFrameMetadata", t), t.type === void 0 && Wa(c, e.stackParser);
        let l = Ja(r, n.captureContext);
        n.mechanism && pe(c, n.mechanism);
        let f = o ? o.getEventProcessors() : [],
            g = Pt().getScopeData();
        if (i) {
            let I = i.getScopeData();
            ar(g, I)
        }
        if (l) {
            let I = l.getScopeData();
            ar(g, I)
        }
        let m = [...n.attachments || [], ...g.attachments];
        m.length && (n.attachments = m), Zo(c, g);
        let S = [...f, ...g.eventProcessors];
        return Wt(S, c, n).then(I => (I && Ya(I), typeof s == "number" && s > 0 ? Ka(I, s, a) : I))
    }

    function ja(e, t) {
        var c, u;
        let {
            environment: n,
            release: r,
            dist: o,
            maxValueLength: i = 250
        } = t;
        e.environment = e.environment || n || Je, !e.release && r && (e.release = r), !e.dist && o && (e.dist = o), e.message && (e.message = ce(e.message, i));
        let s = (u = (c = e.exception) == null ? void 0 : c.values) == null ? void 0 : u[0];
        s != null && s.value && (s.value = ce(s.value, i));
        let a = e.request;
        a != null && a.url && (a.url = ce(a.url, i))
    }

    function Wa(e, t) {
        var r, o;
        let n = qo(t);
        (o = (r = e.exception) == null ? void 0 : r.values) == null || o.forEach(i => {
            var s, a;
            (a = (s = i.stacktrace) == null ? void 0 : s.frames) == null || a.forEach(c => {
                c.filename && (c.debug_id = n[c.filename])
            })
        })
    }

    function Ya(e) {
        var r, o;
        let t = {};
        if ((o = (r = e.exception) == null ? void 0 : r.values) == null || o.forEach(i => {
                var s, a;
                (a = (s = i.stacktrace) == null ? void 0 : s.frames) == null || a.forEach(c => {
                    c.debug_id && (c.abs_path ? t[c.abs_path] = c.debug_id : c.filename && (t[c.filename] = c.debug_id), delete c.debug_id)
                })
            }), Object.keys(t).length === 0) return;
        e.debug_meta = e.debug_meta || {}, e.debug_meta.images = e.debug_meta.images || [];
        let n = e.debug_meta.images;
        Object.entries(t).forEach(([i, s]) => {
            n.push({
                type: "sourcemap",
                code_file: i,
                debug_id: s
            })
        })
    }

    function za(e, t) {
        t.length > 0 && (e.sdk = e.sdk || {}, e.sdk.integrations = [...e.sdk.integrations || [], ...t])
    }

    function Ka(e, t, n) {
        var o, i;
        if (!e) return null;
        let r = p(p(p(p(p({}, e), e.breadcrumbs && {
            breadcrumbs: e.breadcrumbs.map(s => p(p({}, s), s.data && {
                data: Q(s.data, t, n)
            }))
        }), e.user && {
            user: Q(e.user, t, n)
        }), e.contexts && {
            contexts: Q(e.contexts, t, n)
        }), e.extra && {
            extra: Q(e.extra, t, n)
        });
        return (o = e.contexts) != null && o.trace && r.contexts && (r.contexts.trace = e.contexts.trace, e.contexts.trace.data && (r.contexts.trace.data = Q(e.contexts.trace.data, t, n))), e.spans && (r.spans = e.spans.map(s => p(p({}, s), s.data && {
            data: Q(s.data, t, n)
        }))), (i = e.contexts) != null && i.flags && r.contexts && (r.contexts.flags = Q(e.contexts.flags, 3, n)), r
    }

    function Ja(e, t) {
        if (!t) return e;
        let n = e ? e.clone() : new K;
        return n.update(t), n
    }

    function ti(e) {
        if (e) return Va(e) ? {
            captureContext: e
        } : Xa(e) ? {
            captureContext: e
        } : e
    }

    function Va(e) {
        return e instanceof K || typeof e == "function"
    }

    function Xa(e) {
        return Object.keys(e).some(t => qa.includes(t))
    }
    var qa, cr = d(() => {
        Ht();
        de();
        Jo();
        rt();
        Xo();
        Se();
        jt();
        je();
        me();
        Qo();
        qa = ["user", "level", "extra", "contexts", "tags", "fingerprint", "propagationContext"]
    });

    function he(e, t) {
        return W().captureException(e, ti(t))
    }

    function Jt(e, t) {
        let n = typeof t == "string" ? t : void 0,
            r = typeof t != "string" ? {
                captureContext: t
            } : void 0;
        return W().captureMessage(e, n, r)
    }

    function st(e, t) {
        return W().captureEvent(e, t)
    }

    function at(e, t) {
        Z().setContext(e, t)
    }

    function Vt(e) {
        Z().setTags(e)
    }

    function ct(e) {
        let t = Z(),
            n = W(),
            {
                userAgent: r
            } = h.navigator || {},
            o = mo(p(p({
                user: n.getUser() || t.getUser()
            }, r && {
                userAgent: r
            }), e)),
            i = t.getSession();
        return (i == null ? void 0 : i.status) === "ok" && _e(i, {
            status: "exited"
        }), qt(), t.setSession(o), o
    }

    function qt() {
        let e = Z(),
            n = W().getSession() || e.getSession();
        n && go(n), ri(), e.setSession()
    }

    function ri() {
        let e = Z(),
            t = v(),
            n = e.getSession();
        n && t && t.captureSession(n)
    }

    function ut(e = !1) {
        if (e) {
            qt();
            return
        }
        ri()
    }
    var oi = d(() => {
        de();
        kt();
        U();
        cr()
    });

    function Qa(e) {
        let t = e.protocol ? `${e.protocol}:` : "",
            n = e.port ? `:${e.port}` : "";
        return `${t}//${e.host}${n}${e.path?`/${e.path}`:""}/api/`
    }

    function ec(e) {
        return `${Qa(e)}${e.projectId}/envelope/`
    }

    function tc(e, t) {
        let n = {
            sentry_version: Za
        };
        return e.publicKey && (n.sentry_key = e.publicKey), t && (n.sentry_client = `${t.name}/${t.version}`), new URLSearchParams(n).toString()
    }

    function ii(e, t, n) {
        return t || `${ec(e)}?${tc(e,n)}`
    }
    var Za, si = d(() => {
        Za = "7"
    });

    function nc(e) {
        let t = {};
        return e.forEach(n => {
            let {
                name: r
            } = n, o = t[r];
            o && !o.isDefaultInstance && n.isDefaultInstance || (t[r] = n)
        }), Object.values(t)
    }

    function ur(e) {
        let t = e.defaultIntegrations || [],
            n = e.integrations;
        t.forEach(o => {
            o.isDefaultInstance = !0
        });
        let r;
        if (Array.isArray(n)) r = [...t, ...n];
        else if (typeof n == "function") {
            let o = n(t);
            r = Array.isArray(o) ? o : [o]
        } else r = t;
        return nc(r)
    }

    function ci(e, t) {
        let n = {};
        return t.forEach(r => {
            r && dr(e, r, n)
        }), n
    }

    function pr(e, t) {
        for (let n of t) n != null && n.afterAllSetup && n.afterAllSetup(e)
    }

    function dr(e, t, n) {
        if (n[t.name]) {
            y && _.log(`Integration skipped because it was already installed: ${t.name}`);
            return
        }
        if (n[t.name] = t, ai.indexOf(t.name) === -1 && typeof t.setupOnce == "function" && (t.setupOnce(), ai.push(t.name)), t.setup && typeof t.setup == "function" && t.setup(e), typeof t.preprocessEvent == "function") {
            let r = t.preprocessEvent.bind(t);
            e.on("preprocessEvent", (o, i) => r(o, i, e))
        }
        if (typeof t.processEvent == "function") {
            let r = t.processEvent.bind(t),
                o = Object.assign((i, s) => r(i, s, e), {
                    id: t.name
                });
            e.addEventProcessor(o)
        }
        y && _.log(`Integration installed: ${t.name}`)
    }
    var ai, lr = d(() => {
        ye();
        M();
        ai = []
    });

    function ui(e, t, n) {
        let r = [{
            type: "client_report"
        }, {
            timestamp: n || ue(),
            discarded_events: e
        }];
        return Pe(t ? {
            dsn: t
        } : {}, [r])
    }
    var pi = d(() => {
        it();
        me()
    });
    var F, Xt = d(() => {
        F = class extends Error {
            constructor(t, n = "warn") {
                super(t), this.message = t, this.logLevel = n
            }
        }
    });

    function Zt(e) {
        let t = [];
        e.message && t.push(e.message);
        try {
            let n = e.exception.values[e.exception.values.length - 1];
            n != null && n.value && (t.push(n.value), n.type && t.push(`${n.type}: ${n.value}`))
        } catch (n) {}
        return t
    }
    var fr = d(() => {});

    function di(e) {
        var c, u, l;
        let {
            trace_id: t,
            parent_span_id: n,
            span_id: r,
            status: o,
            origin: i,
            data: s,
            op: a
        } = (u = (c = e.contexts) == null ? void 0 : c.trace) != null ? u : {};
        return R({
            data: s != null ? s : {},
            description: e.transaction,
            op: a,
            parent_span_id: n,
            span_id: r != null ? r : "",
            start_timestamp: (l = e.start_timestamp) != null ? l : 0,
            status: o,
            timestamp: e.timestamp,
            trace_id: t != null ? t : "",
            origin: i,
            profile_id: s == null ? void 0 : s[Xn],
            exclusive_time: s == null ? void 0 : s[Zn],
            measurements: e.measurements,
            is_segment: !0
        })
    }

    function li(e) {
        let t = {
            type: "transaction",
            timestamp: e.timestamp,
            start_timestamp: e.start_timestamp,
            transaction: e.description,
            contexts: {
                trace: {
                    trace_id: e.trace_id,
                    span_id: e.span_id,
                    parent_span_id: e.parent_span_id,
                    op: e.op,
                    status: e.status,
                    origin: e.origin,
                    data: p(p(p({}, e.data), e.profile_id && {
                        [Xn]: e.profile_id
                    }), e.exclusive_time && {
                        [Zn]: e.exclusive_time
                    })
                }
            },
            measurements: e.measurements
        };
        return R(t)
    }
    var fi = d(() => {
        Ft();
        j()
    });

    function rc(e, t) {
        let n = `${t} must return \`null\` or a valid event.`;
        if (fe(e)) return e.then(r => {
            if (!ee(r) && r !== null) throw new F(n);
            return r
        }, r => {
            throw new F(`${t} rejected with ${r}`)
        });
        if (!ee(e) && e !== null) throw new F(n);
        return e
    }

    function oc(e, t, n, r) {
        let {
            beforeSend: o,
            beforeSendTransaction: i,
            beforeSendSpan: s
        } = t, a = n;
        if (mr(a) && o) return o(a, r);
        if (_i(a)) {
            if (s) {
                let c = s(di(a));
                if (c ? a = Ie(n, li(c)) : er(), a.spans) {
                    let u = [];
                    for (let l of a.spans) {
                        let f = s(l);
                        f ? u.push(f) : (er(), u.push(l))
                    }
                    a.spans = u
                }
            }
            if (i) {
                if (a.spans) {
                    let c = a.spans.length;
                    a.sdkProcessingMetadata = E(p({}, n.sdkProcessingMetadata), {
                        spanCountBeforeProcessing: c
                    })
                }
                return i(a, r)
            }
        }
        return a
    }

    function mr(e) {
        return e.type === void 0
    }

    function _i(e) {
        return e.type === "transaction"
    }
    var mi, gi, pt, hi = d(() => {
        si();
        Ht();
        de();
        ye();
        Ko();
        lr();
        kt();
        tr();
        pi();
        $t();
        it();
        Xt();
        Y();
        M();
        Se();
        Ye();
        fr();
        Dt();
        vo();
        cr();
        Bt();
        fi();
        mi = "Not capturing exception because it's already been captured.", gi = "Discarded session because of missing or non-string release", pt = class {
            constructor(t) {
                if (this._options = t, this._integrations = {}, this._numProcessing = 0, this._outcomes = {}, this._hooks = {}, this._eventProcessors = [], t.dsn ? this._dsn = Ho(t.dsn) : y && _.warn("No DSN provided, client will not send events."), this._dsn) {
                    let n = ii(this._dsn, t.tunnel, t._metadata ? t._metadata.sdk : void 0);
                    this._transport = t.transport(E(p({
                        tunnel: this._options.tunnel,
                        recordDroppedEvent: this.recordDroppedEvent.bind(this)
                    }, t.transportOptions), {
                        url: n
                    }))
                }
            }
            captureException(t, n, r) {
                let o = w();
                if (Nt(t)) return y && _.log(mi), o;
                let i = p({
                    event_id: o
                }, n);
                return this._process(this.eventFromException(t, i).then(s => this._captureEvent(s, i, r))), i.event_id
            }
            captureMessage(t, n, r, o) {
                let i = p({
                        event_id: w()
                    }, r),
                    s = $e(t) ? t : String(t),
                    a = Ae(t) ? this.eventFromMessage(s, n, i) : this.eventFromException(t, i);
                return this._process(a.then(c => this._captureEvent(c, i, o))), i.event_id
            }
            captureEvent(t, n, r) {
                let o = w();
                if (n != null && n.originalException && Nt(n.originalException)) return y && _.log(mi), o;
                let i = p({
                        event_id: o
                    }, n),
                    s = t.sdkProcessingMetadata || {},
                    a = s.capturedSpanScope,
                    c = s.capturedSpanIsolationScope;
                return this._process(this._captureEvent(t, i, a || r, c)), i.event_id
            }
            captureSession(t) {
                this.sendSession(t), _e(t, {
                    init: !1
                })
            }
            getDsn() {
                return this._dsn
            }
            getOptions() {
                return this._options
            }
            getSdkMetadata() {
                return this._options._metadata
            }
            getTransport() {
                return this._transport
            }
            flush(t) {
                let n = this._transport;
                return n ? (this.emit("flush"), this._isClientDoneProcessing(t).then(r => n.flush(t).then(o => r && o))) : X(!0)
            }
            close(t) {
                return this.flush(t).then(n => (this.getOptions().enabled = !1, this.emit("close"), n))
            }
            getEventProcessors() {
                return this._eventProcessors
            }
            addEventProcessor(t) {
                this._eventProcessors.push(t)
            }
            init() {
                (this._isEnabled() || this._options.integrations.some(({
                    name: t
                }) => t.startsWith("Spotlight"))) && this._setupIntegrations()
            }
            getIntegrationByName(t) {
                return this._integrations[t]
            }
            addIntegration(t) {
                let n = this._integrations[t.name];
                dr(this, t, this._integrations), n || pr(this, [t])
            }
            sendEvent(t, n = {}) {
                this.emit("beforeSendEvent", t, n);
                let r = zo(t, this._dsn, this._options._metadata, this._options.tunnel);
                for (let i of n.attachments || []) r = $o(r, jo(i));
                let o = this.sendEnvelope(r);
                o && o.then(i => this.emit("afterSendEvent", t, i), null)
            }
            sendSession(t) {
                let {
                    release: n,
                    environment: r = Je
                } = this._options;
                if ("aggregates" in t) {
                    let i = t.attrs || {};
                    if (!i.release && !n) {
                        y && _.warn(gi);
                        return
                    }
                    i.release = i.release || n, i.environment = i.environment || r, t.attrs = i
                } else {
                    if (!t.release && !n) {
                        y && _.warn(gi);
                        return
                    }
                    t.release = t.release || n, t.environment = t.environment || r
                }
                this.emit("beforeSendSession", t);
                let o = Yo(t, this._dsn, this._options._metadata, this._options.tunnel);
                this.sendEnvelope(o)
            }
            recordDroppedEvent(t, n, r = 1) {
                if (this._options.sendClientReports) {
                    let o = `${t}:${n}`;
                    y && _.log(`Recording outcome: "${o}"${r>1?` (${r} times)`:""}`), this._outcomes[o] = (this._outcomes[o] || 0) + r
                }
            }
            on(t, n) {
                let r = this._hooks[t] = this._hooks[t] || [];
                return r.push(n), () => {
                    let o = r.indexOf(n);
                    o > -1 && r.splice(o, 1)
                }
            }
            emit(t, ...n) {
                let r = this._hooks[t];
                r && r.forEach(o => o(...n))
            }
            sendEnvelope(t) {
                return this.emit("beforeEnvelope", t), this._isEnabled() && this._transport ? this._transport.send(t).then(null, n => (y && _.error("Error while sending envelope:", n), n)) : (y && _.error("Transport disabled"), X({}))
            }
            _setupIntegrations() {
                let {
                    integrations: t
                } = this._options;
                this._integrations = ci(this, t), pr(this, t)
            }
            _updateSessionFromEvent(t, n) {
                var c;
                let r = n.level === "fatal",
                    o = !1,
                    i = (c = n.exception) == null ? void 0 : c.values;
                if (i) {
                    o = !0;
                    for (let u of i) {
                        let l = u.mechanism;
                        if ((l == null ? void 0 : l.handled) === !1) {
                            r = !0;
                            break
                        }
                    }
                }
                let s = t.status === "ok";
                (s && t.errors === 0 || s && r) && (_e(t, E(p({}, r && {
                    status: "crashed"
                }), {
                    errors: t.errors || Number(o || r)
                })), this.captureSession(t))
            }
            _isClientDoneProcessing(t) {
                return new ne(n => {
                    let r = 0,
                        o = 1,
                        i = setInterval(() => {
                            this._numProcessing == 0 ? (clearInterval(i), n(!0)) : (r += o, t && r >= t && (clearInterval(i), n(!1)))
                        }, o)
                })
            }
            _isEnabled() {
                return this.getOptions().enabled !== !1 && this._transport !== void 0
            }
            _prepareEvent(t, n, r, o) {
                let i = this.getOptions(),
                    s = Object.keys(this._integrations);
                return !n.integrations && (s != null && s.length) && (n.integrations = s), this.emit("preprocessEvent", t, n), t.type || o.setLastEventId(t.event_id || n.event_id), ei(i, t, n, r, this, o).then(a => {
                    if (a === null) return a;
                    this.emit("postprocessEvent", a, n), a.contexts = p({
                        trace: Kn(r)
                    }, a.contexts);
                    let c = Fo(this, r);
                    return a.sdkProcessingMetadata = p({
                        dynamicSamplingContext: c
                    }, a.sdkProcessingMetadata), a
                })
            }
            _captureEvent(t, n = {}, r = W(), o = Z()) {
                return y && mr(t) && _.log(`Captured error event \`${Zt(t)[0]||"<unknown>"}\``), this._processEvent(t, n, r, o).then(i => i.event_id, i => {
                    y && (i instanceof F && i.logLevel === "log" ? _.log(i.message) : _.warn(i))
                })
            }
            _processEvent(t, n, r, o) {
                let i = this.getOptions(),
                    {
                        sampleRate: s
                    } = i,
                    a = _i(t),
                    c = mr(t),
                    u = t.type || "error",
                    l = `before send for type \`${u}\``,
                    f = typeof s == "undefined" ? void 0 : bo(s);
                if (c && typeof f == "number" && Math.random() > f) return this.recordDroppedEvent("sample_rate", "error"), Te(new F(`Discarding event because it's not included in the random sample (sampling rate = ${s})`, "log"));
                let g = u === "replay_event" ? "replay" : u;
                return this._prepareEvent(t, n, r, o).then(m => {
                    if (m === null) throw this.recordDroppedEvent("event_processor", g), new F("An event processor returned `null`, will not send event.", "log");
                    if (n.data && n.data.__sentry__ === !0) return m;
                    let T = oc(this, i, m, n);
                    return rc(T, l)
                }).then(m => {
                    var I;
                    if (m === null) {
                        if (this.recordDroppedEvent("before_send", g), a) {
                            let re = 1 + (t.spans || []).length;
                            this.recordDroppedEvent("before_send", "span", re)
                        }
                        throw new F(`${l} returned \`null\`, will not send event.`, "log")
                    }
                    let S = r.getSession() || o.getSession();
                    if (c && S && this._updateSessionFromEvent(S, m), a) {
                        let O = ((I = m.sdkProcessingMetadata) == null ? void 0 : I.spanCountBeforeProcessing) || 0,
                            re = m.spans ? m.spans.length : 0,
                            oe = O - re;
                        oe > 0 && this.recordDroppedEvent("before_send", "span", oe)
                    }
                    let T = m.transaction_info;
                    if (a && T && m.transaction !== t.transaction) {
                        let O = "custom";
                        m.transaction_info = E(p({}, T), {
                            source: O
                        })
                    }
                    return this.sendEvent(m, n), m
                }).then(null, m => {
                    throw m instanceof F ? m : (this.captureException(m, {
                        data: {
                            __sentry__: !0
                        },
                        originalException: m
                    }), new F(`Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.
Reason: ${m}`))
                })
            }
            _process(t) {
                this._numProcessing++, t.then(n => (this._numProcessing--, n), n => (this._numProcessing--, n))
            }
            _clearOutcomes() {
                let t = this._outcomes;
                return this._outcomes = {}, Object.entries(t).map(([n, r]) => {
                    let [o, i] = n.split(":");
                    return {
                        reason: o,
                        category: i,
                        quantity: r
                    }
                })
            }
            _flushOutcomes() {
                y && _.log("Flushing outcomes...");
                let t = this._clearOutcomes();
                if (t.length === 0) {
                    y && _.log("No outcomes to send");
                    return
                }
                if (!this._dsn) {
                    y && _.log("No dsn provided, will not send outcomes");
                    return
                }
                y && _.log("Sending outcomes:", t);
                let n = ui(t, this._options.tunnel && Ve(this._dsn));
                this.sendEnvelope(n)
            }
        }
    });

    function gr(e, t) {
        t.debug === !0 && (y ? _.enable() : V(() => {
            console.warn("[Sentry] Cannot initialize SDK with `debug` option using a non-debug bundle.")
        })), W().update(t.initialScope);
        let r = new e(t);
        return _r(r), r.init(), r
    }

    function _r(e) {
        W().setClient(e)
    }
    var Ei = d(() => {
        de();
        ye();
        M()
    });

    function yi(e) {
        let t = [];

        function n() {
            return e === void 0 || t.length < e
        }

        function r(s) {
            return t.splice(t.indexOf(s), 1)[0] || Promise.resolve(void 0)
        }

        function o(s) {
            if (!n()) return Te(new F("Not adding Promise because buffer limit was reached."));
            let a = s();
            return t.indexOf(a) === -1 && t.push(a), a.then(() => r(a)).then(null, () => r(a).then(null, () => {})), a
        }

        function i(s) {
            return new ne((a, c) => {
                let u = t.length;
                if (!u) return a(!0);
                let l = setTimeout(() => {
                    s && s > 0 && a(!1)
                }, s);
                t.forEach(f => {
                    X(f).then(() => {
                        --u || (clearTimeout(l), a(!0))
                    }, c)
                })
            })
        }
        return {
            $: t,
            add: o,
            drain: i
        }
    }
    var Si = d(() => {
        Xt();
        Ye()
    });

    function ic(e, t = Date.now()) {
        let n = parseInt(`${e}`, 10);
        if (!isNaN(n)) return n * 1e3;
        let r = Date.parse(`${e}`);
        return isNaN(r) ? 6e4 : r - t
    }

    function sc(e, t) {
        return e[t] || e.all || 0
    }

    function Ti(e, t, n = Date.now()) {
        return sc(e, t) > n
    }

    function Ii(e, {
        statusCode: t,
        headers: n
    }, r = Date.now()) {
        let o = p({}, e),
            i = n == null ? void 0 : n["x-sentry-rate-limits"],
            s = n == null ? void 0 : n["retry-after"];
        if (i)
            for (let a of i.trim().split(",")) {
                let [c, u, , , l] = a.split(":", 5), f = parseInt(c, 10), g = (isNaN(f) ? 60 : f) * 1e3;
                if (!u) o.all = r + g;
                else
                    for (let m of u.split(";")) m === "metric_bucket" ? (!l || l.split(";").includes("custom")) && (o[m] = r + g) : o[m] = r + g
            } else s ? o.all = r + ic(s, r) : t === 429 && (o.all = r + 60 * 1e3);
        return o
    }
    var xi = d(() => {});

    function Qt(e, t, n = yi(e.bufferSize || ac)) {
        let r = {},
            o = s => n.drain(s);

        function i(s) {
            let a = [];
            if (or(s, (f, g) => {
                    let m = ir(g);
                    Ti(r, m) ? e.recordDroppedEvent("ratelimit_backoff", m) : a.push(f)
                }), a.length === 0) return X({});
            let c = Pe(s[0], a),
                u = f => {
                    or(c, (g, m) => {
                        e.recordDroppedEvent(f, ir(m))
                    })
                },
                l = () => t({
                    body: Go(c)
                }).then(f => (f.statusCode !== void 0 && (f.statusCode < 200 || f.statusCode >= 300) && y && _.warn(`Sentry responded with status code ${f.statusCode} to sent event.`), r = Ii(r, f), f), f => {
                    throw u("network_error"), f
                });
            return n.add(l).then(f => f, f => {
                if (f instanceof F) return y && _.error("Skipped sending event because buffer is full."), u("queue_overflow"), X({});
                throw f
            })
        }
        return {
            send: i,
            flush: o
        }
    }
    var ac, bi = d(() => {
        ye();
        it();
        Xt();
        M();
        Si();
        xi();
        Ye();
        ac = 64
    });

    function hr(e) {
        var t;
        ((t = e.user) == null ? void 0 : t.ip_address) === void 0 && (e.user = E(p({}, e.user), {
            ip_address: "{{auto}}"
        }))
    }

    function Er(e) {
        var t;
        "aggregates" in e ? ((t = e.attrs) == null ? void 0 : t.ip_address) === void 0 && (e.attrs = E(p({}, e.attrs), {
            ip_address: "{{auto}}"
        })) : e.ipAddress === void 0 && (e.ipAddress = "{{auto}}")
    }
    var vi = d(() => {});

    function yr(e, t, n = [t], r = "npm") {
        let o = e._metadata || {};
        o.sdk || (o.sdk = {
            name: `sentry.javascript.${t}`,
            packages: n.map(i => ({
                name: `${r}:@sentry/${i}`,
                version: ie
            })),
            version: ie
        }), e._metadata = o
    }
    var Ci = d(() => {
        Cn()
    });

    function le(e, t) {
        let n = v(),
            r = Z();
        if (!n) return;
        let {
            beforeBreadcrumb: o = null,
            maxBreadcrumbs: i = cc
        } = n.getOptions();
        if (i <= 0) return;
        let s = ue(),
            a = p({
                timestamp: s
            }, e),
            c = o ? V(() => o(a, t)) : a;
        c !== null && (n.emit && n.emit("beforeAddBreadcrumb", c, t), r.addBreadcrumb(c, i))
    }
    var cc, Ri = d(() => {
        de();
        M();
        me();
        cc = 100
    });
    var Ni, uc, ki, pc, en, Ai = d(() => {
        de();
        j();
        uc = "FunctionToString", ki = new WeakMap, pc = () => ({
            name: uc,
            setupOnce() {
                Ni = Function.prototype.toString;
                try {
                    Function.prototype.toString = function(...e) {
                        let t = Oe(this),
                            n = ki.has(v()) && t !== void 0 ? t : this;
                        return Ni.apply(n, e)
                    }
                } catch (e) {}
            },
            setup(e) {
                ki.set(e, !0)
            }
        }), en = pc
    });

    function mc(e = {}, t = {}) {
        return {
            allowUrls: [...e.allowUrls || [], ...t.allowUrls || []],
            denyUrls: [...e.denyUrls || [], ...t.denyUrls || []],
            ignoreErrors: [...e.ignoreErrors || [], ...t.ignoreErrors || [], ...e.disableErrorDefaults ? [] : dc],
            ignoreTransactions: [...e.ignoreTransactions || [], ...t.ignoreTransactions || []],
            ignoreInternal: e.ignoreInternal !== void 0 ? e.ignoreInternal : !0
        }
    }

    function gc(e, t) {
        return t.ignoreInternal && Sc(e) ? (y && _.warn(`Event dropped due to being internal Sentry Error.
Event: ${te(e)}`), !0) : _c(e, t.ignoreErrors) ? (y && _.warn(`Event dropped due to being matched by \`ignoreErrors\` option.
Event: ${te(e)}`), !0) : Ic(e) ? (y && _.warn(`Event dropped due to not having an error message, error type or stacktrace.
Event: ${te(e)}`), !0) : hc(e, t.ignoreTransactions) ? (y && _.warn(`Event dropped due to being matched by \`ignoreTransactions\` option.
Event: ${te(e)}`), !0) : Ec(e, t.denyUrls) ? (y && _.warn(`Event dropped due to being matched by \`denyUrls\` option.
Event: ${te(e)}.
Url: ${tn(e)}`), !0) : yc(e, t.allowUrls) ? !1 : (y && _.warn(`Event dropped due to not being matched by \`allowUrls\` option.
Event: ${te(e)}.
Url: ${tn(e)}`), !0)
    }

    function _c(e, t) {
        return e.type || !t || !t.length ? !1 : Zt(e).some(n => Ge(n, t))
    }

    function hc(e, t) {
        if (e.type !== "transaction" || !t || !t.length) return !1;
        let n = e.transaction;
        return n ? Ge(n, t) : !1
    }

    function Ec(e, t) {
        if (!(t != null && t.length)) return !1;
        let n = tn(e);
        return n ? Ge(n, t) : !1
    }

    function yc(e, t) {
        if (!(t != null && t.length)) return !0;
        let n = tn(e);
        return n ? Ge(n, t) : !0
    }

    function Sc(e) {
        try {
            return e.exception.values[0].type === "SentryError"
        } catch (t) {}
        return !1
    }

    function Tc(e = []) {
        for (let t = e.length - 1; t >= 0; t--) {
            let n = e[t];
            if (n && n.filename !== "<anonymous>" && n.filename !== "[native code]") return n.filename || null
        }
        return null
    }

    function tn(e) {
        try {
            let t;
            try {
                t = e.exception.values[0].stacktrace.frames
            } catch (n) {}
            return t ? Tc(t) : null
        } catch (t) {
            return y && _.error(`Cannot extract url for event ${te(e)}`), null
        }
    }

    function Ic(e) {
        var t, n;
        return e.type || !((n = (t = e.exception) == null ? void 0 : t.values) != null && n.length) ? !1 : !e.message && !e.exception.values.some(r => r.stacktrace || r.type && r.type !== "Error" || r.value)
    }
    var dc, lc, fc, nn, wi = d(() => {
        ye();
        M();
        Se();
        je();
        fr();
        dc = [/^Script error\.?$/, /^Javascript error: Script error\.? on line 0$/, /^ResizeObserver loop completed with undelivered notifications.$/, /^Cannot redefine property: googletag$/, "undefined is not an object (evaluating 'a.L')", `can't redefine non-configurable property "solana"`, "vv().getRestrictions is not a function. (In 'vv().getRestrictions(1,a)', 'vv().getRestrictions' is undefined)", "Can't find variable: _AutofillCallbackHandler", /^Non-Error promise rejection captured with value: Object Not Found Matching Id:\d+, MethodName:simulateEvent, ParamCount:\d+$/], lc = "InboundFilters", fc = (e = {}) => ({
            name: lc,
            processEvent(t, n, r) {
                let o = r.getOptions(),
                    i = mc(e, o);
                return gc(t, i) ? null : t
            }
        }), nn = fc
    });

    function Tr(e, t, n = 250, r, o, i, s) {
        var c;
        if (!((c = i.exception) != null && c.values) || !s || !ae(s.originalException, Error)) return;
        let a = i.exception.values.length > 0 ? i.exception.values[i.exception.values.length - 1] : void 0;
        a && (i.exception.values = xc(Sr(e, t, o, s.originalException, r, i.exception.values, a, 0), n))
    }

    function Sr(e, t, n, r, o, i, s, a) {
        if (i.length >= n + 1) return i;
        let c = [...i];
        if (ae(r[o], Error)) {
            Di(s, a);
            let u = e(t, r[o]),
                l = c.length;
            Oi(u, o, l, a), c = Sr(e, t, n, r[o], o, [u, ...c], u, l)
        }
        return Array.isArray(r.errors) && r.errors.forEach((u, l) => {
            if (ae(u, Error)) {
                Di(s, a);
                let f = e(t, u),
                    g = c.length;
                Oi(f, `errors[${l}]`, g, a), c = Sr(e, t, n, u, o, [f, ...c], f, g)
            }
        }), c
    }

    function Di(e, t) {
        e.mechanism = e.mechanism || {
            type: "generic",
            handled: !0
        }, e.mechanism = E(p(p({}, e.mechanism), e.type === "AggregateError" && {
            is_exception_group: !0
        }), {
            exception_id: t
        })
    }

    function Oi(e, t, n, r) {
        e.mechanism = e.mechanism || {
            type: "generic",
            handled: !0
        }, e.mechanism = E(p({}, e.mechanism), {
            type: "chained",
            source: t,
            exception_id: n,
            parent_id: r
        })
    }

    function xc(e, t) {
        return e.map(n => (n.value && (n.value = ce(n.value, t)), n))
    }
    var Pi = d(() => {
        Y();
        je()
    });

    function Ir(e) {
        let t = "console";
        B(t, e), H(t, bc)
    }

    function bc() {
        "console" in h && Qe.forEach(function(e) {
            e in h.console && A(h.console, e, function(t) {
                return Ue[e] = t,
                    function(...n) {
                        k("console", {
                            args: n,
                            level: e
                        });
                        let o = Ue[e];
                        o == null || o.apply(h.console, n)
                    }
            })
        })
    }
    var Li = d(() => {
        M();
        j();
        U();
        Be()
    });

    function xr(e) {
        return e === "warn" ? "warning" : ["fatal", "error", "warning", "log", "info", "debug"].includes(e) ? e : "log"
    }
    var Mi = d(() => {});

    function Rc(e, t) {
        return t ? !!(Nc(e, t) || kc(e, t)) : !1
    }

    function Nc(e, t) {
        let n = e.message,
            r = t.message;
        return !(!n && !r || n && !r || !n && r || n !== r || !Bi(e, t) || !Ui(e, t))
    }

    function kc(e, t) {
        let n = Fi(t),
            r = Fi(e);
        return !(!n || !r || n.type !== r.type || n.value !== r.value || !Bi(e, t) || !Ui(e, t))
    }

    function Ui(e, t) {
        let n = Tt(e),
            r = Tt(t);
        if (!n && !r) return !0;
        if (n && !r || !n && r || (n = n, r = r, r.length !== n.length)) return !1;
        for (let o = 0; o < r.length; o++) {
            let i = r[o],
                s = n[o];
            if (i.filename !== s.filename || i.lineno !== s.lineno || i.colno !== s.colno || i.function !== s.function) return !1
        }
        return !0
    }

    function Bi(e, t) {
        let n = e.fingerprint,
            r = t.fingerprint;
        if (!n && !r) return !0;
        if (n && !r || !n && r) return !1;
        n = n, r = r;
        try {
            return n.join("") === r.join("")
        } catch (o) {
            return !1
        }
    }

    function Fi(e) {
        var t;
        return ((t = e.exception) == null ? void 0 : t.values) && e.exception.values[0]
    }
    var vc, Cc, rn, Hi = d(() => {
        ye();
        M();
        et();
        vc = "Dedupe", Cc = () => {
            let e;
            return {
                name: vc,
                processEvent(t) {
                    if (t.type) return t;
                    try {
                        if (Rc(t, e)) return y && _.warn("Event dropped due to being a duplicate of previously captured event."), null
                    } catch (n) {}
                    return e = t
                }
            }
        }, rn = Cc
    });

    function dt(e) {
        if (!e) return {};
        let t = e.match(/^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);
        if (!t) return {};
        let n = t[6] || "",
            r = t[8] || "";
        return {
            host: t[4],
            path: t[5],
            protocol: t[2],
            search: n,
            hash: r,
            relative: t[5] + n + r
        }
    }
    var $i = d(() => {});

    function on(e) {
        if (e !== void 0) return e >= 400 && e < 500 ? "warning" : e >= 500 ? "error" : void 0
    }
    var Gi = d(() => {});

    function br() {
        return "history" in sn
    }

    function an() {
        if (!("fetch" in sn)) return !1;
        try {
            return new Headers, new Request("http://www.example.com"), new Response, !0
        } catch (e) {
            return !1
        }
    }

    function lt(e) {
        return e && /^function\s+\w+\(\)\s+\{\s+\[native code\]\s+\}$/.test(e.toString())
    }

    function vr() {
        var n;
        if (typeof EdgeRuntime == "string") return !0;
        if (!an()) return !1;
        if (lt(sn.fetch)) return !0;
        let e = !1,
            t = sn.document;
        if (t && typeof t.createElement == "function") try {
            let r = t.createElement("iframe");
            r.hidden = !0, t.head.appendChild(r), (n = r.contentWindow) != null && n.fetch && (e = lt(r.contentWindow.fetch)), t.head.removeChild(r)
        } catch (r) {
            J && _.warn("Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ", r)
        }
        return e
    }
    var sn, Cr = d(() => {
        Fe();
        M();
        U();
        sn = h
    });

    function Nr(e, t) {
        let n = "fetch";
        B(n, e), H(n, () => Ac(void 0, t))
    }

    function Ac(e, t = !1) {
        t && !vr() || A(h, "fetch", function(n) {
            return function(...r) {
                let o = new Error,
                    {
                        method: i,
                        url: s
                    } = wc(r),
                    a = {
                        args: r,
                        fetchData: {
                            method: i,
                            url: s
                        },
                        startTimestamp: z() * 1e3,
                        virtualError: o
                    };
                return e || k("fetch", p({}, a)), n.apply(h, r).then(c => C(this, null, function*() {
                    return e ? e(c) : k("fetch", E(p({}, a), {
                        endTimestamp: z() * 1e3,
                        response: c
                    })), c
                }), c => {
                    throw k("fetch", E(p({}, a), {
                        endTimestamp: z() * 1e3,
                        error: c
                    })), ke(c) && c.stack === void 0 && (c.stack = o.stack, G(c, "framesToPop", 1)), c
                })
            }
        })
    }

    function Rr(e, t) {
        return !!e && typeof e == "object" && !!e[t]
    }

    function ji(e) {
        return typeof e == "string" ? e : e ? Rr(e, "url") ? e.url : e.toString ? e.toString() : "" : ""
    }

    function wc(e) {
        if (e.length === 0) return {
            method: "GET",
            url: ""
        };
        if (e.length === 2) {
            let [n, r] = e;
            return {
                url: ji(n),
                method: Rr(r, "method") ? String(r.method).toUpperCase() : "GET"
            }
        }
        let t = e[0];
        return {
            url: ji(t),
            method: Rr(t, "method") ? String(t.method).toUpperCase() : "GET"
        }
    }
    var Wi = d(() => {
        Y();
        j();
        Cr();
        me();
        U();
        Be()
    });

    function kr() {
        return "npm"
    }
    var Yi = d(() => {});
    var D = d(() => {
        oi();
        de();
        hi();
        Ei();
        bi();
        lr();
        vi();
        Ci();
        Ri();
        Ai();
        wi();
        Hi();
        Pi();
        Gi();
        Bn();
        U();
        Li();
        Wi();
        io();
        so();
        Be();
        Y();
        M();
        Se();
        jt();
        j();
        Mi();
        et();
        je();
        Cr();
        Ye();
        me();
        Yi();
        $i()
    });

    function wr() {
        return Ar > 0
    }

    function $c() {
        Ar++, setTimeout(() => {
            Ar--
        })
    }

    function Le(e, t = {}) {
        function n(o) {
            return typeof o == "function"
        }
        if (!n(e)) return e;
        try {
            let o = e.__sentry_wrapped__;
            if (o) return typeof o == "function" ? o : e;
            if (Oe(e)) return e
        } catch (o) {
            return e
        }
        let r = function(...o) {
            try {
                let i = o.map(s => Le(s, t));
                return e.apply(this, i)
            } catch (i) {
                throw $c(), Lt(s => {
                    s.addEventProcessor(a => (t.mechanism && (We(a, void 0, void 0), pe(a, t.mechanism)), a.extra = E(p({}, a.extra), {
                        arguments: o
                    }), a)), he(i)
                }), i
            }
        };
        try {
            for (let o in e) Object.prototype.hasOwnProperty.call(e, o) && (r[o] = e[o])
        } catch (o) {}
        Ct(r, e), G(e, "__sentry_wrapped__", r);
        try {
            Object.getOwnPropertyDescriptor(r, "name").configurable && Object.defineProperty(r, "name", {
                get() {
                    return e.name
                }
            })
        } catch (o) {}
        return r
    }
    var b, Ar, xe = d(() => {
        D();
        b = h, Ar = 0
    });

    function cn(e, t) {
        let n = Pr(e, t),
            r = {
                type: zc(t),
                value: Kc(t)
            };
        return n.length && (r.stacktrace = {
            frames: n
        }), r.type === void 0 && r.value === "" && (r.value = "Unrecoverable error caught"), r
    }

    function Gc(e, t, n, r) {
        let o = v(),
            i = o == null ? void 0 : o.getOptions().normalizeDepth,
            s = qc(t),
            a = {
                __serialized__: Gt(t, i)
            };
        if (s) return {
            exception: {
                values: [cn(e, s)]
            },
            extra: a
        };
        let c = {
            exception: {
                values: [{
                    type: we(t) ? t.constructor.name : r ? "UnhandledRejection" : "Error",
                    value: Jc(t, {
                        isUnhandledRejection: r
                    })
                }]
            },
            extra: a
        };
        if (n) {
            let u = Pr(e, n);
            u.length && (c.exception.values[0].stacktrace = {
                frames: u
            })
        }
        return c
    }

    function Dr(e, t) {
        return {
            exception: {
                values: [cn(e, t)]
            }
        }
    }

    function Pr(e, t) {
        let n = t.stacktrace || t.stack || "",
            r = Wc(t),
            o = Yc(t);
        try {
            return e(n, r, o)
        } catch (i) {}
        return []
    }

    function Wc(e) {
        return e && jc.test(e.message) ? 1 : 0
    }

    function Yc(e) {
        return typeof e.framesToPop == "number" ? e.framesToPop : 0
    }

    function Ki(e) {
        return typeof WebAssembly != "undefined" && typeof WebAssembly.Exception != "undefined" ? e instanceof WebAssembly.Exception : !1
    }

    function zc(e) {
        let t = e == null ? void 0 : e.name;
        return !t && Ki(e) ? e.message && Array.isArray(e.message) && e.message.length == 2 ? e.message[0] : "WebAssembly.Exception" : t
    }

    function Kc(e) {
        let t = e == null ? void 0 : e.message;
        return Ki(e) ? Array.isArray(e.message) && e.message.length == 2 ? e.message[1] : "wasm exception" : t ? t.error && typeof t.error.message == "string" ? t.error.message : t : "No error message"
    }

    function Ji(e, t, n, r) {
        let o = (n == null ? void 0 : n.syntheticException) || void 0,
            i = un(e, t, o, r);
        return pe(i), i.level = "error", n != null && n.event_id && (i.event_id = n.event_id), X(i)
    }

    function Vi(e, t, n = "info", r, o) {
        let i = (r == null ? void 0 : r.syntheticException) || void 0,
            s = Or(e, t, i, o);
        return s.level = n, r != null && r.event_id && (s.event_id = r.event_id), X(s)
    }

    function un(e, t, n, r, o) {
        let i;
        if (xt(t) && t.error) return Dr(e, t.error);
        if (bt(t) || On(t)) {
            let s = t;
            if ("stack" in t) i = Dr(e, t);
            else {
                let a = s.name || (bt(s) ? "DOMError" : "DOMException"),
                    c = s.message ? `${a}: ${s.message}` : a;
                i = Or(e, c, n, r), We(i, c)
            }
            return "code" in s && (i.tags = E(p({}, i.tags), {
                "DOMException.code": `${s.code}`
            })), i
        }
        return ke(t) ? Dr(e, t) : ee(t) || we(t) ? (i = Gc(e, t, n, o), pe(i, {
            synthetic: !0
        }), i) : (i = Or(e, t, n, r), We(i, `${t}`, void 0), pe(i, {
            synthetic: !0
        }), i)
    }

    function Or(e, t, n, r) {
        let o = {};
        if (r && n) {
            let i = Pr(e, n);
            i.length && (o.exception = {
                values: [{
                    value: t,
                    stacktrace: {
                        frames: i
                    }
                }]
            }), pe(o, {
                synthetic: !0
            })
        }
        if ($e(t)) {
            let {
                __sentry_template_string__: i,
                __sentry_template_values__: s
            } = t;
            return o.logentry = {
                message: i,
                params: s
            }, o
        }
        return o.message = t, o
    }

    function Jc(e, {
        isUnhandledRejection: t
    }) {
        let n = $n(e),
            r = t ? "promise rejection" : "exception";
        return xt(e) ? `Event \`ErrorEvent\` captured as ${r} with message \`${e.message}\`` : we(e) ? `Event \`${Vc(e)}\` (type=${e.type}) captured as ${r}` : `Object captured as ${r} with keys: ${n}`
    }

    function Vc(e) {
        try {
            let t = Object.getPrototypeOf(e);
            return t ? t.constructor.name : void 0
        } catch (t) {}
    }

    function qc(e) {
        for (let t in e)
            if (Object.prototype.hasOwnProperty.call(e, t)) {
                let n = e[t];
                if (n instanceof Error) return n
            }
    }
    var jc, pn = d(() => {
        D();
        jc = /Minified React error #\d+;/i
    });
    var dn, qi = d(() => {
        D();
        pn();
        xe();
        dn = class extends pt {
            constructor(t) {
                let n = p({
                        parentSpanIsAlwaysRootSpan: !0
                    }, t),
                    r = b.SENTRY_SDK_SOURCE || kr();
                yr(n, "browser", ["browser"], r), super(n), n.sendClientReports && b.document && b.document.addEventListener("visibilitychange", () => {
                    b.document.visibilityState === "hidden" && this._flushOutcomes()
                }), this._options.sendDefaultPii && (this.on("postprocessEvent", hr), this.on("beforeSendSession", Er))
            }
            eventFromException(t, n) {
                return Ji(this._options.stackParser, t, n, this._options.attachStacktrace)
            }
            eventFromMessage(t, n = "info", r) {
                return Vi(this._options.stackParser, t, n, r, this._options.attachStacktrace)
            }
            _prepareEvent(t, n, r, o) {
                return t.platform = t.platform || "javascript", super._prepareEvent(t, n, r, o)
            }
        }
    });
    var Xi, Zi = d(() => {
        Xi = typeof __SENTRY_DEBUG__ == "undefined" || __SENTRY_DEBUG__
    });
    var P, ft = d(() => {
        D();
        P = h
    });

    function Fr(e) {
        let t = "dom";
        B(t, e), H(t, Zc)
    }

    function Zc() {
        if (!P.document) return;
        let e = k.bind(null, "dom"),
            t = es(e, !0);
        P.document.addEventListener("click", t, !1), P.document.addEventListener("keypress", t, !1), ["EventTarget", "Node"].forEach(n => {
            var i, s;
            let o = (i = P[n]) == null ? void 0 : i.prototype;
            (s = o == null ? void 0 : o.hasOwnProperty) != null && s.call(o, "addEventListener") && (A(o, "addEventListener", function(a) {
                return function(c, u, l) {
                    if (c === "click" || c == "keypress") try {
                        let f = this.__sentry_instrumentation_handlers__ = this.__sentry_instrumentation_handlers__ || {},
                            g = f[c] = f[c] || {
                                refCount: 0
                            };
                        if (!g.handler) {
                            let m = es(e);
                            g.handler = m, a.call(this, c, m, l)
                        }
                        g.refCount++
                    } catch (f) {}
                    return a.call(this, c, u, l)
                }
            }), A(o, "removeEventListener", function(a) {
                return function(c, u, l) {
                    if (c === "click" || c == "keypress") try {
                        let f = this.__sentry_instrumentation_handlers__ || {},
                            g = f[c];
                        g && (g.refCount--, g.refCount <= 0 && (a.call(this, c, g.handler, l), g.handler = void 0, delete f[c]), Object.keys(f).length === 0 && delete this.__sentry_instrumentation_handlers__)
                    } catch (f) {}
                    return a.call(this, c, u, l)
                }
            }))
        })
    }

    function Qc(e) {
        if (e.type !== Lr) return !1;
        try {
            if (!e.target || e.target._sentryId !== Mr) return !1
        } catch (t) {}
        return !0
    }

    function eu(e, t) {
        return e !== "keypress" ? !1 : t != null && t.tagName ? !(t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable) : !0
    }

    function es(e, t = !1) {
        return n => {
            if (!n || n._sentryCaptured) return;
            let r = tu(n);
            if (eu(n.type, r)) return;
            G(n, "_sentryCaptured", !0), r && !r._sentryId && G(r, "_sentryId", w());
            let o = n.type === "keypress" ? "input" : n.type;
            Qc(n) || (e({
                event: n,
                name: o,
                global: t
            }), Lr = n.type, Mr = r ? r._sentryId : void 0), clearTimeout(Qi), Qi = P.setTimeout(() => {
                Mr = void 0, Lr = void 0
            }, Xc)
        }
    }

    function tu(e) {
        try {
            return e.target
        } catch (t) {
            return null
        }
    }
    var Xc, Qi, Lr, Mr, ts = d(() => {
        D();
        ft();
        Xc = 1e3
    });

    function mt(e) {
        let t = "history";
        B(t, e), H(t, nu)
    }

    function nu() {
        if (P.addEventListener("popstate", () => {
                let t = P.location.href,
                    n = ln;
                if (ln = t, n === t) return;
                k("history", {
                    from: n,
                    to: t
                })
            }), !br()) return;

        function e(t) {
            return function(...n) {
                let r = n.length > 2 ? n[2] : void 0;
                if (r) {
                    let o = ln,
                        i = String(r);
                    if (ln = i, o === i) return;
                    k("history", {
                        from: o,
                        to: i
                    })
                }
                return t.apply(this, n)
            }
        }
        A(P.history, "pushState", e), A(P.history, "replaceState", e)
    }
    var ln, ns = d(() => {
        D();
        ft()
    });

    function Ur(e) {
        let t = fn[e];
        if (t) return t;
        let n = P[e];
        if (lt(n)) return fn[e] = n.bind(P);
        let r = P.document;
        if (r && typeof r.createElement == "function") try {
            let o = r.createElement("iframe");
            o.hidden = !0, r.head.appendChild(o);
            let i = o.contentWindow;
            i != null && i[e] && (n = i[e]), r.head.removeChild(o)
        } catch (o) {
            Xi && _.warn(`Could not create sandbox iframe for ${e} check, bailing to window.${e}: `, o)
        }
        return n && (fn[e] = n.bind(P))
    }

    function mn(e) {
        fn[e] = void 0
    }
    var fn, rs = d(() => {
        D();
        Zi();
        ft();
        fn = {}
    });

    function Br(e) {
        let t = "xhr";
        B(t, e), H(t, ru)
    }

    function ru() {
        if (!P.XMLHttpRequest) return;
        let e = XMLHttpRequest.prototype;
        e.open = new Proxy(e.open, {
            apply(t, n, r) {
                let o = new Error,
                    i = z() * 1e3,
                    s = $(r[0]) ? r[0].toUpperCase() : void 0,
                    a = ou(r[1]);
                if (!s || !a) return t.apply(n, r);
                n[Me] = {
                    method: s,
                    url: a,
                    request_headers: {}
                }, s === "POST" && a.match(/sentry_key/) && (n.__sentry_own_request__ = !0);
                let c = () => {
                    let u = n[Me];
                    if (u && n.readyState === 4) {
                        try {
                            u.status_code = n.status
                        } catch (f) {}
                        let l = {
                            endTimestamp: z() * 1e3,
                            startTimestamp: i,
                            xhr: n,
                            virtualError: o
                        };
                        k("xhr", l)
                    }
                };
                return "onreadystatechange" in n && typeof n.onreadystatechange == "function" ? n.onreadystatechange = new Proxy(n.onreadystatechange, {
                    apply(u, l, f) {
                        return c(), u.apply(l, f)
                    }
                }) : n.addEventListener("readystatechange", c), n.setRequestHeader = new Proxy(n.setRequestHeader, {
                    apply(u, l, f) {
                        let [g, m] = f, S = l[Me];
                        return S && $(g) && $(m) && (S.request_headers[g.toLowerCase()] = m), u.apply(l, f)
                    }
                }), t.apply(n, r)
            }
        }), e.send = new Proxy(e.send, {
            apply(t, n, r) {
                let o = n[Me];
                if (!o) return t.apply(n, r);
                r[0] !== void 0 && (o.body = r[0]);
                let i = {
                    startTimestamp: z() * 1e3,
                    xhr: n
                };
                return k("xhr", i), t.apply(n, r)
            }
        })
    }

    function ou(e) {
        if ($(e)) return e;
        try {
            return e.toString()
        } catch (t) {}
    }
    var Me, os = d(() => {
        D();
        ft();
        Me = "__sentry_xhr_v3__"
    });
    var gn = d(() => {
        ts();
        ns();
        rs();
        os()
    });

    function is(e, t = Ur("fetch")) {
        let n = 0,
            r = 0;

        function o(i) {
            let s = i.body.length;
            n += s, r++;
            let a = p({
                body: i.body,
                method: "POST",
                referrerPolicy: "strict-origin",
                headers: e.headers,
                keepalive: n <= 6e4 && r < 15
            }, e.fetchOptions);
            if (!t) return mn("fetch"), Te("No fetch implementation available");
            try {
                return t(e.url, a).then(c => (n -= s, r--, {
                    statusCode: c.status,
                    headers: {
                        "x-sentry-rate-limits": c.headers.get("X-Sentry-Rate-Limits"),
                        "retry-after": c.headers.get("Retry-After")
                    }
                }))
            } catch (c) {
                return mn("fetch"), n -= s, r--, Te(c)
            }
        }
        return Qt(e, o)
    }
    var ss = d(() => {
        gn();
        D()
    });

    function Hr(e, t, n, r) {
        let o = {
            filename: e,
            function: t === "<anonymous>" ? se : t,
            in_app: !0
        };
        return n !== void 0 && (o.lineno = n), r !== void 0 && (o.colno = r), o
    }
    var iu, su, au, cu, uu, pu, du, lu, fu, mu, gu, _u, as, cs, us = d(() => {
        D();
        iu = 30, su = 50;
        au = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i, cu = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, uu = /\((\S*)(?::(\d+))(?::(\d+))\)/, pu = e => {
            let t = au.exec(e);
            if (t) {
                let [, r, o, i] = t;
                return Hr(r, se, +o, +i)
            }
            let n = cu.exec(e);
            if (n) {
                if (n[2] && n[2].indexOf("eval") === 0) {
                    let s = uu.exec(n[2]);
                    s && (n[2] = s[1], n[3] = s[2], n[4] = s[3])
                }
                let [o, i] = cs(n[1] || se, n[2]);
                return Hr(i, o, n[3] ? +n[3] : void 0, n[4] ? +n[4] : void 0)
            }
        }, du = [iu, pu], lu = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i, fu = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i, mu = e => {
            let t = lu.exec(e);
            if (t) {
                if (t[3] && t[3].indexOf(" > eval") > -1) {
                    let i = fu.exec(t[3]);
                    i && (t[1] = t[1] || "eval", t[3] = i[1], t[4] = i[2], t[5] = "")
                }
                let r = t[3],
                    o = t[1] || se;
                return [o, r] = cs(o, r), Hr(r, o, t[4] ? +t[4] : void 0, t[5] ? +t[5] : void 0)
            }
        }, gu = [su, mu], _u = [du, gu], as = St(..._u), cs = (e, t) => {
            let n = e.indexOf("safari-extension") !== -1,
                r = e.indexOf("safari-web-extension") !== -1;
            return n || r ? [e.indexOf("@") !== -1 ? e.split("@")[0] : se, n ? `safari-extension:${t}` : `safari-web-extension:${t}`] : [e, t]
        }
    });
    var Ee, gt = d(() => {
        Ee = typeof __SENTRY_DEBUG__ == "undefined" || __SENTRY_DEBUG__
    });

    function yu(e) {
        return function(n) {
            v() === e && le({
                category: `sentry.${n.type==="transaction"?"transaction":"event"}`,
                event_id: n.event_id,
                level: n.level,
                message: te(n)
            }, {
                event: n
            })
        }
    }

    function Su(e, t) {
        return function(r) {
            if (v() !== e) return;
            let o, i, s = typeof t == "object" ? t.serializeAttribute : void 0,
                a = typeof t == "object" && typeof t.maxStringLength == "number" ? t.maxStringLength : void 0;
            a && a > _n && (Ee && _.warn(`\`dom.maxStringLength\` cannot exceed ${_n}, but a value of ${a} was configured. Sentry will use ${_n} instead.`), a = _n), typeof s == "string" && (s = [s]);
            try {
                let u = r.event,
                    l = vu(u) ? u.target : u;
                o = nt(l, {
                    keyAttrs: s,
                    maxStringLength: a
                }), i = Un(l)
            } catch (u) {
                o = "<unknown>"
            }
            if (o.length === 0) return;
            let c = {
                category: `ui.${r.name}`,
                message: o
            };
            i && (c.data = {
                "ui.component_name": i
            }), le(c, {
                event: r.event,
                name: r.name,
                global: r.global
            })
        }
    }

    function Tu(e) {
        return function(n) {
            if (v() !== e) return;
            let r = {
                category: "console",
                data: {
                    arguments: n.args,
                    logger: "console"
                },
                level: xr(n.level),
                message: vt(n.args, " ")
            };
            if (n.level === "assert")
                if (n.args[0] === !1) r.message = `Assertion failed: ${vt(n.args.slice(1)," ")||"console.assert"}`, r.data.arguments = n.args.slice(1);
                else return;
            le(r, {
                input: n.args,
                level: n.level
            })
        }
    }

    function Iu(e) {
        return function(n) {
            if (v() !== e) return;
            let {
                startTimestamp: r,
                endTimestamp: o
            } = n, i = n.xhr[Me];
            if (!r || !o || !i) return;
            let {
                method: s,
                url: a,
                status_code: c,
                body: u
            } = i, l = {
                method: s,
                url: a,
                status_code: c
            }, f = {
                xhr: n.xhr,
                input: u,
                startTimestamp: r,
                endTimestamp: o
            }, g = on(c);
            le({
                category: "xhr",
                data: l,
                type: "http",
                level: g
            }, f)
        }
    }

    function xu(e) {
        return function(n) {
            if (v() !== e) return;
            let {
                startTimestamp: r,
                endTimestamp: o
            } = n;
            if (!o || n.fetchData.url.match(/sentry_key/) && n.fetchData.method === "POST") return;
            let i = {
                method: n.fetchData.method,
                url: n.fetchData.url
            };
            if (n.error) {
                let s = {
                    data: n.error,
                    input: n.args,
                    startTimestamp: r,
                    endTimestamp: o
                };
                le({
                    category: "fetch",
                    data: i,
                    level: "error",
                    type: "http"
                }, s)
            } else {
                let s = n.response;
                i.request_body_size = n.fetchData.request_body_size, i.response_body_size = n.fetchData.response_body_size, i.status_code = s == null ? void 0 : s.status;
                let a = {
                        input: n.args,
                        response: s,
                        startTimestamp: r,
                        endTimestamp: o
                    },
                    c = on(i.status_code);
                le({
                    category: "fetch",
                    data: i,
                    type: "http",
                    level: c
                }, a)
            }
        }
    }

    function bu(e) {
        return function(n) {
            if (v() !== e) return;
            let r = n.from,
                o = n.to,
                i = dt(b.location.href),
                s = r ? dt(r) : void 0,
                a = dt(o);
            s != null && s.path || (s = i), i.protocol === a.protocol && i.host === a.host && (o = a.relative), i.protocol === s.protocol && i.host === s.host && (r = s.relative), le({
                category: "navigation",
                data: {
                    from: r,
                    to: o
                }
            })
        }
    }

    function vu(e) {
        return !!e && !!e.target
    }
    var _n, hu, Eu, ps, ds = d(() => {
        gn();
        D();
        gt();
        xe();
        _n = 1024, hu = "Breadcrumbs", Eu = (e = {}) => {
            let t = p({
                console: !0,
                dom: !0,
                fetch: !0,
                history: !0,
                sentry: !0,
                xhr: !0
            }, e);
            return {
                name: hu,
                setup(n) {
                    t.console && Ir(Tu(n)), t.dom && Fr(Su(n, t.dom)), t.xhr && Br(Iu(n)), t.fetch && Nr(xu(n)), t.history && mt(bu(n)), t.sentry && n.on("beforeSendEvent", yu(n))
                }
            }
        }, ps = Eu
    });

    function ls(e) {
        return function(...t) {
            let n = t[0];
            return t[0] = Le(n, {
                mechanism: {
                    data: {
                        function: q(e)
                    },
                    handled: !1,
                    type: "instrument"
                }
            }), e.apply(this, t)
        }
    }

    function ku(e) {
        return function(t) {
            return e.apply(this, [Le(t, {
                mechanism: {
                    data: {
                        function: "requestAnimationFrame",
                        handler: q(e)
                    },
                    handled: !1,
                    type: "instrument"
                }
            })])
        }
    }

    function Au(e) {
        return function(...t) {
            let n = this;
            return ["onload", "onerror", "onprogress", "onreadystatechange"].forEach(o => {
                o in n && typeof n[o] == "function" && A(n, o, function(i) {
                    let s = {
                            mechanism: {
                                data: {
                                    function: o,
                                    handler: q(i)
                                },
                                handled: !1,
                                type: "instrument"
                            }
                        },
                        a = Oe(i);
                    return a && (s.mechanism.data.handler = q(a)), Le(i, s)
                })
            }), e.apply(this, t)
        }
    }

    function wu(e) {
        var r, o;
        let n = (r = b[e]) == null ? void 0 : r.prototype;
        (o = n == null ? void 0 : n.hasOwnProperty) != null && o.call(n, "addEventListener") && (A(n, "addEventListener", function(i) {
            return function(s, a, c) {
                try {
                    Du(a) && (a.handleEvent = Le(a.handleEvent, {
                        mechanism: {
                            data: {
                                function: "handleEvent",
                                handler: q(a),
                                target: e
                            },
                            handled: !1,
                            type: "instrument"
                        }
                    }))
                } catch (u) {}
                return i.apply(this, [s, Le(a, {
                    mechanism: {
                        data: {
                            function: "addEventListener",
                            handler: q(a),
                            target: e
                        },
                        handled: !1,
                        type: "instrument"
                    }
                }), c])
            }
        }), A(n, "removeEventListener", function(i) {
            return function(s, a, c) {
                try {
                    let u = a.__sentry_wrapped__;
                    u && i.call(this, s, u, c)
                } catch (u) {}
                return i.call(this, s, a, c)
            }
        }))
    }

    function Du(e) {
        return typeof e.handleEvent == "function"
    }
    var Cu, Ru, Nu, fs, ms = d(() => {
        D();
        xe();
        Cu = ["EventTarget", "Window", "Node", "ApplicationCache", "AudioTrackList", "BroadcastChannel", "ChannelMergerNode", "CryptoOperation", "EventSource", "FileReader", "HTMLUnknownElement", "IDBDatabase", "IDBRequest", "IDBTransaction", "KeyOperation", "MediaController", "MessagePort", "ModalWindow", "Notification", "SVGElementInstance", "Screen", "SharedWorker", "TextTrack", "TextTrackCue", "TextTrackList", "WebSocket", "WebSocketWorker", "Worker", "XMLHttpRequest", "XMLHttpRequestEventTarget", "XMLHttpRequestUpload"], Ru = "BrowserApiErrors", Nu = (e = {}) => {
            let t = p({
                XMLHttpRequest: !0,
                eventTarget: !0,
                requestAnimationFrame: !0,
                setInterval: !0,
                setTimeout: !0
            }, e);
            return {
                name: Ru,
                setupOnce() {
                    t.setTimeout && A(b, "setTimeout", ls), t.setInterval && A(b, "setInterval", ls), t.requestAnimationFrame && A(b, "requestAnimationFrame", ku), t.XMLHttpRequest && "XMLHttpRequest" in b && A(XMLHttpRequest.prototype, "send", Au);
                    let n = t.eventTarget;
                    n && (Array.isArray(n) ? n : Cu).forEach(wu)
                }
            }
        }, fs = Nu
    });
    var gs, _s = d(() => {
        gn();
        D();
        gt();
        xe();
        gs = () => ({
            name: "BrowserSession",
            setupOnce() {
                if (typeof b.document == "undefined") {
                    Ee && _.warn("Using the `browserSessionIntegration` in non-browser environments is not supported.");
                    return
                }
                ct({
                    ignoreDuration: !0
                }), ut(), mt(({
                    from: e,
                    to: t
                }) => {
                    e !== void 0 && e !== t && (ct({
                        ignoreDuration: !0
                    }), ut())
                })
            }
        })
    });

    function Lu(e) {
        An(t => {
            let {
                stackParser: n,
                attachStacktrace: r
            } = ys();
            if (v() !== e || wr()) return;
            let {
                msg: o,
                url: i,
                line: s,
                column: a,
                error: c
            } = t, u = Bu(un(n, c || o, void 0, r, !1), i, s, a);
            u.level = "error", st(u, {
                originalException: c,
                mechanism: {
                    handled: !1,
                    type: "onerror"
                }
            })
        })
    }

    function Mu(e) {
        Dn(t => {
            let {
                stackParser: n,
                attachStacktrace: r
            } = ys();
            if (v() !== e || wr()) return;
            let o = Fu(t),
                i = Ae(o) ? Uu(o) : un(n, o, void 0, r, !0);
            i.level = "error", st(i, {
                originalException: o,
                mechanism: {
                    handled: !1,
                    type: "onunhandledrejection"
                }
            })
        })
    }

    function Fu(e) {
        if (Ae(e)) return e;
        try {
            if ("reason" in e) return e.reason;
            if ("detail" in e && "reason" in e.detail) return e.detail.reason
        } catch (t) {}
        return e
    }

    function Uu(e) {
        return {
            exception: {
                values: [{
                    type: "UnhandledRejection",
                    value: `Non-Error promise rejection captured with value: ${String(e)}`
                }]
            }
        }
    }

    function Bu(e, t, n, r) {
        let o = e.exception = e.exception || {},
            i = o.values = o.values || [],
            s = i[0] = i[0] || {},
            a = s.stacktrace = s.stacktrace || {},
            c = a.frames = a.frames || [],
            u = r,
            l = n,
            f = $(t) && t.length > 0 ? t : De();
        return c.length === 0 && c.push({
            colno: u,
            filename: f,
            function: se,
            in_app: !0,
            lineno: l
        }), e
    }

    function hs(e) {
        Ee && _.log(`Global Handler attached: ${e}`)
    }

    function ys() {
        let e = v();
        return (e == null ? void 0 : e.getOptions()) || {
            stackParser: () => [],
            attachStacktrace: !1
        }
    }
    var Ou, Pu, Es, Ss = d(() => {
        D();
        gt();
        pn();
        xe();
        Ou = "GlobalHandlers", Pu = (e = {}) => {
            let t = p({
                onerror: !0,
                onunhandledrejection: !0
            }, e);
            return {
                name: Ou,
                setupOnce() {
                    Error.stackTraceLimit = 50
                },
                setup(n) {
                    t.onerror && (Lu(n), hs("onerror")), t.onunhandledrejection && (Mu(n), hs("onunhandledrejection"))
                }
            }
        }, Es = Pu
    });
    var Ts, Is = d(() => {
        D();
        xe();
        Ts = () => ({
            name: "HttpContext",
            preprocessEvent(e) {
                var s, a;
                if (!b.navigator && !b.location && !b.document) return;
                let t = ((s = e.request) == null ? void 0 : s.url) || De(),
                    {
                        referrer: n
                    } = b.document || {},
                    {
                        userAgent: r
                    } = b.navigator || {},
                    o = p(p(p({}, (a = e.request) == null ? void 0 : a.headers), n && {
                        Referer: n
                    }), r && {
                        "User-Agent": r
                    }),
                    i = E(p(p({}, e.request), t && {
                        url: t
                    }), {
                        headers: o
                    });
                e.request = i
            }
        })
    });
    var Hu, $u, Gu, ju, xs, bs = d(() => {
        D();
        pn();
        Hu = "cause", $u = 5, Gu = "LinkedErrors", ju = (e = {}) => {
            let t = e.limit || $u,
                n = e.key || Hu;
            return {
                name: Gu,
                preprocessEvent(r, o, i) {
                    let s = i.getOptions();
                    Tr(cn, s.stackParser, s.maxValueLength, n, t, r, o)
                }
            }
        }, xs = ju
    });

    function vs(e) {
        return [nn(), en(), fs(), ps(), Es(), xs(), rn(), Ts(), gs()]
    }

    function Wu(e = {}) {
        var n;
        let t = {
            defaultIntegrations: vs(),
            release: typeof __SENTRY_RELEASE__ == "string" ? __SENTRY_RELEASE__ : (n = b.SENTRY_RELEASE) == null ? void 0 : n.id,
            sendClientReports: !0
        };
        return p(p({}, t), Yu(e))
    }

    function Yu(e) {
        let t = {};
        for (let n of Object.getOwnPropertyNames(e)) {
            let r = n;
            e[r] !== void 0 && (t[r] = e[r])
        }
        return t
    }

    function zu() {
        var c;
        let e = typeof b.window != "undefined" && b;
        if (!e) return !1;
        let t = e.chrome ? "chrome" : "browser",
            n = e[t],
            r = (c = n == null ? void 0 : n.runtime) == null ? void 0 : c.id,
            o = De() || "",
            i = ["chrome-extension:", "moz-extension:", "ms-browser-extension:", "safari-web-extension:"],
            s = !!r && b === b.top && i.some(u => o.startsWith(`${u}//`)),
            a = typeof e.nw != "undefined";
        return !!r && !s && !a
    }

    function $r(e = {}) {
        let t = Wu(e);
        if (!t.skipBrowserExtensionCheck && zu()) {
            Ee && V(() => {
                console.error("[Sentry] You cannot run Sentry this way in a browser extension, check: https://docs.sentry.io/platforms/javascript/best-practices/browser-extensions/")
            });
            return
        }
        Ee && !an() && _.warn("No Fetch API detected. The Sentry SDK requires a Fetch API compatible environment to send events. Please add a Fetch API polyfill.");
        let n = E(p({}, t), {
            stackParser: Nn(t.stackParser || as),
            integrations: ur(t),
            transport: t.transport || is
        });
        return gr(dn, n)
    }
    var Cs = d(() => {
        D();
        qi();
        gt();
        xe();
        ds();
        ms();
        _s();
        Ss();
        Is();
        bs();
        us();
        ss()
    });
    var Rs = d(() => {
        D();
        Cs()
    });
    var Ns, Gr, ks = d(() => {
        Ns = "https://5796bb572427c551fc9b4e018162a30a@o58632.ingest.us.sentry.io/4508807764377601", Gr = {
            PRODUCTION: "production",
            STAGE: "stage",
            DEVELOPMENT: "development"
        }
    });

    function As(e) {
        var s, a, c, u, l;
        let t = e.settings,
            n = (a = (s = e == null ? void 0 : e.init) == null ? void 0 : s.context) == null ? void 0 : a.document,
            r = t.environment === "prod",
            o = r ? Gr.PRODUCTION : Gr.STAGE,
            i = (u = (c = e == null ? void 0 : e.init) == null ? void 0 : c.data) == null ? void 0 : u.shop;
        r && Ju({
            store: {
                name: i == null ? void 0 : i.name,
                storefrontUrl: i == null ? void 0 : i.storefrontUrl,
                storeId: t.store_id
            },
            location: {
                href: (l = n == null ? void 0 : n.location) == null ? void 0 : l.href,
                referrer: n == null ? void 0 : n.referrer
            },
            environment: o
        })
    }

    function Ju(e) {
        let {
            store: t,
            location: n,
            environment: r
        } = e;
        $r({
            dsn: Ns,
            defaultIntegrations: !1,
            environment: r
        }), self.addEventListener("unhandledrejection", o => {
            he(new Error(o.reason.stack))
        }), self.addEventListener("error", o => {
            he(new Error(o.message))
        }), Vt({
            storeId: t.storeId
        }), at("store", t), at("location", n)
    }

    function L(e, t) {
        let n;
        return t && (n = {
            context: e,
            errorMessage: t instanceof Error ? t.message : "Unknown error",
            errorStack: t instanceof Error ? t.stack : void 0
        }), he(new Error(e), r => (n && r.setContext("payload", {
            payload: n
        }), r))
    }

    function ws(e, t) {
        let n;
        return t && (n = {
            context: e,
            errorResponse: t
        }), he(new Error(e), r => (n && r.setContext("payload", {
            payload: n
        }), r))
    }

    function jr(e, t) {
        x(e, t), Jt(e, {
            extra: t == null ? void 0 : t.extra,
            tags: t == null ? void 0 : t.tags,
            level: "debug"
        })
    }
    var Xe = d(() => {
        Rs();
        ks();
        be()
    });

    function Ds(e) {
        let t = e.settings,
            n = e.init.data.shop.myshopifyDomain,
            r = t.store_id;
        return function(i, s) {
            return C(this, null, function*() {
                try {
                    x("Sending Recharge Analytics", i, s);
                    let a = yield fetch(t.environment === "stage" ? Vu : qu, {
                        method: "POST",
                        body: JSON.stringify(E(p({}, s), {
                            store_id: r,
                            shop_url: n,
                            event_timestamp: new Date().valueOf(),
                            event_datetime: new Date().toISOString()
                        })),
                        headers: {
                            "Content-Type": "application/json",
                            Accept: "*/*"
                        },
                        keepalive: !0
                    });
                    return a.ok || (N("Failed to track Recharge analytics", a), ws("Failed to track Recharge analytics", a)), x("Recharge Analytics Response", a), a
                } catch (a) {
                    N("Failed to track Recharge analytics with error", a), L("Failed to track Recharge analytics with error", a)
                }
            })
        }
    }
    var Vu, qu, Os = d(() => {
        be();
        Xe();
        Vu = "https://web-analytics-receiver.stage.rechargeapps.com/events", qu = "https://web-analytics-receiver.prod.rechargeapps.com/events"
    });
    var Ps = d(() => {});

    function Wr(e, t) {
        return t ? `${e}_${t}` : `${e}_onetime`
    }

    function En(e) {
        return e ? Number(e.split("/").pop()) : null
    }

    function Ls(e, t, n) {
        return C(this, null, function*() {
            try {
                let r = yield n.localStorage.getItem(hn), o = r ? JSON.parse(r) : {};
                o[e] = t, yield n.localStorage.setItem(hn, JSON.stringify(o)), x("Saved widget properties for checkout", o)
            } catch (r) {
                N("Failed to save widget properties for checkout", r), L("Failed to save widget properties for checkout", r)
            }
        })
    }

    function Ms(e, {
        analytics: t,
        init: n,
        browser: r
    }) {
        r.sessionStorage.setItem(Xu, "true");
        let o = null,
            i = null,
            s = null;
        t.subscribe("page_viewed", () => {
            o = null, s = null
        }), t.subscribe("checkout_completed", a => C(this, null, function*() {
            var c;
            try {
                let u = ((c = a.data.checkout.order) == null ? void 0 : c.id) || null;
                if (!u) {
                    N("No order id found for checkout"), L("No order id found for checkout");
                    return
                }
                let l = yield r.localStorage.getItem(hn);
                if (!l) {
                    x("No widget properties found for checkout");
                    return
                }
                let f = JSON.parse(l),
                    g = a.data.checkout.lineItems.flatMap(S => {
                        var O, re, oe, _t;
                        let T = ((O = S.variant) == null ? void 0 : O.id) || null,
                            I = En((oe = (re = S.sellingPlanAllocation) == null ? void 0 : re.sellingPlan) == null ? void 0 : oe.id);
                        if (T) {
                            let Tn = Wr(T, I),
                                ht = f[Tn];
                            return ht ? [E(p({}, ht), {
                                external_order_line_item_id: S.id || null,
                                external_variant_id: T,
                                external_product_id: ((_t = S.variant) == null ? void 0 : _t.product.id) || null
                            })] : (x("No widget properties found for checkout line item", S), [])
                        }
                        return []
                    }),
                    m = {
                        event_name: "rc_widget_checkout_completed",
                        external_order_id: u,
                        line_items_widget_info: g,
                        external_cart_token: a.data.checkout.token
                    };
                e(a.name, m), r.localStorage.removeItem(hn), x("Local storage reset")
            } catch (u) {
                N("Failed to track widget properties for checkout", u), L("Failed to track widget properties for checkout", u)
            }
        })), t.subscribe("product_added_to_cart", a => {
            var l, f, g;
            if (o && i && s) {
                let c = o,
                    {
                        preselected_item_type_option: m,
                        event_name: S,
                        external_product_id: T,
                        external_variant_id: I
                    } = c,
                    O = Ze(c, ["preselected_item_type_option", "event_name", "external_product_id", "external_variant_id"]),
                    u = i,
                    {
                        event_name: re,
                        external_plan_id: oe
                    } = u,
                    _t = Ze(u, ["event_name", "external_plan_id"]),
                    Tn = (l = a.data.cartLine) == null ? void 0 : l.merchandise.product.id,
                    ht = (f = a.data.cartLine) == null ? void 0 : f.merchandise.id;
                if (Tn === T && ht === I) {
                    let Ws = E(p(p({}, O), _t), {
                        event_name: "add_to_cart",
                        external_product_id: T,
                        external_variant_id: I,
                        selected_item_type_option: s,
                        external_cart_token: (g = n.data.cart) == null ? void 0 : g.id
                    });
                    if (e(a.name, Ws), !oe && s !== "onetime") {
                        N("No external_plan_id found"), L("No external_plan_id found");
                        return
                    }
                    Ls(Wr(I, oe), {
                        widget_flow_id: o.widget_flow_id,
                        ab_split_id: o.ab_split_id,
                        rc_widget_config_id: o.rc_widget_config_id,
                        widget_embed_template_name: o.widget_embed_template_name,
                        external_market_id: o.external_market_id,
                        item_type: s,
                        external_plan_id: oe ? String(oe) : null
                    }, r)
                }
            }
        }), t.subscribe("rc_widget_load", a => {
            var c;
            o = a.customData, s = (c = o == null ? void 0 : o.preselected_item_type_option) != null ? c : null, e(a.name, o)
        }), t.subscribe("rc_widget_type_changed", a => {
            var u;
            let c = a.customData;
            c && (s = (u = c.selected_item_type_option) != null ? u : null)
        }), t.subscribe("rc_widget_variant_changed", a => {
            let c = a.customData;
            o && c && (o.external_variant_id = c.external_variant_id, o.external_product_id = c.external_product_id)
        }), t.subscribe("selling_plan_changed", a => {
            i = a.customData
        }), t.subscribe("rc_widget_buy_now_clicked", a => {
            var l;
            if (o && i && s) {
                let c = o,
                    {
                        preselected_item_type_option: f,
                        external_product_id: g,
                        external_variant_id: m
                    } = c,
                    S = Ze(c, ["preselected_item_type_option", "external_product_id", "external_variant_id"]),
                    u = i,
                    {
                        external_plan_id: T
                    } = u,
                    I = Ze(u, ["external_plan_id"]),
                    O = E(p(p({}, S), I), {
                        event_name: "add_to_cart",
                        external_product_id: g,
                        external_variant_id: m,
                        selected_item_type_option: s,
                        external_cart_token: (l = n.data.cart) == null ? void 0 : l.id
                    });
                if (x("Add to cart event via buy now", O), e("product_added_to_cart", O), !T && s !== "onetime") {
                    N("No external_plan_id found"), L("No external_plan_id found");
                    return
                }
                Ls(Wr(m, T), {
                    widget_flow_id: o.widget_flow_id,
                    ab_split_id: o.ab_split_id,
                    rc_widget_config_id: o.rc_widget_config_id,
                    widget_embed_template_name: o.widget_embed_template_name,
                    external_market_id: o.external_market_id,
                    item_type: s,
                    external_plan_id: T ? String(T) : null
                }, r)
            }
        })
    }
    var Xu, hn, Yr = d(() => {
        be();
        Xe();
        Ps();
        Xu = "rc_subscription_widget_analytics", hn = "rc_subscription_widget_checkout_properties"
    });

    function Zu(e, t) {
        return C(this, null, function*() {
            try {
                let n = yield e.localStorage.getItem(yn), r = n ? JSON.parse(n) : [];
                r.push(t), yield e.localStorage.setItem(yn, JSON.stringify(r)), x("Added accepted config for checkout", r)
            } catch (n) {
                N("Failed to add accepted cart overlay config for checkout", n), L("Failed to add accepted cart overlay config for checkout", n)
            }
        })
    }

    function Qu(e) {
        return {
            external_product_id: e.external_product_id,
            external_variant_id: e.external_variant_id,
            external_market_id: e.external_market_id,
            offer_type: e.offer_type,
            flow_id: e.flow_id
        }
    }

    function ep(e, t) {
        var r, o, i;
        let n = e.find(s => {
            var c, u;
            let a = En((c = t.sellingPlanAllocation) == null ? void 0 : c.sellingPlan.id);
            return a ? ((u = t.variant) == null ? void 0 : u.id) === String(s.external_variant_id) && a === s.selling_plan_id : !1
        });
        return n ? E(p({}, Qu(n)), {
            quantity: t.quantity,
            final_line_price: t.finalLinePrice,
            variant_price: ((r = t.variant) == null ? void 0 : r.price) || null,
            external_order_line_item_id: t.id || null,
            external_variant_id: ((o = t.variant) == null ? void 0 : o.id) || null,
            external_product_id: ((i = t.variant) == null ? void 0 : i.product.id) || null
        }) : null
    }

    function Fs(e) {
        var t, n, r, o, i;
        return {
            id: e.id,
            variantId: (t = e.variant) == null ? void 0 : t.id,
            sellingPlanAllocation: JSON.stringify(e.sellingPlanAllocation),
            sellingPlanId: ((r = (n = e.sellingPlanAllocation) == null ? void 0 : n.sellingPlan) == null ? void 0 : r.id) || null,
            parsedSellingPlanId: En((i = (o = e.sellingPlanAllocation) == null ? void 0 : o.sellingPlan) == null ? void 0 : i.id),
            quantity: e.quantity
        }
    }

    function Us(e, {
        analytics: t,
        init: n,
        browser: r
    }) {
        t.subscribe("checkout_completed", o => C(this, null, function*() {
            var s, a;
            let i = yield r.localStorage.getItem(yn);
            if (i) try {
                let c = ((s = o.data.checkout.order) == null ? void 0 : s.id) || null;
                if (!c) {
                    N("No order id found for checkout"), L("No order id found for checkout");
                    return
                }
                let u = JSON.parse(i);
                if (u.length === 0) return;
                let l = o.data.checkout.lineItems,
                    f = l.flatMap(g => {
                        let m = ep(u, g);
                        return m ? [m] : []
                    });
                if (f.length > 0) {
                    let g = {
                        event_name: "cart_overlay_checkout_completed",
                        external_order_id: c,
                        line_items: f,
                        external_checkout_token: o.data.checkout.token,
                        external_cart_token: (a = n.data.cart) == null ? void 0 : a.id
                    };
                    e(o.name, g)
                } else {
                    let g = l.filter(m => u.some(S => {
                        var T;
                        return ((T = m.variant) == null ? void 0 : T.id) === String(S.external_variant_id)
                    }));
                    g.length > 0 ? jr("Accepted offer variant found, but selling plans do not match for checkout_completed event", {
                        tags: {
                            feature: "cart_overlay"
                        },
                        extra: {
                            acceptedConfigs: u,
                            checkoutLineItems: g.flatMap(Fs)
                        }
                    }) : jr("No associated line items found for checkout_completed event", {
                        tags: {
                            feature: "cart_overlay"
                        },
                        extra: {
                            acceptedConfigs: u,
                            checkoutLineItems: l.flatMap(Fs)
                        }
                    })
                }
                r.localStorage.removeItem(yn), x("Local storage reset")
            } catch (c) {
                N("Failed to track cart overlay settings for checkout", c), L("Failed to track cart overlay settings for checkout", c)
            }
        })), t.subscribe("cart_overlay_displayed", o => {
            let i = o.customData;
            x("cart_overlay_displayed", i), e(o.name, i)
        }), t.subscribe("cart_overlay_offer_accepted", o => C(this, null, function*() {
            let i = o.customData;
            i && (yield Zu(r, i), x("cart_overlay_offer_accepted", i), e(o.name, i))
        })), t.subscribe("cart_overlay_offer_declined", o => {
            let i = o.customData;
            x("cart_overlay_offer_declined", i), e(o.name, i)
        })
    }
    var yn, Bs = d(() => {
        be();
        Xe();
        Yr();
        yn = "rc_cart_overlay_analytics"
    });

    function tp(e, t) {
        return C(this, null, function*() {
            try {
                let n = yield e.localStorage.getItem(Sn), r = n ? JSON.parse(n) : [];
                r.length > 0 && r[0].external_cart_token !== t.external_cart_token && (r = [], x("Local storage reset for new cart")), r.push(t), yield e.localStorage.setItem(Sn, JSON.stringify(r)), x("Added accepted config for checkout", r)
            } catch (n) {
                N("Failed to add accepted cart drawer config for checkout", n), L("Failed to add accepted cart drawer config for checkout", n)
            }
        })
    }

    function np(e, t) {
        return C(this, null, function*() {
            try {
                let n = yield e.localStorage.getItem(zr), r = n ? JSON.parse(n) : [];
                r.length > 0 && r[0].external_cart_token !== t.external_cart_token && (r = [], x("Local storage reset for new cart")), r.push(t), yield e.localStorage.setItem(zr, JSON.stringify(r)), x("Added displayed config for checkout", r)
            } catch (n) {
                N("Failed to get displayed cart drawer config for checkout", n), L("Failed to get displayed cart drawer config for checkout", n)
            }
        })
    }

    function rp(e, t) {
        return C(this, null, function*() {
            try {
                let n = yield e.localStorage.getItem(zr);
                return (n ? JSON.parse(n) : []).find(o => o.external_product_id === t.external_product_id && o.external_variant_id === t.external_variant_id && o.external_cart_token === t.external_cart_token && o.offer_type === t.offer_type) || null
            } catch (n) {
                N("Failed to get displayed cart drawer config for checkout", n), L("Failed to get displayed cart drawer config for checkout", n)
            }
            return null
        })
    }

    function op(e) {
        return e ? {
            external_product_id: e.external_product_id,
            external_variant_id: e.external_variant_id,
            external_market_id: e.external_market_id,
            offer_type: e.offer_type,
            flow_id: e.flow_id
        } : {}
    }

    function Hs(e, {
        analytics: t,
        init: n,
        browser: r
    }) {
        t.subscribe("checkout_completed", o => C(this, null, function*() {
            var s, a;
            let i = yield r.localStorage.getItem(Sn);
            if (i) try {
                let c = ((s = o.data.checkout.order) == null ? void 0 : s.id) || null;
                if (!c) {
                    N("No order id found for checkout"), L("No order id found for checkout");
                    return
                }
                let u = JSON.parse(i);
                if (u.length === 0) return;
                let l = o.data.checkout.lineItems.filter(g => u.find(m => {
                        var S, T;
                        return ((S = g.variant) == null ? void 0 : S.id) === String(m.external_variant_id) && ((T = g.sellingPlanAllocation) == null ? void 0 : T.sellingPlan.id.includes(String(m.selling_plan_id)))
                    })).map(g => {
                        var m, S, T;
                        return E(p({}, op(u.find(I => {
                            var O, re;
                            return ((O = g.variant) == null ? void 0 : O.id) === String(I.external_variant_id) && ((re = g.sellingPlanAllocation) == null ? void 0 : re.sellingPlan.id.includes(String(I.selling_plan_id)))
                        }))), {
                            quantity: g.quantity,
                            final_line_price: g.finalLinePrice,
                            variant_price: (m = g.variant) == null ? void 0 : m.price,
                            external_order_line_item_id: g.id || null,
                            external_variant_id: ((S = g.variant) == null ? void 0 : S.id) || null,
                            external_product_id: ((T = g.variant) == null ? void 0 : T.product.id) || null
                        })
                    }),
                    f = {
                        event_name: "cart_drawer_checkout_completed",
                        external_order_id: c,
                        line_items: l,
                        external_checkout_token: o.data.checkout.token,
                        external_cart_token: (a = n.data.cart) == null ? void 0 : a.id
                    };
                e(o.name, f), r.localStorage.removeItem(Sn), x("Local storage reset")
            } catch (c) {
                N("Failed to track cart drawer settings for checkout", c), L("Failed to track cart drawer settings for checkout", c)
            }
        })), t.subscribe("cart_drawer_offer_displayed", o => C(this, null, function*() {
            x("Displayed", n.data);
            let i = o.customData;
            i && ((yield rp(r, i)) ? x("Duplicate displayed event") : (yield np(r, i), x("cart_drawer_offer_displayed", i), e(o.name, i)))
        })), t.subscribe("cart_drawer_offer_accepted", o => C(this, null, function*() {
            let i = o.customData;
            i && (yield tp(r, i), x("cart_drawer_offer_accepted", i), e(o.name, i))
        }))
    }
    var Sn, zr, $s = d(() => {
        be();
        Xe();
        Sn = "rc_cart_drawer_analytics", zr = "rc_cart_drawer_offer_displayed_analytics"
    });
    var js = Xs(Gs => {
        Qr();
        be();
        Xe();
        Os();
        Yr();
        Bs();
        $s();
        bn(e => C(Gs, null, function*() {
            eo(e), As(e);
            let t = Ds(e);
            Ms(t, e), Us(t, e), Hs(t, e)
        }))
    });
    var ny = Qs(js());
})();