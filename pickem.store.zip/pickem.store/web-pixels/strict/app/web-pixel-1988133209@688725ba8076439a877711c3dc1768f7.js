(() => {
    var A = Object.create;
    var x = Object.defineProperty,
        L = Object.defineProperties,
        N = Object.getOwnPropertyDescriptor,
        C = Object.getOwnPropertyDescriptors,
        E = Object.getOwnPropertyNames,
        _ = Object.getOwnPropertySymbols,
        V = Object.getPrototypeOf,
        f = Object.prototype.hasOwnProperty,
        b = Object.prototype.propertyIsEnumerable;
    var k = (o, t, c) => t in o ? x(o, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: c
        }) : o[t] = c,
        s = (o, t) => {
            for (var c in t || (t = {})) f.call(t, c) && k(o, c, t[c]);
            if (_)
                for (var c of _(t)) b.call(t, c) && k(o, c, t[c]);
            return o
        },
        y = (o, t) => L(o, C(t));
    var D = (o, t) => {
        var c = {};
        for (var e in o) f.call(o, e) && t.indexOf(e) < 0 && (c[e] = o[e]);
        if (o != null && _)
            for (var e of _(o)) t.indexOf(e) < 0 && b.call(o, e) && (c[e] = o[e]);
        return c
    };
    var h = (o, t) => () => (o && (t = o(o = 0)), t);
    var $ = (o, t) => () => (t || o((t = {
        exports: {}
    }).exports, t), t.exports);
    var j = (o, t, c, e) => {
        if (t && typeof t == "object" || typeof t == "function")
            for (let r of E(t)) !f.call(o, r) && r !== c && x(o, r, {
                get: () => t[r],
                enumerable: !(e = N(t, r)) || e.enumerable
            });
        return o
    };
    var q = (o, t, c) => (c = o != null ? A(V(o)) : {}, j(t || !o || !o.__esModule ? x(c, "default", {
        value: o,
        enumerable: !0
    }) : c, o));
    var m = (o, t, c) => new Promise((e, r) => {
        var i = a => {
                try {
                    n(c.next(a))
                } catch (d) {
                    r(d)
                }
            },
            u = a => {
                try {
                    n(c.throw(a))
                } catch (d) {
                    r(d)
                }
            },
            n = a => a.done ? e(a.value) : Promise.resolve(a.value).then(i, u);
        n((c = c.apply(o, t)).next())
    });
    var I, w = h(() => {
        I = "WebPixel::Render"
    });
    var g, P = h(() => {
        w();
        g = o => shopify.extend(I, o)
    });
    var T = h(() => {
        P()
    });
    var U = h(() => {
        T()
    });
    var S = $(O => {
        U();
        var G = "G-4ZW2ZLTVD7",
            J = "3oi1P_8HTMylEkNO2xXD5w",
            R = `https://www.google-analytics.com/mp/collect?measurement_id=${G}&api_secret=${J}`,
            W = "a2548598-bd80-4dc0-b43a-66312435b5f3",
            X = "https://insights-hive.com/report/insights",
            Z = "https://staging.insights-hive.com/report/insights";

        function B() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, o => {
                let t = Math.random() * 16 | 0;
                return (o === "x" ? t : t & 3 | 8).toString(16)
            })
        }

        function H(o, t) {
            return m(this, null, function*() {
                let e = (t == null ? void 0 : t.shop_uuid) !== W ? X : Z,
                    d = t || {},
                    {
                        shopify_client_id: r,
                        hive_dp_id: i,
                        hive_user_type: u
                    } = d,
                    n = D(d, ["shopify_client_id", "hive_dp_id", "hive_user_type"]),
                    a = {
                        name: o,
                        id: B(),
                        timestamp: new Date().toISOString(),
                        properties: y(s({}, n), {
                            hive_dp_id: i,
                            hive_user_type: u
                        })
                    };
                try {
                    yield fetch(e, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            insight: a
                        })
                    })
                } catch (l) {
                    console.error(l)
                }
            })
        }

        function M(o) {
            return o.map(t => {
                var c;
                return (c = t == null ? void 0 : t.variant) == null ? void 0 : c.id
            }).map(t => t == null ? void 0 : t.replace(/\D+/, "")).filter(Boolean).map(t => `${t}`)
        }

        function z(o) {
            let t = o.reduce((c, e) => {
                let {
                    key: r,
                    value: i
                } = e || {};
                return ["hive_user_type", "hive_dp_id"].includes(r) && (c[r] = i), c
            }, {});
            return s({}, t)
        }

        function p(o, t) {
            return m(this, null, function*() {
                let c = {
                    engagement_time_msec: t.timestamp,
                    timestamp: t.timestamp
                };
                try {
                    let e = yield fetch(R, {
                        method: "POST",
                        mode: "no-cors",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        keepalive: !0,
                        body: JSON.stringify({
                            client_id: t.shopify_client_id,
                            events: [{
                                name: o,
                                params: s(s({}, c), t)
                            }]
                        })
                    })
                } catch (e) {
                    console.error(e)
                }
            })
        }
        g(e => m(O, [e], function*({
            analytics: o,
            browser: t,
            settings: c
        }) {
            let r = yield t.cookie.get("_shopify_s");
            o.subscribe("product_viewed", i => {
                p("product_viewed", {
                    shop_uuid: c.shopUUID,
                    shopify_client_id: i.clientId,
                    shopify_session_id: r,
                    url: i.context.document.location.href,
                    product_id: i.data.productVariant.product.id,
                    product_title: i.data.productVariant.title,
                    product_sku: i.data.productVariant.sku,
                    price_amount: i.data.productVariant.price.amount,
                    price_currency: i.data.productVariant.price.currencyCode
                })
            }), o.subscribe("product_added_to_cart", i => {
                p("product_added_to_cart", {
                    shop_uuid: c.shopUUID,
                    shopify_client_id: i.clientId,
                    shopify_session_id: r,
                    url: i.context.document.location.href,
                    quantity: i.data.cartLine.quantity,
                    price_amount: i.data.cartLine.cost.totalAmount.amount,
                    price_currency: i.data.cartLine.cost.totalAmount.currencyCode,
                    product_id: i.data.cartLine.merchandise.product.id,
                    product_title: i.data.cartLine.merchandise.product.title,
                    product_sku: i.data.cartLine.merchandise.sku
                })
            }), o.subscribe("prediction", i => {
                p("prediction", s({
                    shop_uuid: c.shopUUID,
                    shopify_client_id: i.clientId,
                    shopify_session_id: r,
                    url: i.context.document.location.href,
                    uuid: i.customData.uuid
                }, i.customData.metadata))
            }), o.subscribe("widget_rendered", i => {
                p("widget_rendered", {
                    shop_uuid: c.shopUUID,
                    shopify_client_id: i.clientId,
                    shopify_session_id: r,
                    url: i.context.document.location.href,
                    widget_version: i.customData.metadata.widget_version,
                    uuid: i.customData.uuid,
                    color: i.customData.metadata.color,
                    icon: i.customData.metadata.icon,
                    font: i.customData.metadata.font,
                    text_option: i.customData.metadata.textOption,
                    variant: i.customData.metadata.variant
                })
            }), o.subscribe("checkout_completed", i => {
                let u = {
                    shop_uuid: c.shopUUID,
                    shopify_client_id: i.clientId,
                    shopify_session_id: r,
                    checkout_token: i.data.checkout.token,
                    url: i.context.document.location.href,
                    order_id: i.data.checkout.order.id,
                    shipping_amount: i.data.checkout.shippingLine.price.amount,
                    subtotal_amount: i.data.checkout.subtotalPrice.amount,
                    tax_amount: i.data.checkout.totalTax.amount,
                    price_amount: i.data.checkout.totalPrice.amount,
                    price_currency: i.data.checkout.totalPrice.currencyCode,
                    country_code: i.data.checkout.shippingAddress.countryCode
                };
                p("checkout_completed", s({}, u));
                let {
                    attributes: n = [],
                    lineItems: a = []
                } = i.data.checkout || {}, d = M(a), l = z(n);
                H("checkout_completed", y(s(s({}, u), l), {
                    variants_ids: d
                }))
            })
        }))
    });
    var at = q(S());
})();