(() => {
    var fe = Object.create;
    var ge = Object.defineProperty;
    var Ie = Object.getOwnPropertyDescriptor;
    var Ne = Object.getOwnPropertyNames;
    var ye = Object.getPrototypeOf,
        Ce = Object.prototype.hasOwnProperty;
    var k = (i, t) => () => (i && (t = i(i = 0)), t);
    var Ee = (i, t) => () => (t || i((t = {
        exports: {}
    }).exports, t), t.exports);
    var we = (i, t, s, h) => {
        if (t && typeof t == "object" || typeof t == "function")
            for (let c of Ne(t)) !Ce.call(i, c) && c !== s && ge(i, c, {
                get: () => t[c],
                enumerable: !(h = Ie(t, c)) || h.enumerable
            });
        return i
    };
    var Te = (i, t, s) => (s = i != null ? fe(ye(i)) : {}, we(t || !i || !i.__esModule ? ge(s, "default", {
        value: i,
        enumerable: !0
    }) : s, i));
    var p = (i, t, s) => new Promise((h, c) => {
        var g = u => {
                try {
                    r(s.next(u))
                } catch (e) {
                    c(e)
                }
            },
            _ = u => {
                try {
                    r(s.throw(u))
                } catch (e) {
                    c(e)
                }
            },
            r = u => u.done ? h(u.value) : Promise.resolve(u.value).then(g, _);
        r((s = s.apply(i, t)).next())
    });
    var _e, be = k(() => {
        _e = "WebPixel::Render"
    });
    var v, ke = k(() => {
        be();
        v = i => shopify.extend(_e, i)
    });
    var ve = k(() => {
        ke()
    });
    var me = k(() => {
        ve()
    });
    var xe = Ee(l => {
        me();
        v(({
            configuration: i,
            analytics: t,
            browser: s,
            settings: h,
            init: c
        }) => {
            if (!h.shopId) {
                console.error("Triple Pixel wasn't Initialized. Triple Pixel stops executing!");
                return
            }
            let g = {
                TripleName: h.shopId,
                ver: "2.16",
                plat: "SHOPIFY",
                isHeadless: !1,
                src: "SHOPIFY_EXT"
            };

            function _(e, o, d, n, a) {
                a === void 0 && (a = !1), n = new XMLHttpRequest, d ? (n.open("POST", e, !0), n.setRequestHeader("Content-Type", "application/json")) : n.open("GET", e, !0), n.send(JSON.stringify(d || {})), n.onreadystatechange = function() {
                    n.readyState === 4 && n.status === 200 ? a = n.responseText : (299 < n.status || n.status < 200) && o && !a && (a = !0, _(e, o - 1, d))
                }
            }
            t.subscribe("page_viewed", e => {
                u(e, "page_viewed")
            }), t.subscribe("product_viewed", e => {
                u(e, "product_viewed")
            }), t.subscribe("collection_viewed", e => {
                u(e, "collection_viewed")
            }), t.subscribe("product_added_to_cart", e => {
                u(e, "product_added_to_cart")
            }), t.subscribe("search_submitted", e => {
                u(e, "search_submitted")
            }), t.subscribe("checkout_started", e => p(null, null, function*() {
                var o;
                r(e, "config1", (o = c.data) == null ? void 0 : o.customer)
            })), t.subscribe("payment_info_submitted", e => p(null, null, function*() {
                var o;
                r(e, "config2", (o = c.data) == null ? void 0 : o.customer)
            })), t.subscribe("checkout_completed", e => p(null, null, function*() {
                var o;
                r(e, "config3", (o = c.data) == null ? void 0 : o.customer)
            })), t.subscribe("checkout_address_info_submitted", e => p(null, null, function*() {
                var o;
                r(e, "config4", (o = c.data) == null ? void 0 : o.customer)
            })), t.subscribe("checkout_contact_info_submitted", e => p(null, null, function*() {
                var o;
                r(e, "config5", (o = c.data) == null ? void 0 : o.customer)
            })), t.subscribe("checkout_shipping_info_submitted", e => p(null, null, function*() {
                var o;
                r(e, "config6", (o = c.data) == null ? void 0 : o.customer)
            }));

            function r(e, o, d) {
                return p(this, null, function*() {
                    var m, x, P, S, f, I, N, y, C, E, w, T, A, O, q, L, W, X, G, z, D, F, J, M, V, Y, Z, j, $, B, K, Q, R, U, H, ee, te, oe, ie, ce, ae, de, se, ne, ue, re;
                    (x = (m = e.context.window.location) == null ? void 0 : m.href) != null && x.includes("fw_debug_params") && console.log("000");
                    let n = e.context.window[atob("c2NyZWVu")],
                        a = ((P = c == null ? void 0 : c.context) == null ? void 0 : P.navigator) || {},
                        Pe = (a == null ? void 0 : a.language) || (a == null ? void 0 : a.browserLanguage) || (a == null ? void 0 : a.userLanguage) || (a == null ? void 0 : a.systemLanguage),
                        Se = {
                            id: Date.now().toString(36) + "_" + Math.random().toString(36),
                            add_eid: e.id,
                            action: o,
                            avatar: yield s.localStorage.getItem("true_rand_gen_sequence.dat_"), avatar2: yield s.localStorage.getItem("true_rand_gen_sequence.dat_tmp"), time: n[atob("d2lkdGg=")] + ":" + n[atob("aGVpZ2h0")], host: g.TripleName, plat: g.plat, url: (S = e.context.window.location) == null ? void 0 : S.href, ref: (f = e.context.document) == null ? void 0 : f.referrer, title: (I = e.context.document) == null ? void 0 : I.title, ver: g.ver, email: ((N = e.data.checkout) == null ? void 0 : N.email) || (d == null ? void 0 : d.email) || ((C = (y = e.data.checkout) == null ? void 0 : y.shippingAddress) == null ? void 0 : C.email) || ((w = (E = e.data.checkout) == null ? void 0 : E.billingAddress) == null ? void 0 : w.email), phone: ((T = e.data.checkout) == null ? void 0 : T.phone) || (d == null ? void 0 : d.phone) || ((O = (A = e.data.checkout) == null ? void 0 : A.shippingAddress) == null ? void 0 : O.phone) || ((L = (q = e.data.checkout) == null ? void 0 : q.billingAddress) == null ? void 0 : L.phone), token: (W = e.data.checkout) == null ? void 0 : W.token, orderId: (G = (X = e.data.checkout) == null ? void 0 : X.order) == null ? void 0 : G.id, firstName: (d == null ? void 0 : d.firstName) || ((F = (D = (z = e.data.checkout) == null ? void 0 : z.order) == null ? void 0 : D.customer) == null ? void 0 : F.firstName) || ((M = (J = e.data.checkout) == null ? void 0 : J.shippingAddress) == null ? void 0 : M.firstName), lastName: (d == null ? void 0 : d.lastName) || ((Z = (Y = (V = e.data.checkout) == null ? void 0 : V.order) == null ? void 0 : Y.customer) == null ? void 0 : Z.lastName) || (($ = (j = e.data.checkout) == null ? void 0 : j.shippingAddress) == null ? void 0 : $.lastName), province_code: (K = (B = e.data.checkout) == null ? void 0 : B.shippingAddress) == null ? void 0 : K.provinceCode, country_code: ((Q = e.data.checkout) == null ? void 0 : Q.country_code) || ((U = (R = e.data.checkout) == null ? void 0 : R.shippingAddress) == null ? void 0 : U.country_code) || ((ee = (H = e.data.checkout) == null ? void 0 : H.billingAddress) == null ? void 0 : ee.country_code), city: (oe = (te = e.data.checkout) == null ? void 0 : te.shippingAddress) == null ? void 0 : oe.city, zip: (ce = (ie = e.data.checkout) == null ? void 0 : ie.shippingAddress) == null ? void 0 : ce.zip, i: (de = (ae = e.data.checkout) == null ? void 0 : ae.lineItems) == null ? void 0 : de.map(b => {
                                var pe, he, le;
                                return {
                                    i: (he = (pe = b.variant) == null ? void 0 : pe.product) == null ? void 0 : he.id,
                                    v: (le = b.variant) == null ? void 0 : le.id,
                                    q: b.quantity,
                                    p: b.finalLinePrice
                                }
                            }), v: (ne = (se = e.data.checkout) == null ? void 0 : se.subtotalPrice) == null ? void 0 : ne.amount, cur: (re = (ue = e.data.checkout) == null ? void 0 : ue.subtotalPrice) == null ? void 0 : re.currencyCode, os_lang: JSON.stringify([Pe])
                        };
                    _("https://api.config-security.com/event", 5, Se)
                })
            }

            function u(e, o) {
                return p(this, null, function*() {
                    h.shopId == "madisonbraids.myshopify.com" && (yield s.localStorage.setItem(`TW_EXT_${o}`, JSON.stringify({
                        i: e.id,
                        t: Date.now()
                    })))
                })
            }
        })
    });
    var je = Te(xe());
})();