var sdk = function(n) {
    var e, t, r;
    ! function(n) {
        n.JSCondition = "jsCondition", n.JSFunction = "jsFunction", n.JSEvent = "jsEvent", n.Selector = "selector", n.ElementEvent = "elementEvent", n.PageLoad = "pageLoad", n.Timeout = "timeout", n.Inactivity = "inactivity", n.ExitIntent = "exitIntent", n.Conjunction = "conjunction"
    }(e || (e = {})),
    function(n) {
        n[n.PAUSED = 4] = "PAUSED"
    }(t || (t = {})),
    function(n) {
        n[n.LOCAL = 0] = "LOCAL", n[n.STAGE = 1] = "STAGE", n[n.PROD = 2] = "PROD", n[n.TEST = 3] = "TEST"
    }(r || (r = {}));
    var i, o = "lmi_preview";

    function u(n, e) {
        (null == e || e > n.length) && (e = n.length);
        for (var t = 0, r = Array(e); t < e; t++) r[t] = n[t];
        return r
    }

    function c(n, e) {
        var t = "undefined" != typeof Symbol && n[Symbol.iterator] || n["@@iterator"];
        if (t) return (t = t.call(n)).next.bind(t);
        if (Array.isArray(n) || (t = function(n, e) {
                if (n) {
                    if ("string" == typeof n) return u(n, e);
                    var t = {}.toString.call(n).slice(8, -1);
                    return "Object" === t && n.constructor && (t = n.constructor.name), "Map" === t || "Set" === t ? Array.from(n) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? u(n, e) : void 0
                }
            }(n)) || e && n && "number" == typeof n.length) {
            t && (n = t);
            var r = 0;
            return function() {
                return r >= n.length ? {
                    done: !0
                } : {
                    done: !1,
                    value: n[r++]
                }
            }
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }

    function a() {
        return a = Object.assign ? Object.assign.bind() : function(n) {
            for (var e = 1; e < arguments.length; e++) {
                var t = arguments[e];
                for (var r in t)({}).hasOwnProperty.call(t, r) && (n[r] = t[r])
            }
            return n
        }, a.apply(null, arguments)
    }

    function s(n, e) {
        return s = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, e) {
            return n.__proto__ = e, n
        }, s(n, e)
    }! function(n) {
        n.USE_CASE = "USE_CASE", n.ADD_TO_CART = "ADD_TO_CART"
    }(i || (i = {}));
    var f = function(n) {
            void 0 === n && (n = function() {
                return window
            });
            try {
                return Promise.resolve(S(function() {
                    return void 0 !== I(function() {
                        return n().removeEventListener
                    })
                }, 100, 100)).then(function() {
                    return Promise.resolve()
                })
            } catch (n) {
                return Promise.reject(n)
            }
        },
        l = function(n, e) {
            void 0 === n && (n = function() {
                return window
            }), void 0 === e && (e = !1);
            try {
                var t = function() {
                        return Promise.resolve()
                    },
                    r = e && v() ? Promise.resolve(S(function() {
                        return d
                    }, 1e3, 10)).then(function() {}) : Promise.resolve(S(function() {
                        return void 0 !== I(function() {
                            return n().addEventListener
                        })
                    }, 10, 1e3)).then(function() {});
                return Promise.resolve(r && r.then ? r.then(t) : t())
            } catch (n) {
                return Promise.reject(n)
            }
        },
        d = !1;

    function v() {
        return !0 === I(function() {
            return window.vslyDeferResources
        })
    }
    window.addEventListener("load", function() {
        setTimeout(function() {
            d = !0
        }, 2e3)
    });
    var m = function() {
            return document.location.hostname.replace("www.", "").replace("checkout.", "")
        },
        h = function(n, e, t, r, i) {
            var o = Infinity === t ? " expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + t,
                u = encodeURIComponent(n) + "=" + e + "; path=/;" + o + (r ? "; domain=" + r : "") + (i ? "; secure" : "");
            document.cookie = u
        };

    function p(n, e) {
        void 0 === e && (e = 20);
        var t = 0;
        return function() {
            var r = arguments;
            clearTimeout(t), t = setTimeout(function() {
                return n.apply(void 0, [].slice.call(r))
            }, e)
        }
    }
    var w = "vsly-hide-theme-preview",
        y = "vslyCtags",
        g = function() {
            return new Date(1e3 * Math.floor(Date.now() / 1e3))
        },
        _ = function() {
            try {
                return Promise.resolve(S(function() {
                    return !!I(function() {
                        return window.loomi.jitsu
                    })
                }, v() ? 1e3 : 500, 120)).then(function() {
                    return I(function() {
                        return window.loomi.jitsu
                    })
                })
            } catch (n) {
                return Promise.reject(n)
            }
        };

    function S(n, e, t, r) {
        return void 0 === e && (e = 500), void 0 === t && (t = 4), new Promise(function(i, o) {
            n() ? i(0) : 0 !== t ? setTimeout(function() {
                r && r() && o("condition rejected " + I(function() {
                    return n.toString()
                })), S(n, e, t - 1).then(i).catch(o)
            }, e) : o("condition rejected " + I(function() {
                return n.toString()
            }))
        })
    }

    function E(n, e) {
        function t(r) {
            try {
                var i = n();
                i ? r(i) : setTimeout(function() {
                    return t(r)
                }, e)
            } catch (n) {
                console.error("vsly-when", n), setTimeout(function() {
                    return t(r)
                }, e)
            }
        }
        return void 0 === e && (e = 500), new Promise(function(n) {
            t(n)
        })
    }

    function I(n, e) {
        void 0 === e && (e = void 0);
        try {
            return n()
        } catch (n) {
            return e
        }
    }
    var b = function(n) {
        return n && decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(n).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null
    };

    function P() {
        return A(function() {
            var n = new Function(document.querySelector('script[id="__st"]').textContent + ";return __st.cid.toString()")();
            return n && window.localStorage.setItem("vsly__st", n), !0
        }), I(function() {
            return window.__st.cid.toString()
        }) || window.localStorage.getItem("vsly__st")
    }

    function A(n, e, t) {
        void 0 === e && (e = 5), void 0 === t && (t = 500), e >= 0 && !I(n) && setTimeout(function() {
            I(n) || A(n, e - 1)
        }, t)
    }
    var k = function(n) {
        return void 0 === n && (n = window.loomi_ctx.env), n === r.STAGE ? "sdk.loomi-stg.xyz" : "live.visually-io.com"
    };

    function C(n) {
        return n.replace(/[^a-z_A-Z0-9]/gi, "_")
    }

    function x() {
        var n = _();
        return {
            register: function(e, t, r, i) {
                n.then(function(n) {
                    return I(function() {
                        return n.register(e, t, r, i)
                    })
                })
            },
            track: function(e, t, r) {
                return Promise.resolve(n).then(function(n) {
                    return Promise.resolve(I(function() {
                        return n.track(e, t, r)
                    })).then(function() {})
                })
            }
        }
    }

    function T(n, e, t) {
        return {
            id: "lmi-" + ++O,
            isApplied: !1,
            kind: n,
            selector: e,
            value: t
        }
    }

    function N(n, e) {
        var t, r = !1;
        return null !== n.previousElementSibling ? t = n.previousElementSibling : (t = n.parentElement, r = !0), t ? (n.outerHTML = e, r ? t.firstElementChild : t.nextElementSibling) : n
    }
    var O = Math.round(1e4 * Math.random()),
        j = [],
        L = new Map,
        U = "lmwv";

    function D() {
        return !!I(function() {
            return window.vsly_fbs
        })
    }

    function R() {
        return window.location.search.includes("lmi_debug") || D()
    }

    function M() {
        var n;
        R() && (n = console).debug.apply(n, ["loomi-editor"].concat([].slice.call(arguments)))
    }

    function q() {
        var n;
        R() && (n = console).error.apply(n, ["loomi-editor"].concat([].slice.call(arguments)))
    }
    var J = !0,
        B = {},
        V = /*#__PURE__*/ function() {
            function n(n, e) {
                this._value = void 0, this._addedAt = void 0, this._value = n, this._addedAt = e || (new Date).getTime()
            }
            var e = n.prototype;
            return e.value = function() {
                return this._value
            }, e.addedAt = function() {
                return this._addedAt
            }, n
        }(),
        H = /*#__PURE__*/ function() {
            function n(n, e) {
                this.backend = void 0, this.ttlMillis = void 0, this.backend = n, this.ttlMillis = e
            }
            var e = n.prototype;
            return e.isValid = function(n) {
                return !!n && (new Date).getTime() - n.addedAt() <= this.ttlMillis
            }, e.get = function(n) {
                var e = this.backend.get(n),
                    t = this.isValid(e);
                if (e && t) return e.value();
                t || this.backend.remove(n)
            }, e.set = function(n, e, t) {
                var r = new V(e, t);
                this.backend.set(n, r)
            }, n
        }(),
        F = /*#__PURE__*/ function() {
            function n(n) {
                this.namespace = void 0, this.namespace = "vsly_cache_" + n, window[this.namespace] = {}
            }
            var e = n.prototype;
            return e.get = function(n) {
                var e = this;
                return I(function() {
                    return window[e.namespace][n]
                })
            }, e.remove = function(n) {
                var e = this;
                I(function() {
                    return delete window[e.namespace][n]
                })
            }, e.set = function(n, e) {
                window[this.namespace][n] = e
            }, n
        }(),
        G = /*#__PURE__*/ function(n) {
            function e(e, t) {
                return n.call(this, new F(e), t) || this
            }
            var t, r;
            return r = n, (t = e).prototype = Object.create(r.prototype), t.prototype.constructor = t, s(t, r), e
        }(H),
        K = function(n, e) {
            void 0 === e && (e = 8397271938200529);
            for (var t, r = 3735928559 ^ e, i = 1103547991 ^ e, o = 0; o < n.length; o++) t = n.charCodeAt(o), r = Math.imul(r ^ t, 2654435761), i = Math.imul(i ^ t, 1597334677);
            return r = Math.imul(r ^ r >>> 16, 2246822507) ^ Math.imul(i ^ i >>> 13, 3266489909), "" + (4294967296 * (2097151 & (i = Math.imul(i ^ i >>> 16, 2246822507) ^ Math.imul(r ^ r >>> 13, 3266489909))) + (r >>> 0))
        },
        Y = "targeting-changed",
        W = "vsly-redirected-event",
        z = "vslyThemeTest";

    function Q(n) {
        return I(function() {
            return window.visually.flags[n]
        }, !1)
    }

    function $() {
        return I(function() {
            return !0 === window.vslyDeferWidgets || Q("sdk-defer-widgets")
        }, !1)
    }

    function X(n, e, t, r, i) {
        void 0 === t && (t = 10), void 0 === r && (r = !1), void 0 === i && (i = "none");
        var o = n._USE_CASE,
            u = n._USE_CASE_VARIANT,
            c = n._USE_CASE_AUDIENCES,
            s = n._USE_CASE_VERSION,
            f = n._USE_CASE_GA_VARIANT,
            l = n._USE_CASE_GA;
        if (!D() && !rn() && function(n) {
                try {
                    var e = location.pathname,
                        t = new URL(n);
                    if (location.search.includes("vsly-redirected-from")) return !1;
                    if (!0 === I(function() {
                            return window.visually.flags["sdk-kill-advanced-redirect-checks"]
                        })) return !0;
                    var r = !1,
                        i = decodeURIComponent(location.search);
                    return t.searchParams.forEach(function(n, e) {
                        var t = decodeURIComponent(e + "=" + n);
                        i.includes(t) || (r = !0)
                    }), !!((I(function() {
                        return Array.from(t.searchParams.values()).length
                    }) || 0) > 0 && r) || e !== t.pathname
                } catch (n) {
                    return !1
                }
            }(e) && function(n, e, t) {
                var r = "vsly-redirect-" + K(t._USE_CASE + "-" + t._USE_CASE_VARIANT + "-" + t._USE_CASE_VERSION + "-" + n);
                return "session" === e ? "true" !== sessionStorage.getItem(r) && (sessionStorage.setItem(r, "true"), !0) : "user" !== e || "true" !== localStorage.getItem(r) && (localStorage.setItem(r, "true"), !0)
            }(e, i, n)) {
            m();
            var d = o + "-" + u,
                v = {
                    type: "USE_CASE",
                    ts: g().valueOf(),
                    payload: a({
                        sid: I(function() {
                            return window.loomi_ctx.session.id
                        }),
                        user: {
                            anonymous_id: I(function() {
                                return window.loomi_ctx.userId
                            })
                        },
                        use_case: o,
                        use_case_variant: u
                    }, s ? {
                        version: s
                    } : {}, c ? {
                        audiences: c
                    } : {}),
                    options: {
                        gaName: I(function() {
                            return C(l)
                        }),
                        gaVariant: I(function() {
                            return C(f)
                        })
                    }
                };
            setTimeout(function() {
                try {
                    var n = function() {
                        location.replace && location.replace(u)
                    };
                    m();
                    var t = JSON.stringify(v),
                        i = btoa(unescape(encodeURIComponent(t))),
                        o = !d.includes(en),
                        u = e;
                    try {
                        new URLSearchParams(location.search).forEach(function(n, e) {
                            (r || tn(e)) && (u = Z(u, e, n))
                        })
                    } catch (n) {
                        M("e87", {
                            redirectUrl: u,
                            key: d,
                            event: t,
                            ex: n
                        })
                    }
                    u = Z(u, "vsly-redirected-from", d), o && (u = Z(u, W, i));
                    var c = function() {
                        if (Q("track-b4-redirect")) return Promise.resolve(_()).then(function() {
                            return Promise.resolve(window.loomi.jitsu.track(v.type, v.payload, v.options)).then(function() {})
                        })
                    }();
                    return Promise.resolve(c && c.then ? c.then(n) : n())
                } catch (n) {
                    return Promise.reject(n)
                }
            }, t)
        }

        function m() {
            document.body && (document.body.style.opacity = 0)
        }
    }

    function Z(n, e, t) {
        try {
            var r = new URL(n);
            return r.searchParams.append(e, t), r.href
        } catch (e) {
            return n + (n.includes("?") ? "&" : "?") + "key=" + t
        }
    }

    function nn(n) {
        return {
            _USE_CASE: n.experienceId,
            _USE_CASE_VARIANT: n.variantId,
            _USE_CASE_VERSION: n.version,
            _USE_CASE_AUDIENCES: I(function() {
                return window.loomi_ctx.audiences.join("|")
            }, ""),
            _USE_CASE_GA: n.gaExperienceName,
            _USE_CASE_GA_VARIANT: n.gaVariantName
        }
    }
    var en = "theme_test_redirect_back_to_main",
        tn = function(n) {
            return n.toLowerCase().startsWith("utm")
        };

    function rn() {
        return I(function() {
            return window.Shopify.designMode
        }, !1)
    }
    var on = function(n, e) {
        I(function() {
            return !0 === window.visually.flags["sdk-disable-dynamic-height-strategy"]
        }, !1) || n && function(n, e, t) {
            for (var r = n, i = 0; r.parentElement && i < 10;) t(r.parentElement), r = r.parentElement, i += 1
        }(n, 0, function(n) {
            var e, t = n.style.height;
            (e = t) && "" !== e && (n.style.removeProperty("height"), n.style.minHeight = t)
        })
    };

    function un(n, e, t, r) {
        if (!document.body.contains(r)) {
            var i = document.querySelector(t);
            return e(), n(), {
                element: i,
                isDetached: !0
            }
        }
        return {
            isDetached: !1
        }
    }

    function cn(n) {
        if (!I(function() {
                return window.visually.flags["visibility-redo"]
            })) return document.querySelector(n);
        for (var e = document.querySelectorAll(n), t = 0; t < e.length; t++) {
            var r = e.item(t);
            if (an(r)) return r
        }
        return I(function() {
            return e[0]
        })
    }

    function an(n) {
        try {
            if (!I(function() {
                    return window.visually.flags["visibility-redo"]
                })) return !0;
            if (!n) return !1;
            var e = n.getBoundingClientRect(),
                t = getComputedStyle(n);
            return !I(function() {
                return "none" == t.display || "0" == t.opacity || "hidden" == t.visibility || e.width <= 5 && e.height <= 5 || "none" == n.style.display || "0" == n.style.opacity || "hidden" == n.style.visibility
            })
        } catch (n) {
            return !0
        }
    }
    var sn, fn = "visually",
        ln = "widgets";
    window.IntersectionObserver && (sn = new IntersectionObserver(function(n, e) {
        n.forEach(function(n) {
            if (n.isIntersecting) {
                var t = n.target;
                (function(n) {
                    var e = n.getAttribute("lmw"),
                        t = n.getAttribute(U);
                    if (e && t) {
                        var r = e + t;
                        return S(function() {
                            return I(function() {
                                return !!window[fn][ln][r]
                            }) && I(function() {
                                return !!window.preact
                            })
                        }, 50, 500).then(function() {
                            I(function() {
                                return window[fn][ln][r]("#" + n.id)
                            })
                        }), !0
                    }
                    return !1
                })(t) && e.unobserve(t)
            }
        })
    }, {
        root: null,
        rootMargin: window.vslyDeferWidgetsMargin || "100px",
        threshold: .1
    }));
    var dn = "vsly-orig-sel";

    function vn(n, e) {
        try {
            var t = n()
        } catch (n) {
            return e(n)
        }
        return t && t.then ? t.then(void 0, e) : t
    }
    var mn = function(n) {
        try {
            return Promise.resolve(vn(function() {
                return Promise.resolve(S(function() {
                    return !!I(function() {
                        return document.querySelector(n)
                    })
                }, 250, 100)).then(function() {
                    return Promise.resolve(document.querySelector(n))
                })
            }, function(n) {
                return Promise.reject(n)
            }))
        } catch (n) {
            return Promise.reject(n)
        }
    };

    function hn(n, e, t) {
        var r = e.extra;
        return t && t >= 3 ? void 0 !== r && !!I(function() {
            return n.childNodes[r]
        }) : !!r && !!I(function() {
            return n.childNodes[r]
        })
    }
    var pn, wn = function(n) {
            try {
                return _n() ? Promise.resolve(!0) : (I(function() {
                    try {
                        return Promise.resolve(S(function() {
                            return !!document && !!document.head
                        }, 10, 2e3)).then(function() {
                            var n = document.head || document.getElementsByTagName("head")[0];
                            if (!n.querySelector("#" + w)) {
                                var e = document.createElement("style");
                                e.id = w, e.appendChild(document.createTextNode("#preview-bar-iframe,#PBarNextFrameWrapper,#PBarNextFrame { display: none !important;}")), n.appendChild(e)
                            }
                        })
                    } catch (n) {
                        return Promise.reject(n)
                    }
                }), Promise.resolve(kn()).then(function(e) {
                    var t = !In(e),
                        r = I(function() {
                            return !window.loomi_ctx.testedThemes.includes(e.id)
                        });
                    return !(!t || !r) || En(e, n)
                }))
            } catch (n) {
                return Promise.reject(n)
            }
        },
        yn = function(n) {
            var e = An();
            return e.searchParams.append("preview_theme_id", "" + (n || "")), e
        },
        gn = function() {
            var n = "vsly-tts";
            if (!Pn(n)) {
                Sn();
                var e = yn("");
                e.searchParams.append(n, "1"), document.body.style.opacity = 0, location.replace(e.href)
            }
        },
        _n = function() {
            var n = "vsly_disableThemeTest",
                e = Pn("disableThemeTest") || !!sessionStorage.getItem(n);
            return e && sessionStorage.setItem(n, "1"), rn() || e
        },
        Sn = function() {
            return [sessionStorage, localStorage].forEach(function(n) {
                return n.removeItem(z)
            })
        },
        En = function(n, e) {
            return n.id === e || In(n) && !e
        },
        In = function(n) {
            return "main" === n.role
        },
        bn = function(n) {
            return n.getItem(z)
        },
        Pn = function(n) {
            return I(function() {
                return An().searchParams.has(n)
            })
        },
        An = function() {
            return I(function() {
                return new URL(window.location.href)
            })
        },
        kn = function() {
            try {
                return Promise.resolve(S(function() {
                    return I(function() {
                        return window.Shopify.theme.id > 0
                    })
                }, 20, 150)).then(function() {
                    return window.Shopify.theme
                })
            } catch (n) {
                return Promise.reject(n)
            }
        };

    function Cn() {
        j.filter(function(n) {
            return !n.isApplied
        }).forEach(function(n) {
            try {
                var e = I(function() {
                    return document.body.querySelector(n.selector)
                });
                if (!e) return void
                function(n, e, t, r, i) {
                    void 0 === r && (r = 100), void 0 === i && (i = 10);
                    var o = !!e,
                        u = I(function() {
                            return B[n]
                        }) || 0;
                    !o && J && u < i && (J = !1, B[n] = (I(function() {
                        return B[n]
                    }) || 0) + 1, setTimeout(function() {
                        try {
                            t()
                        } catch (e) {
                            q("failed to run setTimeout on refreshAllElementsSets", n, e)
                        }
                        J = !0
                    }, r + 50 * u))
                }(n.selector, e, Cn, 100, 10);
                if (L.has(n.id)) return;
                var t = xn(n, e);
                t && (L.set(n.id, t), n.isApplied = !0)
            } catch (e) {
                ! function() {
                    var n;
                    R() && (n = console).warn.apply(n, ["loomi-editor"].concat([].slice.call(arguments)))
                }("failed to resolve command from mutation request with exception.", e, n)
            }
        }), On()
    }

    function xn(n, e) {
        if ("replace" === n.kind) return function(n, e, t, r) {
            var i = !1,
                o = t.outerHTML;
            return {
                id: n,
                isApplied: function() {
                    return i
                },
                kind: "replace",
                do: function() {
                    i || t.outerHTML !== r && (t = N(t, r), on(t), i = !0)
                },
                undo: function() {
                    i && t.outerHTML !== o && (t = N(t, o), i = !1)
                },
                redoIfNeeded: function() {
                    return !1
                },
                setDebugId: function(n) {
                    return n
                }
            }
        }(n.id, 0, e, n.value);
        if ("appendBefore" === n.kind || "appendAfter" === n.kind) return function(n, e, t, r) {
            var i = !1,
                o = document.querySelector(e),
                u = document.createElement("div"),
                c = function() {
                    i || ("appendBefore" === r && (o = document.querySelector(e), I(function() {
                        return o.parentNode.insertBefore(u, o)
                    }), on(o), u = N(u, t), i = !0), "appendAfter" === r && (i || ((o = document.querySelector(e)).nextSibling ? (I(function() {
                        return o.parentNode.insertBefore(u, o.nextSibling)
                    }), on(o)) : (I(function() {
                        return o.parentNode.appendChild(u)
                    }), on(o)), u = N(u, t), i = !0)), i = !0)
                },
                a = function() {
                    i && (u.remove(), i = !1)
                };
            return {
                id: n,
                isApplied: function() {
                    return i
                },
                kind: r,
                do: c,
                undo: a,
                redoIfNeeded: function() {
                    var n = un(c, a, e, o);
                    return n.element && (o = n.element), n.isDetached
                },
                setDebugId: function(n) {
                    return n
                }
            }
        }(n.id, n.selector, n.value, n.kind);
        if ("appendCss" === n.kind) return function(n, e, t) {
            var r = !1,
                i = document.querySelector(e),
                o = document.createElement("style"),
                u = function() {
                    r || (o.innerHTML = t, document.head.appendChild(o), r = !0)
                },
                c = function() {
                    r && (o.remove(), r = !1)
                };
            return {
                id: n,
                kind: "appendCss",
                isApplied: function() {
                    return r
                },
                do: u,
                undo: c,
                redoIfNeeded: function() {
                    var n = un(u, c, e, i);
                    return n.element && (i = n.element), n.isDetached
                },
                setDebugId: function(n) {
                    return n
                }
            }
        }(n.id, n.selector, n.value);
        if ("appendJs" === n.kind) return function(n, e, t, r, i) {
            var o = !1,
                u = document.querySelector(e),
                c = document.createElement("script");
            c.setAttribute("type", "application/javascript");
            var a = function() {
                    o || (c.innerHTML = function(n, e) {
                        return n && e ? '(function (){\n    const _USE_CASE = "' + e.experienceId + '";\n    const _USE_CASE_VARIANT = "' + e.variantId + '";\n    const _USE_CASE_VERSION = ' + I(function() {
                            return e.version || 0
                        }, 0) + ';\n    const _USE_CASE_AUDIENCES = "' + I(function() {
                            return window.loomi_ctx.audiences.join("|")
                        }, "") + '";\n    const _USE_CASE_GA = "' + I(function() {
                            return e.gaExperienceName.replace(/"/g, '\\"')
                        }, e.gaExperienceName) + '";\n    const _USE_CASE_GA_VARIANT = "' + I(function() {
                            return e.gaVariantName.replace(/"/g, '\\"')
                        }, e.gaVariantName) + '";\n    const _USE_CASE_CTX = {_USE_CASE,_USE_CASE_VARIANT,_USE_CASE_VERSION,_USE_CASE_AUDIENCES,_USE_CASE_GA,_USE_CASE_GA_VARIANT};\n    ' + n + "\n  })()" : n
                    }(t, i), document.body.appendChild(c), o = !0)
                },
                s = function() {
                    o && (c.remove(), o = !1)
                };
            return {
                id: n,
                kind: "appendJs",
                isApplied: function() {
                    return o
                },
                do: a,
                undo: s,
                redoIfNeeded: function() {
                    var n = un(a, s, e, u);
                    return n.element && (u = n.element), n.isDetached
                },
                setDebugId: function(n) {
                    return n
                }
            }
        }(n.id, n.selector, n.value, 0, n.options);
        if ("appendFont" === n.kind) {
            var t = JSON.parse(n.value);
            if (t && t.family && t.weights) return function(n, e, t) {
                t = t || n;
                var r, i, o = !1,
                    u = document.createElement("link"),
                    c = (i = e.weights, (r = e.family).toLowerCase().includes("jetbrains") && (r = "JetBrains Mono"), "https://fonts.googleapis.com/css2?family=" + encodeURIComponent(r) + ":wght@" + I(function() {
                        return i.join(";")
                    }) + "&display=block");
                return u.setAttribute("href", c), u.setAttribute("rel", "stylesheet"), {
                    id: n,
                    isApplied: function() {
                        return o
                    },
                    kind: "appendFont",
                    do: function() {
                        o || (document.head.appendChild(u), o = !0)
                    },
                    undo: function() {
                        o && (u.remove(), o = !1)
                    },
                    redoIfNeeded: function() {
                        return !1
                    }
                }
            }(n.id, t, n.id)
        } else {
            if ("compound" === n.kind) {
                var r = n.value.map(function(t) {
                    return t.options = n.options, xn(t, e)
                }).filter(function(n) {
                    return n
                });
                return function(n, e, t) {
                    var r = !1;
                    return {
                        id: n,
                        isApplied: function() {
                            return r
                        },
                        kind: "compound",
                        do: function() {
                            r || (e.filter(function(n) {
                                return !n.isApplied()
                            }).forEach(function(n) {
                                n.setDebugId && n.setDebugId(t), n.do()
                            }), r = !0)
                        },
                        undo: function() {
                            r && (e.filter(function(n) {
                                return n.isApplied()
                            }).reverse().forEach(function(n) {
                                return n.undo()
                            }), r = !1)
                        },
                        redoIfNeeded: function() {
                            return e.map(function(n) {
                                return n.redoIfNeeded()
                            }).filter(function(n) {
                                return n
                            }).length > 0
                        }
                    }
                }(n.id, r, n.id)
            }
            if ("widget" === n.kind) {
                var i = I(function() {
                        return n.block.value
                    }),
                    o = I(function() {
                        return i.env.sectionId.substring(1)
                    }, n.id);
                return function(n, e, t, r, i, o, u) {
                    void 0 === u && (u = "");
                    var a = !1,
                        s = "vslyp-" + e,
                        f = null,
                        l = null,
                        d = [],
                        v = function() {
                            a || (function(n, e) {
                                var t = n + e,
                                    r = "vslyw-" + t;
                                if (!document.getElementById(r)) {
                                    var i = document.createElement("script");
                                    i.id = r, i.type = "text/javascript";
                                    var o = I(function() {
                                            return window.visually.flags["bunny-cdn"]
                                        }),
                                        u = k();
                                    i.src = "https://" + (o ? "visually-sdk.b-cdn.net" : u) + "/widgets/" + t + ".js", document.head.appendChild(i)
                                }
                            }(r, u), "replace" === n ? p() : w(), $() && sn || m(), a = !0)
                        },
                        m = function() {
                            var n = r + u;
                            S(function() {
                                return I(function() {
                                    return !!window[fn][ln][n]
                                }) && I(function() {
                                    return !!window.preact
                                })
                            }, 50, 500).then(function() {
                                on(f), I(function() {
                                    return window[fn][ln][n]("#" + e)
                                })
                            })
                        },
                        h = function() {
                            if (a) {
                                l && l.remove();
                                var e = document.getElementById(s);
                                if (e && e.remove(), "replace" === n && f && f.children && f.children.length > 0)
                                    for (var t, r = 0, i = c(f.children); !(t = i()).done;) t.value.style.display = d[r], r += 1;
                                a = !1
                            }
                        },
                        p = function() {
                            if (f = cn(t)) {
                                if (d = [], f.children && f.children.length > 0)
                                    for (var n, e = c(f.children); !(n = e()).done;) {
                                        var r = n.value;
                                        r && !r.getAttribute("preact") && (d.push(r.style.display), r.style.display = "none")
                                    }
                                y(), f.appendChild(l), $() && sn && sn.observe(l)
                            } else q("vsly", "failed to find element with selector: " + t + " when trying to replace with widget")
                        },
                        w = function() {
                            (f = cn(t)) ? (y(), f.insertAdjacentElement("appendBefore" === n ? "beforebegin" : "afterend", l), $() && sn && sn.observe(l)) : q("vsly", "failed to find element with selector: " + t + " when trying to append widget")
                        },
                        y = function() {
                            if (!(l = document.getElementById(e))) {
                                (l = document.createElement("section")).style.all = "unset", l.style.width = "100%", l.setAttribute("preact", "1"), l.setAttribute("lmw", r), l.setAttribute(U, u), l.id = e;
                                var n = document.createElement("script");
                                n.id = s, n.setAttribute("type", "text/props"), n.innerHTML = JSON.stringify(i), I(function() {
                                    return document.body.appendChild(n)
                                })
                            }
                        };
                    return {
                        id: e,
                        isApplied: function() {
                            return a
                        },
                        kind: "widget",
                        do: v,
                        undo: h,
                        redoIfNeeded: function() {
                            var n = un(v, h, t, f);
                            return n.element && (f = n.element), n.isDetached
                        }
                    }
                }(i.htmlKind, o, n.selector, i.widgetId, i.env, 0, i.version)
            }
            if ("moveElem" === n.kind) {
                var u = I(function() {
                    return n.block.value
                });
                return function(n, e, t, r) {
                    var i = !1,
                        o = {
                            display: ""
                        },
                        u = null,
                        c = null,
                        a = function() {
                            i || S(function() {
                                return u = document.querySelector(e), c = document.querySelector(t), !!u && !!c
                            }, 50, 500).then(function() {
                                u = document.querySelector(e), c = document.querySelector(t), s()
                            })
                        },
                        s = function() {
                            c && u && (o = {
                                display: c.style.display,
                                parentNode: u.parentElement,
                                nextSib: u.nextElementSibling,
                                prevSib: u.previousElementSibling
                            }, "appendBefore" === r ? c.insertAdjacentElement("beforebegin", u) : "appendAfter" === r ? c.insertAdjacentElement("afterend", u) : "replace" === r && (c.style.display = "none!important", c.insertAdjacentElement("afterend", u)), u.setAttribute(dn, e), i = !0)
                        };
                    return {
                        id: n,
                        isApplied: function() {
                            return i
                        },
                        kind: "moveElem",
                        do: a,
                        undo: function() {
                            i && c && u && (o && o.prevSib ? o.prevSib.insertAdjacentElement("afterend", u) : o && o.nextSib ? o.nextSib.insertAdjacentElement("beforebegin", u) : o && o.parentNode && o.parentNode.appendChild(u), "replace" === r && (c.style.display = o.display), u.removeAttribute(dn), i = !1)
                        },
                        redoIfNeeded: function() {
                            return !(I(function() {
                                return u.hasAttribute(dn)
                            }) && document.body.contains(u) || (i = !1, a(), 0))
                        }
                    }
                }(n.id, n.selector, u.destSelector, I(function() {
                    return u.htmlKind
                }))
            }
            if ("automation" === n.kind) return l = I(function() {
                return n.block.value
            }).steps, d = !1, {
                id: "automation-" + (new Date).getDate(),
                kind: "automation",
                isApplied: function() {
                    return d
                },
                do: function() {
                    if (!d) {
                        d = !0;
                        try {
                            l.sort(function(n, e) {
                                return n.order - e.order
                            }).map(function(n) {
                                switch (n.kind) {
                                    case "click":
                                        return function() {
                                            return function(n) {
                                                try {
                                                    return Promise.resolve(vn(function() {
                                                        return M("fake-click", "about to click on:", n.selector), Promise.resolve(mn(n.selector)).then(function(n) {
                                                            return n && n.click(), Promise.resolve()
                                                        })
                                                    }, function(n) {
                                                        return Promise.reject(n)
                                                    }))
                                                } catch (n) {
                                                    return Promise.reject(n)
                                                }
                                            }(n)
                                        };
                                    case "type":
                                        return function() {
                                            return function(n) {
                                                try {
                                                    return Promise.resolve(vn(function() {
                                                        return M("fake-click", "about to type on:", n.selector, "with text: ", n.data), Promise.resolve(mn(n.selector)).then(function(e) {
                                                            var t = I(function() {
                                                                return Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set
                                                            });
                                                            I(function() {
                                                                return t.call(e, n.data || "")
                                                            });
                                                            var r = new Event("input", {
                                                                bubbles: !0
                                                            });
                                                            return e.dispatchEvent(r), Promise.resolve()
                                                        })
                                                    }, function(n) {
                                                        return Promise.reject(n)
                                                    }))
                                                } catch (n) {
                                                    return Promise.reject(n)
                                                }
                                            }(n)
                                        };
                                    case "scroll":
                                        return function() {
                                            return function(n) {
                                                try {
                                                    return Promise.resolve(vn(function() {
                                                        return M("fake-click", "about to scroll to:", n.selector), Promise.resolve(mn(n.selector)).then(function(n) {
                                                            return n.scrollIntoView(!0), Promise.resolve()
                                                        })
                                                    }, function(n) {
                                                        return Promise.reject(n)
                                                    }))
                                                } catch (n) {
                                                    return Promise.reject(n)
                                                }
                                            }(n)
                                        };
                                    case "wait":
                                        return function() {
                                            return function(n) {
                                                try {
                                                    try {
                                                        return M("fake-click", "about to wait for: " + n.data + "ms"), Promise.resolve(new Promise(function(e) {
                                                            setTimeout(function() {
                                                                return e()
                                                            }, I(function() {
                                                                return n.data
                                                            }) || 1e3)
                                                        }))
                                                    } catch (n) {
                                                        return Promise.reject(n)
                                                    }
                                                } catch (n) {
                                                    return Promise.reject(n)
                                                }
                                            }(n)
                                        };
                                    default:
                                        return function() {
                                            return Promise.resolve()
                                        }
                                }
                            }).reduce(function(n, e) {
                                return n.then(function(n) {
                                    return e()
                                })
                            }, Promise.resolve()).then()
                        } catch (n) {
                            q("failed to run automation with exception:", n)
                        }
                    }
                },
                undo: function() {},
                redoIfNeeded: function() {
                    return !1
                }
            };
            if ("visualEdit" === n.kind) {
                var a = I(function() {
                    return n.block.value
                });
                return function(n, e) {
                    var t = !1,
                        r = {},
                        i = function(n, e, t) {
                            void 0 === t && (t = !0);
                            var i = e.subChanges.map(function(t) {
                                switch (t.kind) {
                                    case "text":
                                        return function(n, e, t) {
                                            if (!n) return function() {};
                                            var r = e.extra;
                                            if (hn(n, e, t)) {
                                                var i = n.childNodes[r].textContent;
                                                return n.childNodes[r].textContent = e.value,
                                                    function() {
                                                        return n.childNodes[r].textContent = i
                                                    }
                                            }
                                            var o = n.textContent;
                                            return n.textContent = e.value,
                                                function() {
                                                    return n.textContent = o
                                                }
                                        }(n, t, e.version);
                                    case "style":
                                        return function(n, e) {
                                            if (!n) return function() {};
                                            var t = I(function() {
                                                return n.style[e.key]
                                            }, null);
                                            return n.style.setProperty(e.key, e.value, "important"),
                                                function() {
                                                    return n.style.setProperty(e.key, t)
                                                }
                                        }(n, t);
                                    case "image":
                                        return function(n, e) {
                                            if (!n || !n.removeAttribute || !n.getAttribute) return function() {};
                                            var t = n.getAttribute("srcset") || "";
                                            n.removeAttribute("srcset");
                                            var r = I(function() {
                                                return n.src
                                            }, void 0);
                                            return n.src = e.value,
                                                function() {
                                                    n.setAttribute("srcset", t), n.src = r
                                                }
                                        }(n, t);
                                    case "video":
                                        return function(n, e) {
                                            if (!n || !n.setAttribute) return function() {};
                                            var t = n.innerHTML;
                                            n.innerHTML = "";
                                            var r = n.getAttribute("src") || "";
                                            return n.setAttribute("src", e.value),
                                                function() {
                                                    n.innerHTML = t, n.setAttribute("src", r)
                                                }
                                        }(n, t);
                                    case "attr":
                                        return function(n, e) {
                                            if (!n || !n.setAttribute || !n.getAttribute) return function() {};
                                            var t = n.getAttribute(e.key);
                                            return n.setAttribute(e.key, e.value),
                                                function() {
                                                    return t ? n.setAttribute(e.key, t) : n.removeAttribute(e.key)
                                                }
                                        }(n, t)
                                }
                            });
                            t && (r[e.selector] = {
                                ve: e,
                                elem: n,
                                reverts: i
                            })
                        };
                    return {
                        id: n,
                        kind: "visualEdit",
                        isApplied: function() {
                            return t
                        },
                        do: function() {
                            t || (t = !0, e.forEach(function(n) {
                                S(function() {
                                    return !!document.querySelector(n.selector)
                                }, 250, 300).then(function() {
                                    var e = document.querySelector(n.selector);
                                    i(e, n)
                                })
                            }))
                        },
                        undo: function() {
                            t && (t = !1, Object.values(r).forEach(function(n) {
                                return n.reverts.forEach(function(n) {
                                    return n()
                                })
                            }), r = {})
                        },
                        redoIfNeeded: function() {
                            if (!t) return !1;
                            var n = !1;
                            return Object.values(r).forEach(function(e) {
                                n = document.body.contains(e.elem) ? function(n, e) {
                                    return n.ve.subChanges.forEach(function(t, r) {
                                        t.value !== function(n, e, t) {
                                            switch (e.kind) {
                                                case "text":
                                                    return function(n, e, t) {
                                                        var r = e.extra;
                                                        return hn(n, e, t) ? n.childNodes[r].textContent : n.textContent
                                                    }(n, e, t);
                                                case "attr":
                                                    return function(n, e) {
                                                        return n.getAttribute(e.key)
                                                    }(n, e);
                                                case "style":
                                                    return function(n, e) {
                                                        return I(function() {
                                                            return n.style[e.key]
                                                        }, null)
                                                    }(n, e);
                                                case "image":
                                                case "video":
                                                    return function(n) {
                                                        return n.src
                                                    }(n)
                                            }
                                        }(n.elem, t, n.ve.version) && (I(function() {
                                            return n.reverts[r]()
                                        }), i(n.elem, {
                                            selector: n.ve.selector,
                                            subChanges: [t]
                                        }, !1), e = !0)
                                    }), e
                                }(e, n) : function(n) {
                                    n.reverts.forEach(function(n) {
                                        return n()
                                    });
                                    var e = document.querySelector(n.ve.selector);
                                    return e && i(e, n.ve), !0
                                }(e)
                            }), n
                        }
                    }
                }(n.id, a.changes)
            }
            if ("pageRedirect" === n.kind) {
                var s = I(function() {
                    return n.block.value
                });
                if (s) return function(n, e, t) {
                    return {
                        id: n,
                        kind: "pageRedirect",
                        isApplied: function() {
                            return !1
                        },
                        do: function() {
                            X(nn(t), e.destUrl, e.redirectAfter, !0 === e.retainQueryParams, e.stickinessMode)
                        },
                        undo: function() {},
                        redoIfNeeded: function() {
                            return !1
                        },
                        setDebugId: function(n) {
                            return ""
                        }
                    }
                }(n.id, s, n.options)
            } else if ("themeTest" === n.kind) {
                var f = I(function() {
                    return n.block.value
                });
                if (f) return function(n, e, t) {
                    var r = function() {
                        return !1
                    };
                    return {
                        id: n,
                        kind: "themeTest",
                        isApplied: r,
                        do: function() {
                            return function(n, e, t) {
                                void 0 === t && (t = 10);
                                try {
                                    return Q("kill-theme-testing") ? Promise.resolve() : Promise.resolve(wn(e)).then(function(r) {
                                        r || (function(n, e) {
                                            var t = n._USE_CASE !== en;
                                            (function(n) {
                                                return !!n
                                            })(e) && t && [sessionStorage, localStorage].forEach(function(n) {
                                                return n.setItem(z, "1")
                                            })
                                        }(n, e), X(n, yn(e).href, t, !0, "session"))
                                    })
                                } catch (n) {
                                    return Promise.reject(n)
                                }
                            }(nn(t), e.targetThemeId)
                        },
                        undo: r,
                        redoIfNeeded: r,
                        setDebugId: r
                    }
                }(n.id, f, n.options)
            }
        }
        var l, d
    }
    var Tn, Nn = !1;

    function On() {
        Nn || (Nn = !0, requestAnimationFrame(jn))
    }

    function jn() {
        L.forEach(function(n) {
            try {
                n.isApplied() ? n.redoIfNeeded() : n.do()
            } catch (e) {
                q("failed to apply mutation command with exception:", e, n)
            }
        }), Nn = !1
    }

    function Ln(n) {
        try {
            var e = L.get(n),
                t = e && e.undo();
            L.delete(n);
            var r = j.findIndex(function(e) {
                return e.id == n
            });
            return (i = I(function() {
                return j[r].selector
            })) && I(function() {
                return B[i]
            }) && delete B[i], j.splice(r, 1), On(), t
        } catch (n) {
            return
        }
        var i
    }

    function Un(n) {
        return "div" === n.selector && (n.selector = "body div"), j.push(n), Cn(), {
            revert: function() {
                return Ln(n.id)
            },
            mutationId: n.id
        }
    }

    function Dn() {
        var n = I(function() {
            return window.loomi_ctx.cart
        });
        if (n) return n;
        var e = localStorage.getItem("loomi-cart");
        if (e) try {
            return JSON.parse(e)
        } catch (n) {}
    }! function(n) {
        n.CART_CHANGE = "CART_CHANGE", n.LOYALTY_CHANGE = "LOYALTY_CHANGE"
    }(Tn || (Tn = {}));
    var Rn = p(function(n, e) {
        var t = function(n, e) {
            var t = new Event(Y);
            return t.key = n, t.value = e, t
        }(n, e);
        document.dispatchEvent(t), console.debug("Targeting has changed:", t)
    }, 80);

    function Mn(n) {
        return I(function() {
            return n.items.map(function(n) {
                return I(function() {
                    return n.selling_plan_allocation.selling_plan.name.toLowerCase()
                })
            }).filter(function(n) {
                return !!n
            })
        }, [])
    }
    var qn = function(n, e) {
        try {
            var t, r = this.cart;
            if (!r) return Promise.resolve(0);
            if (!I(function() {
                    return window.visually.flags["currency-aware-client-targeting"]
                })) return Promise.resolve(0);
            var i = function() {
                try {
                    var i = r.currency === n ? (t = 1, r.total_price / 100) : function() {
                        if (e) return Promise.resolve(S(function() {
                            return !!window.loomi_ctx.Currency
                        }, 100, 10)).then(function() {
                            var e = (window.loomi_ctx.Currency.convert(r.total_price, r.currency, n) || 0) / 100;
                            return t = 1, e
                        })
                    }()
                } catch (n) {
                    return
                }
                return i && i.then ? i.then(void 0, function() {}) : i
            }();
            return Promise.resolve(i && i.then ? i.then(function(n) {
                return t ? n : 0
            }) : t ? i : 0)
        } catch (n) {
            return Promise.reject(n)
        }
    };

    function Jn(n, e) {
        function t(n) {
            return n.toLowerCase()
        }
        var r = {
            "==": function(e) {
                return t(e) == t(n)
            },
            "!=": function(e) {
                return t(e) != t(n)
            },
            contains: function(e) {
                return t(e).includes(t(n))
            },
            matches: function(e) {
                return new RegExp(n).test(e)
            }
        };
        return !!this.CartSubs().find(function(n) {
            return r[e](n)
        })
    }

    function Bn() {
        return Mn(this.cart)
    }

    function Vn(n) {
        var e = this.cart;
        return !!I(function() {
            return e.items.find(function(e) {
                return e.handle === n
            })
        })
    }

    function Hn(n) {
        var e = this.cart;
        return !!I(function() {
            return e.items.find(function(e) {
                return !!e.tags && e.tags.includes(n)
            })
        })
    }

    function Fn(n) {
        var e = this.cart;
        if (e.items.length <= 0) return !1;
        var t = I(function() {
            return e.items.filter(function(e) {
                return !!e.tags && e.tags.includes(n)
            })
        });
        return I(function() {
            return t.length === e.items.length
        }, !1)
    }

    function Gn(n) {
        var e = this.cart;
        return !!I(function() {
            return e.items.find(function(e) {
                return !!e.collections && e.collections.includes(n)
            })
        })
    }

    function Kn() {
        return !0 === I(function() {
            return window.loomi_ctx.loyalty.isMember
        }, !1)
    }

    function Yn() {
        return I(function() {
            return window.loomi_ctx.loyalty.pointsBalance
        }, 0)
    }

    function Wn() {
        return I(function() {
            return window.loomi_ctx.loyalty.earnedPoints
        }, 0)
    }

    function zn() {
        var n = I(function() {
            return window.loomi_ctx.sessionProducts
        });
        if (n) return n;
        var e = localStorage.getItem("loomi_session_products"),
            t = e ? JSON.parse(e) : [];
        return I(function() {
            return t.filter(function(n) {
                return "" != n.handle
            }).reverse().slice(0, 20)
        })
    }

    function Qn(n) {
        return JSON.parse(localStorage.getItem(n) || "[]")
    }

    function $n(n, e, t, r) {
        n = n || [], e = e || [];
        var i = I(function() {
                return e.filter(function(e) {
                    return !n.find(t(e))
                })
            }) || [],
            o = [].concat(n, i).slice(0, 25);
        return o.length > 0 && localStorage.setItem(r, JSON.stringify(o)), o
    }

    function Xn() {
        return JSON.parse(localStorage.getItem("loomi_purchased_products") || "[]")
    }
    var Zn, ne, ee = "vsly_params_history",
        te = "vsly_visited_pages",
        re = function(n) {
            try {
                var e = n.matches ? ne.MOBILE : ne.DESKTOP,
                    t = function() {
                        if (Zn != e) {
                            M("device-listener", "device changed to " + e + " from " + Zn), window.loomi_ctx.deviceOverride = e === ne.MOBILE ? "m" : "d", Zn = e;
                            var n = I(function() {
                                    return window.visually.reload
                                }),
                                t = function() {
                                    if (n) return Promise.resolve(n()).then(function() {});
                                    q("device-listener", "can't find reload function")
                                }();
                            if (t && t.then) return t.then(function() {})
                        }
                    }();
                return Promise.resolve(t && t.then ? t.then(function() {}) : void 0)
            } catch (n) {
                return Promise.reject(n)
            }
        };

    function ie() {
        if (I(function() {
                return !0 === window.visually.flags["reload-on-device-changed"]
            })) {
            var n = I(function() {
                return window.vslyDesktopBreakpoint
            }) || 960;
            n <= 0 && (n = 960);
            var e = window.matchMedia("(max-width: " + n + "px)");
            e.removeEventListener("change", re), e.addEventListener("change", re)
        }
    }! function(n) {
        n.MOBILE = "MOBILE", n.DESKTOP = "DESKTOP"
    }(ne || (ne = {}));
    var oe = function() {
            return edgetag("getUserId")
        },
        ue = "lmi_type",
        ce = "lmi_from",
        ae = "lmi_class",
        se = "lmi_utm_data",
        fe = {
            utm_source: "source",
            utm_medium: "medium",
            utm_campaign: "campaign",
            utm_term: "term",
            utm_content: "content"
        },
        le = function(n, e) {
            void 0 === e && (e = 3);
            for (var t = n, r = 0; r < e; r++) try {
                var i = decodeURIComponent(t);
                if (i === t) break;
                t = i
            } catch (n) {
                break
            }
            return t
        };

    function de() {
        var n, e, t, r = (n = function(n) {
            if (function(n) {
                    return !n || "{}" === JSON.stringify(n)
                }(n)) return null;
            var e = {};
            return n.campaign && (e.campaign = n.campaign), n.medium && (e.medium = n.medium), n.source && (e.source = n.source), n.term && (e.term = n.term), n.content && (e.content = n.content), e
        }(I(function() {
            return function(n) {
                void 0 === n && (n = window.location.search);
                var e = {
                    utm: {},
                    lmi_params: {}
                };
                return I(function() {
                    return new URLSearchParams(n)
                }).forEach(function(n, t) {
                    if (n) {
                        var r = fe[t],
                            i = le(n);
                        r ? e.utm[r] = i : function(n) {
                            return I(function() {
                                return [ae, ce, ue].includes(n)
                            })
                        }(t) && (e.lmi_params[t] = i)
                    }
                }), e
            }().utm
        })), e = [], null != (t = localStorage.getItem(se)) && (e = [].concat(JSON.parse(t)).slice(0, 20)), n && (n.ts = g(), e = [n].concat(e)), e);
        return localStorage.setItem(se, JSON.stringify(r)), r
    }

    function ve() {
        var n = de();
        return I(function() {
            return n.filter(function(n) {
                return n.campaign
            }).reduce(function(n, e) {
                return e.ts > n.ts ? e : n
            }, n[0]).campaign
        }) || ""
    }
    var me = function(n) {
            return Promise.resolve(he()).then(function(e) {
                return new Promise(function(t, r) {
                    var i = e.transaction([we], "readonly").objectStore(we).get(n);
                    i.onerror = function(n) {
                        r("IDB e:r" + n.target.error)
                    }, i.onsuccess = function(n) {
                        t(n.target.result)
                    }
                })
            })
        },
        he = function() {
            try {
                var n = function() {
                    if (!ye) return Promise.resolve(new Promise(function(n, e) {
                        var t = indexedDB.open(pe, 1);
                        t.onerror = function(n) {
                            e("IDB e:o" + n.target.error)
                        }, t.onsuccess = function(e) {
                            n(ye = e.target.result)
                        }, t.onupgradeneeded = function(n) {
                            n.target.result.createObjectStore(we, {
                                keyPath: "id"
                            }).createIndex("id", "id", {
                                unique: !0
                            })
                        }
                    })).then(function() {})
                }();
                return Promise.resolve(n && n.then ? n.then(function() {
                    return ye
                }) : ye)
            } catch (n) {
                return Promise.reject(n)
            }
        },
        pe = "VISUALLY_IO",
        we = "VISUALLY_IO",
        ye = null;

    function ge() {
        return I(function() {
            return Dn().items.map(function(n) {
                return {
                    variantId: n.variant_id || 0,
                    quantity: n.quantity || 0,
                    productId: n.product_id || 0,
                    price: n.price || 0
                }
            })
        }) || []
    }

    function _e() {
        var n = new URL(window.location.href);
        return n.protocol + "//" + n.hostname + n.pathname
    }
    var Se = "__eventn_id";

    function Ee(n) {
        return {
            firstSeen: I(function() {
                return parseInt(n.split(".")[1])
            }, null),
            id: I(function() {
                return n.split(".")[0]
            })
        }
    }

    function Ie(n) {
        var e = n || Math.random().toString(36).substring(2, 12),
            t = Math.trunc((new Date).getTime() / 1e3);
        return {
            newId: e,
            newEpoch: t,
            value: be(e, t)
        }
    }

    function be(n, e) {
        return n + "." + e
    }
    var Pe = "vsly_vid",
        Ae = "lmi_debug";

    function ke(n) {
        return I(function() {
            return new URL(window.location.href).searchParams.get(n) || void 0
        })
    }
    var Ce = ["Roboto", "Open Sans", "Fredoka", "Fredoka", "Smooch Sans", "Rubik", "Lato", "Poppins", "Oswald", "League Spartan", "Noto Sans", "Raleway", "Merriweather", "Playfair Display", "Inter", "JetBrains Mono", "Jetbrains Mono"];

    function xe(n) {
        try {
            (function(n) {
                var e = n.flatMap(function(n) {
                    return I(function() {
                        return n.code
                    })
                }).filter(function(n) {
                    return !!n
                }).filter(function(n) {
                    return "widget" === n.kind
                }).map(function(n) {
                    return Te(n.value.env)
                }).flatMap(function(n) {
                    for (var e = Object.entries(n).filter(function(n) {
                            var e = n[0];
                            return e.includes("fontFamily") || e.includes("fontWeight")
                        }).map(function(n) {
                            return n[1]
                        }), t = [], r = function(n) {
                            t.push({
                                family: e[n],
                                weight: parseInt(I(function() {
                                    return e[n + 1]
                                }), 10) || 500
                            })
                        }, i = 0; i < e.length; i += 2) r(i);
                    return t
                }).reduce(function(n, e) {
                    var t = e.family;
                    return (n[t] || (n[t] = new Set)).add(e.weight), n
                }, {});
                return Object.entries(e).filter(function(n) {
                    return Ce.includes(n[0])
                }).map(function(n) {
                    return {
                        family: n[0],
                        weights: Array.from(n[1]).sort()
                    }
                })
            })(n).forEach(function(n) {
                return Un(T("appendFont", "div", JSON.stringify({
                    family: n.family,
                    weights: n.weights
                })))
            })
        } catch (n) {
            q("failed to install custom fonts", n)
        }
    }

    function Te(n) {
        var e = {};
        for (var t in n)
            if ("object" != typeof n[t] || Array.isArray(n[t])) e[t] = n[t];
            else {
                var r = Te(n[t]);
                for (var i in r) e[t + "." + i] = r[i]
            }
        return e
    }
    var Ne = function(n, e, t, r) {
        void 0 === t && (t = !0), void 0 === r && (r = void 0);
        try {
            var i = I(function() {
                    return window.loomi_api.addToCart
                }),
                o = function() {
                    if (i) return Promise.resolve(window.loomi_api.addToCart(n, e, t, r)).then(function() {})
                }();
            return Promise.resolve(o && o.then ? o.then(function() {}) : void 0)
        } catch (n) {
            return Promise.reject(n)
        }
    };

    function Oe() {
        var n = {},
            e = window.loomi_ctx || {};
        e.productId && (n.productId = e.productId);
        var t = I(function() {
            var n = new URL(location.href).searchParams,
                e = "variant";
            return n.has(e) && function(n) {
                var e = Number(n),
                    t = isNaN(e) ? Number(("" + n).replace(/[^\d.]+/g, "")) || void 0 : e;
                if (void 0 !== t && 0 !== t) return "" + t
            }(n.get(e))
        }) || e.variantId;
        return t && (n.variantId = t), n
    }
    var je = new G("recs_cache", 300001),
        Le = function(n, e) {
            try {
                var t = Promise.resolve([]);
                return Promise.resolve(function(r, i) {
                    try {
                        var o = function() {
                            if (!n) return t;
                            var r, i = I(function() {
                                return n.recommendationOptions
                            });
                            if (!i) return t;
                            ! function(n) {
                                var e = Oe(),
                                    t = e.productId,
                                    r = e.variantId;
                                (t || r) && (n.productId = {
                                    productId: t,
                                    variantId: r
                                })
                            }(i), i.cartItems = (r = ge(), I(function() {
                                return r.filter(function(n) {
                                    return !!n.productId
                                }).map(function(n) {
                                    return {
                                        productId: "" + n.productId,
                                        variantId: "" + n.variantId,
                                        quantity: n.quantity || 1
                                    }
                                })
                            })), i.currency = I(function() {
                                return Dn().currency || "USD"
                            }, "USD"), i.cart_total = I(function() {
                                return Dn().total_price
                            }, 0), I(function() {
                                return +Date.now() - window.loomi_ctx.last_vid_atc.ts < 5e3
                            }) && (i.last_vid_atc = window.loomi_ctx.last_vid_atc), i.respSize = I(function() {
                                return window.visually.recsPerVariant[e.variantId]
                            }), ["RECENTLY_VIEWED", "VIEWED_WITH_RECENTLY_VIEWED"].find(function(n) {
                                return Ue(i, n)
                            }) && (i.recentlyViewed = zn().filter(function(n) {
                                return !!n.productId
                            }).map(function(n) {
                                return a({
                                    productId: "" + n.productId,
                                    variantId: "" + (n.variantId || "")
                                }, n.ts ? {
                                    ts: n.ts
                                } : {})
                            }));
                            var o = Xn();
                            return o.length > 0 && (i.pastPurchases = o), (Ue(i, "CART_ITEMS") || function(n) {
                                return I(function() {
                                    return !!n.layeredRuling.find(function(n) {
                                        return "latest_added" == n.ruleCond.itemSelection
                                    })
                                })
                            }(i)) && (i.cartHistory = JSON.parse(localStorage.getItem("loomi-cart-history") || "[]")), i.userId = I(function() {
                                return window.loomi_ctx.userId
                            }, ""), e && (i.widgetContext = e), I(function() {
                                return !!window.loomi_ctx.storeAlias
                            }) && (i.storeAlias = window.loomi_ctx.storeAlias), i.locale = I(function() {
                                return window.Shopify.locale
                            }) || I(function() {
                                return window.visually.locale
                            }), i.country = I(function() {
                                return window.Shopify.country
                            }) || I(function() {
                                return window.visually.country
                            }), Promise.resolve(function(n, e) {
                                var t = I(function() {
                                        return window.loomi_api.updateRecsOpts
                                    }),
                                    r = I(function() {
                                        return t.get(function(n) {
                                            return n.widgetId + n.experienceId + n.variantId + n.sectionId
                                        }(n))(e)
                                    }, e);
                                return I(function() {
                                    return t.get(window.loomi_ctx.storeAlias)(r)
                                }, r)
                            }(e, i)).then(function(n) {
                                function e() {
                                    return I(function() {
                                        return o.products
                                    })
                                }
                                var t = function(n) {
                                        return btoa(unescape(encodeURIComponent(JSON.stringify(a({}, n)))))
                                    }(i = n),
                                    r = K(t),
                                    o = je.get(r),
                                    u = function() {
                                        if (!o) return Promise.resolve(Me(r, t)).then(function(n) {
                                            o = n, I(function() {
                                                return [De, window.loomi_api.onRecsResp].forEach(function(n) {
                                                    return n && n(o)
                                                })
                                            }), je.set(r, o)
                                        })
                                    }();
                                return u && u.then ? u.then(e) : e()
                            })
                        }()
                    } catch (n) {
                        return i(n)
                    }
                    return o && o.then ? o.then(void 0, i) : o
                }(0, function(n) {
                    return q("loomi-widget,recProducts failed:", n), t
                }))
            } catch (n) {
                return Promise.reject(n)
            }
        };

    function Ue(n, e) {
        return n.type === e || I(function() {
            return n.strategyPerSlot.find(function(n) {
                return n.strategy === e
            })
        }) || I(function() {
            return !!Object.values(n.conditions).find(function(n) {
                return n.qbProps.envKey === e
            })
        }) || I(function() {
            return !!n.layeredRuling.find(function(n) {
                return n.strategy === e || !!I(function() {
                    return n.strategyPerSlot.slots.find(function(n) {
                        return n.strategy === e
                    })
                })
            })
        })
    }

    function De(n) {
        if (Q("opt-img")) {
            var e = (t = window.innerWidth) <= 480 ? 480 : t <= 768 ? 640 : t <= 1024 ? 960 : 1280;
            n.products.forEach(function(n) {
                var t = new URL(n.image.src);
                t.searchParams.set("width", "" + Math.min(e, n.image.width || 1280)), n.image.src = t.href
            })
        }
        var t
    }
    var Re = new Map,
        Me = function(n, e) {
            if (Q("coalesce-recs") && Re.has(n)) return Re.get(n);
            var t = window.vslyNativeFetch || window.fetch,
                r = k(window.loomi_ctx.env),
                i = function() {
                    try {
                        return Promise.resolve(function(n, i) {
                            try {
                                var o = Promise.resolve(t("https://" + r + "/api/recommendations/web/public/v2/recommend?q=" + e)).then(function(n) {
                                    return Promise.resolve(n.json())
                                })
                            } catch (n) {
                                return i(!0, n)
                            }
                            return o && o.then ? o.then(i.bind(null, !1), i.bind(null, !0)) : i(!1, o)
                        }(0, function(e, t) {
                            if (Re.delete(n), e) throw t;
                            return t
                        }))
                    } catch (n) {
                        return Promise.reject(n)
                    }
                }();
            return Re.set(n, i), i
        };

    function qe(n) {
        return "vsly_pi_" + n
    }

    function Je(n) {
        return "vsly_hbt_" + n
    }

    function Be(n) {
        return "vsly_hbc_" + n
    }

    function Ve(n) {
        return Array(n).fill(0).map(function() {
            return Math.floor(10 * Math.random())
        }).join("")
    }

    function He() {
        try {
            var n = I(function() {
                return window.vslyAntiFlickerReveal
            }, void 0);
            n && n()
        } catch (n) {}
    }
    var Fe = "vslyb";

    function Ge(n) {
        return btoa(unescape(encodeURIComponent(JSON.stringify(n))))
    }
    var Ke = new Map;

    function Ye(n) {
        if ("number" == typeof n.chance && n.chance < 100) {
            var e = {
                experienceId: n.name,
                variantId: n.variant,
                storeAlias: I(function() {
                    return window.loomi_ctx.storeAlias
                }),
                anonymousId: I(function() {
                    return window.loomi_ctx.userId
                })
            };
            n.version && (e.version = n.version);
            var t = Ge(e),
                i = I(function() {
                    return window.loomi_ctx.env
                }, r.PROD),
                o = new URL(We(i).cfgUrl.replace("/allocate", "/match"));
            o.searchParams.append("q", t), fetch(o)
        }
    }

    function We(n) {
        var e = "/api/allocator/web/public/v2/allocate";
        return Qe(n) && (e = "/allocate"), {
            cfgUrl: "" + ze(n) + e
        }
    }

    function ze(n) {
        return Qe(n) ? "http://localhost:8080" : "https://" + k()
    }

    function Qe(n) {
        return [r.TEST, r.LOCAL].includes(n)
    }
    var $e = function(n, e) {
            return !!I(function() {
                return n.audiences.includes(e)
            })
        },
        Xe = function(n) {
            var e = {},
                t = $e(n, "d"),
                r = $e(n, "m");
            return t || r ? (I(function() {
                return n.experiments.filter(function(n) {
                    return !!n.code
                }).forEach(function(n) {
                    return n.code.forEach(function(r) {
                        var i = I(function() {
                                return r.value.env.general.recsCount
                            }),
                            o = I(function() {
                                return t ? i.desktop.value : i.value
                            });
                        o > (e[n.variant] || 0) && "number" == typeof o && (e[n.variant] = o)
                    })
                })
            }), e) : e
        };

    function Ze(n, e, t, r) {
        var i = e.split(","),
            o = i[0],
            u = i[1];
        return new Promise(function(e) {
            me(te).then(function(t) {
                for (var i, a = c(function(n, e, t) {
                        var r = (new Date).valueOf();
                        return (I(function() {
                            return n.visits
                        }, []) || []).filter(function(n) {
                            var i = new Date(n.ts).valueOf(),
                                o = 36e5,
                                u = parseInt(e);
                            switch (t.replaceAll('"', "")) {
                                case "hours":
                                    return i > r - u * o;
                                case "weeks":
                                    return i > r - u * o * 24 * 7;
                                case "days":
                                    return i > r - u * o * 24;
                                default:
                                    return !1
                            }
                        })
                    }(t, o, u)); !(i = a()).done;) {
                    var s = i.value;
                    if (r || ot(n)) {
                        if (et(s, n)) return void e(!0)
                    } else if (nt(s, n)) return void e(!0)
                }
                e(!1)
            })
        })
    }

    function nt(n, e) {
        return !![tt(n), it(tt(n))].find(function(n) {
            return n.includes(e)
        })
    }

    function et(n, e) {
        var t = n.search || "",
            r = tt(n) + t;
        return !![r, it(r)].find(function(n) {
            return n.includes(rt(e))
        })
    }

    function tt(n) {
        return rt(function(n) {
            var e = I(function() {
                return new URL(n)
            });
            if (!e) return n;
            var t = e.pathname.split("/");
            return /^[a-z]{2}-[a-z]{2}$/.test(t[1]) && (e.pathname = t.slice(2).join("/")), rt(e.href)
        }(n.name))
    }

    function rt(n) {
        var e = I(function() {
            return new URL(n)
        });
        return e && e.pathname.endsWith("/") ? "/" === e.pathname ? e.href.slice(0, -1) : (e.pathname = e.pathname.slice(0, -1), e.href) : n
    }

    function it(n) {
        return n.includes("/products/") && n.includes("/collections/") ? n.replace(/\/collections\/[^/]+/, "") : n
    }

    function ot(n) {
        return I(function() {
            return !!new URL(n).search
        })
    }
    var ut = function(n, e) {
            return Promise.resolve(function() {
                try {
                    var t = Promise.resolve(window.klaviyo.getGroupMembership([n])).then(function(t) {
                        var r = t.includes(n);
                        return "not in" === e ? !r : r
                    })
                } catch (n) {
                    return !1
                }
                return t && t.then ? t.then(void 0, function() {
                    return !1
                }) : t
            }())
        },
        ct = function(n) {
            try {
                return St(), wt(n) && (lt[vt(n)] = n), Promise.resolve(_t(n)).then(function(e) {
                    return e ? (ht(n), !0) : (M("exp: " + n.gaName + " not run client targeting: " + n.clientTargetingFormula + " => false"), !1)
                })
            } catch (n) {
                return Promise.reject(n)
            }
        },
        at = function(n) {
            try {
                var e = Object.entries(lt).map(function(e) {
                    var t = e[1];
                    return wt(t) && (lt[vt(t)] = t), {
                        exp: t,
                        shouldBeApplied: st(t, n),
                        hasBeenApplied: function() {
                            return !!dt[vt(t)]
                        }
                    }
                });
                return Promise.resolve(yt(e)).then(function(n) {
                    ! function(n) {
                        n.filter(function(n) {
                            return n.hasBeenApplied() && !n.shouldBeApplied
                        }).flatMap(function(n) {
                            var e = I(function() {
                                return dt[vt(n.exp)]
                            });
                            return e && delete dt[vt(n.exp)], e
                        }).forEach(function(n) {
                            I(n.revert)
                        })
                    }(n),
                    function(n) {
                        n.filter(function(n) {
                            return n.shouldBeApplied && !n.hasBeenApplied()
                        }).forEach(function(n) {
                            var e, t, r;
                            ht(n.exp), e = n.exp, t = pt, void 0 === r && (r = x()), t.has(e.variant) || (Pt(r, e), t.add(e.variant), Ye(e))
                        })
                    }(n)
                })
            } catch (n) {
                return Promise.reject(n)
            }
        },
        st = function(n, e) {
            try {
                return wt(n) ? (e.Total = qn, e.CartHasSubs = Jn, e.CartSubs = Bn, e.CartHasItem = Vn, e.CartItemHasTag = Hn, e.AllCartItemsHasTag = Fn, e.CartItemHasCollection = Gn, e.IsLoyaltyCustomer = Kn, e.LoyaltyPointsBalance = Yn, e.LoyaltyPointsEarned = Wn, e.PageVisit = Ze, e.CustomerTag = Et, e.IsGuest = It, e.KlavyioSegment = ut, Promise.resolve(new Promise(function(t) {
                    return t(new Function("\n        const c = arguments[0];\n        return " + function(n) {
                        for (var e = function(e) {
                                return I(function() {
                                    return n.includes(e)
                                })
                            }, t = 0, r = ["PageVisit", "Total"]; t < r.length; t++) {
                            var i = r[t];
                            e("c." + i) && !e("await c." + i) && (n = "( " + n.replaceAll("c." + i, "await c." + i) + " )")
                        }
                        return !e("(async ()") && e("await") ? "(async () => (" + n + "))()" : n
                    }(n.clientTargetingFormula))(e))
                }).catch(function(n) {
                    return q("client side formula err", n), !1
                }))) : Promise.resolve(!0)
            } catch (n) {
                return Promise.reject(n)
            }
        },
        ft = !1,
        lt = {},
        dt = {},
        vt = function(n) {
            return n.name + "-" + n.variant
        };

    function mt() {
        return {
            cart: Dn(),
            Total: qn,
            CartHasSubs: Jn,
            CartSubs: Bn,
            CartHasItem: Vn,
            CartItemHasTag: Hn,
            AllCartItemsHasTag: Fn,
            CartItemHasCollection: Gn,
            IsLoyaltyCustomer: Kn,
            LoyaltyPointsBalance: Yn,
            LoyaltyPointsEarned: Wn,
            PageVisit: Ze,
            CustomerTag: Et,
            IsGuest: It,
            KlavyioSegment: ut
        }
    }

    function ht(n) {
        var e, t = {
            experienceId: n.name,
            variantId: n.variant,
            gaExperienceName: n.gaName,
            gaVariantName: n.gaVariant,
            publishedAt: n.publishedAt,
            version: n.version
        };
        e = I(function() {
            return n.code.map(function(n) {
                try {
                    return function(n, e) {
                        if ("compound" === n.kind) {
                            var t = n.value,
                                r = function(n, e, t, r, i) {
                                    var o = [];
                                    return t && "" !== t && o.push(T(n, e, t)), r && "" !== r && o.push(T("appendCss", e, r)), i && "" !== i && o.push(T("appendJs", e, i)), o
                                }(t.htmlKind, n.selector, t.html, t.css, t.js),
                                i = T(n.kind, n.selector, r);
                            i.options = e;
                            var o = Un(i);
                            return o.htmlId = r[0].id, r[1] && (o.cssId = r[1].id), r[2] && (o.jsId = r[2].id), o
                        }
                        if ("widget" === n.kind) {
                            var u = T(n.kind, n.selector, "");
                            u.options = e, u.block = n;
                            var c = function(n, e) {
                                var t = I(function() {
                                    return n.block.value
                                });
                                return a({}, e, {
                                    sectionId: I(function() {
                                        return t.env.sectionId
                                    }),
                                    widgetId: I(function() {
                                        return t.widgetId
                                    }),
                                    widgetVersion: I(function() {
                                        return t.version
                                    })
                                })
                            }(u, e);
                            ! function(n, e) {
                                var t = I(function() {
                                    return n.block.value.env
                                });
                                t && Object.entries(e).forEach(function(n) {
                                    return t[n[0]] = n[1]
                                })
                            }(u, c);
                            var s = Un(u);
                            return s.htmlId = u.id, s
                        }
                        if (["pageRedirect", "themeTest"].includes(n.kind)) {
                            var f = T(n.kind, n.selector, "");
                            return f.options = e, f.block = n, Un(f)
                        }
                        if (["moveElem", "automation", "visualEdit"].includes(n.kind)) {
                            var l = T(n.kind, n.selector, "");
                            l.options = e, l.block = n;
                            var d = Un(l);
                            return d.htmlId = l.id, d
                        }
                        var v = T(n.kind, n.selector, n.value);
                        return v.options = e, Un(v)
                    }(n, t)
                } catch (n) {}
            }).filter(function(n) {
                return !!n
            })
        }, []), dt[vt(n)] = e
    }
    var pt = new Set;

    function wt(n) {
        var e = I(function() {
            return n.clientTargetingFormula
        });
        return e && "" !== e
    }
    var yt = function(n) {
            try {
                return Promise.resolve(Promise.all(n.map(function(n) {
                    try {
                        return Promise.resolve(n.shouldBeApplied).then(function(e) {
                            return a({}, n, {
                                shouldBeApplied: e
                            })
                        })
                    } catch (n) {
                        return Promise.reject(n)
                    }
                })))
            } catch (n) {
                return Promise.reject(n)
            }
        },
        gt = function(n) {
            var e = I(function() {
                    return n.key
                }),
                t = I(function() {
                    return n.value
                }),
                r = mt();
            e === Tn.CART_CHANGE ? (at(a({}, r, {
                cart: t
            })), I(function() {
                return window.loomi_ctx.maintainCartAttributes(t)
            })) : e === Tn.LOYALTY_CHANGE && at(r)
        };

    function _t(n) {
        return st(n, mt())
    }

    function St() {
        ft || l(function() {
            return document
        }).then(function() {
            document.addEventListener(Y, gt), ft = !0
        })
    }

    function Et(n, e) {
        void 0 === e && (e = "");
        var t = ["!", "not in"].some(function(n) {
                return e.includes(n)
            }),
            r = I(function() {
                return window.loomi_ctx.ctags.includes(n)
            }) || !1;
        return t ? !r : r
    }

    function It() {
        return "spa" === window.vslyIntegrationType ? Promise.resolve(I(function() {
            return !window.loomi_ctx.clientId
        })) : S(function() {
            return "object" == typeof window.__st
        }, 500, 10).then(function() {
            return !window.__st.cid
        })
    }
    var bt = function(n, e, t) {
        try {
            return Promise.resolve(t()).then(function(t) {
                !t || (Pt(e, n), wt(n) && Ye(n))
            })
        } catch (n) {
            return Promise.reject(n)
        }
    };

    function Pt(n, e) {
        return I(function() {
            return n.register(e.name, e.variant, e.gaVariant, e.gaName), n.track(i.USE_CASE, a({
                use_case: e.name,
                use_case_variant: e.variant
            }, e.version ? {
                version: e.version
            } : {}), {
                isAudience: e.isAudience,
                gaName: e.gaName,
                gaVariant: e.gaVariant
            })
        })
    }
    var At, kt = new Set,
        Ct = new Set,
        xt = new Set,
        Tt = new Set;

    function Nt(n) {
        void 0 === At && (At = new MutationObserver(Ot(n))).observe(document.body, {
            childList: !0,
            subtree: !0,
            attributes: !1,
            characterData: !1
        })
    }

    function Ot(n) {
        return function() {
            jt(kt, xt, function(e, t) {
                bt(t, n, function() {
                    return e.add(Lt(t.trigger.selector, t)), ct(t)
                })
            }), jt(Ct, Tt, function(e, t, r) {
                var i = t.trigger;
                e.add(Lt(i.selector, t)), r.addEventListener(i.name, function() {
                    return bt(t, n, function() {
                        return ct(t)
                    })
                }, {
                    once: void 0 !== i.once && i.once
                })
            })
        }
    }

    function jt(n, e, t) {
        n.forEach(function(n) {
            I(function() {
                var r = n.trigger.selector;
                document.body.querySelectorAll(r).forEach(function(i) {
                    e.has(Lt(r, n)) || t(e, n, i)
                })
            })
        })
    }

    function Lt(n, e) {
        return n + "-" + e.name
    }

    function Ut(n) {
        var e, t = JSON.stringify(a({
                ts: (new Date).getTime()
            }, n)),
            r = 0;
        if (0 === t.length) return r;
        for (e = 0; e < t.length; e++) r = (r << 5) - r + t.charCodeAt(e), r |= 0;
        return r
    }

    function Dt(n) {
        var e = Ut(n);
        return qt(e), S(function() {
            return new Function(n.code)(window)
        }, n.timeoutMillis, n.retries, function() {
            return void 0 === Jt(e)
        })
    }

    function Rt(n) {
        return JSON.parse(localStorage.getItem(n) || "[]")
    }
    var Mt = [],
        qt = function(n) {
            Mt.push(n)
        },
        Jt = function(n) {
            return Mt.find(function(e) {
                return e === n
            })
        };

    function Bt(n, t) {
        switch (I(function() {
            return n.trigger.type
        })) {
            case e.PageLoad:
                ! function(n, e) {
                    bt(n, e, function() {
                        return ct(n)
                    })
                }(n, t);
                break;
            case e.Timeout:
                ! function(n, e) {
                    var t, r = n.trigger.timeoutMillis;
                    bt(n, e, function() {
                        return t = setTimeout(function() {
                            ct(n)
                        }, r), _t(n)
                    }), qt(function() {
                        t && clearTimeout(t)
                    })
                }(n, t);
                break;
            case e.Inactivity:
                ! function(n, e) {
                    var t, r = n.trigger.timeoutMillis;

                    function i() {
                        clearTimeout(t), t = setTimeout(function() {
                            bt(n, e, function() {
                                try {
                                    return Promise.resolve(_t(n)).then(function(e) {
                                        return e && ct(n), e
                                    })
                                } catch (n) {
                                    return Promise.reject(n)
                                }
                            })
                        }, r)
                    }
                    i();
                    var o = ["mousemove", "keypress", "scroll", "touchstart", "touchmove"];
                    qt(function() {
                        clearTimeout(t), f(function() {
                            return document
                        }).then(function() {
                            return o.forEach(function(n) {
                                return document.removeEventListener(n, i)
                            })
                        })
                    }), l(function() {
                        return document
                    }, !0).then(function() {
                        o.forEach(function(n) {
                            return document.addEventListener(n, i, {
                                passive: !0
                            })
                        })
                    })
                }(n, t);
                break;
            case e.Selector:
                ! function(n, e) {
                    Nt(n), kt.add(e), Ot(n)()
                }(t, n);
                break;
            case e.ExitIntent:
                ! function(n, e) {
                    var t = function(r) {
                        I(function() {
                            return !r.toElement && !r.relatedTarget
                        }) && bt(n, e, function() {
                            var e = ct(n);
                            return f(function() {
                                return document
                            }).then(function() {
                                document.removeEventListener("mouseout", t)
                            }), e
                        })
                    };
                    l(function() {
                        return document
                    }, !0).then(function() {
                        document.addEventListener("mouseout", t, {
                            passive: !0
                        })
                    }), qt(function() {
                        f(function() {
                            return document
                        }).then(function() {
                            document.removeEventListener("mouseout", t)
                        })
                    })
                }(n, t);
                break;
            case e.JSCondition:
                ! function(n, e) {
                    Dt(n.trigger).then(function() {
                        bt(n, e, function() {
                            return ct(n)
                        })
                    }).catch(function() {})
                }(n, t);
                break;
            case e.JSFunction:
                ! function(n, e) {
                    ! function(t) {
                        try {
                            var r = new Function("return async function() { " + t.code + " }")()(),
                                i = Ut(t);
                            qt(i), r.then(function() {
                                return void 0 !== Jt(i) && void bt(n, e, function() {
                                    return ct(n)
                                })
                            })
                        } catch (n) {}
                    }(n.trigger)
                }(n, t);
                break;
            case e.JSEvent:
                ! function(n, e) {
                    var t = n.trigger,
                        r = "vsly-js-events";

                    function i(t) {
                        t && bt(n, e, function() {
                            return ct(n)
                        })
                    }
                    var o = function(n) {
                        var e;
                        try {
                            e = new Function(t.jsEvent.matchCode)(n), localStorage.setItem(r, JSON.stringify([].concat(Rt(r), [{
                                event: {
                                    detail: n.detail
                                },
                                ts: (new Date).valueOf() / 1e3
                            }]).splice(0, 25)))
                        } catch (n) {
                            q("handleJsEvent", n), e = !1
                        }
                        i(e)
                    };
                    i(function(n, e) {
                        return I(function() {
                            return !!Rt(n).find(function(n) {
                                var t = n.ts;
                                return (new Date).valueOf() / 1e3 - t < 2628e3 && new Function(e)(n.event)
                            })
                        })
                    }(r, t.jsEvent.matchCode)), l(function() {
                        return window
                    }).then(function() {
                        window.addEventListener(t.jsEvent.name, o)
                    }), qt(function() {
                        f().then(function() {
                            window.removeEventListener(t.jsEvent.name, o)
                        })
                    })
                }(n, t);
                break;
            case e.Conjunction:
                ! function(n, t) {
                    if (function(n) {
                            return [e.ExitIntent, e.Selector, e.Timeout].includes(n.trigger.condition.type)
                        }(n)) {
                        var r = n.trigger;
                        Dt(r.jsCond).then(function() {
                            Bt(a({}, n, {
                                trigger: r.condition
                            }), t)
                        }).catch(function() {})
                    }
                }(n, t);
                break;
            case e.ElementEvent:
                ! function(n, e) {
                    Nt(e), Ct.add(n), Ot(e)()
                }(n, t)
        }
    }
    var Vt = ["vsly-backdrop-container", "__loomi_crosshair_container"];

    function Ht(n) {
        for (var e = I(function() {
                return n.target
            }), t = !1; e;) {
            if (Vt.includes(I(function() {
                    return e.id
                }))) {
                t = !0;
                break
            }
            e = I(function() {
                return e.parentElement
            })
        }
        t && (M("vsly", "about to stop propagation of event", n), I(function() {
            return n.stopImmediatePropagation()
        }), I(function() {
            return n.stopPropagation()
        }))
    }

    function Ft(n, e) {
        var t = I(function() {
                return window.Shopify.currency.active
            }, "USD"),
            r = I(function() {
                return window.Shopify.locale
            }, "en-US"),
            i = I(function() {
                return window.Shopify.currency.rate
            }, "1"),
            o = new Intl.NumberFormat(r, {
                style: "currency",
                currency: t,
                minimumFractionDigits: !0 === I(function() {
                    return window.visually.flags["op-locale-currency-always-show-decimals"]
                }, !1) ? 2 : 0,
                maximumFractionDigits: 2
            });
        if (e) return o.format(n);
        var u = Number.parseFloat(i),
            c = n * (u = Number.isNaN(u) ? 1 : u);
        return 1 != u && Q("exchange-fee") && (c *= 1.02), c = Gt(u, c, t), o.format(c)
    }
    var Gt = function(n, e, t) {
        return 1 !== n && Q("exchange-round") || !Q("op-locale-currency-no-round") ? (I(function() {
            return window.visually.priceRound
        }) || Math.round)(e, t) : e
    };

    function Kt() {
        var n = I(function() {
                return !0 === window.visually.flags["kill-locale-currency"]
            }),
            e = I(function() {
                return window.Shopify.currency
            }, {}),
            t = !!I(function() {
                return e.active
            }),
            r = I(function() {
                return e.rate
            }),
            i = !!r && !Number.isNaN(Number.parseFloat(r));
        return !n && t && i
    }
    var Yt, Wt = window.location.href,
        zt = function() {
            requestAnimationFrame(function() {
                Wt !== window.location.href && (Wt = window.location.href, window.dispatchEvent(new CustomEvent("vslyUrlChanged", {
                    detail: {
                        prev: Wt,
                        curr: window.location.href
                    }
                })))
            })
        };
    ! function(n) {
        n.NONE = "none", n.YOTPO = "yotpo"
    }(Yt || (Yt = {}));
    var Qt = {
        isMember: !1,
        provider: Yt.NONE
    };

    function $t(n, e) {
        try {
            var t = n()
        } catch (n) {
            return e(n)
        }
        return t && t.then ? t.then(void 0, e) : t
    }
    var Xt, Zt, nr, er, tr = "vsly-loyalty-ctx",
        rr = (Zt = ["swell:customer:updated", "swell:redemption", "swell:initialized", "swell:setup", "vsly:loyalty-changed"], er = function(n) {
            I(function() {
                return "vsly:loyalty-changed" === n.type
            }) && I(function() {
                return window.swellAPI.refreshCustomerDetails()
            }), Xt(nr())
        }, {
            provide: nr = function() {
                var n = I(function() {
                    return window.swellConfig.customer
                });
                return n ? {
                    id: n.local_customer_id,
                    providerId: n.id,
                    email: n.email,
                    earnedPoints: n.points_earned,
                    isMember: !0 === n.is_member,
                    pointsBalance: n.points_balance,
                    adjustedPointsBalance: I(function() {
                        return n.adjusted_points_balance
                    }, 0),
                    provider: Yt.YOTPO
                } : Qt
            },
            onChange: function(n) {
                try {
                    Xt = n;
                    var e = $t(function() {
                        return Promise.resolve(S(function() {
                            return !!window.jQuery
                        }, 50, 200)).then(function() {
                            Zt.forEach(function(n) {
                                window.jQuery(document).on(n, er)
                            })
                        })
                    }, function() {
                        Zt.forEach(function(n) {
                            document.addEventListener(n, er)
                        })
                    });
                    return Promise.resolve(e && e.then ? e.then(function() {}) : void 0)
                } catch (n) {
                    return Promise.reject(n)
                }
            },
            connect: function() {
                return S(function() {
                    return !!I(function() {
                        return window.swellConfig.customer.local_customer_id
                    })
                }, 400, 20)
            },
            disconnect: function() {
                try {
                    var n = $t(function() {
                        return Promise.resolve(S(function() {
                            return !!window.jQuery
                        }, 50, 200)).then(function() {
                            Zt.forEach(function(n) {
                                window.jQuery(document).off(n, er)
                            })
                        })
                    }, function() {
                        Zt.forEach(function(n) {
                            document.removeEventListener(n, er)
                        })
                    });
                    return Promise.resolve(n && n.then ? n.then(function() {}) : void 0)
                } catch (n) {
                    return Promise.reject(n)
                }
            }
        });

    function ir(n) {
        Rn(Tn.LOYALTY_CHANGE, n), sessionStorage.setItem(tr, JSON.stringify({
            ts: (new Date).getTime(),
            ctx: n
        })), window.loomi_ctx = a({}, window.loomi_ctx || {}, {
            loyalty: n
        })
    }
    var or = "vsly_session";

    function ur(n) {
        return le((n || "").replace("+", " "))
    }

    function cr() {
        var n = K(window.loomi_ctx.storeAlias + window.loomi_ctx.userId + g() + ve()),
            e = fr();
        lr(e) && (n = e.payload.sid || n);
        var t = {
            id: n,
            utm_campaign: ve(),
            last_interaction: new Date,
            landing_page: I(function() {
                return location.href
            }, ""),
            start_at: new Date
        };
        return ar(t), t
    }

    function ar(n) {
        var e = JSON.stringify(n);
        localStorage.setItem(or, e), window.loomi_ctx.session = n
    }

    function sr() {
        var n = function() {
            window.loomi_ctx = window.loomi_ctx || {};
            var n = window.loomi_ctx.session || I(function() {
                var n = JSON.parse(localStorage.getItem(or));
                return n.last_interaction = new Date(n.last_interaction), n.start_at = new Date(n.start_at), n
            }) || cr();
            return function(n) {
                var e = new Date,
                    t = n.last_interaction;
                return (e.valueOf() - t.valueOf()) / 6e4 > 30 || ur(ve()) !== ur(n.utm_campaign) || n.last_interaction.getDate() !== e.getDate()
            }(n) && (n = cr()), window.loomi_ctx.session = n, n
        }();
        n.last_interaction = new Date, ar(n)
    }
    var fr = function(n) {
            return I(function() {
                return JSON.parse(decodeURIComponent(escape(atob(I(function() {
                    return new URLSearchParams(n || window.location.search)
                }).get(W)))))
            })
        },
        lr = function(n) {
            if (!n) return !1;
            var e = I(function() {
                return n.ts
            });
            return !e || (new Date).valueOf() - e < 36e5
        },
        dr = function(n, e) {
            try {
                return void 0 === n && (n = r.PROD), Promise.resolve(function(t, r) {
                    try {
                        var i = function(t, r) {
                            try {
                                var i = (function() {
                                    if (window.vsly_blocked) throw He(), new Error(Fe)
                                }(), function(n, e) {
                                    window.loomi_ctx = window.loomi_ctx || {}, window.loomi_ctx.env = window.loomi_ctx.env || n, window.loomi_ctx.storeAlias = window.loomi_ctx.storeAlias || e
                                }(n, e), Promise.resolve(vr(n, e)).then(function(t) {
                                    var r = t.jitsu,
                                        i = t.configuration;
                                    if (!I(function() {
                                            return i.flags["kill-switch"]
                                        }) && ! function(n) {
                                            try {
                                                if (I(function() {
                                                        return n.flags["redirect-asap"]
                                                    })) {
                                                    var e = n.experiments.find(function(n) {
                                                        return n.code.find(function(n) {
                                                            return "pageRedirect" === n.kind
                                                        })
                                                    });
                                                    if (e) {
                                                        var t = e.code.find(function(n) {
                                                            return "pageRedirect" === n.kind
                                                        });
                                                        if (t) {
                                                            var r = t.value;
                                                            return window.stop(), X(nn({
                                                                experienceId: e.name,
                                                                variantId: e.variant,
                                                                gaExperienceName: e.gaName,
                                                                gaVariantName: e.gaVariant,
                                                                publishedAt: e.publishedAt,
                                                                version: e.version
                                                            }), r.destUrl, 0, r.retainQueryParams, r.stickinessMode), !0
                                                        }
                                                    }
                                                }
                                            } catch (n) {}
                                            return !1
                                        }(i)) return Promise.resolve(function() {
                                        try {
                                            return Promise.resolve(S(function() {
                                                return !!document && !!document.body && !!document.querySelector
                                            }, 100, 100)).then(function() {
                                                ! function() {
                                                    if ("undefined" != typeof document) {
                                                        pn || (pn = new MutationObserver(Cn)), Cn();
                                                        var n = "spa" === I(function() {
                                                            return window.vslyIntegrationType
                                                        }, "static") ? document : document.body;
                                                        pn.observe(n, {
                                                            childList: !0,
                                                            subtree: !0,
                                                            characterData: !0,
                                                            attributes: !1
                                                        })
                                                    }
                                                }()
                                            })
                                        } catch (n) {
                                            return Promise.reject(n)
                                        }
                                    }()).then(function() {
                                        xe(i.experiments),
                                            function(n, e) {
                                                I(function() {
                                                    return e.experiments.forEach(function(e) {
                                                        Bt(e, n)
                                                    })
                                                })
                                            }(r, i),
                                            function(n, e, t) {
                                                var r = function(r) {
                                                    I(function() {
                                                        return !!r.persisted
                                                    }) && (Q("cache-nav-clear") && (window.loomi_ctx.cart = void 0), t(n, e, 500).catch(function(n) {
                                                        q("failed  reloading sdk", n)
                                                    }))
                                                };
                                                I(function() {
                                                    return !window.loomi_ctx.pageshow
                                                }) && (M("pageshow initialized"), l().then(function() {
                                                    window.addEventListener("pageshow", r), window.loomi_ctx.pageshow = !0
                                                }))
                                            }(n, e, mr), v() ? function() {
                                                try {
                                                    return Promise.resolve(S(function() {
                                                        return d
                                                    }, 1e3, 10)).then(function() {
                                                        return ie(), Promise.resolve()
                                                    })
                                                } catch (n) {
                                                    return Promise.reject(n)
                                                }
                                            }().catch(console.error) : ie()
                                    })
                                }))
                            } catch (n) {
                                return r(n)
                            }
                            return i && i.then ? i.then(void 0, r) : i
                        }(0, function(n) {
                            I(function() {
                                return n.message
                            }) !== Fe && q("failed initialising sdk", n)
                        })
                    } catch (n) {
                        return r(!0, n)
                    }
                    return i && i.then ? i.then(r.bind(null, !1), r.bind(null, !0)) : r(!1, i)
                }(0, function(n, e) {
                    if (He(), n) throw e;
                    return e
                }))
            } catch (n) {
                return Promise.reject(n)
            }
        },
        vr = function(n, e, t) {
            try {
                void 0 === n && (n = r.PROD), I(sr), I(function() {
                    var n = window.loomi_ctx.ctags || [];
                    0 === n.length ? window.loomi_ctx.ctags = JSON.parse(localStorage.getItem(y) || "[]") : localStorage.setItem(y, JSON.stringify(n)), I(function() {
                        var n = JSON.parse(localStorage.getItem("vslyCustomCtags") || "[]");
                        n && n.length > 0 && (window.loomi_ctx.ctags = [].concat(window.loomi_ctx.ctags || [], n))
                    })
                });
                var i = function(n, e, t) {
                    try {
                        var r = (u = function(n, e) {
                                var t = function(n, e) {
                                        var t = b(n),
                                            r = Ee(t);
                                        if (t) return {
                                            id: r.id,
                                            firstSeen: r.firstSeen || 0
                                        };
                                        var i = Ie(),
                                            o = i.newId,
                                            u = i.newEpoch;
                                        return h(n, i.value, Infinity, e, "http:" !== document.location.protocol), {
                                            id: o,
                                            firstSeen: u
                                        }
                                    }(n, e),
                                    r = t.id,
                                    i = t.firstSeen,
                                    o = function(n, e) {
                                        var t = window.localStorage.getItem(n),
                                            r = Ee(t);
                                        if (t) return {
                                            id: r.id,
                                            firstSeen: r.firstSeen || 1
                                        };
                                        var i = Ie(e),
                                            o = i.newId,
                                            u = i.newEpoch;
                                        return window.localStorage.setItem(n, i.value), {
                                            id: o,
                                            firstSeen: u
                                        }
                                    }(n, r),
                                    u = o.id,
                                    c = o.firstSeen;
                                return i <= c ? (function(n, e, t, r) {
                                    n != e && localStorage.setItem(t, be(e, r))
                                }(u, r, n, c), {
                                    id: r,
                                    firstSeen: i
                                }) : (function(n, e, t, r, i) {
                                    n != e && h(t, be(n, r), Infinity, i, "http:" !== document.location.protocol)
                                }(u, r, n, i, e), {
                                    id: u,
                                    firstSeen: c
                                })
                            }(Se, m()), c = u.firstSeen, {
                                id: u.id,
                                firstSession: (new Date).getTime() / 1e3 - c <= 7200,
                                firstSeen: c
                            }),
                            i = function(n, e, t) {
                                var r = function() {
                                    var n = ge(),
                                        e = {
                                            path: window.location.pathname,
                                            host: window.location.hostname
                                        };
                                    I(function() {
                                        return n.length
                                    }) > 0 && (e.cartItems = n);
                                    var t = I(function() {
                                        return Dn().token
                                    });
                                    t && (e.cartToken = t);
                                    var r = de();
                                    r && (e.trafficSources = r), e.productsSeenInSession = zn(), e.isCustomer = !!P(), e.query = window.location.search || "";
                                    var i = I(function() {
                                        return (("spa" == window.vslyIntegrationType ? I(function() {
                                            return Dn().attributes.map(function(n) {
                                                return n.key
                                            })
                                        }) : I(function() {
                                            return Object.keys(Dn().attributes)
                                        })) || []).filter(function(n) {
                                            return !n.startsWith("vsly") && n.length < 20
                                        }).slice(0, 15)
                                    });
                                    return i && (e.cartAttributes = i), e
                                }();
                                r.storeAlias = n;
                                var i = P();
                                i && (r.clientId = i), r.anonymousId = e.id, r.firstSeen = e.firstSeen, r.firstSession = e.firstSession, r.gaId = I(function() {
                                    return document.cookie.split(";").map(function(n) {
                                        return n.split("=")
                                    }).find(function(n) {
                                        return "_ga" == n[0].trim()
                                    })[1]
                                }, ""), r.customerTags = I(function() {
                                    return window.loomi_ctx.ctags.slice(0, 20)
                                }), r.landingPage = I(function() {
                                    return window.loomi_ctx.session.landing_page
                                }), r.hasSubs = !!I(function() {
                                    return Mn(Dn()).length > 0
                                });
                                var o, u = (o = "vsly_edgetag", A(function() {
                                    return oe() && localStorage.setItem(o, oe()), !0
                                }), I(oe) || localStorage.getItem(o));
                                u && (r.edgetag = u);
                                var c = function() {
                                        try {
                                            var n = I(function() {
                                                return new URL(window.location.href)
                                            });
                                            if (I(function() {
                                                    return n.searchParams.get("forceOverride")
                                                })) {
                                                var e = I(function() {
                                                    return n.searchParams.get("targeting")
                                                });
                                                if (e) return JSON.parse(atob(e))
                                            }
                                        } catch (n) {
                                            q("preview overrides", n)
                                        }
                                        return {}
                                    }(),
                                    s = Qn(ee),
                                    f = function() {
                                        var n = Qn(te);

                                        function e(n) {
                                            return new Date(n.ts).valueOf()
                                        }

                                        function t() {
                                            var n = new URL(location.href);
                                            return ["vslyvid", "vslywgid", "vslysid", "lmi_preview", "targeting", "vsly_vid"].forEach(function(e) {
                                                return n.searchParams.delete(e)
                                            }), n.search || ""
                                        }
                                        return me(te).then(function(r) {
                                            var i, o = {
                                                    ts: new Date,
                                                    name: _e(),
                                                    search: I(t, "")
                                                },
                                                u = !!o.search,
                                                c = (I(function() {
                                                    return r.visits
                                                }) || n || []).filter(function(n) {
                                                    return !u || !(n.name === o.name && !n.search)
                                                }).filter(function(n) {
                                                    return !(n.name === o.name && (o.search === n.search || u && !n.search))
                                                }).sort(function(n, t) {
                                                    return e(t) - e(n)
                                                }).slice(0, 500);
                                            c.unshift(o), (i = {
                                                id: te,
                                                visits: c
                                            }, Promise.resolve(he()).then(function(n) {
                                                return new Promise(function(e, t) {
                                                    var r = n.transaction([we], "readwrite").objectStore(we).put(i);
                                                    r.onerror = function(n) {
                                                        t("IDB e:w" + n.target.error)
                                                    }, r.onsuccess = function() {
                                                        e("")
                                                    }
                                                })
                                            })).catch()
                                        }).catch(), $n([{
                                            ts: g(),
                                            name: _e()
                                        }], n, function(n) {
                                            return function(e) {
                                                return n.name === e.name
                                            }
                                        }, te)
                                    }(),
                                    l = Xn(),
                                    d = a({
                                        deviceKind: I(function() {
                                            return window.loomi_ctx.deviceOverride
                                        }, void 0)
                                    }, t || {}),
                                    v = !!I(function() {
                                        return navigator.userAgent.includes("Macintosh") && "ontouchend" in document
                                    }),
                                    m = I(function() {
                                        return b("cart_currency")
                                    }) || I(function() {
                                        return Dn().currency
                                    }) || "";
                                return I(function() {
                                    return window.loomi_ctx.current_product
                                }) && (r.oos = I(function() {
                                    return window.loomi_ctx.current_product.oos
                                }), r.price = I(function() {
                                    return window.loomi_ctx.current_product.price
                                }), r.iq = I(function() {
                                    return window.loomi_ctx.current_product.variants.reduce(function(n, e) {
                                        return e.iq + n
                                    }, 0)
                                })), a({
                                    cartCurrency: m
                                }, r, {
                                    queryHistory: s,
                                    isIPadPro: v,
                                    visitedPages: f,
                                    purchasedLineItems: l
                                }, d || {}, c || {})
                            }(n, r, t);
                        return Promise.resolve(function(n, e) {
                            try {
                                var t = Ge(e),
                                    r = (a = We(n).cfgUrl, s = function() {
                                        [o, Pe].map(function(n) {
                                            var e = ke(n);
                                            e && sessionStorage.setItem(n, e)
                                        });
                                        var n = sessionStorage.getItem(o),
                                            e = sessionStorage.getItem(Pe);
                                        return {
                                            previewKey: n,
                                            debugAllocator: ke(Ae),
                                            previewVariantId: e
                                        }
                                    }(), f = s.previewKey, l = s.debugAllocator, d = s.previewVariantId, v = new URL(a), f && v.searchParams.append(o, f), l && v.searchParams.append(Ae, "true"), d && v.searchParams.append(Pe, d), v);
                                r.searchParams.append("q", t);
                                var i = K(r.href),
                                    u = window.vslyNativeFetch || window.fetch,
                                    c = Ke.has(i) ? Ke.get(i) : u(r.href).finally(function() {
                                        return Ke.delete(i)
                                    });
                                return Q("coalesce-alloc") && Ke.set(i, c), Promise.resolve(c).then(function(n) {
                                    if (n.ok) return Promise.resolve(n.json());
                                    throw new Error("failed to load config: " + n.statusText)
                                })
                            } catch (n) {
                                return Promise.reject(n)
                            }
                            var a, s, f, l, d, v
                        }(e, i)).then(function(n) {
                            return I(function() {
                                    window.loomi_ctx.audiences = n.audiences, I(function() {
                                        return n.audiences && localStorage.setItem("vsly_audiences", JSON.stringify(n.audiences))
                                    }), window.loomi_ctx.testedThemes = n.testedThemes || []
                                }),
                                function(n) {
                                    var e = n.currentVariant;
                                    window.loomi_ctx = a({}, window.loomi_ctx || {});
                                    var t = I(function() {
                                        return e.pid
                                    });
                                    t && (window.loomi_ctx.productId = "" + t);
                                    var r = I(function() {
                                        return e.vid
                                    });
                                    r && (window.loomi_ctx.variantId = "" + r);
                                    var i = I(function() {
                                        return e.price
                                    });
                                    i && (window.loomi_ctx.variantPrice = i);
                                    var o = I(function() {
                                        return e.meta
                                    });
                                    o && (window.loomi_ctx.productMeta = "" + o)
                                }(n), $n(n.queryHistory, i.queryHistory, function(n) {
                                    return function(e) {
                                        return e.v === n.v && e.k === n.k
                                    }
                                }, ee),
                                function(n) {
                                    var e;
                                    (e = n.experiments) && e.findIndex(function(n) {
                                        var e = I(function() {
                                            return n.clientTargetingFormula.toString()
                                        }, "") || "";
                                        return e.includes("CartItemHasTag") || e.includes("CartItemHasCollection") || e.includes("AllCartItemsHasTag")
                                    }) > -1 || !0 === I(function() {
                                        return n.flags["sdk-enable-cart-enrichment"]
                                    }, !1) && (n.flags["sdk-enable-cart-enrichment"] = !1)
                                }(n), {
                                    configuration: n,
                                    tracking: r
                                }
                        })
                    } catch (n) {
                        return Promise.reject(n)
                    }
                    var u, c
                }(e, n, t);
                return Promise.resolve(Promise.all([i])).then(function(t) {
                    var r, i = t[0],
                        o = i.configuration,
                        u = i.tracking;
                    return r = o.flags, window.visually = a({}, I(function() {
                            return window.visually
                        }) || {}, {
                            flags: r
                        }), localStorage.setItem("loomi-flags", JSON.stringify(r)),
                        function(n, e, t, r, i) {
                            St(), window.loomi_ctx = a({}, I(function() {
                                return window.loomi_ctx
                            }) || {}, {
                                env: e,
                                storeAlias: n,
                                apply: function(n) {
                                    xe([n]), ct(n)
                                }
                            });
                            var o = I(function() {
                                    return i.productId
                                }),
                                u = window.loomi_ctx;
                            o && !u.productId && (u.productId = o);
                            var c = I(function() {
                                return i.variantId
                            });
                            c && !u.variantId && (u.variantId = c), window.loomi = a({}, I(function() {
                                return window.loomi
                            }) || {}, {
                                conf: t
                            }), window.visually = a({}, I(function() {
                                return window.visually
                            }) || {}, {
                                flags: t.flags,
                                enabledIntegrations: t.integrations,
                                recsPerVariant: Xe(t),
                                sdk_api: {
                                    addToCart: Ne,
                                    recommendProducts: Le
                                },
                                reload: function() {
                                    try {
                                        return Promise.resolve(r(e, n, 1e3)).then(function() {})
                                    } catch (n) {
                                        return Promise.reject(n)
                                    }
                                }
                            })
                        }(e, n, o, mr, Oe()),
                        function(n) {
                            Promise.resolve(function() {
                                try {
                                    var e = function() {
                                        if (n.noActiveThemeTests) return Promise.resolve(wn(0)).then(function(n) {
                                            n || gn()
                                        });
                                        (function(n) {
                                            return !((n.experiments || []).find(function(n) {
                                                return n.isThemeTest
                                            }) || ![localStorage, sessionStorage].find(bn))
                                        })(n) && gn()
                                    }()
                                } catch (n) {
                                    return
                                }
                                return e && e.then ? e.then(void 0, function() {}) : e
                            }())
                        }(o), Promise.resolve(yr()).then(function() {
                            var t, r, i;
                            (function(n, e, t) {
                                window.loomi_api || (window.loomi_api = {}), window.loomi_api.when = E, window.loomi_api.awaitCondition = S, window.loomi_api.debounce = p, window.loomi_api.allocatorQuery = function(n) {
                                    return function(n, e) {
                                        try {
                                            var t = function() {
                                                    return Promise.resolve(r)
                                                },
                                                r = {
                                                    results: {}
                                                },
                                                i = a({}, n);
                                            i.queries = function(n, e) {
                                                return n.queries.filter(function(n) {
                                                    var t = I(function() {
                                                        return n.oneOf.productInfo
                                                    });
                                                    if (t) {
                                                        var r = qe(t.handle),
                                                            i = sessionStorage.getItem(r);
                                                        if (!i) return !0;
                                                        var o = JSON.parse(i);
                                                        return !! function(n, e) {
                                                            return !((!n.includeCollections || e.collections) && (!n.includeTags || e.tags) && (!n.includeSales || e.sales) && (!n.includeVariants || e.variants))
                                                        }(t, o) || (o.cached = !0, e.results[n.name] = o, !1)
                                                    }
                                                    var u = I(function() {
                                                        return n.oneOf.handlesByTag
                                                    });
                                                    if (u) {
                                                        var c = Je(u),
                                                            a = sessionStorage.getItem(c);
                                                        if (!a) return !0;
                                                        var s = JSON.parse(a);
                                                        return s.cached = !0, e.results[n.name] = s, !1
                                                    }
                                                    var f = I(function() {
                                                        return n.oneOf.handlesByCollection
                                                    });
                                                    if (f) {
                                                        var l = Be(f),
                                                            d = sessionStorage.getItem(l);
                                                        if (!d) return !0;
                                                        var v = JSON.parse(d);
                                                        return v.cached = !0, e.results[n.name] = v, !1
                                                    }
                                                    return !0
                                                })
                                            }(n, r);
                                            var o = function() {
                                                if (i.queries.length > 0) {
                                                    var n = function(n, e) {
                                                            n.timestamp = "" + Ve(4) + e + Ve(5), n.alias = window.loomi_ctx.storeAlias || "", n.userId = window.loomi_ctx.userId || "";
                                                            var t = JSON.stringify(n),
                                                                r = btoa(unescape(encodeURIComponent(t)));
                                                            return {
                                                                query: r,
                                                                hashedQuery: (r + window.loomi_ctx.userId + window.loomi_ctx.storeAlias + e).split("").reduce(function(n, e) {
                                                                    return (n = (n << 5) - n + e.charCodeAt(0)) & n
                                                                }, 0)
                                                            }
                                                        }(i, e),
                                                        t = n.query,
                                                        o = n.hashedQuery,
                                                        u = We(window.loomi_ctx.env).cfgUrl.replace("/allocate", "/query?q=" + t + "&h=" + o);
                                                    return Promise.resolve(fetch(u)).then(function(n) {
                                                        var e = function() {
                                                            if (n.ok) return Promise.resolve(n.json()).then(function(n) {
                                                                n.results && Object.entries(n.results).forEach(function(n) {
                                                                    var e = n[0],
                                                                        t = n[1];
                                                                    ! function(n, e, t) {
                                                                        if (e)
                                                                            if ("ProductInfo" === e.kind) {
                                                                                var r = t.queries.find(function(e) {
                                                                                    return e.name === n
                                                                                });
                                                                                r && (I(function() {
                                                                                    return r.oneOf.productInfo.includeTags
                                                                                }, !1) && !e.tags && (e.tags = []), I(function() {
                                                                                    return r.oneOf.productInfo.includeCollections
                                                                                }, !1) && !e.collections && (e.collections = []), I(function() {
                                                                                    return r.oneOf.productInfo.includeSales
                                                                                }, !1) && !e.sales && (e.sales = ""), I(function() {
                                                                                    return r.oneOf.productInfo.includeVariants
                                                                                }, !1) && !e.variants && (e.variants = []), sessionStorage.setItem(qe(e.handle), JSON.stringify(e)))
                                                                            } else if ("HandlesByCollection" === e.kind) {
                                                                            var i = t.queries.find(function(e) {
                                                                                return e.name === n
                                                                            });
                                                                            if (i) {
                                                                                var o = I(function() {
                                                                                    return i.oneOf.handlesByCollection
                                                                                }, "") || "";
                                                                                sessionStorage.setItem(Be(o), JSON.stringify(e))
                                                                            }
                                                                        } else if ("HandlesByTag" === e.kind) {
                                                                            var u = t.queries.find(function(e) {
                                                                                return e.name === n
                                                                            });
                                                                            if (u) {
                                                                                var c = I(function() {
                                                                                    return u.oneOf.handlesByTag
                                                                                }, "") || "";
                                                                                sessionStorage.setItem(Je(c), JSON.stringify(e))
                                                                            }
                                                                        }
                                                                    }(e, t, i), r.results[e] = t
                                                                })
                                                            })
                                                        }();
                                                        if (e && e.then) return e.then(function() {})
                                                    })
                                                }
                                            }();
                                            return Promise.resolve(o && o.then ? o.then(t) : t())
                                        } catch (n) {
                                            return Promise.reject(n)
                                        }
                                    }(n, "" + ((new Date).getTime() + Math.round(1e6 * Math.random())))
                                }, I(function() {
                                    return n.shopApi.forEach(function(n) {
                                        var e = n.js,
                                            t = n.windowKey;
                                        try {
                                            window.loomi_api[t] = new Function(e)
                                        } catch (n) {}
                                    })
                                }), window.loomi_api.formatLocaleMoney = function() {
                                    var n = [].slice.call(arguments);
                                    return t() ? e.apply(void 0, n) : (I(function() {
                                        return window.loomi_api.formatMoney
                                    }) || function() {
                                        return "" + I(function() {
                                            return n[0]
                                        }, "")
                                    }).apply(void 0, n)
                                }, window.loomi_api.redirectTest = X
                            })(o, Ft, Kt), r = o.first_seen, (t = o.uid) !== (i = u.id) && t && r > 0 ? (window.loomi_ctx.userId = t, function(n, e) {
                                    var t = be(n, e);
                                    localStorage.setItem(Se, t), h(Se, t, Infinity, m(), "http:" !== document.location.protocol)
                                }(t, r)) : window.loomi_ctx.userId = i, I(function() {
                                    return !0 === window.visually.flags["op-focus-trap-removal"]
                                }) && l(function() {
                                    return document
                                }, !0).then(function() {
                                    document.addEventListener("focusin", Ht, {
                                        capture: !0,
                                        passive: !0
                                    }), document.addEventListener("mousedown", Ht, {
                                        capture: !0,
                                        passive: !0
                                    }), document.addEventListener("touchstart", Ht, {
                                        capture: !0,
                                        passive: !0
                                    }), document.addEventListener("touchend", Ht, {
                                        capture: !0,
                                        passive: !0
                                    })
                                }),
                                function(n, e) {
                                    if (["/products/", "/collections/"].find(function(n) {
                                            return window.location.href.includes(n)
                                        }) && !I(function() {
                                            return window.visually.flags["kill-sdk-reload-url-detection"]
                                        })) var t = function() {
                                        var r = function() {
                                                requestAnimationFrame(function() {
                                                    (I(function() {
                                                        return window.visually.flags["sdk-reload-url-detection-href"]
                                                    }) ? wr !== window.location.href : new URL(wr).pathname !== new URL(window.location.href).pathname) && (wr = window.location.href, t(), pr(n, e, 10))
                                                })
                                            } || zt,
                                            i = ["click", "touchend", "pdpresp"];
                                        return l(function() {
                                                return document.body
                                            }, !0).then(function() {
                                                i.forEach(function(n) {
                                                    return document.body.addEventListener(n, r, !0)
                                                })
                                            }),
                                            function() {
                                                f(function() {
                                                    return document.body
                                                }).then(function() {
                                                    i.forEach(function(n) {
                                                        document.body.removeEventListener(n, r, !0)
                                                    })
                                                })
                                            }
                                    }()
                                }(n, e),
                                function() {
                                    try {
                                        return Promise.resolve(function(n, e) {
                                            try {
                                                var t = function() {
                                                    ir(function() {
                                                        var n = sessionStorage.getItem(tr);
                                                        if (n) {
                                                            var e = I(function() {
                                                                return JSON.parse(n)
                                                            });
                                                            if (e && e.ts > (new Date).getTime() - 3e5) return e.ctx
                                                        }
                                                    }() || Qt);
                                                    var n = I(function() {
                                                            return !0 === window.visually.flags["loyalty-targeting"]
                                                        }),
                                                        e = function() {
                                                            if (n) return Promise.resolve(function(n) {
                                                                try {
                                                                    return n.onChange(function(n) {
                                                                        ir(n)
                                                                    }), Promise.resolve(n.connect()).then(function() {
                                                                        var e = n.provide();
                                                                        return ir(e), {
                                                                            ctx: e,
                                                                            disconnect: n.disconnect
                                                                        }
                                                                    })
                                                                } catch (n) {
                                                                    return Promise.reject(n)
                                                                }
                                                            }(rr)).then(function() {
                                                                var n = document.querySelectorAll('[href*="/account/logout"]');
                                                                n && Array.from(n).forEach(function(n) {
                                                                    n.addEventListener("click", function() {
                                                                        return sessionStorage.removeItem(tr), !0
                                                                    })
                                                                })
                                                            })
                                                        }();
                                                    if (e && e.then) return e.then(function() {})
                                                }()
                                            } catch (n) {
                                                return e(n)
                                            }
                                            return t && t.then ? t.then(void 0, e) : t
                                        }(0, function(n) {
                                            console.debug("vsly-loyalty", "unable to find loyalty provider", n)
                                        }))
                                    } catch (n) {
                                        return Promise.reject(n)
                                    }
                                }();
                            var c = x();
                            return {
                                configuration: o,
                                jitsu: c
                            }
                        })
                })
            } catch (n) {
                return Promise.reject(n)
            }
        },
        mr = function(n, e, t) {
            void 0 === t && (t = 1e3);
            try {
                return !0 === I(function() {
                    return window.visually.flags["sdk-force-apply-after-revert"]
                }, !1) && hr ? (console.debug("vsly-sdk", "cannot reload since another reload is in progress"), Promise.resolve()) : (hr = !0, console.debug("vsly-sdk", "about to reload sdk"), Promise.resolve(function() {
                    try {
                        return ft && f(function() {
                            return document
                        }).then(function() {
                            document.removeEventListener(Y, gt), ft = !1
                        }), Mt.forEach(function(n) {
                            try {
                                "number" != typeof n && n()
                            } catch (n) {}
                        }), Mt = [], Array.from(L.keys()).forEach(function(n) {
                            Ln(n)
                        }), pn && pn.disconnect(), Promise.resolve()
                    } catch (n) {
                        return Promise.reject(n)
                    }
                }()).then(function() {
                    return Promise.resolve((r = t, void 0 === r && (r = 40), new Promise(function(n) {
                        return setTimeout(n, r)
                    }))).then(function() {
                        return Promise.resolve(dr(n, e)).then(function() {
                            hr = !1
                        })
                    });
                    var r
                }))
            } catch (n) {
                return Promise.reject(n)
            }
        },
        hr = !1,
        pr = p(mr, 10),
        wr = window.location.href,
        yr = function() {
            try {
                return Promise.resolve(function() {
                    if (Q("block-do-not-track")) return Promise.resolve(I(function() {
                        return window.Shopify.customerPrivacy.analyticsProcessingAllowed
                    }) || I(function() {
                        return window.Shopify.customerPrivacy.userCanBeTracked
                    }) || I(function() {
                        return window.visually.analyticsProcessingAllowed
                    })).then(function(n) {
                        if (!n) throw new Error(Fe)
                    })
                }())
            } catch (n) {
                return Promise.reject(n)
            }
        },
        gr = {
            initialize: dr
        };
    return function() {
        if (window.vslyIntegrationType = "static", "undefined" != typeof window && !window.vsly_init) {
            var n = function() {
                    var n = {
                        apiKey: "",
                        storeAlias: "",
                        env: 0,
                        shouldStart: !1
                    };
                    try {
                        if (window.location.search.includes("lmi_no_init=1")) return n;
                        if (I(function() {
                                return window.loomi_ctx.jitsuKey
                            })) {
                            var e = window.loomi_ctx,
                                t = e.jitsuKey,
                                r = e.storeAlias,
                                i = e.env;
                            return {
                                apiKey: t,
                                env: i,
                                storeAlias: r,
                                shouldStart: !!t && !!i && !!r
                            }
                        }
                        var o = function() {
                                for (var n, e = document.getElementsByTagName("script"), t = function(t) {
                                        var r = I(function() {
                                            return e[t]
                                        });
                                        if (["sdk.loomi-prod.xyz/", "live.visually-io.com/", "sdk.loomi-stg.xyz/"].some(function(n) {
                                                return I(function() {
                                                    return r.src.includes("https://" + n)
                                                })
                                            }) && r.src.includes("k=")) return n = r, 1
                                    }, r = 0; r < e.length && !t(r); r++);
                                return new URL(n.src)
                            }(),
                            u = o.searchParams.get("k"),
                            c = o.searchParams.get("s"),
                            a = parseInt(o.searchParams.get("e") || "");
                        return {
                            apiKey: u,
                            env: a,
                            storeAlias: c,
                            shouldStart: !!u && !!a && !!c
                        }
                    } catch (e) {
                        return n
                    }
                }(),
                e = n.env,
                t = n.storeAlias,
                r = n.shouldStart;
            r ? (window.vsly_init = !0, M("vsly start", {
                env: e,
                storeAlias: t,
                shouldStart: r
            }), dr(e, t).then(function() {})) : M("vsly abort", {
                env: e,
                storeAlias: t,
                shouldStart: r
            })
        }
    }(), n.default = gr, n.sdk = gr, n
}({});