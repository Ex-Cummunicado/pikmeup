var sdk = function(t) {
    var n, e, r;
    ! function(t) {
        t.JSCondition = "jsCondition", t.JSFunction = "jsFunction", t.JSEvent = "jsEvent", t.Selector = "selector", t.ElementEvent = "elementEvent", t.PageLoad = "pageLoad", t.Timeout = "timeout", t.Inactivity = "inactivity", t.ExitIntent = "exitIntent", t.Conjunction = "conjunction"
    }(n || (n = {})),
    function(t) {
        t[t.PAUSED = 4] = "PAUSED"
    }(e || (e = {})),
    function(t) {
        t[t.LOCAL = 0] = "LOCAL", t[t.STAGE = 1] = "STAGE", t[t.PROD = 2] = "PROD", t[t.TEST = 3] = "TEST"
    }(r || (r = {}));
    var i = "lmi_preview";

    function o(t, n) {
        (null == n || n > t.length) && (n = t.length);
        for (var e = 0, r = Array(n); e < n; e++) r[e] = t[e];
        return r
    }

    function a() {
        return a = Object.assign ? Object.assign.bind() : function(t) {
            for (var n = 1; n < arguments.length; n++) {
                var e = arguments[n];
                for (var r in e)({}).hasOwnProperty.call(e, r) && (t[r] = e[r])
            }
            return t
        }, a.apply(null, arguments)
    }

    function c(t, n) {
        void 0 === n && (n = 20);
        var e = 0;
        return function() {
            var r = arguments;
            clearTimeout(e), e = setTimeout(function() {
                return t.apply(void 0, [].slice.call(r))
            }, n)
        }
    }
    window.addEventListener("load", function() {
        setTimeout(function() {}, 2e3)
    });
    var u = "vsly-hide-theme-preview",
        s = function() {
            return new Date(1e3 * Math.floor(Date.now() / 1e3))
        };

    function l(t, n, e, r) {
        return void 0 === n && (n = 500), void 0 === e && (e = 4), new Promise(function(i, o) {
            t() ? i(0) : 0 !== e ? setTimeout(function() {
                r && r() && o("condition rejected " + d(function() {
                    return t.toString()
                })), l(t, n, e - 1).then(i).catch(o)
            }, n) : o("condition rejected " + d(function() {
                return t.toString()
            }))
        })
    }

    function f(t) {
        return d(function() {
            return t.toString()
        }, "")
    }

    function d(t, n) {
        void 0 === n && (n = void 0);
        try {
            return t()
        } catch (t) {
            return n
        }
    }

    function m(t, n, e) {
        void 0 === n && (n = 5), void 0 === e && (e = 500), n >= 0 && !d(t) && setTimeout(function() {
            d(t) || m(t, n - 1)
        }, e)
    }

    function p() {
        window.loomi_ctx = window.loomi_ctx || {}
    }

    function v(t) {
        window.loomi_ctx.tagIds = window.loomi_ctx.tagIds || new Set, t.forEach(function(t) {
            return window.loomi_ctx.tagIds.add(t)
        }), window.loomi_ctx.gtags = window.loomi_ctx.gtags || []
    }

    function h(t) {
        return t.replace(/[^a-z_A-Z0-9]/gi, "_")
    }
    var w, y = function() {
            return d(function() {
                return window.Shopify.customerPrivacy.analyticsProcessingAllowed
            }) || d(function() {
                return window.Shopify.customerPrivacy.userCanBeTracked
            }) || d(function() {
                return window.visually.analyticsProcessingAllowed
            })
        },
        g = {
            DEBUG: {
                name: "DEBUG",
                severity: 10
            },
            INFO: {
                name: "INFO",
                severity: 100
            },
            WARN: {
                name: "WARN",
                severity: 1e3
            },
            ERROR: {
                name: "ERROR",
                severity: 1e4
            },
            NONE: {
                name: "NONE",
                severity: 1e4
            }
        };

    function _() {
        return w || (t = d(function() {
            return window.location.search.includes("lmi_debug")
        }) ? g.WARN : g.NONE, n = {
            minLogLevel: t
        }, Object.values(g).forEach(function(e) {
            var r = e.name,
                i = e.severity;
            n[r.toLowerCase()] = function() {
                var n = [].slice.call(arguments);
                if (i >= t.severity && n.length > 0 && "NONE" != t.name) {
                    var e, o = n[0],
                        a = n.splice(1),
                        c = "[VSLY-" + r + "] " + o;
                    if ("DEBUG" === r || "INFO" === r)(e = console).log.apply(e, [c].concat(a));
                    else if ("WARN" === r) {
                        var u;
                        (u = console).warn.apply(u, [c].concat(a))
                    } else {
                        var s;
                        (s = console).error.apply(s, [c].concat(a))
                    }
                }
            }
        }), w = n);
        var t, n
    }

    function P() {
        try {
            return !!d(function() {
                return d(function() {
                    return new URL(window.location.href).searchParams.get(i)
                }) || sessionStorage.getItem(i)
            })
        } catch (t) {
            return _().error("failed getting lmi_preview for preview"), !1
        }
    }
    var E = "lmi_type",
        S = "lmi_from",
        k = "lmi_class";

    function x(t, n) {
        return t.includes(n, t.length - n.length)
    }

    function I(t, n, e, r) {
        void 0 === e && (e = 2e3), void 0 === r && (r = 5);
        var i = 0,
            o = 0,
            a = !1;
        return function() {
            var c, u, s, l = Date.now();
            l - i < e ? (o += 1) >= r && !a && (a = !0, void 0 === c && (c = "counter"), void 0 === u && (u = "sdk"), void 0 === s && (s = "inc"), fetch("https://logs.loomi-prod.xyz/af3a0f80-908b-4602-9c31-535a453d2b3a/collect/" + c + "/" + u + "/" + n + "/" + s, {
                method: "POST",
                body: JSON.stringify({
                    alias: window.loomi_ctx.storeAlias
                }),
                headers: {
                    "Content-Type": "application/json; charset=UTF-8"
                }
            })) : o = 0, i = l, !a && t().apply(void 0, [].slice.call(arguments))
        }
    }
    var A = "lmi_utm_data",
        N = {
            utm_source: "source",
            utm_medium: "medium",
            utm_campaign: "campaign",
            utm_term: "term",
            utm_content: "content"
        },
        C = function(t, n) {
            void 0 === n && (n = 3);
            for (var e = t, r = 0; r < n; r++) try {
                var i = decodeURIComponent(e);
                if (i === e) break;
                e = i
            } catch (t) {
                break
            }
            return e
        },
        T = function(t) {
            void 0 === t && (t = window.location.search);
            var n = {
                utm: {},
                lmi_params: {}
            };
            return d(function() {
                return new URLSearchParams(t)
            }).forEach(function(t, e) {
                if (t) {
                    var r = N[e],
                        i = C(t);
                    r ? n.utm[r] = i : function(t) {
                        return d(function() {
                            return [k, S, E].includes(t)
                        })
                    }(e) && (n.lmi_params[e] = i)
                }
            }), n
        };

    function O() {
        var t, n, e, r, i = (t = function(t) {
            if (function(t) {
                    return !t || "{}" === JSON.stringify(t)
                }(t)) return null;
            var n = {};
            return t.campaign && (n.campaign = t.campaign), t.medium && (n.medium = t.medium), t.source && (n.source = t.source), t.term && (n.term = t.term), t.content && (n.content = t.content), n
        }(d(function() {
            return T().utm
        })), n = [], null != (e = localStorage.getItem(A)) && (n = [].concat(JSON.parse(e)).slice(0, 20)), t && (t.ts = s(), n = [t].concat(n)), r = n, localStorage.setItem(A, JSON.stringify(r)), r);
        return d(function() {
            return i.filter(function(t) {
                return t.campaign
            }).reduce(function(t, n) {
                return n.ts > t.ts ? n : t
            }, i[0]).campaign
        }) || ""
    }
    var b = "vslyCT",
        R = "vslySUBS",
        j = "vslySID",
        L = "vslyUID",
        D = "vsly_session";

    function U(t) {
        return C((t || "").replace("+", " "))
    }

    function V() {
        var t = function(t, n) {
                void 0 === n && (n = 8397271938200529);
                for (var e, r = 3735928559 ^ n, i = 1103547991 ^ n, o = 0; o < t.length; o++) e = t.charCodeAt(o), r = Math.imul(r ^ e, 2654435761), i = Math.imul(i ^ e, 1597334677);
                return r = Math.imul(r ^ r >>> 16, 2246822507) ^ Math.imul(i ^ i >>> 13, 3266489909), "" + (4294967296 * (2097151 & (i = Math.imul(i ^ i >>> 16, 2246822507) ^ Math.imul(r ^ r >>> 13, 3266489909))) + (r >>> 0))
            }(window.loomi_ctx.storeAlias + window.loomi_ctx.userId + s() + O()),
            n = H();
        F(n) && (t = n.payload.sid || t);
        var e = {
            id: t,
            utm_campaign: O(),
            last_interaction: new Date,
            landing_page: d(function() {
                return location.href
            }, ""),
            start_at: new Date
        };
        return G(e), e
    }

    function G(t) {
        var n = JSON.stringify(t);
        localStorage.setItem(D, n), window.loomi_ctx.session = t
    }

    function M() {
        window.loomi_ctx = window.loomi_ctx || {};
        var t = window.loomi_ctx.session || d(function() {
            var t = JSON.parse(localStorage.getItem(D));
            return t.last_interaction = new Date(t.last_interaction), t.start_at = new Date(t.start_at), t
        }) || V();
        return function(t) {
            var n = new Date,
                e = t.last_interaction;
            return (n.valueOf() - e.valueOf()) / 6e4 > 30 || U(O()) !== U(t.utm_campaign) || t.last_interaction.getDate() !== n.getDate()
        }(t) && (t = V()), window.loomi_ctx.session = t, t
    }

    function q() {
        var t = M();
        t.last_interaction = new Date, G(t)
    }
    var J, H = function(t) {
            return d(function() {
                return JSON.parse(decodeURIComponent(escape(atob(d(function() {
                    return new URLSearchParams(t || window.location.search)
                }).get("vsly-redirected-event")))))
            })
        },
        F = function(t) {
            if (!t) return !1;
            var n = d(function() {
                return t.ts
            });
            return !n || (new Date).valueOf() - n < 36e5
        };

    function B(t, n) {
        if (!t && !n) return !0;
        if (!t && n) return !1;
        if (t && !n) return !1;
        var e = Object.keys(t).sort(function(t, n) {
                return t.localeCompare(n)
            }),
            r = Object.keys(n).sort(function(t, n) {
                return t.localeCompare(n)
            });
        if (e.length !== r.length) return !1;
        for (var i, a = function(t) {
                var n = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (n) return (n = n.call(t)).next.bind(n);
                if (Array.isArray(t) || (n = function(t, n) {
                        if (t) {
                            if ("string" == typeof t) return o(t, n);
                            var e = {}.toString.call(t).slice(8, -1);
                            return "Object" === e && t.constructor && (e = t.constructor.name), "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? o(t, n) : void 0
                        }
                    }(t))) {
                    n && (t = n);
                    var e = 0;
                    return function() {
                        return e >= t.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: t[e++]
                        }
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }(e); !(i = a()).done;) {
            var c = i.value,
                u = t[c],
                s = n[c],
                l = K(u) && K(s);
            if (l && !B(u, s) || !l && u !== s) return !1
        }
        return !0
    }

    function K(t) {
        return null != t && "object" == typeof t
    }

    function z(t) {
        return d(function() {
            return window.visually.flags[t]
        }, !1)
    }! function(t) {
        t.SIGNUP = "SIGNUP", t.ADD_TO_CART = "ADD_TO_CART", t.CHANGE_QTY = "CHANGE_QTY", t.REMOVE_FROM_CART = "REMOVE_FROM_CART", t.PAGE_LOAD = "PAGE_LOAD", t.CLICK = "CLICK", t.LOGIN = "LOGIN", t.LOGOUT = "LOGOUT", t.TIME_SPENT = "TIME_SPENT", t.USE_CASE = "USE_CASE"
    }(J || (J = {}));
    var W = new Map,
        Y = function() {
            return edgetag("getUserId")
        };

    function $(t) {
        var n = t.trim();
        return /^[a-zA-Z0-9_\- .:|/]+$/.test(n) || (n = n.replace(/[^a-zA-Z0-9_\- .:|/]/g, "")), n.slice(0, 250)
    }
    var X, Q, Z = [{
            name: "amplitude",
            track: function(t, n) {
                l(function() {
                    return !!d(function() {
                        return window.amplitude.track
                    })
                }, 100, 100).then(function() {
                    window.amplitude.track("Visually", {
                        vslyExpId: t.use_case,
                        vslyExpVarId: t.use_case_variant,
                        vslyExpName: n.gaName,
                        vslyExpVarName: n.gaVariant,
                        vslyVersion: t.version
                    })
                })
            }
        }, {
            name: "clarity",
            track: function(t, n) {
                l(function() {
                    return !!window.clarity
                }, 100, 100).then(function() {
                    window.clarity("event", "Visually_" + n.gaName + "_" + n.gaVariant + "_" + t.version)
                })
            }
        }, {
            name: "contentsquare",
            track: function(t, n) {
                window._uxa = window._uxa || [], window._uxa.push(["trackDynamicVariable", {
                    key: $(n.gaName),
                    value: $(n.gaVariant) + "(" + t.version + ")"
                }])
            }
        }, {
            name: "fullstory",
            track: function(t, n) {
                l(function() {
                    return !!window.FS
                }, 100, 100).then(function() {
                    window.FS("trackEvent", {
                        name: "Visually",
                        properties: {
                            vslyExpId: t.use_case,
                            vslyExpVarId: t.use_case_variant,
                            vslyExpName: n.gaName,
                            vslyExpVarName: n.gaVariant,
                            vslyVersion: t.version
                        }
                    })
                })
            }
        }, {
            name: "heatmap",
            track: function(t, n) {
                d(function() {
                    window.dataLayer = window.dataLayer || [], window.dataLayer.push({
                        _heatmap_split_test: {
                            platform: "visually",
                            experimentId: t.use_case,
                            experimentName: n.gaName,
                            variantId: t.use_case_variant,
                            variantName: n.gaVariant
                        }
                    })
                })
            }
        }, {
            name: "hotjar",
            track: function(t, n) {
                l(function() {
                    return !!window.hj
                }, 100, 100).then(function() {
                    window.hj("event", $("vsly_" + n.gaName + "_" + n.gaVariant + "_" + t.version))
                })
            }
        }, {
            name: "segment",
            track: function(t, n) {
                l(function() {
                    return !!d(function() {
                        return window.analytics.track
                    })
                }, 100, 100).then(function() {
                    window.analytics.track("Visually", {
                        vslyExpId: t.use_case,
                        vslyExpVarId: t.use_case_variant,
                        vslyExpName: n.gaName,
                        vslyExpVarName: n.gaVariant,
                        vslyVersion: t.version
                    })
                })
            }
        }, {
            name: "shopify",
            track: function(t, n) {
                l(function() {
                    return !!d(function() {
                        return window.Shopify.analytics.publish
                    })
                }, 100, 100).then(function() {
                    window.Shopify.analytics.publish("Visually-Experience", {
                        vslyExpId: t.use_case,
                        vslyExpVarId: t.use_case_variant,
                        vslyExpName: n.gaName,
                        vslyExpVarName: n.gaVariant,
                        vslyVersion: t.version
                    })
                })
            }
        }],
        tt = /*#__PURE__*/ function() {
            function t(t, n) {
                this.cookieDomain = void 0, this.cookieName = void 0, this.cookieDomain = t, this.cookieName = n
            }
            var n = t.prototype;
            return n.save = function(t) {
                var n, e, r, i;
                n = this.cookieName, e = encodeURIComponent(JSON.stringify(t)), r = this.cookieDomain, i = "http:" !== document.location.protocol, document.cookie = encodeURIComponent(n) + "=" + e + "; path=/; expires=Fri, 31 Dec 9999 23:59:59 GMT" + (r ? "; domain=" + r : "") + (i ? "; secure" : "")
            }, n.restore = function() {
                var t, n = (t = this.cookieName) && decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(t).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null;
                if (n) try {
                    var e = JSON.parse(decodeURIComponent(n));
                    if ("object" != typeof e) return;
                    return e
                } catch (t) {
                    return
                }
            }, n.delete = function() {}, t
        }(),
        nt = /*#__PURE__*/ function() {
            function t() {}
            var n = t.prototype;
            return n.save = function(t) {}, n.restore = function() {}, n.delete = function() {}, t
        }(),
        et = /*#__PURE__*/ function() {
            function t() {
                this.userIdPersistence = void 0, this.propsPersistance = void 0, this.anonymousId = "", this.userProperties = {}, this.permanentProperties = {
                    globalProps: {},
                    propsPerEvent: {}
                }, this.cookieDomain = "", this.trackingHost = "", this.idCookieName = "", this.apiKey = "", this.initialized = !1, this.initialOptions = void 0, this.cookiePolicy = "keep", this.ipPolicy = "keep", this.runningUseCases = new Set, this.getAnalyticsCtx = function() {
                    return {}
                }
            }
            var n = t.prototype;
            return n.id = function(t, n) {
                return this.userProperties = a({}, this.userProperties, t), this.userIdPersistence && this.userIdPersistence.save(t), n ? Promise.resolve() : this.track("user_identify", {})
            }, n.makeEvent = function(t, n, e) {
                var r;
                this.restoreId();
                var i, o = this.getCtx(),
                    c = (i = "vsly_edgetag", m(function() {
                        return Y() && localStorage.setItem(i, Y()), !0
                    }), d(Y) || localStorage.getItem(i));
                c && (o.edgetag = c);
                var u = a({}, this.permanentProperties.globalProps, null != (r = this.permanentProperties.propsPerEvent[t]) ? r : {}),
                    s = a({
                        api_key: this.apiKey,
                        src: n,
                        event_type: t
                    }, e);
                return o = function(t, n) {
                    try {
                        Object.keys(t).forEach(function(t) {
                            if (d(function() {
                                    return t.includes("_")
                                }) && t.toUpperCase() === t) {
                                var e = d(function() {
                                    return t.split("_").map(function(t) {
                                        return t.toLowerCase()
                                    })
                                }, [""]);
                                switch (e.length) {
                                    case 1:
                                        d(function() {
                                            return n[e[0]]
                                        }) && delete n[e[0]];
                                        break;
                                    case 2:
                                        d(function() {
                                            return n[e[0]][e[1]]
                                        }) && delete n[e[0]][e[1]];
                                        break;
                                    case 3:
                                        d(function() {
                                            return n[e[0]][e[1]][e[2]]
                                        }) && delete n[e[0]][e[1]][e[2]];
                                        break;
                                    case 4:
                                        d(function() {
                                            return n[e[0]][e[1]][e[2]][e[3]]
                                        }) && delete n[e[0]][e[1]][e[2]][e[3]]
                                }
                            }
                        })
                    } catch (e) {
                        _().error("vsly err code 666:" + f(n) + ":" + f(t))
                    }
                    return n
                }(e, o), a({}, u, o, s)
            }, n.sendJson = function(t) {
                return navigator.sendBeacon(this.trackingHost + "/api/s?token=" + this.apiKey + ("keep" !== this.cookiePolicy ? "&cookie_policy=" + this.cookiePolicy : "") + ("keep" !== this.ipPolicy ? "&ip_policy=" + this.ipPolicy : ""), new Blob([JSON.stringify(t)], {
                    type: "text/plain"
                })), Promise.resolve()
            }, n.getCtx = function() {
                var t, n, e = this,
                    r = d(function() {
                        return window.loomi_ctx.audiences
                    }),
                    i = new Date;
                return a({
                    event_id: "",
                    user: a({
                        anonymous_id: this.anonymousId
                    }, this.userProperties),
                    user_agent: navigator.userAgent,
                    utc_time: (t = i.toISOString(), n = t.split(".")[1], n ? n.length >= 7 ? t : t.slice(0, -1) + "0".repeat(7 - n.length) + "Z" : t),
                    local_tz_offset: i.getTimezoneOffset(),
                    url: window.location.href,
                    doc_path: document.location.pathname,
                    doc_host: document.location.hostname,
                    doc_search: window.location.search,
                    ids_ga: d(function() {
                        return document.cookie.split(";").map(function(t) {
                            return t.split("=")
                        }).find(function(t) {
                            return "_ga" == t[0].trim()
                        })[1]
                    }, ""),
                    alias: window.loomi_ctx.storeAlias
                }, r ? {
                    audiences: r.join("|")
                } : {}, {
                    sid: d(function() {
                        return window.loomi_ctx.session.id
                    }),
                    sid_start: d(function() {
                        return window.loomi_ctx.session.start_at.toISOString()
                    })
                }, d(function() {
                    return e.getAnalyticsCtx()
                }, {}), T())
            }, n.track = function(t, n, e) {
                try {
                    var r = this;
                    return Promise.resolve(l(function() {
                        return !!d(function() {
                            return !!window.loomi_ctx.storeAlias && window.loomi_ctx.session.id
                        })
                    }, 200)).then(function() {
                        return Promise.resolve(r.skipTracking()).then(function(i) {
                            if (i) return Promise.resolve();
                            if (t === J.USE_CASE) {
                                ! function(t) {
                                    z("kill-ga") || t.isAudience || (z("ga-use-store-data-layer") ? function(t) {
                                        try {
                                            var n = h(t.gaName),
                                                e = h(t.gaVariant),
                                                r = "DL-" + n + "-" + e;
                                            return W.has(r) || (W.set(r, !0), l(function() {
                                                return !!window.dataLayer
                                            }, 100, 10).then(function() {
                                                window.dataLayer.push({
                                                    event: "VISUALLY",
                                                    EXPERIENCE: n,
                                                    VARIANT: e,
                                                    non_interaction: !0
                                                })
                                            })), Promise.resolve()
                                        } catch (t) {
                                            return Promise.reject(t)
                                        }
                                    }(t).catch() : function(t) {
                                        try {
                                            return p(), v(function() {
                                                for (var t = document.getElementsByTagName("script"), n = [], e = 0; e < t.length; e++) try {
                                                    var r = t[e];
                                                    r.src.includes("www.googletagmanager.com/gtag/js") && n.push(new URL(r.src).searchParams.get("id"))
                                                } catch (t) {}
                                                return n
                                            }()), window.loomi_ctx.gtags = [].concat(window.loomi_ctx.gtags, [function(n) {
                                                var e = h(t.gaName),
                                                    r = h(t.gaVariant),
                                                    i = "" + n + e + r;
                                                if (!W.get(i)) {
                                                    var o = d(function() {
                                                        return window.gtag
                                                    });
                                                    !o && window.dataLayer && (o = function() {
                                                        window.dataLayer.push(arguments)
                                                    }), W.set(i, !0), d(function() {
                                                        o("event", "VISUALLY", {
                                                            EXPERIENCE: e,
                                                            VARIANT: r,
                                                            non_interaction: !0,
                                                            send_to: n
                                                        })
                                                    })
                                                }
                                            }]), d(function() {
                                                return "ANDIE_SWIM_1" === window.loomi_ctx.storeAlias
                                            }) && window.loomi_ctx.tagIds.add("G-D5DRR8JQ64"), window.loomi_ctx.tagIds.forEach(function(t) {
                                                window.loomi_ctx.gtags.forEach(function(n) {
                                                    return n(t)
                                                })
                                            }), Promise.resolve()
                                        } catch (t) {
                                            return Promise.reject(t)
                                        }
                                    }(t).catch())
                                }(e);
                                try {
                                    ! function(t, n) {
                                        z("kill-int-track") || n.isAudience || (X || (X = Z.filter(function(t) {
                                            return !!d(function() {
                                                return window.visually.enabledIntegrations.find(function(n) {
                                                    return n === t.name
                                                })
                                            })
                                        })), X.forEach(function(e) {
                                            e.track(t, n)
                                        }))
                                    }(n, e)
                                } catch (t) {}
                            }
                            return d(q), r.sendJson(r.makeEvent(t, "jitsu", n || {}))
                        })
                    })
                } catch (t) {
                    return Promise.reject(t)
                }
            }, n.skipTracking = function() {
                try {
                    var t, n = function(n) {
                            if (t) return n;
                            var i = d(function() {
                                return window.location.hostname
                            }, "");
                            if ("FOO" !== r && ("test" === e.apiKey || P() || "localhost" === i || "127.0.0.1" === i || i.endsWith("netlify.app") || "" != location.port)) return !0;
                            if ("UNDEROUTFIT" === r) {
                                var o = d(function() {
                                        return window.location.pathname.endsWith("the-comfort-shaping-bra-rp")
                                    }),
                                    a = d(function() {
                                        return "rp" === new URL(window.location.href).searchParams.get("utm_source")
                                    });
                                return o || a
                            }
                            return !1
                        },
                        e = this,
                        r = window.loomi_ctx.storeAlias;
                    if ("KARMA" === r) return Promise.resolve(!0);
                    var i = function() {
                        if (z("do-not-track") || z("block-do-not-track")) return Promise.resolve(l(function() {
                            return !!d(y)
                        })).then(function() {
                            var n = !y()();
                            return t = 1, n
                        })
                    }();
                    return Promise.resolve(i && i.then ? i.then(n) : n(i))
                } catch (t) {
                    return Promise.reject(t)
                }
            }, n.init = function(t) {
                if (this.ipPolicy = "keep", this.getAnalyticsCtx = t.analyticsContext, t.ip_policy && (this.ipPolicy = t.ip_policy), t.cookie_policy && (this.cookiePolicy = t.cookie_policy), "strict" === t.privacy_policy && (this.ipPolicy = "strict", this.cookiePolicy = "strict"), "comply" === this.cookiePolicy && (this.cookiePolicy = "strict"), this.initialOptions = t, t.key) {
                    if (this.cookieDomain = t.cookie_domain || document.location.hostname.replace("www.", ""), this.trackingHost = function(t) {
                            for (; x(t, "/");) t = t.substr(0, t.length - 1);
                            return 0 === t.indexOf("https://") || 0 === t.indexOf("http://") ? t : "//" + t
                        }(t.tracking_host || ""), this.idCookieName = t.cookie_name || "__eventn_id", this.apiKey = t.key, this.propsPersistance = "strict" === this.cookiePolicy ? new nt : new tt(this.cookieDomain, this.idCookieName + "_props"), this.userIdPersistence = "strict" === this.cookiePolicy ? new nt : new tt(this.cookieDomain, this.idCookieName + "_usr"), this.propsPersistance) {
                        var n, e, r = this.propsPersistance.restore();
                        r && (this.permanentProperties = r, this.permanentProperties.globalProps = null != (n = r.globalProps) ? n : {}, this.permanentProperties.propsPerEvent = null != (e = r.propsPerEvent) ? e : {}), _().debug("", this.permanentProperties)
                    }
                    "strict" !== this.cookiePolicy && (this.anonymousId = window.loomi_ctx.userId), this.initialized = !0
                }
            }, n.restoreId = function() {
                if (this.userIdPersistence) {
                    var t = this.userIdPersistence.restore();
                    t && (this.userProperties = a({}, t, this.userProperties))
                }
            }, n.set = function(t, n) {
                var e = d(function() {
                        return n.eventType
                    }),
                    r = d(function() {
                        return n.persist
                    });
                if (void 0 !== e) {
                    var i, o = null != (i = this.permanentProperties.propsPerEvent[e]) ? i : {};
                    this.permanentProperties.propsPerEvent[e] = a({}, o, t)
                } else this.permanentProperties.globalProps = a({}, this.permanentProperties.globalProps, t);
                this.propsPersistance && r && this.propsPersistance.save(this.permanentProperties)
            }, n.unset = function(t, n) {
                var e = d(function() {
                        return n.eventType
                    }),
                    r = d(function() {
                        return n.persist
                    });
                e ? this.permanentProperties.propsPerEvent[e] && delete this.permanentProperties.propsPerEvent[e][t] : delete this.permanentProperties.globalProps[t], this.propsPersistance && r && this.propsPersistance.save(this.permanentProperties)
            }, n.register = function(t, n, e, r) {
                this.runningUseCases.add({
                    name: t,
                    variant: n,
                    gaName: r,
                    gaVariant: e
                })
            }, n.getRunningUseCases = function() {
                return JSON.stringify(Array.from(this.runningUseCases))
            }, n.setAnalyticsContext = function(t) {
                this.getAnalyticsCtx = t
            }, t
        }();

    function rt(t) {
        var n = {
            trackingHost: "https://live.visually-io.com"
        };
        return t === r.TEST && (n.trackingHost = "http://localhost:8088"), t === r.STAGE && (n.trackingHost = "https://sdk.loomi-stg.xyz"), n
    }! function(t) {
        t.CART_CHANGE = "CART_CHANGE", t.LOYALTY_CHANGE = "LOYALTY_CHANGE"
    }(Q || (Q = {}));
    var it = c(function(t, n) {
        var e = function(t, n) {
            var e = new Event("targeting-changed");
            return e.key = t, e.value = n, e
        }(t, n);
        document.dispatchEvent(e), console.debug("Targeting has changed:", e)
    }, 80);

    function ot(t, n) {
        it(t, n)
    }

    function at() {
        var t;
        (window.location.search.includes("lmi_debug") || d(function() {
            return window.vsly_fbs
        })) && (t = console).error.apply(t, ["loomi-editor"].concat([].slice.call(arguments)))
    }

    function ct() {
        return l(function() {
            return d(function() {
                return !!window.loomi.jitsu
            })
        }, 100, 100)
    }

    function ut() {
        if (d(function() {
                return void 0 === window.loomi_ctx.cart
            })) {
            var t = localStorage.getItem(dt);
            if (t) try {
                window.loomi_ctx = a({}, window.loomi_ctx || {}, {
                    cart: JSON.parse(t)
                })
            } catch (n) {
                _().error("failed parsing cart", t)
            }
        }
        return d(function() {
            return window.loomi_ctx.cart
        })
    }
    var st = function(t, n, e, r, i, o) {
            if (gt(t)) {
                var a = d(function() {
                    return n.toUpperCase()
                });
                if ("POST" === a) {
                    if (At(e)) ct().then(function() {
                        return window.loomi.jitsu.track(J.ADD_TO_CART, St(r))
                    }), ht(i, e, !e.includes("update"));
                    else if (function(t) {
                            return t.match(/^\/cart\/change.*/) || t.match(/^\/cart\/update.*/) && !t.includes("vsly=t") || t.match(/cart\/(change|update)\.(js|json)$/)
                        }(e)) {
                        var c = St(r),
                            u = function(t) {
                                if (d(function() {
                                        return !t.qty
                                    }) || d(function() {
                                        return !t.variantId
                                    })) return null;
                                var n = d(function() {
                                    return ut().items.find(function(n) {
                                        return n.id == t.variantId || n.variant_id == t.variantId
                                    }).quantity
                                });
                                if (!n) return J.CHANGE_QTY;
                                var e = parseInt(t.qty);
                                return 0 === e ? J.REMOVE_FROM_CART : e === n ? null : e > n ? J.ADD_TO_CART : J.REMOVE_FROM_CART
                            }(c);
                        u && ct().then(function() {
                            return window.loomi.jitsu.track(u, c)
                        }), ht(i, e)
                    }
                } else "GET" !== a && a || function(t) {
                    return t.match(/^\/cart\.json.*|^\/cart\.js.*|^\/cart.*/) || t.match(/cart\.(js|json)$/)
                }(e) && i && _t(i) && vt(i)
            }
        },
        lt = c(function() {
            return document.body.dispatchEvent(new CustomEvent("pdpresp"))
        }, 500),
        ft = function(t, n, e) {
            var r = "/products/",
                i = ["/collections/", r];
            gt(t) && (e || "").includes(r) && d(function() {
                return !!i.find(function(t) {
                    return window.location.pathname.includes(t)
                })
            }) && !z("kill-pdp-intercept") && lt()
        },
        dt = "loomi-cart",
        mt = function(t) {
            (function(t, n) {
                var e = d(function() {
                    var t = n.attributes,
                        e = d(function() {
                            return window.loomi_ctx.userId
                        }),
                        r = d(function() {
                            return window.loomi_ctx.session.id
                        }, "");
                    return !(!e || !r || t[b] && t[L] === e && t[j] === r)
                }, !1);
                try {
                    return void 0 !== n && (!B(t, n) || e)
                } catch (t) {
                    return !0
                }
            })(ut(), t) && (!0 === d(function() {
                return window.visually.flags["sdk-enable-cart-enrichment"]
            }, !1) ? function(t) {
                try {
                    var n = function() {
                        return Promise.resolve(t)
                    };
                    if (d(function() {
                            return t.items.length <= 0
                        })) return Promise.resolve(t);
                    var e = function(n, e) {
                        try {
                            var r = (i = d(function() {
                                return Array.from(t.items.map(function(t) {
                                    return t.handle
                                }))
                            }, []).map(function(t) {
                                return {
                                    name: t,
                                    oneOf: {
                                        productInfo: {
                                            handle: t,
                                            includeCollections: !0,
                                            includeTags: !0
                                        }
                                    }
                                }
                            }), Promise.resolve(window.loomi_api.allocatorQuery({
                                queries: i
                            })).then(function(n) {
                                t.items = t.items.map(function(t) {
                                    return t.tags = d(function() {
                                        return n.results[t.handle].tags
                                    }, []), t.collections = d(function() {
                                        return n.results[t.handle].collections
                                    }, []), t
                                })
                            }))
                        } catch (t) {
                            return e(t)
                        }
                        var i;
                        return r && r.then ? r.then(void 0, e) : r
                    }(0, function(n) {
                        at("failed to enrich cart with error", n, t)
                    });
                    return Promise.resolve(e && e.then ? e.then(n) : n())
                } catch (t) {
                    return Promise.reject(t)
                }
            }(t).then(function(t) {
                yt(t), ot(Q.CART_CHANGE, d(function() {
                    return window.loomi_ctx.cart
                }))
            }) : (yt(t), ot(Q.CART_CHANGE, d(function() {
                return window.loomi_ctx.cart
            }))))
        },
        pt = c(mt, 400),
        vt = function(t) {
            !0 === d(function() {
                return window.visually.flags["sdk-enable-cart-change-debounce"]
            }, !1) ? pt(t) : mt(t)
        };

    function ht(t, n, e) {
        void 0 === e && (e = !0);
        var r = !z("disable-update-cart-refresh") || e;
        _t(t) && r && vt(t), d(function() {
            return !n.includes("vsly=t")
        }) && It()
    }
    var wt = "loomi-cart-history";

    function yt(t) {
        (function(t) {
            try {
                var n = function(t) {
                    return d(function() {
                        return t.items.map(function(t) {
                            return {
                                price: t.price,
                                variant_id: "" + t.variant_id,
                                product_id: "" + t.product_id,
                                quantity: t.quantity,
                                timestamp: Ct()
                            }
                        })
                    }, [])
                }(t);
                e = function(t) {
                    var n = ut(),
                        e = JSON.parse(localStorage.getItem(wt) || "[]"),
                        r = d(function() {
                            return e.map(function(t) {
                                return "" + t.variant_id
                            })
                        });
                    return d(function() {
                        return t.forEach(function(t) {
                            var i = r.indexOf("" + t.variant_id);
                            i < 0 ? e = [t].concat(e) : function(t, n) {
                                return d(function() {
                                    return t.items.find(function(t) {
                                        return "" + t.variant_id == "" + n.variant_id
                                    }).quantity < n.quantity
                                })
                            }(n, t) && (e[i] = a({}, t, {
                                timestamp: Ct()
                            }), e = e.sort(function(t, n) {
                                return Nt(n) - Nt(t)
                            }))
                        })
                    }), e
                }(n), localStorage.setItem(wt, JSON.stringify(e.slice(0, 25)))
            } catch (t) {
                _().error("handleCartItemsHistory", t)
            }
            var e
        })(t), localStorage.setItem(dt, JSON.stringify(t)), window.loomi_ctx = a({}, window.loomi_ctx || {}, {
            cart: t
        })
    }

    function gt(t) {
        var n = ".myshopify.com";
        return window.location.hostname == d(function() {
            return t.split(":")[0]
        }) || d(function() {
            return t.endsWith(n)
        }) || t === d(function() {
            return window.loomi_ctx.storeAlias.toLowerCase().replace("_", "-") + n
        })
    }

    function _t(t) {
        return d(function() {
            return void 0 !== t.items
        }) && d(function() {
            return void 0 !== t.total_price
        }) && d(function() {
            return void 0 !== t.token
        })
    }

    function Pt(t) {
        return d(function() {
            return decodeURIComponent(t).split("&").find(function(t) {
                return "id" === t.split("=")[0]
            }).split("=")[1].split(":")[0]
        }) || d(function() {
            return kt(t).id
        }) || d(function() {
            return t.get("id")
        })
    }

    function Et(t) {
        return isNaN(Number(t))
    }

    function St(t) {
        var n = {},
            e = function(t) {
                return d(function() {
                    return decodeURIComponent(t).split("&").find(function(t) {
                        return "quantity" === t.split("=")[0]
                    }).split("=")[1]
                }) || d(function() {
                    return kt(t).quantity.toString()
                })
            }(t),
            r = Pt(t);
        return r && !Et(r) || (r = "0"), Et(e) || (n.qty = e), Et(r) || (n.variantId = r), n
    }

    function kt(t) {
        try {
            return d(function() {
                return JSON.parse(t).items[0]
            })
        } catch (t) {
            return
        }
    }
    var xt = c(function() {
        return fetch("/cart.json?vsly=t")
    }, 500);

    function It() {
        d(function() {
            return "static" !== window.vslyIntegrationType
        }) || z("no-cart-refresh") || xt()
    }

    function At(t) {
        return t.match(/^\/cart\/add.*/) || t.match(/cart\/add\.(js|json)$/)
    }

    function Nt(t) {
        return new Date(t.timestamp).valueOf()
    }

    function Ct() {
        return s().toISOString()
    }

    function Tt() {
        var t = window.ShopifyAnalytics;
        if (!t) return {};
        try {
            var n = function(t) {
                    return d(function() {
                        return t.meta.product
                    })
                }(t),
                e = function(t, n) {
                    var e = d(function() {
                        return t.meta.selectedVariantId
                    }, "0");
                    return bt(e) && function(t, n) {
                            return d(function() {
                                return t.variants.find(function(t) {
                                    return t.id == n
                                })
                            })
                        }(n, e) || (e = function() {
                            try {
                                return new URL("http://" + window.location.pathname + window.location.search).searchParams.get("variant")
                            } catch (t) {
                                return _().info("vsly-e: 444"), ""
                            }
                        }()), bt(e) || (e = d(function() {
                            return n.variants[0].id
                        })),
                        function(t) {
                            var n = Number(t),
                                e = isNaN(n) ? Number(("" + t).replace(/[^\d.]+/g, "")) || void 0 : n;
                            if (void 0 !== e) return "" + e
                        }(e)
                }(t, n),
                r = {
                    cartId: Ot(t)
                };
            return function(t) {
                return d(function() {
                    return !!t.meta.page.pageType
                })
            }(t) && (r.page = {
                pageType: Rt(t)
            }), d(function() {
                return !!n.id
            }) && (r.product = {
                id: d(function() {
                    return n.id.toString()
                })
            }), e && (r.variant = {
                id: e
            }), r.themeId = d(function() {
                return "" + window.Shopify.theme.id
            }), void 0 !== window.__st && window.__st.cid && (r.clientId = (m(function() {
                var t = new Function(document.querySelector('script[id="__st"]').textContent + ";return __st.cid.toString()")();
                return t && window.localStorage.setItem("vsly__st", t), !0
            }), d(function() {
                return window.__st.cid.toString()
            }) || window.localStorage.getItem("vsly__st"))), r
        } catch (t) {
            return _().error("vsly-e 555", t), {}
        }
    }

    function Ot(t) {
        var n = d(function() {
                return t.lib.config.initialDocumentCookie
            }),
            e = /cart=(.*?);/.exec(n);
        return d(function() {
            return function(t) {
                if ("string" != typeof t) return t;
                var n = t.indexOf('\\"');
                return -1 === n ? t : t.slice(0, n)
            }(e[1])
        })
    }

    function bt(t) {
        return ("string" == typeof t || "number" == typeof t) && "" !== t && 0 !== t
    }

    function Rt(t) {
        return d(function() {
            return t.meta.page.pageType.toString()
        })
    }
    var jt = !1;

    function Lt(t) {
        try {
            var n = new URL(t);
            if (Ut(n.hostname)) {
                var e = n.searchParams.get("tid");
                e && (p(), v([]), window.loomi_ctx.tagIds.add(e), window.loomi_ctx.gtags && window.loomi_ctx.gtags.map(function(t) {
                    return t(e)
                }))
            }
        } catch (t) {}
    }

    function Dt(t, n, e, r, i, o) {
        "POST" === n && Ut(t) && (e.startsWith("/") && (e = "https://" + t + e), Lt(e))
    }

    function Ut(t) {
        return t.includes("analytics.google.com") || t.includes("google-analytics.com")
    }

    function Vt(t) {
        try {
            var n = t && "function" == typeof d(function() {
                    return t.indexOf
                }) && 0 == t.indexOf("/") ? window.location.origin + t : t,
                e = n.match(/^https?\:\/\/([^\/?#]+)(?:[\/?#]|$)/i),
                r = e && e[1] || "";
            return {
                domain: r,
                path: n.replace("https://", "").replace(r, "").replace("http://", "")
            }
        } catch (t) {
            return {
                domain: "",
                path: ""
            }
        }
    }

    function Gt(t, n, e) {
        try {
            if (gt(t) && At(n)) {
                var r = Pt(e);
                r && r != d(function() {
                    return window.loomi_ctx.last_vid_atc.vid
                }) && (document.dispatchEvent(new Event("VSLY_PRE_ATC")), window.loomi_ctx.last_vid_atc = {
                    vid: "" + r,
                    ts: +new Date
                })
            }
        } catch (t) {}
    }
    var Mt = [],
        qt = "loomi_session_products";

    function Jt(t) {
        localStorage.setItem(qt, JSON.stringify(t)), window.loomi_ctx = a({}, window.loomi_ctx || {}, {
            sessionProducts: t
        })
    }
    var Ht = HTMLFormElement.prototype.submit,
        Ft = (new Date).getTime(),
        Bt = !1,
        Kt = function() {
            return Bt ? Promise.resolve() : (console.log("vsly-loyalty", "Tracking signup"), Bt = !0, function() {
                try {
                    return Promise.resolve(l(function() {
                        return !!d(function() {
                            return window.loomi.jitsu
                        })
                    }, !0 === d(function() {
                        return window.vslyDeferResources
                    }) ? 1e3 : 500, 120)).then(function() {
                        return d(function() {
                            return window.loomi.jitsu
                        })
                    })
                } catch (t) {
                    return Promise.reject(t)
                }
            }().then(function() {
                return window.loomi.jitsu.track(J.SIGNUP, {
                    PAGE_LOAD_ID: "i" + Ft
                })
            }))
        };

    function zt(t, n, e, r, i, o) {
        "POST" === n && (gt(t) ? function(t) {
            return t.endsWith("/account")
        }(e) && Kt() : function(t) {
            var n = d(function() {
                return new URL(t)
            });
            return !!n && n.pathname.endsWith("api/public/v1/point_redemptions")
        }(e) && document.dispatchEvent(new CustomEvent("vsly:loyalty-changed")))
    }
    HTMLFormElement.prototype.submit = function() {
        var t = this;
        try {
            var n = this.getAttribute("action"),
                e = this.getAttribute("method");
            "/account" === n && "post" === e ? Kt().then(function() {
                Ht.call(t)
            }) : Ht.call(this)
        } catch (t) {
            Ht.call(this)
        }
    };
    var Wt = function(t, n, e, r) {
            try {
                var i = function(i, o) {
                    try {
                        var a = function() {
                            var i = new URLSearchParams;
                            i.append("attributes[" + b + "]", t), i.append("attributes[" + R + "]", "" + n), e && i.append("attributes[" + L + "]", "" + e), r && i.append("attributes[" + j + "]", "" + r);
                            var o = i.toString();
                            return Promise.resolve(fetch("/cart/update.js?vsly=t", {
                                credentials: "include",
                                headers: {
                                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                                },
                                body: o,
                                method: "POST",
                                mode: "cors"
                            })).then(function() {})
                        }()
                    } catch (t) {
                        return o(t)
                    }
                    return a && a.then ? a.then(void 0, o) : a
                }(0, function(t) {
                    at("vsly cart attr update err", t)
                });
                return Promise.resolve(i && i.then ? i.then(function() {}) : void 0)
            } catch (t) {
                return Promise.reject(t)
            }
        },
        Yt = I(function() {
            return window.visually.updateCartAttributes
        }, "cart_attr_loop");

    function $t(t) {
        if (!d(function() {
                return window.visually.flags["kill-cart-attr"]
            }) && t && !(d(function() {
                return t.token.length
            }, 0) <= 5)) {
            var n = function(t) {
                    var n = d(function() {
                            return window.loomi_ctx.session.id
                        }),
                        e = d(function() {
                            return window.loomi_ctx.userId
                        }),
                        r = b + "_" + t.token,
                        i = function(t) {
                            return d(function() {
                                return t.items.map(function(t) {
                                    return d(function() {
                                        return t.selling_plan_allocation.selling_plan.name.toLowerCase()
                                    })
                                }).filter(function(t) {
                                    return !!t
                                })
                            }, [])
                        }(t).length;
                    return {
                        sid: n,
                        uid: e,
                        vslyCartToken: r,
                        cartSubscriptions: i
                    }
                }(t),
                e = n.sid,
                r = n.uid,
                i = n.vslyCartToken,
                o = n.cartSubscriptions,
                a = d(function() {
                    return t.attributes[b] || ""
                }, ""),
                c = d(function() {
                    return t.attributes[R] || 0
                }, 0),
                u = d(function() {
                    return t.attributes[j] || ""
                }, ""),
                s = r !== d(function() {
                    return t.attributes[L] || ""
                }, "") && !!r,
                l = e !== u && !!e;
            ("" + o != "" + c || a != i && i || s || l) && (t.attributes = t.attributes || {}, t.attributes[b] = i, t.attributes[R] = "" + o, s && (t.attributes[L] = "" + r), l && (t.attributes[j] = "" + e), yt(t), Xt(i, o, r, e))
        }
    }
    c(function(t, n) {
        Yt(t, n)
    }, 1e3);
    var Xt = c(I(function() {
            return Wt
        }, "cart_attr_loop"), 1e3),
        Qt = c(I(function() {
            return tn
        }, "click_loop"), 500),
        Zt = I(function() {
            return nn
        }, "custom_loop", 5e3, 10),
        tn = function(t, n) {
            if (![t._USE_CASE, t._USE_CASE_VARIANT, n].every(en) || !Number.isInteger(t._USE_CASE_VERSION)) throw new Error("invalid args");
            window.loomi.jitsu.track(J.CLICK, {
                use_case: t._USE_CASE,
                use_case_variant: t._USE_CASE_VARIANT,
                version: t._USE_CASE_VERSION,
                clickId: n
            })
        },
        nn = function(t) {
            if (!Number.isInteger(t) || t < 1 || t > 3) throw new Error("invalid event");
            window.loomi.jitsu.track("CUSTOM_EVENT", {
                clickid: "custom_" + t
            })
        },
        en = function(t) {
            return "string" == typeof t && t.length < 40
        };

    function rn() {
        if ("undefined" != typeof window && !window.vsly_analytics_init) {
            var t = function() {
                    var t = {
                        apiKey: "",
                        storeAlias: "",
                        env: 0,
                        shouldStart: !1
                    };
                    try {
                        if (window.location.search.includes("lmi_no_init=1")) return t;
                        if (d(function() {
                                return window.loomi_ctx.jitsuKey
                            })) {
                            var n = window.loomi_ctx,
                                e = n.jitsuKey,
                                r = n.storeAlias,
                                i = n.env;
                            return {
                                apiKey: e,
                                env: i,
                                storeAlias: r,
                                shouldStart: !!e && !!i && !!r
                            }
                        }
                        var o = function() {
                                for (var t, n = document.getElementsByTagName("script"), e = function(e) {
                                        var r = d(function() {
                                            return n[e]
                                        });
                                        if (["sdk.loomi-prod.xyz/", "live.visually-io.com/", "sdk.loomi-stg.xyz/"].some(function(t) {
                                                return d(function() {
                                                    return r.src.includes("https://" + t)
                                                })
                                            }) && r.src.includes("k=")) return t = r, 1
                                    }, r = 0; r < n.length && !e(r); r++);
                                return new URL(t.src)
                            }(),
                            a = o.searchParams.get("k"),
                            c = o.searchParams.get("s"),
                            u = parseInt(o.searchParams.get("e") || "");
                        return {
                            apiKey: a,
                            env: u,
                            storeAlias: c,
                            shouldStart: !!a && !!u && !!c
                        }
                    } catch (n) {
                        return t
                    }
                }(),
                n = t.apiKey,
                e = t.env,
                i = t.storeAlias;
            t.shouldStart && (window.vsly_analytics_init = !0, function(t, n, e) {
                try {
                    return void 0 === e && (e = r.PROD), Promise.resolve(function(i, o) {
                        try {
                            var c = (function() {
                                try {
                                    fetch("https://cdn.shopify.com/s/javascripts/currencies.js").then(function(t) {
                                        return t.text()
                                    }).then(function(t) {
                                        return new Function(t + ";return Currency")()
                                    }).then(function(t) {
                                        window.loomi_ctx = a({}, d(function() {
                                            return window.loomi_ctx
                                        }) || {}, {
                                            Currency: t
                                        })
                                    }).catch(function(t) {
                                        return console.error("fail currencies js", t)
                                    })
                                } catch (t) {}
                            }(), function(t, n, e) {
                                p(), window.loomi_ctx.env = window.loomi_ctx.env || t, window.loomi_ctx.storeAlias = window.loomi_ctx.storeAlias || n, e && (window.loomi_ctx.jitsuKey = window.loomi_ctx.jitsuKey || e)
                            }(e, n, t), function() {
                                try {
                                    var t = arguments;
                                    return z("kill-proxy") || (function() {
                                        if (!z("kill-beacon-intercept") && !jt) {
                                            var t = navigator.sendBeacon;
                                            navigator.sendBeacon = function(n, e) {
                                                return Lt(n), t.call(this, n, e)
                                            }, jt = !0
                                        }
                                    }(), [].slice.call(t).forEach(function(t) {
                                        (function(t) {
                                            try {
                                                return Promise.resolve(l(function() {
                                                    return !!window.XMLHttpRequest
                                                })).then(function() {
                                                    if (window.XMLHttpRequest) {
                                                        var n = window.XMLHttpRequest.prototype.send;
                                                        window.XMLHttpRequest.prototype.send = function() {
                                                            return this.reqBody = arguments[0], Gt(this.reqDomain, this.reqPath, this.reqBody), n.apply(this, arguments)
                                                        };
                                                        var e = XMLHttpRequest.prototype.open;
                                                        window.XMLHttpRequest.prototype.open = function() {
                                                            var n = arguments,
                                                                r = this,
                                                                i = Vt(arguments[1]),
                                                                o = i.domain,
                                                                a = i.path;
                                                            this.reqDomain = o, this.reqPath = a, e.apply(this, arguments);
                                                            try {
                                                                var c = d(function() {
                                                                        return n[0]
                                                                    }),
                                                                    u = d(function() {
                                                                        return n[1]
                                                                    });
                                                                this.requestDetails = {
                                                                    method: c,
                                                                    url: u,
                                                                    domain: o,
                                                                    path: a
                                                                }, d(function() {
                                                                    return r.addEventListener("load", function() {
                                                                        var n = this,
                                                                            e = this.requestDetails,
                                                                            r = e.method,
                                                                            i = e.domain,
                                                                            o = e.path,
                                                                            a = d(function() {
                                                                                return JSON.parse(n.responseText)
                                                                            }, {});
                                                                        t(i, r || "GET", o, this.reqBody, a, "xhr")
                                                                    })
                                                                })
                                                            } catch (t) {}
                                                        }
                                                    }
                                                })
                                            } catch (t) {
                                                return Promise.reject(t)
                                            }
                                        })(t).catch(),
                                            function(t) {
                                                try {
                                                    return Promise.resolve(l(function() {
                                                        return !!window.fetch
                                                    })).then(function() {
                                                        if (window.fetch) {
                                                            var n = window.fetch;
                                                            window.fetch = function() {
                                                                var e = arguments,
                                                                    r = arguments[0],
                                                                    i = d(function() {
                                                                        return e[1]
                                                                    }) || {},
                                                                    o = Vt(r),
                                                                    a = o.domain,
                                                                    c = o.path,
                                                                    u = d(function() {
                                                                        return i.body
                                                                    }),
                                                                    s = d(function() {
                                                                        return JSON.parse(u)
                                                                    }, u);
                                                                return Gt(a, c, s), n.call(this, r, i).then(function(n) {
                                                                    try {
                                                                        if ("string" != typeof r) return n;
                                                                        n.clone().text().then(function(n) {
                                                                            var e = d(function() {
                                                                                return JSON.parse(n)
                                                                            }, n);
                                                                            t(a, d(function() {
                                                                                return i.method
                                                                            }, "GET"), c, s, e, "fetch")
                                                                        }).catch()
                                                                    } catch (t) {}
                                                                    return n
                                                                })
                                                            }
                                                        }
                                                    })
                                                } catch (t) {
                                                    return Promise.reject(t)
                                                }
                                            }(t).catch()
                                    })), Promise.resolve()
                                } catch (t) {
                                    return Promise.reject(t)
                                }
                            }(st, zt, ft, Dt).then(), Promise.resolve(function() {
                                try {
                                    return Promise.resolve(l(function() {
                                        return !!d(function() {
                                            return !!window.loomi_ctx.userId
                                        })
                                    }, 500, 101)).then(function() {})
                                } catch (t) {
                                    return Promise.reject(t)
                                }
                            }()).then(function() {
                                function n() {
                                    var n = Tt(),
                                        i = function(t, n) {
                                            return function(t, n) {
                                                return e = {
                                                    key: t,
                                                    tracking_host: rt(n).trackingHost,
                                                    analyticsContext: function() {
                                                        return a({}, Tt(), {
                                                            userCanBeTracked: d(function() {
                                                                return window.Shopify.customerPrivacy.analyticsProcessingAllowed()
                                                            }, !1),
                                                            userDataCanBeSold: d(function() {
                                                                return window.Shopify.customerPrivacy.userCanBeTracked()
                                                            }, !1)
                                                        })
                                                    }
                                                }, (r = new et).init(e), r;
                                                var e, r
                                            }(t, n)
                                        }(t, e);
                                    return function(t) {
                                            d(M), window.loomi = a({}, window.loomi || {}, {
                                                jitsu: t,
                                                reportAnalyticsErr: function() {},
                                                reportSdkErr: function() {}
                                            })
                                        }(i), P() && function() {
                                            d(function() {
                                                try {
                                                    return Promise.resolve(l(function() {
                                                        return !!document && !!document.head
                                                    }, 10, 2e3)).then(function() {
                                                        var t = document.head || document.getElementsByTagName("head")[0];
                                                        if (!t.querySelector("#" + u)) {
                                                            var n = document.createElement("style");
                                                            n.id = u, n.appendChild(document.createTextNode("#preview-bar-iframe,#PBarNextFrameWrapper,#PBarNextFrame { display: none !important;}")), t.appendChild(n)
                                                        }
                                                    })
                                                } catch (t) {
                                                    return Promise.reject(t)
                                                }
                                            });
                                            var t = document.createElement("script");
                                            t.type = "text/javascript";
                                            var n, e = (void 0 === n && (n = window.loomi_ctx.env), n === r.STAGE ? "sdk.loomi-stg.xyz" : "live.visually-io.com");
                                            t.src = "https://" + e + "/preview-widget.js";
                                            var i = document.getElementsByTagName("script")[0];
                                            d(function() {
                                                return i.parentNode.insertBefore(t, i)
                                            })
                                        }(),
                                        function(t) {
                                            Mt.forEach(clearTimeout), Mt = [], [{
                                                s: 11,
                                                e: 30
                                            }, {
                                                s: 31,
                                                e: 60
                                            }, {
                                                s: 61,
                                                e: 180
                                            }, {
                                                s: 181,
                                                e: 600
                                            }, {
                                                s: 601,
                                                e: 1800
                                            }, {
                                                s: 1800,
                                                e: 1e4
                                            }].forEach(function(n) {
                                                Mt.push(setTimeout(function() {
                                                    t.track(J.TIME_SPENT, n)
                                                }, 1e3 * n.s))
                                            })
                                        }(i),
                                        function(t) {
                                            var n = d(function() {
                                                    return t.product
                                                }),
                                                e = d(function() {
                                                    return t.variant
                                                });
                                            if (e || n) {
                                                var r = localStorage.getItem(qt),
                                                    i = function(t, n) {
                                                        return {
                                                            productId: parseInt(d(function() {
                                                                return t.id
                                                            }) || "0"),
                                                            variantId: parseInt(d(function() {
                                                                return n.id
                                                            }) || "0"),
                                                            ts: s(),
                                                            handle: d(function() {
                                                                return window.location.pathname.split("products/")[1]
                                                            }) || ""
                                                        }
                                                    }(n, e);
                                                if (r) {
                                                    var o = JSON.parse(r);
                                                    (o = o.filter(function(t) {
                                                        return !((n = t).variantId == (e = i).variantId && n.productId == e.productId);
                                                        var n, e
                                                    })).push(i), o.length > 20 && o.shift(), Jt(o)
                                                } else Jt([i])
                                            }
                                        }(n), location.pathname.includes("/account/") && l(function() {
                                            return !!document.querySelector('form[action="/account"][method="post"]')
                                        }, 1e3, 10).then(function() {
                                            var t = document.querySelector('form[action="/account"][method="post"]');
                                            console.debug("vsly-loyalty", "Capturing account form submit", t), t && t.addEventListener("submit", function(n) {
                                                try {
                                                    var e = function() {
                                                            t.submit()
                                                        },
                                                        r = function(t, e) {
                                                            try {
                                                                var r = (n.preventDefault(), Promise.resolve(Kt()).then(function() {}))
                                                            } catch (t) {
                                                                return e(t)
                                                            }
                                                            return r && r.then ? r.then(void 0, e) : r
                                                        }(0, function(t) {
                                                            console.error("vsly-loyalty", "Error tracking signup", t)
                                                        });
                                                    return Promise.resolve(r && r.then ? r.then(e) : e())
                                                } catch (t) {
                                                    return Promise.reject(t)
                                                }
                                            })
                                        }).catch(function() {}), Promise.resolve(i.track(J.PAGE_LOAD)).then(function() {
                                            var t;
                                            ! function(t, n) {
                                                try {
                                                    var e = H(n);
                                                    if (F(e)) {
                                                        d(function() {
                                                            return delete e.payload.now
                                                        });
                                                        var r = d(function() {
                                                            return window.loomi_ctx.session.id
                                                        });
                                                        r && (e.payload.sid = r), t.track(e.type, e.payload, e.options)
                                                    }
                                                } catch (t) {
                                                    console.error("vsly-sdk-redirection", "Failed to track redirection event", t)
                                                }
                                            }(i, location.search), It(), window.loomi_ctx.maintainCartAttributes = $t, t = function() {
                                                    return $t(ut())
                                                }, l(function() {
                                                    return !!ut()
                                                }, 500, 10).then(t), window.loomi_api = window.loomi_api || {}, window.loomi_api.trackClick = Qt, window.loomi_api.trackCustomEvent = Zt,
                                                function(t) {
                                                    try {
                                                        return Promise.resolve(l(function() {
                                                            return !!document.body
                                                        })).then(function() {
                                                            d(function() {
                                                                t || (t = d(function() {
                                                                    return window.loomi.conf.custom_goals
                                                                }) || []);
                                                                var n = function() {
                                                                    return window.loomi.custom_goals
                                                                };
                                                                t.forEach(function(t) {
                                                                    n() || (window.loomi.custom_goals = new Set), n().has(t.id) || (d(function() {
                                                                        return new Function(t.code)()
                                                                    }), n().add(t.id))
                                                                })
                                                            })
                                                        })
                                                    } catch (t) {
                                                        return Promise.reject(t)
                                                    }
                                                }()
                                        })
                                }
                                if (!z("kill-switch") && !z("kill-tracking")) {
                                    var i = function() {
                                        if (!d(function() {
                                                return window.vslyNotShopify
                                            })) return Promise.resolve(function(t, n) {
                                            void 0 === t && (t = 100), void 0 === n && (n = 100);
                                            try {
                                                return Promise.resolve(l(function() {
                                                    return void 0 !== window.ShopifyAnalytics
                                                }, t, n)).then(function() {
                                                    return "ok"
                                                })
                                            } catch (t) {
                                                return Promise.reject(t)
                                            }
                                        }(100, 100)).then(function() {})
                                    }();
                                    return i && i.then ? i.then(n) : n()
                                }
                            }))
                        } catch (t) {
                            return o(t)
                        }
                        return c && c.then ? c.then(void 0, o) : c
                    }(0, function(t) {
                        _().error("vsly", "init failed", t)
                    }))
                } catch (t) {
                    return Promise.reject(t)
                }
            }(n, i, e))
        }
    }
    return rn(), t.bootstrap = rn, t
}({});